#include "main.h"

namespace file
{
	int readOneFile(const char* filePath, void** readBuffer)
	{
		HANDLE f;
		DWORD realReadBytesNum;
		int readBytesNum;
		std::cout << filePath << std::endl;
		f = CreateFileA(filePath, GENERIC_READ, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

		if (f == INVALID_HANDLE_VALUE)
			return 0;

		readBytesNum = GetFileSize(f, NULL);

		if (!ReadFile(f, *readBuffer, readBytesNum, &realReadBytesNum, NULL))
			return 0;

		CloseHandle(f);

		return readBytesNum;
	}

	int readDirAllFile(const char* dirPath)
	{
		return 0;
	}

	int OutPutToFile(const char* FilePath, char* writebuffer)
	{
		HANDLE f;
		DWORD RealWriteBytesNum = 0;
		int WriteBytesNum;

		f = CreateFileA(FilePath, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

		if (f == INVALID_HANDLE_VALUE)
		{
			return 0;
		}

		SetFilePointer(f, NULL, NULL, FILE_END);

		if (!WriteFile(f, writebuffer, strlen(writebuffer), &RealWriteBytesNum, NULL))
			return 0;

		FlushFileBuffers(f);

		CloseHandle(f);

		return RealWriteBytesNum;
	}
}