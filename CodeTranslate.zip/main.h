#pragma once

#include <iostream>
#include <string.h>
#include <Windows.h>
#include <vector>
#include <time.h> 
#include <stdio.h>

#include "file.h"
#include "func.h"
#include "Real.h"

/*return 0 == fail*/