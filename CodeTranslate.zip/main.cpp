#include "main.h"

void** func::pSourceCode = new void*;

int main(int argc,char* argv[])
{
	//�˴�������������ΪӲ���룬������Ҫ��̬�����������ļ�·������ΪASCII
	char fileBytes[1000];
	char fileNamePath[100];
	char tempFileNo[10];
	char collectBuffer[1000];
	int tempIndex = 0;
	int tempLBraceNum = 0;
	int tempRBraceNum = 0;
	char InterMediateFilePath[100];
	//char temp[1000] = "size_t i, destLen;\nchar dest[100];\nmemset(dest, 'C', 100-1);\ndata = GetWindowText(a,b);\n";
	char tempNSTBuffer[20] = { 0 };
	char tempNSTBuffer1[3] = "\n";
	int64_t tempNSTime1 = 0;
	int64_t tempNSTime2 = 0;

	func::Mod = -1;
	tempNSTime1 = func::GetSysTimeMicros();

	*func::pSourceCode = malloc(500000);                       //Ӳ����
	memset(*func::pSourceCode, 0, 500000);
	memset(InterMediateFilePath, 0x0, 100);
	memset(fileNamePath, 0x0, 100);
	memset(func::OutputFilePath, 0x0, 100);
#ifdef _DEBUG
	strcpy(InterMediateFilePath, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\1.txt");
	//strcpy(InterMediateFilePath, "LIKED");
	strcpy(fileNamePath, "E:\\shiyan\\zms_old\\data\\dataset\\Vul2Image\\second\\Code\\second\\CWE190_Integer_Overflow\\02.c");
	strcpy(func::OutputFilePath, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\2.txt");
	strcpy(func::OutputFilePath2, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\3.txt");
	strcpy(func::OutputFilePath3, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\12.txt");
	strcpy(func::OutputFilePath4, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\19.txt");
	strcpy(func::OutputFilePath5, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\6.txt");
	strcpy(func::OutputFilePath6, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\7.txt");
	strcpy(func::OutputFilePath7, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\8.txt");
	strcpy(func::OutputFilePath8, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\9.txt");
	strcpy(func::OutputFilePath9, "E:\\shiyan\zms_old\\data\\Code\\Pic_test\\");
	strcpy(func::OutputFilePath10, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\10.txt");
	strcpy(func::OutputFilePath11, "E:\\shiyan\zms_old\\data\\Code\\");
	strcpy(func::OutputFilePath12, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\20.txt");
	strcpy(func::OutputPicNumConfigFilePath, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\PicNum.txt");
	strcpy(func::OutputPicNumConfigFilePath2, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\PicNum2.txt");
	strcpy(func::OutputFilePath13, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\Vul\\");
	strcpy(func::OutputFilePath14, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\No-Vul\\");
	strcpy(func::OutputFilePath15, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\FuncNum.txt");
	strcpy(func::OutputFilePath16, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\DataDependenceTime.txt");
	strcpy(func::OutputFilePath17, "E:\\shiyan\\zms_old\\Code\\Code-a8e56c97fe40425a9b835b88cff655e6fbc81e98\\x64\\Debug\\ControlDependenceTime.txt");
	func::Mod = 0;
	strcpy(func::OutputFilePath18, "E:\\shiyan\zms_old\\data\\Code\\Pic\\NotAllConvertIR\\");
#else
	if (argc != 24)
	{
		std::cout << argc << std::endl;
		std::cout << "xxx.exe InterMediateFilePath SourceFilePath OutputFilePath OutputFilePath2 OutputFilePath3 OutputFilePath4 OutputFilePath5 OutputFilePath6 OutputFilePath7 OutputFilePath8 OutputFilePath9 OutputFilePath10 OutputFilePath11 OutputPicNumConfigFilePath OutputPicNumConfigFilePath2 OutputFilePath12 OutputFilePath13(Vul) OutputFilePath14(No-Vul) OutputFilePath15(FuncNo) OutputFilePath16(DataDependenceTime) OutputFilePath17(ControlDependenceTime) Mod(Real Code File Or Not) OutputFilePath18(Real Code File Output Pic Path)" << std::endl;
		return 0;
	}
	strcpy(InterMediateFilePath, argv[1]);
	strcpy(fileNamePath, argv[2]);
	strcpy(func::OutputFilePath, argv[3]);
	strcpy(func::OutputFilePath2, argv[4]);
	strcpy(func::OutputFilePath3, argv[5]);
	strcpy(func::OutputFilePath4, argv[6]);
	strcpy(func::OutputFilePath5, argv[7]);
	strcpy(func::OutputFilePath6, argv[8]);
	strcpy(func::OutputFilePath7, argv[9]);
	strcpy(func::OutputFilePath8, argv[10]);
	strcpy(func::OutputFilePath9, argv[11]);
	strcpy(func::OutputFilePath10, argv[12]);
	strcpy(func::OutputFilePath11, argv[13]);
	strcpy(func::OutputPicNumConfigFilePath, argv[14]);
	strcpy(func::OutputPicNumConfigFilePath2, argv[15]);
	strcpy(func::OutputFilePath12, argv[16]);
	strcpy(func::OutputFilePath13, argv[17]);
	strcpy(func::OutputFilePath14, argv[18]);
	strcpy(func::OutputFilePath15, argv[19]);
	strcpy(func::OutputFilePath16, argv[20]);
	strcpy(func::OutputFilePath17, argv[21]);
	func::Mod = func::StrToInt(argv[22]);
	strcpy(func::OutputFilePath18, argv[23]);
#endif

	try
	{
		if (strcmp(InterMediateFilePath, "LIKED") == 0)
		{

			func::LIKED();
			exit(0);
		}

		if (strcmp(InterMediateFilePath, "LOVE") == 0)
		{

			func::LOVE();
			exit(0);
		}

		/*std::cout << "�����ļ�·�����ܰ�������" << std::endl;
		std::cin >> fileNamePath;*/

		/*if (!file::readOneFile(fileNamePath, fileBytes))
		{
			std::cout << "Read File Failed!" << std::endl;
			return 0;
		}*/

		/*if (!func::collectCode(fileBytes, collectBuffer))
		{
			std::cout << "Collect Code Failed!" << std::endl;
			return 0;
		}*/

		///////////////////////////////////////////////
		//
		////ReadIntermediate������������ֻҪ���ϸ�ʽҪ���û����
		//func::Init(11);
		//
		//if (!func::ReadIntermediate("G:\\c\\yan\\CodeTranslate\\x64\\Debug\\1.txt"))
		//{
		//	std::cout << "Read Intermediate Fail!" << std::endl;
		//	return 0;
		//}

		//for (int i = 0; i < 5000; i++)
		//{
		//	strcpy(fileNamePath, "G:\\data\\Code\\stack_base_buffer_overflow\\");
		//	func::IntToStrNew(i, tempFileNo);
		//	strcat(fileNamePath, tempFileNo);
		//	strcat(fileNamePath, ".c");
		//	std::cout << fileNamePath << std::endl;

		//	if (!func::ReadOneSourceFile(fileNamePath))
		//	{
		//		std::cout << "Read Source File Fail!" << std::endl;
		//		return 0;
		//	}

		//	std::cout << "\n\n File i : " << fileNamePath << std::endl;

		//	printf(temp);

		//	//while ((*(char**)func::pSourceCode)[tempIndex] != 0x0)
		//	//{
		//	//	func::MoveCodeIndexUntillNoBlank(func::pSourceCode, &tempIndex);
		//	//	tempIndex = tempIndex + func::CheckFunctionOrVariable(func::pSourceCode, &tempIndex, false, &tempLBraceNum, &tempRBraceNum) + 2;
		//	//	if (tempLBraceNum > 0 && tempLBraceNum == tempRBraceNum)
		//	//	{
		//	//		tempLBraceNum = 0;
		//	//		tempRBraceNum = 0;
		//	//		((func::pSourceCodeFile)->WriteFunctionNo)++;
		//	//		((func::pSourceCodeFile)->FunctionNum)++;
		//	//	}
		//	//}

		//	tempIndex = 0;
		//	func::AnalysisFile(func::pSourceCode, &tempIndex, func::pSourceCodeFile);

		//	//func::Translate(func::pSourceCode, &tempIndex);

		//	func::CheckAllCodeLineHaveImportAPIToGenerateCodeSlice(5, 5, 5, 5, 5, 5, 1);

		//	//func::display((char*)"a", 0, 3);
		//}

		/////////////////////////////////////

		func::Init(11);

		//ReadIntermediate������������ֻҪ���ϸ�ʽҪ���û����
		///func::ReadIntermediate(InterMediateFilePath);
		if (!func::ReadIntermediate(InterMediateFilePath))
		{
			std::cout << "Read Intermediate Fail!" << std::endl;
			return 0;
		}

		if (!func::ReadOneSourceFile(fileNamePath))
		{
			std::cout << "Read Source File Fail!" << std::endl;
			return 0;
		}

		if (!func::ReadVecTable(func::OutputFilePath3, func::OutputFilePath4))
		{
			std::cout << "Read Vec Table File Fail!" << std::endl;
			return 0;
		}

		if (!func::ReadOutputPicNumConfigFile(func::OutputPicNumConfigFilePath, func::OutputPicNumConfigFilePath2))
		{
			std::cout << "Read Output Pic Num Config File Fail!" << std::endl;
			return 0;
		}

		if (!func::ReadOutputFuncNumConfigFile(func::OutputFilePath15))
		{
			std::cout << "Read Output Func Num Config File Fail!" << std::endl;
			return 0;
		}

		//func::DisplayInterMediateArray();

		//printf(temp);

		////while ((*(char**)func::pSourceCode)[tempIndex] != 0x0)
		////{
		////	func::MoveCodeIndexUntillNoBlank(func::pSourceCode, &tempIndex);
		////	tempIndex = tempIndex + func::CheckFunctionOrVariable(func::pSourceCode, &tempIndex, false, &tempLBraceNum, &tempRBraceNum) + 2;
		////	if (tempLBraceNum > 0 && tempLBraceNum == tempRBraceNum)
		////	{
		////		tempLBraceNum = 0;
		////		tempRBraceNum = 0;
		////		((func::pSourceCodeFile)->WriteFunctionNo)++;
		////		((func::pSourceCodeFile)->FunctionNum)++;
		////	}
		////}

		tempIndex = 0;
		// mod=1 代表 处理真实软件 无pvcf输出  =0 代表处理CVE文件  有pvcf输出
		if (func::Mod == 1)
		{
			if (func::HandleUnprocessableFunc(func::pSourceCode, &tempIndex) == 0)
			{
				Real::HandleReal(func::pSourceCode, &tempIndex);
			}
		}
		else if(func::Mod == 0)
		{

			func::AnalysisFile(func::pSourceCode, &tempIndex, func::pSourceCodeFile);

			/*func::Translate(func::pSourceCode, &tempIndex);*/

			func::CheckAllCodeLineToGenerateCodeSlice(5, 5, 5, 5, 5, 5, 1);

			/*func::WriteOutputPicNumConfigFile(func::OutputPicNumConfigFilePath, func::OutputPicNumConfigFilePath2);*/

			//func::OutputAllSourceFileIntermediate();
		}
		else 
		{
			std::cout << "Input Mod error!\n";
		}
		//if (strstr((func::pSourceCodeFile)->FilePath, "Unprocessable"))
		//{
		//	func::HandleUnprocessableFunc(func ::pSourceCode, &tempIndex);
		//}
		//else
		//{
		//	func::AnalysisFile(func::pSourceCode, &tempIndex, func::pSourceCodeFile);

		//	/*func::Translate(func::pSourceCode, &tempIndex);*/

		//	func::CheckAllCodeLineToGenerateCodeSlice(5, 5, 5, 5, 5, 5, 1);

		//	/*func::WriteOutputPicNumConfigFile(func::OutputPicNumConfigFilePath, func::OutputPicNumConfigFilePath2);*/

		//	//func::OutputAllSourceFileIntermediate();
		//}

		func::WriteOutputPicNumConfigFile(func::OutputPicNumConfigFilePath, func::OutputPicNumConfigFilePath2);

		func::WriteOutputFuncNumConfigFile(func::OutputFilePath15);

		//func::display((char*)"a", 0, 3);

		//free(func::pSourceCode);
		//free(*(func::pSourceCode));
		free(*func::pSourceCode);
		delete func::pSourceCode;

		//printf("Finish\n");

		func::HandleFileNumFunc(".//FileNum.txt", ".//ErrorFile.txt");
	}
	catch (...)
	{
		std::cout << fileNamePath << std::endl;
	}

	tempNSTime2 = func::GetSysTimeMicros();
	if (tempNSTime1 != 0)
	{
		func::IntToStrNew(tempNSTime2 - tempNSTime1, tempNSTBuffer);
		file::OutPutToFile("./AT.txt", tempNSTBuffer);
		file::OutPutToFile("./AT.txt", tempNSTBuffer1);
	}

	Sleep(100);

	//getchar();

	return 0;
}