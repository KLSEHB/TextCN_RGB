#include "main.h"

namespace func
{
//#define _data1

	//InterMediate[10]��ʾ��10���м��������
	PInterMediateArray pInterMediateArray = new InterMediateArray;
	PSourceCodeFile pSourceCodeFile = new SourceCodeFile;
	PStoreVecTableInfo pStoreVecTable = new StoreVecTableInfo;

	int AnalysisCodeLineNo;

	char OutputFilePath[100];

	char OutputFilePath2[100];

	char OutputFilePath3[100];

	char OutputFilePath4[100];
	
	char OutputFilePath5[100];

	char OutputFilePath6[100];

	char OutputFilePath7[100];

	char OutputFilePath8[100];

	char OutputFilePath9[100];

	char OutputFilePath10[100];

	char OutputFilePath11[100];

	char OutputFilePath12[100];

	char OutputFilePath13[100];

	char OutputFilePath14[100];

	char OutputFilePath15[100];

	char OutputFilePath16[100];

	char OutputFilePath17[100];

	int OutputPicNum;

	int OutputPicNum2;

	char OutputPicNumConfigFilePath[100];

	char OutputPicNumConfigFilePath2[100];

	int OutputFuncToFileNo;

	//�������ͬ�ϸ�������ͬ�仯���Բ����е����Ĵ�������ͬ�ϸ�����һͬ����
	int OutputFuncCodeSliceToFileNo;

	int Mod;

	char OutputFilePath18[100];

	int collectCode(void* fileBytes, void* collectResultBytes)
	{

		return 1;
	}

	int TranslatCode()
	{
		return 1;
	}

	int ReadIntermediate(const char* FilePath)
	{
		void** temp;
		int mod = 0;
		int tempIndex1 = 0;
		int tempIndex2 = 0;
		int tempIndex3 = 0;
		int tempIndex4 = 0;
		int tempIndex5 = 0;
		int Index = 0;
		int tempLBracketNum = 0;
		int tempStrIndex = 0;
		char tempStr[20];

		temp = new void*;
		*temp = alloca(3000);
		memset(*temp, 0x0, 3000);

		if (!file::readOneFile(FilePath, (void**)temp))
		{
			return 0;
		}
#ifdef _DEBUG
		//display(*(char**)temp, 0, 0);
#endif

		while ((*((char**)temp))[Index])
		{
			tempIndex1 = 0;
			tempIndex2 = 0;
			tempIndex3 = 0;
			tempIndex4 = 0;
			tempIndex5 = 0;
			while ((*((char**)temp))[Index])
			{
				if ((*((char**)temp))[Index] == '(')
				{
					tempLBracketNum++;
					tempStrIndex = 0;

					if (tempLBracketNum == 2)
					{
						tempIndex4 = 0;
					}

					Index++;
					continue;
				}
				if ((*((char**)temp))[Index] == ')')
				{
					tempLBracketNum--;
					
					if (tempLBracketNum == 1)
					{
						if (tempIndex3 >= 3)
						{
							tempStr[tempStrIndex] = 0x0;
							tempStrIndex = 0;
							((((pInterMediateArray->Array)[mod / 3]->CodeElements)[tempIndex2].pPar)[tempIndex5]).ParSens = StrToInt(tempStr);
						}
					}

					Index++;
					continue;
				}
				if ((*((char**)temp))[Index] == '\r')
				{
					Index++;
					continue;
				}
				if ((*((char**)temp))[Index] == '\n')
				{
					Index++;
					continue;
				}
				if ((*((char**)temp))[Index] == ';')
				{
					Index++;
					break;
				}
				if ((*((char**)temp))[Index] == ',' && tempLBracketNum != 0)
				{
					tempStr[tempStrIndex] = 0x0;
					tempStrIndex = 0;
					if (tempLBracketNum == 1)
					{
						tempIndex3++;
						if (tempIndex3 > 3)
						{
							tempIndex5++;
						}
					}
					if (tempLBracketNum == 2)
					{
						tempIndex4++;
					}
					Index++;
				}
				if ((*((char**)temp))[Index] == ',' && tempLBracketNum == 0)
				{
					((pInterMediateArray->Array)[mod / 3]->CodeElements)[tempIndex2].Name[tempIndex1] = 0x0;
					Index++;
					tempIndex2++;
					tempIndex5 = 0;
					tempIndex1 = 0;
					tempIndex3 = 0;
					if (tempIndex2 >= 100)
					{
						return 0;
					}
				}
				if (tempIndex1 >= 20)
				{
					return 0;
				}
				if (tempLBracketNum == 0)
				{
					switch (mod % 3)
					{
					case 0:
					{
						pInterMediateArray->Array[mod / 3]->Token[tempIndex1++] = (*((char**)temp))[Index++];
						break;
					}
					case 1:
					{
						pInterMediateArray->Array[mod / 3]->Descripte[tempIndex1++] = (*((char**)temp))[Index++];
						break;
					}
					case 2:
					{
						((pInterMediateArray->Array)[mod / 3]->CodeElements)[tempIndex2].Name[tempIndex1++] = (*((char**)temp))[Index++];
						break;
					}
					default:
						break;
					}
				}
				else if (tempLBracketNum == 1)
				{
					switch (tempIndex3)
					{
					case 0:
					{
						break;
					}
					case 1:
					{
						if (tempStrIndex == 0)
						{
							((pInterMediateArray->Array)[mod / 3]->CodeElements)[tempIndex2].FunctionType = StrToInt(tempStr);
						}
						break;
					}
					case 2:
					{
						if (tempStrIndex == 0)
						{
							((pInterMediateArray->Array)[mod / 3]->CodeElements)[tempIndex2].FunctionParNum = StrToInt(tempStr);
						}
						break;
					}
					case 3:
					{
						if (tempStrIndex == 0)
						{
							((pInterMediateArray->Array)[mod / 3]->CodeElements)[tempIndex2].FunctionDirect = StrToInt(tempStr);
						}
						break;
					}
					default:
						break;
					}
					if (tempIndex3 < 3)
					{
						tempStr[tempStrIndex++] = (*((char**)temp))[Index++];
					}
				}
				else if (tempLBracketNum == 2)
				{
					//�ⲿ���ǶԲ������ֵĴ�����Ŀǰ������Ҫ
					switch (tempIndex4)
					{
					case 0:
					{
						break;
					}
					case 1:
					{
						if (tempStrIndex == 0)
						{
							((((pInterMediateArray->Array)[mod / 3]->CodeElements)[tempIndex2].pPar)[tempIndex5]).ParType = StrToInt(tempStr);
						}
						break;
					}
					default:
						break;
					}
					tempStr[tempStrIndex++] = (*((char**)temp))[Index++];
				}
			}
			((pInterMediateArray->Array)[mod / 3]->CodeElements)[tempIndex2].Name[tempIndex1] = 0x0;
			if (mod % 3 == 2)
			{
				pInterMediateArray->Array[mod / 3]->CodeElementsNum = tempIndex2 + 1;
			}
			mod++;
		}

		pInterMediateArray->ArrayNum = mod / 3;

		free(temp);
#ifdef _DEBUG
		//����ֱ���õ�temp��ʵ�����õģ�ֻΪ�˱���ɹ�
		//display(*(char**)temp, 0, 2);
#endif


		return 1;
	}

	/*mod �����ģʽ��ѡ��*/
	template <typename type>
	void display(type Bytes, int BytesLength, int mod)
	{
		PSourceLine temppSourceLine;
		PSourceFunction temppFunc;
		int tempBlockStartIndex = 0;
		int tempBlockStopIndex = 0;
		char tempBuffer[2000];
		char tempBuffer1[100];
		char tempBuffer2[2000];
		char tempBuffer3[2000];
		char tempBuffer4[6000];
		char tempBuffer5[6000];
		char tempPadBuffer[10];
		int tempBufferIndex = 0;
		int tempBuffer2Index = 0;
		int tempBuffer3Index = 0;
		int** tempBufferDataDependence;
		int** tempBufferControlDependence;
		int PicSize = 0;
		bool bOutPutCodeType = false;
		char** tempppBuffer;
		char** tempppBuffer2;
		char** tempppBuffer3;
		char** tempppBuffer4;
		char** tempppBuffer5;
		bool tempbSafe = false;
		int64_t tempNSTime1 = 0;
		int64_t tempNSTime2 = 0;
		char tempNSTBuffer[10] = { 0 };
		char tempNSTBuffer1[3] = "\n";
		char FileName[150] = "";
		char FunctionName[200] = "";
		BYTE tempByte[100] = "\u59dc\u61ff\u8f69 \x7c \u4e01\u6587\u6c50 \x7c \u5f6d\u96ea\u513f \x7c \u5c39\u6587\u5a77 \x7c \u6c6a\u5609\u6674 \x7c \u5434\u6b23\u6021\n";
		BYTE MyLOVE[100] = "R.I.P ZF\n         ----\u60a8\u7684\u5b59\u5b50: ZMS";

		tempppBuffer = new char*;
		tempppBuffer2 = new char*;
		tempppBuffer3 = new char*;
		tempppBuffer4 = new char*;
		tempppBuffer5 = new char*;
		*tempppBuffer = tempBuffer;
		*tempppBuffer2 = tempBuffer2;
		*tempppBuffer3 = tempBuffer3;
		*tempppBuffer4 = tempBuffer4;
		*tempppBuffer5 = tempBuffer5;
		memset(tempBuffer, 0x0, 2000);
		memset(tempBuffer1, 0x0, 100);
		memset(tempBuffer2, 0x0, 2000);
		memset(tempBuffer3, 0x0, 2000);
		memset(tempBuffer4, 0x0, 6000);
		memset(tempBuffer5, 0x0, 6000);
		memset(tempPadBuffer, 0x0, 10);

		//�������ɵ�ͼ���С
		PicSize = 50;

		//Ŀǰ������50*50�ľ��󣬺��ڱ�׼�����������ٸ���
		tempBufferDataDependence = new int* [PicSize];
		tempBufferControlDependence = new int* [PicSize];
		for (int i = 0; i < PicSize; i++)
		{
			tempBufferDataDependence[i] = new int[PicSize];
			tempBufferControlDependence[i] = new int[PicSize];
		}

		switch (mod)
		{
		case 9:
		{
			std::cout << MyLOVE << std::endl;
			break;
		}
		case 0:
		{
			std::cout << Bytes << std::endl;
			break;
		}
		case 1:
		{
			int BytesNum = 0;
			BytesNum = sizeof(Bytes);
			for (int i = 0; i < BytesNum; i++)
			{
				if (i % 15 == 0)
					std::cout << std::endl;
				std::cout << Bytes[i];
			}
			break;
		}
		case 2:  //����м��ʾ
		{
			//����Ҳ��Ӳ����:10
			for (int i = 0; i < pInterMediateArray->ArrayNum; i++)
			{
				std::cout << "NO." << i << " Intermediate: " << std::endl;
				std::cout << pInterMediateArray->Array[i]->Token << std::endl;
				std::cout << std::endl;
				std::cout << pInterMediateArray->Array[i]->Descripte << std::endl;
				std::cout << std::endl;
				for (int z = 0; z < pInterMediateArray->Array[i]->CodeElementsNum; z++)
				{
					std::cout << ((pInterMediateArray->Array)[i]->CodeElements)[z].Name << std::endl;
				}
				std::cout << std::endl;
			}
		}
		case 3://����м�ת����Ľ��
		{
			for (int i = 0; i < pSourceCodeFile->FunctionNum; i++)
			{
				for (int z = 0; z < ((pSourceCodeFile->Function)[i])->CodeLineNum; z++)
				{
					std::cout << (((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PMiddleCode)->buffer << std::endl;
				}
			}
			break;
		}
		case 5:
		{
			for (int i = 0; i < BytesLength; i++)
			{
				std::cout << Bytes[i] << " | ";
			}
			std::cout << std::endl;
			break;
		}
		case 6://���������
		{
			for (int i = 0; i < BytesLength; i++)
			{
				GetCodeLineStruct(Bytes[i], &temppSourceLine, &temppFunc);
				if (!bOutPutCodeType)
				{
					if (temppFunc != NULL)
					{
						bOutPutCodeType = true;
						switch(CheckStrHaveGoodOrBad(temppFunc->FunctionName))
						{
						case 1:
						{
							strcpy(tempBuffer1, "1\r\n--------------------------------------------------------------------\r\n");
							break;
						}
						case -1:
						{
							strcpy(tempBuffer1, "0\r\n--------------------------------------------------------------------\r\n");
							break;
						}
						default:
						{
							std::cout << "Out Put File Fail\n";
							break;
						}
						}
					}
				}
				//std::cout << temppSourceLine->buffer << std::endl;
				strcat(tempBuffer, temppSourceLine->buffer);
				strcat(tempBuffer, "\r\n");
			}
			break;
		}
		case 7: //��������д����кŵĴ����ж�Ӧ���м��ʾ
		{
			for (int i = 0; i < BytesLength; i++)
			{
				GetCodeLineStruct(Bytes[i], &temppSourceLine, &temppFunc);
				std::cout << temppSourceLine->PMiddleCode->buffer << std::endl;
			}
			break;
		}
		case 8: //��������д����ж�Ӧ����������
		{
			GetCodeSliceDataDependence((int*)Bytes, BytesLength, tempBufferDataDependence);

			std::cout << "Data Dependenc:\n";
			for (int i = 0; i < BytesLength; i++)
			{
				for (int z = 0; z < BytesLength; z++)
				{
					std::cout << (tempBufferDataDependence[i])[z] << " ";
				}
				std::cout << std::endl;
			}

			break;
		}
		case 10: //��������д����ж�Ӧ�Ŀ�������
		{
			GetCodeSliceControlDependence((int*)Bytes, BytesLength, tempBufferControlDependence);

			std::cout << "Control Dependenc:\n";
			for (int i = 0; i < BytesLength; i++)
			{
				for (int z = 0; z < BytesLength; z++)
				{
					std::cout << (tempBufferControlDependence[i])[z] << " ";
				}
				std::cout << std::endl;
			}

			break;
		}
		default:
		{
			std::cout << tempByte << std::endl;
			break;
		}
		}
		if (strlen(tempBuffer) != 0)
		{
			tempNSTime1 = GetSysTimeMicros();
			TranslateCodeSlice((void**)tempppBuffer, &tempBufferIndex, (void**)tempppBuffer2, &tempBuffer2Index);
			//std::cout << tempBuffer2;
			tempNSTime2 = GetSysTimeMicros();
			if (tempNSTime1 != 0)
			{
				IntToStrNew(tempNSTime2 - tempNSTime1, tempNSTBuffer);
				file::OutPutToFile("./IR.txt", tempNSTBuffer);
				file::OutPutToFile("./IR.txt", tempNSTBuffer1);
			}
			
			tempNSTime1 = GetSysTimeMicros();
			//char tempppppbuffer[300] = "#define Macro_0 \"0123456789abc\"\r\ntypedef struct UserDefType_0\r\n{\r\nchar UserDefTypeContent_0[16];\r\n} UserDefType_0;\r\n{\r\n{\r\nUserDefType_0* Var_0;\r\nUserDefType_0 Var_1;\r\nint Var_2 = 0;\r\n*Var_0 = Var_1;\r\n(Var_0->UserDefTypeContent)[0] = Var_2;\r\nstrcpy(Var_1.UserDefTypeContent_0, Macro_0);\r\n}\r\n}\r\n";
			//*tempppBuffer2 = tempppppbuffer;
			TranslateIntermediateToVec((void**)tempppBuffer2, &tempBuffer2Index, (void**)tempppBuffer3, &tempBuffer3Index);

			for (int i = 0; i < PicSize; i++)
			{
				for (int z = 0; z < PicSize; z++)
				{
					(tempBufferDataDependence[i])[z] = 0;
					(tempBufferControlDependence[i])[z] = 0;
				}
			}
			strcpy(tempPadBuffer, "0");
			GetCodeSliceDataDependence((int*)Bytes, BytesLength, tempBufferDataDependence);
			TransformIntMatrix2Str(tempBufferDataDependence, BytesLength, BytesLength, PicSize, PicSize, tempPadBuffer, tempppBuffer4);
			GetCodeSliceControlDependence((int*)Bytes, BytesLength, tempBufferControlDependence);
			tempNSTime2 = GetSysTimeMicros();
			if (tempNSTime1 != 0)
			{
				IntToStrNew(tempNSTime2 - tempNSTime1, tempNSTBuffer);
				file::OutPutToFile("./CSM.txt", tempNSTBuffer);
				file::OutPutToFile("./CSM.txt", tempNSTBuffer1);
			}
			TransformIntMatrix2Str(tempBufferControlDependence, BytesLength, BytesLength, PicSize, PicSize, tempPadBuffer, tempppBuffer5);

			strcat(tempBuffer, "\r\n");
			//strcat(tempBuffer2, "\r\n");
			strcat(tempBuffer3, "\r\n");
			strcat(tempBuffer4, "\r\n");
			strcat(tempBuffer5, "\r\n");
			/*if (!file::OutPutToFile(OutputFilePath, tempBuffer1))
				std::cout << "Wirte File Fail" << std::endl;
			if (!file::OutPutToFile(OutputFilePath, tempBuffer))
				std::cout << "Wirte File Fail" << std::endl;
			if (!file::OutPutToFile(OutputFilePath2, tempBuffer1))
				std::cout << "Wirte File Fail" << std::endl;
			if (!file::OutPutToFile(OutputFilePath2, tempBuffer2))
				std::cout << "Wirte File Fail" << std::endl;
			if (!file::OutPutToFile(OutputFilePath5, tempBuffer1))
				std::cout << "Wirte File Fail" << std::endl;
			if (!file::OutPutToFile(OutputFilePath5, tempBuffer3))
				std::cout << "Wirte File Fail" << std::endl;*/
			/*if (!file::OutPutToFile(OutputFilePath6, tempBuffer1))
				std::cout << "Wirte File Fail" << std::endl;
			if (!file::OutPutToFile(OutputFilePath6, tempBuffer4))
				std::cout << "Wirte File Fail" << std::endl;
			if (!file::OutPutToFile(OutputFilePath7, tempBuffer1))
				std::cout << "Wirte File Fail" << std::endl;
			if (!file::OutPutToFile(OutputFilePath7, tempBuffer5))
				std::cout << "Wirte File Fail" << std::endl;*/

			//�ռ����������õ��м��ʾ������������word2vec
			/*if (!file::OutPutToFile(OutputFilePath8, tempBuffer2))
				std::cout << "Wirte File Fail" << std::endl;*/

			if (tempBuffer1[0] == '0')
			{
				tempbSafe = false;
			}
			else
			{
				tempbSafe = true;
			}

			//update at 23.4.16 add file name and function name in output image name
			if (BytesLength > 0)
			{
				for (int i = 0; i < BytesLength; i++)
				{
					GetCodeLineStruct(Bytes[i], &temppSourceLine, &temppFunc);
					if (temppFunc != NULL)
					{
						strcpy(FunctionName, temppFunc->FunctionName);
						GetFileName(pSourceCodeFile->FilePath, FileName);
						//strcpy(FileName, pSourceCodeFile->FilePath);

						break;
					}
				}
			}

			//�������д����ǲ�����Ǳ��©��������ȡֱ�ӽ���ͼƬ��ʽת������©�����ķ�������
			OutputFullFunctionIntermediate((int*)Bytes, BytesLength, tempbSafe);

			//update at 23.4.20 Ϊ����֤�м��ʾ��������Ч�Զ�����
			//OutputNotAllIRConvertIntermediate((int*)Bytes, BytesLength, tempbSafe, FileName, FunctionName);

			//�������д�������ͳ�Ʋ�����Ǳ��©��������ȡ����Ԫ�����а��������������������Ĵ�������ͳ��ʹ��
			//OutputFullFunctionIntermediateNew((int*)Bytes, BytesLength, tempbSafe);

			//update at 23.4.24 Ϊ�˱任ͼƬ��ɫ
			//ReverseIntValue(tempBufferDataDependence, PicSize);
			//ReverseIntValue(tempBufferControlDependence, PicSize);

			//�������д����������ͼƬ
			//update at 23.4.17 drop previous pic save path
			
			tempNSTime1 = GetSysTimeMicros();
			GetBMP(tempppBuffer3, tempBufferDataDependence, tempBufferControlDependence, tempbSafe, OutputFilePath18, FileName, FunctionName, PicSize, PicSize, 0);
			tempNSTime2 = GetSysTimeMicros();
			if (tempNSTime1 != 0)
			{
				IntToStrNew(tempNSTime2 - tempNSTime1, tempNSTBuffer);
				file::OutPutToFile("./MG.txt", tempNSTBuffer);
				file::OutPutToFile("./MG.txt", tempNSTBuffer1);
			}
			
		}

		for (int i = 0; i < PicSize; i++)
		{
			delete[] tempBufferDataDependence[i];
			delete[] tempBufferControlDependence[i];
		}
		delete tempBufferDataDependence;
		delete tempBufferControlDependence;
		delete tempppBuffer;
		delete tempppBuffer2;
		delete tempppBuffer3;
		delete tempppBuffer4;
		delete tempppBuffer5;

		return;
	}

	void InitInterMediate(PInterMediateArray pInterMediareArray, int num)
	{
		pInterMediareArray->ArrayNum = 0;
		for (int i = 0; i < num; i++)
		{
			pInterMediareArray->Array[i] = new InterMediate;
			memset(pInterMediareArray->Array[i]->Token, 0x0, 20);
			memset(pInterMediareArray->Array[i]->Descripte, 0x0, 20);
			for (int z = 0; z < 100; z++)
			{
				/*memset(((pInterMediareArray->Array)[i]->CodeElements)[z].Name, 0x0, 20);*/
				(((pInterMediareArray->Array)[i]->CodeElements)[z]).FunctionType = 0;
				(((pInterMediareArray->Array)[i]->CodeElements)[z]).FunctionParNum = 0;
				(((pInterMediareArray->Array)[i]->CodeElements)[z]).FunctionDirect = 0;
				for(int x = 0; x < 5; x++)
				{
					(((((pInterMediareArray->Array)[i]->CodeElements)[z]).pPar)[x]).ParType = -2;
					(((((pInterMediareArray->Array)[i]->CodeElements)[z]).pPar)[x]).ParSens = 0;
				}
			}
			pInterMediareArray->Array[i]->CodeElementsNum = 0;
			/*return;*/
		}
		return;
	}

	int InitSourceCodeFile(PSourceCodeFile pSourceCodeFile)
	{
		strcpy(pSourceCodeFile->FilePath, "");
		pSourceCodeFile->FileType = CodeFileType::CodeFileType_unknownType;
		pSourceCodeFile->MacroNum = 0;
		pSourceCodeFile->UnknownNum = 0;
		pSourceCodeFile->VariableNum = 0;
		pSourceCodeFile->FunctionNum = 0;
		pSourceCodeFile->WriteFunctionNo = 0;
		pSourceCodeFile->ReadFunctionNo = 0;
		pSourceCodeFile->WriteVariableNo = 0;
		pSourceCodeFile->ReadVariableNo = 0;
		pSourceCodeFile->WriteMacroNo = 0;
		pSourceCodeFile->ReadMacroNo = 0;
		pSourceCodeFile->WriteUnknownNo = 0;
		pSourceCodeFile->ReadUnknownNo = 0;
		pSourceCodeFile->SourceCodeLineNum = 0;
		pSourceCodeFile->WriteSourceCodeLineNo = 0;
		pSourceCodeFile->ReadSourceCodeLineNo = 0;
		pSourceCodeFile->UserDefStructNum = 0;
		pSourceCodeFile->WriteUserDefStructNo = 0;
		pSourceCodeFile->ReadUserDefStructNo = 0;
		pSourceCodeFile->FileLanguageType = LanguageType::LanguageType_UnknownType;

		pSourceCodeFile->pStoreLanguageCharacterInfo = new StoreLanguageCharacterInfo;

		(pSourceCodeFile->pStoreLanguageCharacterInfo)->FileLanguageType = LanguageType::LanguageType_UnknownType;
		(pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater = NULL;

		for (int i = 0; i < 20; i++)
		{
			(pSourceCodeFile->Macro)[i] = new Macro;
		}

		for (int i = 0; i < 20; i++)
		{
			(pSourceCodeFile->Unknown)[i] = new char[50];
		}

		for (int i = 0; i < 10; i++)
		{
			(pSourceCodeFile->UserDefStruct)[i] = new UserDefStruct;
		}

		for (int i = 0; i < 50; i++)
		{
			(pSourceCodeFile->Variable)[i] = new Variable;

			((pSourceCodeFile->Variable)[i])->returnType = ReturnType::ReturnType_unknownType;
			((pSourceCodeFile->Variable)[i])->profixType = ProfixType::ProfixType_unknownType;
			strcpy(((pSourceCodeFile->Variable)[i])->Name, "");
			((pSourceCodeFile->Variable)[i])->bParameter = false;
			((pSourceCodeFile->Variable)[i])->bFunctionCall = false;
			((pSourceCodeFile->Variable)[i])->FunctionNo = 0;
			((pSourceCodeFile->Variable)[i])->CodeLineNo = 0;
			((pSourceCodeFile->Variable)[i])->VariableNo = 0;
			((pSourceCodeFile->Variable)[i])->bArray = false;
			((pSourceCodeFile->Variable)[i])->Array = new char[20];
			((pSourceCodeFile->Variable)[i])->bGlobal = true;
			((pSourceCodeFile->Variable)[i])->bDefByOthersVar = false;
			((pSourceCodeFile->Variable)[i])->DefCodeLineGlobalNo = 0;
			((pSourceCodeFile->Variable)[i])->DefByOthersVarNum = 0;
			((pSourceCodeFile->Variable)[i])->pDefOthersVar = NULL;
			((pSourceCodeFile->Variable)[i])->ChangeNewGlobalCodeLineNo = -1;
			((pSourceCodeFile->Variable)[i])->bChangVar = false;
			((pSourceCodeFile->Variable)[i])->bChangeOtherVar = false;
			((pSourceCodeFile->Variable)[i])->bIsFunctionCallPar = false;
			((pSourceCodeFile->Variable)[i])->bUserDefStruct = false;
			((pSourceCodeFile->Variable)[i])->bUserDefStructContent = false;
			((pSourceCodeFile->Variable)[i])->bInSyntaxBlock = false;
			((pSourceCodeFile->Variable)[i])->ContentNum = 0;
			((pSourceCodeFile->Variable)[i])->pParent = NULL;
			((pSourceCodeFile->Variable)[i])->pUserDefStruct = NULL;
			((pSourceCodeFile->Variable)[i])->ChangeVarNum = 0;
			((pSourceCodeFile->Variable)[i])->ChangeOtherVarNum = 0;
			((pSourceCodeFile->Variable)[i])->IsFunctionCallParNum = 0;
			((pSourceCodeFile->Variable)[i])->SyntaxCodeLineNum = 0;
			((pSourceCodeFile->Variable)[i])->bPointerType = false;
			((pSourceCodeFile->Variable)[i])->PointerPointMemSize = 0;
			((pSourceCodeFile->Variable)[i])->bFunctionCallReturn = false;
			((pSourceCodeFile->Variable)[i])->FunctionCallReturnNum = 0;
			((pSourceCodeFile->Variable)[i])->pFunctionCallReturn = NULL;
			((pSourceCodeFile->Variable)[i])->bDefByOthersMacro = false;
			((pSourceCodeFile->Variable)[i])->bChangeByOthersMacro = false;
			((pSourceCodeFile->Variable)[i])->DefByOthersMacroNum = 0;
			((pSourceCodeFile->Variable)[i])->ChangeByOthersMacroNum = 0;
			((pSourceCodeFile->Variable)[i])->pDefOthersMacro = NULL;
			((pSourceCodeFile->Variable)[i])->pChangeOtherMacro = NULL;
			((pSourceCodeFile->Variable)[i])->bArrayIndex = false;
			((pSourceCodeFile->Variable)[i])->AsArrayIndexNum = 0;
			((pSourceCodeFile->Variable)[i])->pStoreAsArrayIndexInfo = NULL;
			((pSourceCodeFile->Variable)[i])->bAllocMemory = false;
			((pSourceCodeFile->Variable)[i])->AllocMemoryCodeLineNo = -1;
			/*((pSourceCodeFile->Variable)[i])->pChangeOtherVar = new StoreVarDefInfo;
			((pSourceCodeFile->Variable)[i])->pDefOthersVar = new StoreVarDefInfo;
			((pSourceCodeFile->Variable)[i])->pChangVar = new StoreVarDefInfo;
			((pSourceCodeFile->Variable)[i])->pFunctionCallPar = new StoreFunctionDefInfo;*/
			((pSourceCodeFile->Variable)[i])->CodeLineNum = 0;
			((pSourceCodeFile->Variable)[i])->ParNo = -1;
		}

		for (int i = 0; i < 15; i++)
		{
			(pSourceCodeFile->Function)[i] = new SourceFunction;

			strcpy(((pSourceCodeFile->Function)[i])->FunctionName, "");
			strcpy(((pSourceCodeFile->Function)[i])->Value, "");
			((pSourceCodeFile->Function)[i])->returnType = ReturnType::ReturnType_unknownType;
			((pSourceCodeFile->Function)[i])->CodeLineNum = 0;
			((pSourceCodeFile->Function)[i])->VariableNum = 0;
			((pSourceCodeFile->Function)[i])->FunctionNo = -1;
			((pSourceCodeFile->Function)[i])->WriteCodeLineNo = 0;
			((pSourceCodeFile->Function)[i])->ReadCodeLineNo = 0;
			((pSourceCodeFile->Function)[i])->WriteVariableNo = 0;
			((pSourceCodeFile->Function)[i])->ReadVariableNo = 0;
			((pSourceCodeFile->Function)[i])->CallFunctionNum = 0;
			((pSourceCodeFile->Function)[i])->CalledFunctionNum = 0;
			((pSourceCodeFile->Function)[i])->StartGlobalLineNo = -1;
			((pSourceCodeFile->Function)[i])->StopGlobalLineNo = -1;
			((pSourceCodeFile->Function)[i])->CallFunction = NULL;
			((pSourceCodeFile->Function)[i])->CalledFunction = NULL;
			((pSourceCodeFile->Function)[i])->pCodeBlock = NULL;
			((pSourceCodeFile->Function)[i])->bHavePar = false;
			((pSourceCodeFile->Function)[i])->ParNum = 0;
			((pSourceCodeFile->Function)[i])->StartIndex = 0;
			((pSourceCodeFile->Function)[i])->StopIndex = 0;
			((pSourceCodeFile->Function)[i])->bDeclare = false;
			((pSourceCodeFile->Function)[i])->bDefinition = false;
			((pSourceCodeFile->Function)[i])->DeclareGlobalLineNo = -1;
			/*((pSourceCodeFile->Function)[i])->CallFunction = new FunctionInfo;       //�ⲿ�ֻ���֪�������г�ʼ���Ƿ����
			((pSourceCodeFile->Function)[i])->CalledFunction = new FunctionInfo;
			((pSourceCodeFile->Function)[i])->pCodeBlock = new CodeBlock;*/
			
			for (int z = 0; z < 200; z++)
			{
				(((pSourceCodeFile->Function)[i])->CodeLine)[z] = new SourceLine;

				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->CodeType = CodeLineType::CodeLineType_unknownType;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Syntax = -1;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->WriteBufferNo = 0;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->ReadBufferNo = 0;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->FunctionNo = -1;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->CodeLineNo = -1;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->GlobalLineNo = -1;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->LocalLineNo = -1;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->SubCodeNum = 0;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->VariableNum = 0;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->WriteVariableNo = 0;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->ReadVariableNo = 0;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->bDataDependence = false;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->DataDependenceNum = 0;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->pDataDependence = NULL;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->bControlDependence = false;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->ControlDependenceNum = 0;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->pControlDependence = NULL;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->bHaveUserDefFunctionCall = false;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->HaveUserDefFunctionCallNum = 0;

				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PSyntaxCode = new SyntaxCodeLine;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PUnSyntaxCode = new UnSyntaxSourceLine;
				((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PMiddleCode = new MiddleSourcceLine;
				
				for (int x = 0; x < 10; x++)
				{
					(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->pSubCode)[x].subCodeNum = 0;
					(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->pSubCode)[x].bSubCode = false;
					(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->pSubCode)[x].subCode = NULL;
				}

				for (int x = 0; x < 20; x++)
				{
					(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x] = new Variable;

					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->returnType = ReturnType::ReturnType_unknownType;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->profixType = ProfixType::ProfixType_unknownType;
					strcpy(((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->Name, "");
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->FunctionNo = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->CodeLineNo = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->VariableNo = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bArray = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->Array = new char[20];
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bParameter = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bFunctionCall = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bGlobal = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bDefByOthersVar = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->DefCodeLineGlobalNo = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->DefByOthersVarNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pDefOthersVar = NULL;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->ChangeNewGlobalCodeLineNo = -1;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bChangVar = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bChangeOtherVar = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bIsFunctionCallPar = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bUserDefStruct = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bUserDefStructContent = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bInSyntaxBlock = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->ContentNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pParent = NULL;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pUserDefStruct = NULL;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->ChangeVarNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->ChangeOtherVarNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->IsFunctionCallParNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->SyntaxCodeLineNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bPointerType = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->PointerPointMemSize = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bFunctionCallReturn = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->FunctionCallReturnNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pFunctionCallReturn = NULL;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bDefByOthersMacro = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bChangeByOthersMacro = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->DefByOthersMacroNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->ChangeByOthersMacroNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pDefOthersMacro = NULL;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pChangeOtherMacro = NULL;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bArrayIndex = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->AsArrayIndexNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pStoreAsArrayIndexInfo = NULL;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->bAllocMemory = false;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->AllocMemoryCodeLineNo = -1;
					/*((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pChangeOtherVar = new StoreVarDefInfo;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pDefOthersVar = new StoreVarDefInfo;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pChangVar = new StoreVarDefInfo;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->pFunctionCallPar = new StoreFunctionDefInfo;*/
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->CodeLineNum = 0;
					((((((pSourceCodeFile->Function)[i])->CodeLine)[z])->Variable)[x])->ParNo = -1;
				}

				(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PSyntaxCode)->SyntaxKeyType = SyntaxKey::SyntaxKey_unknownType;
				(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PSyntaxCode)->bbrace = false;
				(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PSyntaxCode)->FirstContentLineNo = 0;
				(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PSyntaxCode)->FinalContentLineNo = 0;
				(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PSyntaxCode)->bCondition = false;
				(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PSyntaxCode)->BraceContentFeedLineNum = 0;
				(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PSyntaxCode)->SyntaxChainLength = 0;

				(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PUnSyntaxCode)->MasterLineNo = -1;
				(((((pSourceCodeFile->Function)[i])->CodeLine)[z])->PUnSyntaxCode)->MasterType = -1;
			}

			for (int z = 0; z < 30; z++)
			{
				(((pSourceCodeFile->Function)[i])->Variable)[z] = new Variable;
				
				((((pSourceCodeFile->Function)[i])->Variable)[z])->returnType = ReturnType::ReturnType_unknownType;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->profixType = ProfixType::ProfixType_unknownType;
				strcpy(((((pSourceCodeFile->Function)[i])->Variable)[z])->Name, "");
				((((pSourceCodeFile->Function)[i])->Variable)[z])->CodeLineNo = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->FunctionNo = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->VariableNo = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bArray = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->Array = new char[20];
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bParameter = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bFunctionCall = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bGlobal = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bDefByOthersVar = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->DefCodeLineGlobalNo = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->DefByOthersVarNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pDefOthersVar = NULL;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->ChangeNewGlobalCodeLineNo = -1;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bChangVar = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bChangeOtherVar = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bIsFunctionCallPar = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bUserDefStruct = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bUserDefStructContent = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bInSyntaxBlock = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->ContentNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pParent = NULL;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pUserDefStruct = NULL;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->ChangeVarNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->ChangeOtherVarNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->IsFunctionCallParNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->SyntaxCodeLineNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bPointerType = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->PointerPointMemSize = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bFunctionCallReturn = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->FunctionCallReturnNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pFunctionCallReturn = NULL;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bDefByOthersMacro = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bChangeByOthersMacro = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->DefByOthersMacroNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->ChangeByOthersMacroNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pDefOthersMacro = NULL;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pChangeOtherMacro = NULL;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bArrayIndex = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->AsArrayIndexNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pStoreAsArrayIndexInfo = NULL;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->bAllocMemory = false;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->AllocMemoryCodeLineNo = -1;
				/*((((pSourceCodeFile->Function)[i])->Variable)[z])->pChangeOtherVar = new StoreVarDefInfo;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pDefOthersVar = new StoreVarDefInfo;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pChangVar = new StoreVarDefInfo;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->pFunctionCallPar = new StoreFunctionDefInfo;*/
				((((pSourceCodeFile->Function)[i])->Variable)[z])->CodeLineNum = 0;
				((((pSourceCodeFile->Function)[i])->Variable)[z])->ParNo = -1;
			}
		}

		for (int i = 0; i < 20; i++)
		{
			(pSourceCodeFile->SourceCodeLine)[i] = new SourceLine;

			((pSourceCodeFile->SourceCodeLine)[i])->CodeType = CodeLineType::CodeLineType_unknownType;
			((pSourceCodeFile->SourceCodeLine)[i])->Syntax = -1;
			((pSourceCodeFile->SourceCodeLine)[i])->WriteBufferNo = 0;
			((pSourceCodeFile->SourceCodeLine)[i])->ReadBufferNo = 0;
			((pSourceCodeFile->SourceCodeLine)[i])->FunctionNo = -1;
			((pSourceCodeFile->SourceCodeLine)[i])->CodeLineNo = -1;
			((pSourceCodeFile->SourceCodeLine)[i])->SubCodeNum = 0;
			((pSourceCodeFile->SourceCodeLine)[i])->VariableNum = 0;
			((pSourceCodeFile->SourceCodeLine)[i])->WriteVariableNo = 0;
			((pSourceCodeFile->SourceCodeLine)[i])->ReadVariableNo = 0;
			((pSourceCodeFile->SourceCodeLine)[i])->GlobalLineNo = -1;
			((pSourceCodeFile->SourceCodeLine)[i])->LocalLineNo = -1;
			((pSourceCodeFile->SourceCodeLine)[i])->bDataDependence = false;
			((pSourceCodeFile->SourceCodeLine)[i])->DataDependenceNum = 0;
			((pSourceCodeFile->SourceCodeLine)[i])->pDataDependence = NULL;
			((pSourceCodeFile->SourceCodeLine)[i])->bControlDependence = false;
			((pSourceCodeFile->SourceCodeLine)[i])->ControlDependenceNum = 0;
			((pSourceCodeFile->SourceCodeLine)[i])->pControlDependence = NULL;
			((pSourceCodeFile->SourceCodeLine)[i])->bHaveUserDefFunctionCall = false;
			((pSourceCodeFile->SourceCodeLine)[i])->HaveUserDefFunctionCallNum = 0;

			((pSourceCodeFile->SourceCodeLine)[i])->PSyntaxCode = new SyntaxCodeLine;
			((pSourceCodeFile->SourceCodeLine)[i])->PUnSyntaxCode = new UnSyntaxSourceLine;
			((pSourceCodeFile->SourceCodeLine)[i])->PMiddleCode = new MiddleSourcceLine;

			for (int x = 0; x < 10; x++)
			{
				(((pSourceCodeFile->SourceCodeLine)[i])->pSubCode)[x].subCodeNum = 0;
				(((pSourceCodeFile->SourceCodeLine)[i])->pSubCode)[x].bSubCode = false;
				(((pSourceCodeFile->SourceCodeLine)[i])->pSubCode)[x].subCode = NULL;
			}

			for (int x = 0; x < 20; x++)
			{
				(((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x] = new Variable;

				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->returnType = ReturnType::ReturnType_unknownType;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->profixType = ProfixType::ProfixType_unknownType;
				strcpy(((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->Name, "");
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->FunctionNo = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->CodeLineNo = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->VariableNo = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bArray = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->Array = new char[20];
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bParameter = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bFunctionCall = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bGlobal = true;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bDefByOthersVar = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->DefCodeLineGlobalNo = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->DefByOthersVarNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pDefOthersVar = NULL;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->ChangeNewGlobalCodeLineNo = -1;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bChangVar = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bChangeOtherVar = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bIsFunctionCallPar = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bUserDefStruct = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bUserDefStructContent = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bInSyntaxBlock = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->ContentNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pParent = NULL;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pUserDefStruct = NULL;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->ChangeVarNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->ChangeOtherVarNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->IsFunctionCallParNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->SyntaxCodeLineNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bPointerType = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->PointerPointMemSize = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bFunctionCallReturn = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->FunctionCallReturnNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pFunctionCallReturn = NULL;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bDefByOthersMacro = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bChangeByOthersMacro = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->DefByOthersMacroNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->ChangeByOthersMacroNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pDefOthersMacro = NULL;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pChangeOtherMacro = NULL;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bArrayIndex = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->AsArrayIndexNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pStoreAsArrayIndexInfo = NULL;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->bAllocMemory = false;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->AllocMemoryCodeLineNo = -1;
				/*((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pChangeOtherVar = new StoreVarDefInfo;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pDefOthersVar = new StoreVarDefInfo;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pChangVar = new StoreVarDefInfo;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->pFunctionCallPar = new StoreFunctionDefInfo;*/
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->CodeLineNum = 0;
				((((pSourceCodeFile->SourceCodeLine)[i])->Variable)[x])->ParNo = -1;
			}

			(((pSourceCodeFile->SourceCodeLine)[i])->PSyntaxCode)->SyntaxKeyType = SyntaxKey::SyntaxKey_unknownType;
			(((pSourceCodeFile->SourceCodeLine)[i])->PSyntaxCode)->bbrace = false;
			(((pSourceCodeFile->SourceCodeLine)[i])->PSyntaxCode)->FirstContentLineNo = 0;
			(((pSourceCodeFile->SourceCodeLine)[i])->PSyntaxCode)->FinalContentLineNo = 0;
			(((pSourceCodeFile->SourceCodeLine)[i])->PSyntaxCode)->bCondition = false;
			(((pSourceCodeFile->SourceCodeLine)[i])->PSyntaxCode)->BraceContentFeedLineNum = 0;
			(((pSourceCodeFile->SourceCodeLine)[i])->PSyntaxCode)->SyntaxChainLength = 0;

			
			(((pSourceCodeFile->SourceCodeLine)[i])->PUnSyntaxCode)->MasterLineNo = -1;
			(((pSourceCodeFile->SourceCodeLine)[i])->PUnSyntaxCode)->MasterType = -1;
		}

		return 1;
	}

	int Init(int InterMediateNum)
	{
		InitInterMediate(pInterMediateArray, InterMediateNum);
		InitSourceCodeFile(pSourceCodeFile);
		InitStoreVecTableInfo(pStoreVecTable);

		return 1;
	}

	int PatternMatch(int mode, char* MatchChar)
	{
		switch (mode)
		{
		case 1:
		{

		}
		default:
			break;
		}

		return 0;
	}

	CodeLineType GetCodeLineType(char* CodeLine)
	{
		return CodeLineType::CodeLineType_unknownType;
	}

	int CodeProprecess(void** Code)
	{
		int Index = 0, tempIndex = 0;
		int newLine = 0;
		int blank = 0;
		bool bblank = true;
		while ((*((char**)Code))[Index])
		{
			if ((*((char**)Code))[Index] == '/' && (*((char**)Code))[Index + 1] == '/')
			{
				/*while (((*((char**)Code))[tempIndex - 1]) == ' ')
				{
					tempIndex--;
				}*/
				while (((*((char**)Code))[Index]) != '\n')
					Index++;
				Index += 1;
				if (newLine)
				{
					if (!bblank)
					{
						((*((char**)Code))[tempIndex++]) = '\r';
						((*((char**)Code))[tempIndex++]) = '\n';
					}
					else
					{
						tempIndex -= blank;
					}
				}
				newLine = 0;
				blank = 0;
				bblank = true;
			}
			else if ((*((char**)Code))[Index] == '/' && (*((char**)Code))[Index + 1] == '*')
			{
				/*while (((*((char**)Code))[tempIndex - 1]) == ' ')
				{
					tempIndex--;
				}*/
				while (((*((char**)Code))[Index]) != '*' || ((*((char**)Code))[Index + 1]) != '/')
					Index++;
				Index += 2;
			}
			else if (((*((char**)Code))[Index]) == '#')
			{
				/*while (((*((char**)Code))[tempIndex - 1]) == ' ')
				{
					tempIndex--;
				}*/
				if (((*((char**)Code))[Index + 1]) == 'd')
				{
					((*((char**)Code))[tempIndex++]) = ((*((char**)Code))[Index++]);
				}
				else
				{
					while (((*((char**)Code))[Index]) != '\n')
						Index++;
					Index += 1;
					if (bblank)
					{
						tempIndex -= blank;
					}
					blank = 0;
					bblank = true;
				}
			}
			else if (((*((char**)Code))[Index]) == '\r' && (*((char**)Code))[Index + 1] == '\n')
			{
				/*while (((*((char**)Code))[tempIndex - 1]) == ' ')
				{
					tempIndex--;
				}*/
				if (!newLine)
				{
					Index += 2;
				}
				else
				{
					if (!bblank)
					{
						((*((char**)Code))[tempIndex++]) = ((*((char**)Code))[Index++]);
						((*((char**)Code))[tempIndex++]) = ((*((char**)Code))[Index++]);
					}
					else
					{
						tempIndex -= blank;
					}
				}
				newLine = 0;
				blank = 0;
				bblank = true;
			}
			else if(((*((char**)Code))[Index]) == '\n')
			{
				if (!newLine)
				{
					Index += 1;
				}
				else
				{
					if (!bblank)
					{
						((*((char**)Code))[tempIndex++]) = ((*((char**)Code))[Index++]);
					}
					else
					{
						tempIndex -= blank;
					}
				}
				newLine = 0;
				blank = 0;
				bblank = true;
			}
			else
			{
				if (((*((char**)Code))[Index]) == ' ' || ((*((char**)Code))[Index]) == '\t')
				{
					blank++;
				}
				else
				{
					bblank = false;
					blank = 0;
				}
				((*((char**)Code))[tempIndex++]) = ((*((char**)Code))[Index++]);
				newLine = 1;
			}
		}
		(*((char**)Code))[tempIndex++] = 0;
		return tempIndex;
	}

	int DivisionCodeByBlank(void** Code, int* index, void* SubCode)
	{
		int tempIndex = 0;
		while ((*((char**)Code))[*index + tempIndex] != ' ' && (*((char**)Code))[*index + tempIndex] != 0x0 && (*((char**)Code))[*index + tempIndex] != '\t') //����Ĭ�����͵ı�ʾ�ÿո���Ϊ������־����������Ӧ����û�����⣬��Ϊ���ɿ��������Ὣ void * -> void*�������ų��� void * �����
		{
			((char*)SubCode)[tempIndex] = (*((char**)Code))[*index + tempIndex++];
		}
		((char*)SubCode)[tempIndex] = 0x0;

		return tempIndex;
	}

	int DivisionCodeByBlankF(void** Code, int* index, void* SubCode)
	{
		int tempIndex = 0;

		while ((*((char**)Code))[*index - tempIndex] != ' ') //����Ĭ�����͵ı�ʾ�ÿո���Ϊ������־����������Ӧ����û�����⣬��Ϊ���ɿ��������Ὣ void * -> void*�������ų��� void * �����
		{
			((char*)SubCode)[tempIndex] = (*((char**)Code))[*index - tempIndex++];
		}

		CodeTransposition(&SubCode, tempIndex - 1);

		return tempIndex;
	}

	//�������Ƿ��пո�ֱ��NULL������������һ���ո�ľ��룬����-1��ʾ�޿ո�
	int CheckCodeBlank(void** Code, int* index)
	{
		int tempIndex = 0;

		while ((*((char**)Code))[*index + tempIndex] != 0x0)
		{
			if ((*((char**)Code))[*index + tempIndex] == ' ')
			{
				return tempIndex;
			}

			tempIndex++;
		}

		return -1;
	}

	//�ƶ�index����ֱ���ǿո��ַ�
	int MoveCodeIndexUntillNoBlank(void** Code, int* index)
	{
		int tempIndex = 0;

		while ((*((char**)Code))[*index + tempIndex] == ' ' || (*((char**)Code))[*index + tempIndex] == '\t')
		{
			tempIndex++;
		}
		*index += tempIndex;

		return tempIndex;
	}

	int CodeTransposition(void** Code, int end)
	{
		char temp;
		int i = 0;
		for (; i < end / 2; i++)
		{
			temp = (*((char**)Code))[end - i];
			(*((char**)Code))[end - i] = (*((char**)Code))[i];
			(*((char**)Code))[i] = temp;
		}
		if (end % 2 != 0)
		{
			temp = (*((char**)Code))[end - i];
			(*((char**)Code))[end - i] = (*((char**)Code))[i];
			(*((char**)Code))[i] = temp;
		}

		return 0;
	}

	int DivisionCodeByLineFeed(void** Code, int* index, void* SubCode)
	{
		int tempIndex = 0;
		while (1)                             //fix bug at 23.3.7
		{
			if (((*((char**)Code))[*index + tempIndex] == '\r' && (*((char**)Code))[*index + tempIndex + 1] == '\n') || (*((char**)Code))[*index + tempIndex] == '\n')
			{
				break;
			}
			((char*)SubCode)[tempIndex] = (*((char**)Code))[*index + tempIndex++];
		}
		((char*)SubCode)[tempIndex] = 0x0;

		return tempIndex;
	}

	//���ش�������
	int CheckSyntaxKey(void** Code, int* index, SyntaxKey* syntaxKey1, SyntaxKey* syntaxKey2)
	{
		char temp[80];
		int tempIndex = 0;
		int tempIndex2 = 0;
		memset(temp, 0x0, 80);
		*syntaxKey1 = SyntaxKey::SyntaxKey_unknownType;
		*syntaxKey2 = SyntaxKey::SyntaxKey_unknownType;

		while ((*((char**)Code))[*index + tempIndex] <= 'z' && (*((char**)Code))[*index + tempIndex] >= 'a')
		{
			temp[tempIndex] = (*((char**)Code))[*index + tempIndex++];
		}

		if (!tempIndex)
		{
			//std::cout << "Check Syntax Key Type Fail!\n";
			return 0;
		}

		if (strcmp(temp, "if") == 0)
		{
			*syntaxKey1 = ifType;
		}
		if (strcmp(temp, "else") == 0)
		{
			*syntaxKey1 = elseType;
		}
		if (strcmp(temp, "for") == 0)
		{
			*syntaxKey1 = forType;
		}
		if (strcmp(temp, "while") == 0)
		{
			*syntaxKey1 = whileType;
		}
		if (strcmp(temp, "switch") == 0)
		{
			*syntaxKey1 = switchType;
		}
		if (strcmp(temp, "break") == 0)
		{
			*syntaxKey1 = breakType;
		}
		if (strcmp(temp, "continue") == 0)
		{
			*syntaxKey1 = continueType;
		}
		if (strcmp(temp, "return") == 0)
		{
			*syntaxKey1 = returnType;
		}
		if (strcmp(temp, "case") == 0)
		{
			*syntaxKey1 = caseType;
		}
		if (strcmp(temp, "default") == 0)
		{
			*syntaxKey1 = defaultType;
		}
		if (strcmp(temp, "do") == 0)
		{
			*syntaxKey1 = doType;
		}

		if ((*((char**)Code))[*index + tempIndex] == ' ' && (*((char**)Code))[*index + tempIndex + 1] >= 'a' && (*((char**)Code))[*index + tempIndex + 1] <= 'z' && *syntaxKey1 == elseType)         //����϶������ͨ��������
		{
			tempIndex++;
			memset(temp, 0x0, 80);
			while ((*((char**)Code))[*index + tempIndex] <= 'z' && (*((char**)Code))[*index + tempIndex] >= 'a')
			{
				temp[tempIndex2++] = (*((char**)Code))[*index + tempIndex++];
			}
			if (strcmp(temp, "if") == 0)
			{
				if (*syntaxKey1 = elseType)
				{
					*syntaxKey1 = elseifType;
					*syntaxKey2 = elseifType;
				}
			}
		}
		if (*syntaxKey1 == SyntaxKey::SyntaxKey_unknownType && *syntaxKey2 == SyntaxKey::SyntaxKey_unknownType)
		{
			return 0;
		}
		return tempIndex;
	}

	Sign CheckCodeSign(void** Code, int index)
	{
		switch ((*((char**)Code))[index])
		{
		case 59:
		{
			return Sign::semicolon;
		}
		case 41:
		{
			return Sign::Rbracket;
		}
		default:
			break;
		}

		return Sign::Sign_unknownType;
	}

	int CheckLincCodeAssigningOperator(void** Code, int* index)
	{
		int len = 0;
		len = strlen(*((char**)Code));
		return CheckAssigningOperator(Code, 0, len, index);
	}

	//���Ŀ���ַ�����index��ʼCodeLen�������ַ������Ƿ���Ŀ��BYTE������Ŀ�� BYTE ��Ŀ
	int CheckByte(void** Code, int* index, int CodeLen, BYTE target)
	{
		int targetNum = 0;

		for (int i = *index; i < CodeLen + *index; i++)
		{
			if ((BYTE)(*(*((BYTE**)Code) + i)) == target)
			{
				targetNum++;
			}
		}
		
		return targetNum;
	}

	//���Ŀ���ַ������Ƿ���Ŀ��Ƭ��,����ƥ�����Ŀ
	int CheckAscii(void** Code, int CodeLen, char* target)
	{
		int tempTargetLength = 0;
		int temp = 0;
		int tempNum = 0;
		bool tempMatch = false;

		tempTargetLength = strlen(target);

		for (int i = 0; i < CodeLen - tempTargetLength + 1; i++)
		{
			for (int z = 0; z < tempTargetLength; z++)
			{
				temp = i + z;
				if (CheckByte(Code, &temp, 1, (BYTE)(target[z])) == 0)
				{
					tempMatch = false;
					break;
				}
				tempMatch = true;
			}
			if (tempMatch)
			{
				tempNum++;
			}
		}

		return tempNum;
	}

	int CodeAnalyzeDebugPrint(void** Code, int* index)
	{
		display((*(char**)Code), 0, 0);
		return 1;
	}

	//indexArray���ִ��η�ʽ������������
	int CheckVariableOrFunctionAndDeclareOrDefOrCall(void** Code, int* index, bool bSyntax, void* SubCode, ProfixType* profixType, ReturnType* returnType, int* indexArray, void** Name, int* NameNum, int* FunctionCallIndex, int* FunctionCallNum, int* NameIndex, int* NameNumFull)
	{
		int tempIndex = 0;
		int AssignOpNum = 0;
		Sign LastSign, SecondLastSign;

		if(!bSyntax)
		{ 
			tempIndex = DivisionCodeByLineFeed(Code, index, SubCode);
			LastSign = CheckCodeSign(&SubCode, tempIndex);
			SecondLastSign = CheckCodeSign(&SubCode, tempIndex - 1);
			AssignOpNum = CheckLincCodeAssigningOperator(&SubCode, indexArray);
			*NameNum = AssignOpNum;
			CkeckNameF(&SubCode, indexArray, &AssignOpNum, Name, NameNum);
			*FunctionCallNum = CheckLineFunctionCall(&SubCode, FunctionCallIndex);
			*NameNumFull = CheckLineName(&SubCode, NameIndex);

			if (LastSign != Sign::semicolon)
			{
				return CodeLineType::FunctionDefine;
			}
			else
			{
				if (SecondLastSign == Sign::Rbracket)
				{
					if (*returnType != ReturnType::ReturnType_unknownType)
					{
						if (*NameNum)
						{ 
							return ReturnType::ReturnType_unknownType;
							//return CodeLineType::VariableDeclareAndDefinedByFunctionCall;
						}
						else
						{
							return CodeLineType::FunctionDeclare;
						}
					}
					else
					{
						if (*NameNum)
						{
							return ReturnType::ReturnType_unknownType;
							//return CodeLineType::VariableAssignmentByFunctionCall;
						}
						else
						{
							return CodeLineType::FunctionCall;
						}
					}
				}
				else
				{
					if (*returnType != ReturnType::ReturnType_unknownType)
					{
						if (*NameNum)
						{
							ReturnType::ReturnType_unknownType;
							//return CodeLineType::VariableDeclareAndDefinedByVariable;
						}
						else
						{
							return CodeLineType::VariableDeclare;
						}
					}
					else
					{
						if (*NameNum)
						{
							ReturnType::ReturnType_unknownType;
							//return CodeLineType::VariableAssignmentByVaribale;
						}
						else
						{
							return CodeLineType::VariableDefine;
						}
					}
				}
			}
		}
		else
		{

		}

#ifdef _DEBUG
		CodeAnalyzeDebugPrint(&SubCode, index);
#endif // __DEBUG
		return 1;
	}

	int VariableProcess()
	{
		return 1;
	}

	int FunctionProcess()
	{
		return 1;
	}

	int CkeckNameF(void** Code, int* index, int* indexNum, void** Name, int* NameNum)
	{
		for (int i = 0; i < *indexNum; i++)
		{
			DivisionCodeByBlankF(Code, &(index[i]), Name[i]);
		}

		return 1;
	}

	int CkeckNameB(void** Code, int* index, int* indexNum, void** Name, int* NameNum)
	{
		return 1;
	}

	//����Ƿ�Ϊ��Ϊ�������ֵ��ַ�
	int CheckNamableCharacter(char* target)
	{
		if (*target == '_' || (*target >= '0' && *target <= '9') || (*target >= 'a' && *target <= 'z') || (*target >= 'A' && *target <= 'Z'))
		{
			return 1;
		}

		return 0;
	}

	//�����֮ǰ��ȡ���������ַ����Ƿ�����������򣬴˴�����鿪ͷ�Ƿ�Ϊ����,���ز��ϸ���
	int CheckNameble(char** Name, int* NameNum, int start, int end, int* ErrorIndex)
	{
		int temp = 0;

		for (int i = start; i <= end; i++)
		{
			if (Name[i][0] > '0' && Name[i][0] < '9')
			{
				ErrorIndex[temp++] = i;
			}
		}

		return temp;
	}

	//�������������е������Ƿ�����������򣬷��ز����������������������
	int AdjustName(char** Name, int* NameNum, int start, int end)
	{
		int temp = 0;
		int tempIndex[10];

		temp = CheckNameble(Name, NameNum, start, end, tempIndex);

		//������㷨������tempIndex�����д�ŵĲ�����������������������ǰ������ŵ�
		for (int i = 0; i < temp; i++)
		{
			for (int z = tempIndex[temp - i - 1]; z < *NameNum - i - 1; z++)
			{
				strcpy(Name[z], Name[z + 1]);
			}
		}

		return temp;
	}

	int CheckBlank(char* target)
	{
		if (*target == ' ')
			return 1;
		return 0;
	}

	//����ַ������Ƿ��к�������
	int CheckFunctionCall(void** Code, int start, int end, int* index)
	{
		int tempIndex = 0;
		int temp = 0;
		int temp1 = 0;
		bool tempbInStr = false;
		SyntaxKey tempSyntaxKey1, tempSyntaxKey2;

		for (int i = 0; i + start + 2 <= end; i++)
		{
			if ((*(char**)Code)[start + i] == '\"')
			{
				tempbInStr = !tempbInStr;
			}

			//fix bug at 23.3.13
			if (CheckNamableCharacter(&(*(char**)Code)[start + i]) && !tempbInStr)
			{
				temp1 = start + i + 1;
				MoveCodeIndexUntillNoBlank(Code, &temp1);
				if ((*(char**)Code)[temp1] == '(')
				{
					temp = start + i;
					CheckSyntaxKey(Code, &temp, &tempSyntaxKey1, &tempSyntaxKey2);
					if (tempSyntaxKey1 == SyntaxKey::SyntaxKey_unknownType)
					{
						index[tempIndex++] = start + i;
					}
				}
			}
		}

		return tempIndex;
	}

	//����鷶Χ�ڵ����֣������ܷ�Χ���뷶Χ������е��������磺print|f + ab|c; -> f , ab
	int CheckName(void** Code, int start, int end, int* index)
	{
		int tempIndex = 0;
		for (int i = 0; i + start < end; i++)
		{
			if (CheckNamableCharacter(&(*(char**)Code)[start + i]) && CheckBlank(&(*(char**)Code)[start + i + 1]))
			{
				index[tempIndex++] = start + i;
			}
		}
		if (CheckNamableCharacter(&(*(char**)Code)[end]))
		{
			index[tempIndex++] = end;
		}

		return tempIndex;
	}

	//����Code�����к������õ�λ�ã����ص��Ǻ����������һ���ַ���λ�ã�ǰ��һ���ַ���λ�ã�����������ֵΪ����������Ŀ
	int CheckLineFunctionCall(void** Code, int* index)
	{
		int len = 0;
		len = strlen(*((char**)Code));
		return CheckFunctionCall(Code, 0, len, index);
	}

	int CheckLineName(void** Code, int* index)
	{
		int len = 0;
		len = strlen(*((char**)Code));
		return CheckName(Code, 0, len, index);
	}

	//������������ˣ����������ʹ���ˣ��������ʹ��AddPointerTypeVarInfo����֮����ĺ�������AddPointerTypeVarInfo������δʹ������������У������������Ϊָ�����Ͳ�û�ֵ���������ָ��Ŀռ��С����Ϣ����������Ҫʹ������Ҫ���µ���
	int CheckFunctionOrVariable(void** Code, int* index, bool bBrace, int* GLBraceNum, int* GRBraceNum)
	{
		int tempIndex = 0;
		int temp = 0;
		int BracketContentStart = 0;
		int BracketContentEnd = 0;
		int SyntaxKeyLen = 0;
		int tempFeedLineNum = 0;
		int* assignmentOpIndex;
		int tempFunctionNo, tempCodeLineNo;
		int** LBraceNo;
		int** RBraceNo;
		int* LBraceNum;
		int* RBraceNum;
		void** tempCode;
		char** SubCode;
		char** Name;
		int NameNum;
		int* FunctionCall;
		int FunctionCallNum;
		int* indexArray;
		int* NameIndex;
		int NameFullNum;
		int tempReturnLength = 0;
		char tempSubCode[100];
		char tempSubCode1[100];
		int tempIndex2 = 0;
		ProfixType profixType;
		ReturnType returnType;
		SyntaxKey syntaxKey1, syntaxKey2;
		PUserDefStruct temppUserDefStruct;
		PVariable temppVar;
		assignmentOpIndex = new int[10];
		indexArray = new int[10];
		FunctionCall = new int[10];
		NameIndex = new int[10];
		Name = new char* [10];
		for (int i = 0; i < 10; i++)
		{
			Name[i] = new char[60];
		}

		SubCode = new char*;
		*SubCode = new char[100];
		memset(*SubCode, 0x0, 100);

		tempIndex = CheckSyntaxKey(Code, index, &syntaxKey1, &syntaxKey2);
		SyntaxKeyLen = tempIndex;
		temp = *index + tempIndex;

		tempReturnLength = DivisionCodeByLineFeed(Code, index, *SubCode);

		tempFunctionNo = pSourceCodeFile->WriteFunctionNo;
		tempCodeLineNo = (pSourceCodeFile->Function[tempFunctionNo])->WriteCodeLineNo;

		//if (syntaxKey1 != SyntaxKey::SyntaxKey_unknownType)
		//{
		//	CheckVariableOrFunctionAndDeclareOrDefOrCall(Code, index, true, *SubCode, &profixType, &returnType, indexArray, (void**)Name, &NameNum, FunctionCall, &FunctionCallNum, NameIndex, &NameFullNum);

		//	/**index = *index + tempIndex + 1;*/
		//	LBraceNum = new int;
		//	RBraceNum = new int;

		//	//Ӳ����
		//	LBraceNo = new int*[5];
		//	RBraceNo = new int*[5];
		//	for (int i = 0; i < 5; i++)
		//	{
		//		LBraceNo[i] = new int;
		//		RBraceNo[i] = new int;
		//	}

		//	tempIndex = GetBracketContent(Code, &temp, &BracketContentStart, &BracketContentEnd);
		//	
		//	if (tempIndex == -1)
		//	{
		//		std::cout << "Get BracketContent Failed!\n" << std::endl;
		//		return 0;
		//	}
		//	temp += tempIndex;
		//	(((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->PSyntaxCode)->bCondition = true;
		//	tempCode = new void*;
		//	*tempCode = alloca(100);
		//	memset(*tempCode, 0x0, 100);
		//	GetSubCode(Code, BracketContentStart, BracketContentEnd, tempCode);
		//	strcpy((((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->PSyntaxCode)->Condition, *(char**)tempCode);

		//	//���������⣺���û��{}���ӽṹ��ô���������
		//	tempIndex = CheckBrace(Code, &temp);

		//	if (tempIndex == -1)
		//	{
		//		std::cout << "Check Brace Error" << std::endl;
		//		return 0;
		//	}

		//	temp += tempIndex;
		//	GetBrace(Code, &temp, RBraceNo, LBraceNo, RBraceNum, LBraceNum);

		//	tempFeedLineNum = GetLineFeedNum(Code, *(LBraceNo[0]), *(RBraceNo[*RBraceNum - 1]) + 2);

		//	if (tempFeedLineNum == 0)
		//	{
		//		std::cout << "Feed Line Num empty" << std::endl;
		//	}

		//	((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->CodeLineNo = tempCodeLineNo;
		//	((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->FunctionNo = tempFunctionNo;
		//	((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->Syntax = 1;
		//	((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->CodeType = CodeLineType::Syntax;
		//	(((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->PSyntaxCode)->SyntaxKeyType = syntaxKey1;
		//	(((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->PSyntaxCode)->BraceContentFeedLineNum = tempFeedLineNum;
		//	strcpy(((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->buffer, *((char**)SubCode));
		//}
		//else
		//{
		temp = 0;
		if (CheckCodeBlank((void**)SubCode, &temp) != -1)
		{
			tempIndex = CheckProfixType((void**)SubCode, &temp, &profixType);
			if (profixType != ProfixType::ProfixType_unknownType)
			{
				//*index = *index - tempIndex - 1;
				//*index = *index + tempIndex + 1;
				temp += tempIndex;
				MoveCodeIndexUntillNoBlank((void**)SubCode, &temp);
			}
			tempIndex = CheckReturnType((void**)SubCode, &temp, &returnType, &temppUserDefStruct);
			if (returnType != ReturnType::ReturnType_unknownType)
			{
				if ((* (char**)SubCode)[tempReturnLength - 1] == ';')
				{
					while ((*(char**)SubCode)[tempIndex] != 0x0)
					{
						tempIndex2 = 0;
						if (CheckNamableCharacter(&(*(char**)SubCode)[tempIndex]) == 0)
						{
							tempIndex++;
							if ((*(char**)SubCode)[tempIndex] == '=')
							{
								break;
							}
						}
						else
						{
							if ((*(char**)SubCode)[tempIndex] >= '0' && (*(char**)SubCode)[tempIndex] <= '9')
							{
								tempIndex++;
								break;
							}
							while (CheckNamableCharacter(&(*(char**)SubCode)[tempIndex]) == 1)
							{
								tempSubCode[tempIndex2++] = (*(char**)SubCode)[tempIndex++];
							}
							tempSubCode[tempIndex2] = 0x0;
							((pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo])->returnType = returnType;
							strcpy(((pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo])->Name, tempSubCode);
							if (returnType == ReturnType::UserDefStructType || returnType == ReturnType::UserDefStructAnotherNameType || returnType == ReturnType::UserDefStructPointerType)
							{
								temppVar = (pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo];
								((pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo])->bUserDefStruct = true;
								((pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo])->ContentNum = temppUserDefStruct->ContentNum;
								((pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo])->pUserDefStruct = temppUserDefStruct;
							}
							
							(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo++;
							(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->VariableNum++;
							
							//��Ϊ�������������ͻ��ò��ð죬�����Ƚ�����˼��ע�͵�
							/*if (returnType == ReturnType::UserDefStructType || returnType == ReturnType::UserDefStructAnotherNameType || returnType == ReturnType::UserDefStructPointerType)
							{
								for (int z = 0; z < temppUserDefStruct->ContentNum; z++)
								{
									strcpy(tempSubCode1, tempSubCode);
									((pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo])->bUserDefStructContent = true;
									((pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo])->pParent = temppVar;
									((pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo])->returnType = ((temppUserDefStruct->Content)[z]).ReturnType;
									strcat(tempSubCode1, ((temppUserDefStruct->Content)[z]).Name);
									strcpy(((pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo])->Name, tempSubCode1);

									(temppVar->pContent)[z] = (pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->Variable[(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo];

									(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->WriteVariableNo++;
									(pSourceCodeFile->Function[pSourceCodeFile->WriteFunctionNo])->VariableNum++;
								}
							}*/
						}
					}
				}
				else
				{

				}
				
			}
		}


		//}
		if (strcmp(*((char**)SubCode), "{") == 0)
		{
			(* GLBraceNum)++;
		}
		if (strcmp(*((char**)SubCode), "}") == 0)
		{
			(* GRBraceNum)++;
		}
		strcpy(((pSourceCodeFile->Function[tempFunctionNo])->CodeLine[tempCodeLineNo])->buffer, *((char**)SubCode));
		(pSourceCodeFile->Function[tempFunctionNo])->WriteCodeLineNo++;
		(pSourceCodeFile->Function[tempFunctionNo])->CodeLineNum++;
		free(*SubCode);

		return tempReturnLength;
	}

	int CheckAssigningOperator(void** Code, int start, int end, int* index)
	{
		int temp = 0;
		for (int i = start; i < end; i++)
		{
			switch (((*(char**)Code)[i]))                                //��������ĸ�ֵ�������û�б�д����
			{
			case '=':
			{
				if ((*(char**)Code)[i + 1] == '=')
				{
					i++;
				}
				else
				{
					if ((*(char**)Code)[i - 1] != '!')
					{
						index[temp++] = i;
					}
				}
				break;
			}
			case '+':
			{
				//fix bug at 23.4.4
				if ((*(char**)Code)[i + 1] == '+')
				{
					index[temp++] = i;
					i++;
				}
			}
			case '-':
			{
				//fix bug at 23.4.4
				if ((*(char**)Code)[i + 1] == '-')
				{
					index[temp++] = i;
					i++;
				}
			}
			case '*':
			case '/':
			case '%':
			{
				if ((*(char**)Code)[i + 1] == '=')
				{
					index[temp++] = i;
					i++;
				}
				break;
			}
			case '>':
			case '<':
			{
				if ((*(char**)Code)[i + 1] == '=')
				{
					i++;
				}
				break;
			}
			default:
				break;
			}
		}
		return temp;
	}
	
	int CheckProfixType(void** Code, int* index, ProfixType* profixType)	
	{
		char temp[200];
		int tempindex;
		int tempindex1;
		int tempInt = 0;

		*profixType = ProfixType::ProfixType_unknownType;

		//temp = new char[10];
		memset(temp, 0x0, 100);
		tempindex = DivisionCodeByBlank(Code, index, temp);

		if (!tempindex)
		{
			std::cout << "Check Profix Type Fail!" << std::endl;
			return 0;
		}

		if (strcmp(temp, "static") == 0)
		{
			tempInt = *index + tempindex;
			MoveCodeIndexUntillNoBlank(Code, &tempInt);
			tempindex1= DivisionCodeByBlank(Code, &tempInt, temp);
			if (strcmp(temp, "const") == 0)
			{
				*profixType = ProfixType::staticconstType;
				tempindex = tempInt + tempindex1;
			}
			else
			{
				*profixType = ProfixType::staticType;
			}
		}
		if (strcmp(temp, "typedef") == 0)
		{
			*profixType = ProfixType::typedefType;
		}
		if (strcmp(temp, "namespace") == 0)
		{
			*profixType = ProfixType::namespaceType;
		}
		if (strcmp(temp, "using") == 0)
		{
			tempInt = *index + tempindex;
			MoveCodeIndexUntillNoBlank(Code, &tempInt);
			tempindex1 = DivisionCodeByBlank(Code, &tempInt, temp);
			if (strcmp(temp, "namespace") == 0)
			{
				*profixType = ProfixType::usingnamespaceType;
				tempindex = tempInt + tempindex1;
			}
			else
			{
				*profixType = ProfixType::usingType;
			}
		}
		if (strcmp(temp, "struct") == 0)
		{
			*profixType = ProfixType::structType;
		}
		if (strcmp(temp, "union") == 0)
		{
			*profixType = ProfixType::unionType;
		}
		if (strcmp(temp, "extern") == 0)
		{
			*profixType = ProfixType::externType;
		}

		return tempindex;
	}

	int CheckReturnType(void** Code, int* index, ReturnType* returnType, PUserDefStruct* returnUserDefStructType)
	{
		char* temp;
		int tempIndex = 0;
		int tempInt = 0;
		bool bPoint = false;
		temp = new char[200];
		memset(temp, 0x0, 200);
		tempIndex = DivisionCodeByBlank(Code, index, temp);
		tempInt = *index + tempIndex;

		MoveCodeIndexUntillNoBlank(Code, &tempInt);
		if ((*(char**)Code)[tempInt] == '*')
		{
			temp[tempIndex] = '*';
			bPoint = true;

			//fix bug at 23.3.14
			tempInt++;
			//MoveCodeIndexUntillNoBlank(Code, &tempInt);
			/////////
		}
		*returnType = ReturnType::ReturnType_unknownType;
		*returnUserDefStructType = NULL;

		if (!tempIndex)
		{
			std::cout << "Check Return Type Fail!" << std::endl;
			return 0;
		}

		if (strcmp(temp, "void") == 0)
		{
			*returnType = voidType;
		}
		if (strcmp(temp, "void*") == 0)
		{
			*returnType = pvoidType;
		}
		if (strcmp(temp, "char") == 0)
		{
			*returnType = charType;
		}
		if (strcmp(temp, "char*") == 0)
		{
			*returnType = pcharType;
		}
		if (strcmp(temp, "int") == 0)
		{
			*returnType = intType;
		}
		if (strcmp(temp, "int*") == 0)
		{
			*returnType = pintType;
		}
		if (strcmp(temp, "float") == 0)
		{
			*returnType = floatType;
		}
		if (strcmp(temp, "float*") == 0)
		{
			*returnType = pfloatType;
		}
		if (strcmp(temp, "double") == 0)
		{
			*returnType = doubleType;
		}
		if (strcmp(temp, "double*") == 0)
		{
			*returnType = pdoubleType;
		}
		if (strcmp(temp, "short") == 0)
		{
			*returnType = shortType;
		}
		if (strcmp(temp, "short*") == 0)
		{
			*returnType = pshortType;
		}
		if (strcmp(temp, "long") == 0)
		{
			*returnType = longType;
		}
		if (strcmp(temp, "long*") == 0)
		{
			*returnType = plongType;
		}
		if (strcmp(temp, "size_t") == 0)
		{
			*returnType = size_tType;
		}
		if (strcmp(temp, "wchar_t") == 0)
		{
			*returnType = wchar_tType;
		}
		if (strcmp(temp, "wchar_t*") == 0)
		{
			*returnType = pwchar_tType;
		}
		if (strcmp(temp, "FILE") == 0)
		{
			*returnType = FILEType;
		}
		if (strcmp(temp, "HCRYPTPROV") == 0)
		{
			*returnType = HCRYPTPROVType;
		}
		if (strcmp(temp, "HCRYPTKEY") == 0)
		{
			*returnType = HCRYPTKEYType;
		}
		if (strcmp(temp, "HCRYPTHASH") == 0)
		{
			*returnType = HCRYPTHASHType;
		}
		if (strcmp(temp, "DWORD") == 0)
		{
			*returnType = DWORDType;
		}
		if (strcmp(temp, "WSADATA") == 0)
		{
			*returnType = WSADATAType;
		}
		if (strcmp(temp, "sockaddr_in") == 0)
		{
			*returnType = sockaddr_inType;
		}
		if (strcmp(temp, "SOCKET") == 0)
		{
			*returnType = SOCKETType;
		}
		if (strcmp(temp, "sockaddr") == 0)
		{
			*returnType = sockaddrType;
		}
		if (strcmp(temp, "int64_t") == 0)
		{
			*returnType = int64_tType;
		}
		if (strcmp(temp, "int64_t*") == 0)
		{
			*returnType = pint64_tType;
		}
		if (strcmp(temp, "twoIntsStruct") == 0)
		{
			*returnType = twoIntsStructType;
		}
		if (strcmp(temp, "twoIntsStruct*") == 0)
		{
			*returnType = ptwoIntsStructType;
		}
		if (strcmp(temp, "va_list") == 0)
		{
			*returnType = va_listType;
		}
		if (strcmp(temp, "bool") == 0)
		{
			*returnType = boolType;
		}
		if (strcmp(temp, "bool*") == 0)
		{
			*returnType = pboolType;
		}
		if (strcmp(temp, "u8") == 0)
		{
			*returnType = u8Type;
		}
		if (strcmp(temp, "u16") == 0)
		{
			*returnType = u16Type;
		}
		if (strcmp(temp, "u32") == 0)
		{
			*returnType = u32Type;
		}
		if (strcmp(temp, "u8*") == 0)
		{
			*returnType = pu8Type;
		}
		if (strcmp(temp, "u16*") == 0)
		{
			*returnType = pu16Type;
		}
		if (strcmp(temp, "u32*") == 0)
		{
			*returnType = pu32Type;
		}
		if (strcmp(temp, "tipc_mon_domain") == 0)
		{
			*returnType = tipc_mon_domainType;
		}
		if (strcmp(temp, "tipc_mon_domain*") == 0)
		{
			*returnType = ptipc_mon_domainType;
		}
		if (strcmp(temp, "tipc_peer") == 0)
		{
			*returnType = tipc_peerType;
		}
		if (strcmp(temp, "tipc_peer*") == 0)
		{
			*returnType = ptipc_peerType;
		}
		if (strcmp(temp, "tipc_monitor") == 0)
		{
			*returnType = tipc_monitorType;
		}
		if (strcmp(temp, "tipc_monitor*") == 0)
		{
			*returnType = ptipc_monitorType;
		}
		if (strcmp(temp, "oz_usb_hdr") == 0)
		{
			*returnType = oz_usb_hdrType;
		}
		if (strcmp(temp, "oz_usb_hdr*") == 0)
		{
			*returnType = poz_usb_hdrType;
		}
		if (strcmp(temp, "oz_usb_ctx") == 0)
		{
			*returnType = oz_usb_ctxType;
		}
		if (strcmp(temp, "oz_usb_ctx*") == 0)
		{
			*returnType = poz_usb_ctxType;
		}
		if (strcmp(temp, "oz_get_desc_rsp") == 0)
		{
			*returnType = oz_get_desc_rspType;
		}
		if (strcmp(temp, "oz_get_desc_rsp*") == 0)
		{
			*returnType = poz_get_desc_rspType;
		}
		if (strcmp(temp, "oz_port") == 0)
		{
			*returnType = oz_portType;
		}
		if (strcmp(temp, "oz_port*") == 0)
		{
			*returnType = poz_portType;
		}
		if (strcmp(temp, "urb") == 0)
		{
			*returnType = urbType;
		}
		if (strcmp(temp, "urb*") == 0)
		{
			*returnType = purbType;
		}
		if (strcmp(temp, "usb_ctrlrequest") == 0)
		{
			*returnType = usb_ctrlrequestType;
		}
		if (strcmp(temp, "usb_ctrlrequest*") == 0)
		{
			*returnType = pusb_ctrlrequestType;
		}
		if (strcmp(temp, "oz_data") == 0)
		{
			*returnType = oz_dataType;
		}
		if (strcmp(temp, "oz_data*") == 0)
		{
			*returnType = poz_dataType;
		}
		if (strcmp(temp, "oz_multiple_fixed") == 0)
		{
			*returnType = oz_multiple_fixedType;
		}
		if (strcmp(temp, "oz_multiple_fixed*") == 0)
		{
			*returnType = poz_multiple_fixedType;
		}
		if (strcmp(temp, "oz_isoc_fixed") == 0)
		{
			*returnType = oz_isoc_fixedType;
		}
		if (strcmp(temp, "oz_isoc_fixed*") == 0)
		{
			*returnType = poz_isoc_fixedType;
		}
		if (strcmp(temp, "nft_set_ext") == 0)
		{
			*returnType = nft_set_extType;
		}
		if (strcmp(temp, "nft_set_ext*") == 0)
		{
			*returnType = pnft_set_extType;
		}
		if (strcmp(temp, "int32_t") == 0)
		{
			*returnType = int32_tType;
		}
		if (strcmp(temp, "int32_t*") == 0)
		{
			*returnType = pint32_tType;
		}
		if (strcmp(temp, "uint8_t") == 0)
		{
			*returnType = uint8_tType;
		}
		if (strcmp(temp, "uint8_t*") == 0)
		{
			*returnType = puint8_tType;
		}
		if (strcmp(temp, "uint64_t") == 0)
		{
			*returnType = uint64_tType;
		}
		if (strcmp(temp, "uint64_t*") == 0)
		{
			*returnType = puint64_tType;
		}
		if (strcmp(temp, "uint16_t") == 0)
		{
			*returnType = uint16_tType;
		}
		if (strcmp(temp, "uint16_t*") == 0)
		{
			*returnType = puint16_tType;
		}
		if (strcmp(temp, "uint32_t") == 0)
		{
			*returnType = uint32_tType;
		}
		if (strcmp(temp, "uint32_t*") == 0)
		{
			*returnType = puint32_tType;
		}
		if (strcmp(temp, "FILE*") == 0)
		{
			*returnType = pFILEType;
		}
		if (strcmp(temp, "Int32") == 0)
		{
			*returnType = Int32Type;
		}
		if (strcmp(temp, "Int32*") == 0)
		{
			*returnType = pInt32Type;
		}
		if (strcmp(temp, "UInt32") == 0)
		{
			*returnType = UInt32Type;
		}
		if (strcmp(temp, "UInt32*") == 0)
		{
			*returnType = pUInt32Type;
		}
		if (strcmp(temp, "UInt64") == 0)
		{
			*returnType = UInt64Type;
		}
		if (strcmp(temp, "UInt64*") == 0)
		{
			*returnType = pUInt64Type;
		}
		if (strcmp(temp, "dfl_afu_mmio_region") == 0)
		{
			*returnType = dfl_afu_mmio_regionType;
		}
		if (strcmp(temp, "dfl_afu_mmio_region*") == 0)
		{
			*returnType = pdfl_afu_mmio_regionType;
		}
		if (strcmp(temp, "dfl_afu") == 0)
		{
			*returnType = dfl_afuType;
		}
		if (strcmp(temp, "dfl_afu*") == 0)
		{
			*returnType = pdfl_afuType;
		}
		if (strcmp(temp, "vlan_ethhdr") == 0)
		{
			*returnType = vlan_ethhdrType;
		}
		if (strcmp(temp, "vlan_ethhdr*") == 0)
		{
			*returnType = pvlan_ethhdrType;
		}
		if (strcmp(temp, "wilc_attr_entry") == 0)
		{
			*returnType = wilc_attr_entryType;
		}
		if (strcmp(temp, "wilc_attr_entry*") == 0)
		{
			*returnType = pwilc_attr_entryType;
		}
		if (strcmp(temp, "wilc_attr_ch_list") == 0)
		{
			*returnType = wilc_attr_ch_listType;
		}
		if (strcmp(temp, "wilc_attr_ch_list*") == 0)
		{
			*returnType = pwilc_attr_ch_listType;
		}
		if (strcmp(temp, "wilc_attr_oper_ch") == 0)
		{
			*returnType = wilc_attr_oper_chType;
		}
		if (strcmp(temp, "wilc_attr_oper_ch*") == 0)
		{
			*returnType = pwilc_attr_oper_chType;
		}
		if (strcmp(temp, "wilc_ch_list_elem") == 0)
		{
			*returnType = wilc_ch_list_elemType;
		}
		if (strcmp(temp, "wilc_ch_list_elem*") == 0)
		{
			*returnType = pwilc_ch_list_elemType;
		}

		if (*returnType == ReturnType::ReturnType_unknownType)
		{
			for (int i = 0; i < pSourceCodeFile->UserDefStructNum; i++)
			{
				if (bPoint)
				{
					temp[tempIndex] = 0x0;
				}
				if (strcmp(temp, ((pSourceCodeFile->UserDefStruct)[i])->Name) == 0)
				{
					*returnType = ReturnType::UserDefStructType;
					*returnUserDefStructType = (pSourceCodeFile->UserDefStruct)[i];
				}
				for (int z = 0; z < ((pSourceCodeFile->UserDefStruct)[i])->AnotherNameNum; z++)
				{
					if (strcmp(temp, (((pSourceCodeFile->UserDefStruct)[i])->AnotherName)[z]) == 0)
					{
						*returnType = ReturnType::UserDefStructAnotherNameType;
						*returnUserDefStructType = (pSourceCodeFile->UserDefStruct)[i];
					}
				}
				for (int z = 0; z < ((pSourceCodeFile->UserDefStruct)[i])->PointerNameNum; z++)
				{
					if (strcmp(temp, (((pSourceCodeFile->UserDefStruct)[i])->PointerName)[z]) == 0)
					{
						*returnType = ReturnType::UserDefStructPointerType;
						*returnUserDefStructType = (pSourceCodeFile->UserDefStruct)[i];
					}
				}
			}
		}

		tempInt -= *index;
		delete [] temp;
		return tempInt;
	}

	int ReadOneSourceFile(const char* FilePath)
	{
		int ProprecessLenth;
		int tempIndex = 0;
		LanguageType tempLanguageType;

		file::readOneFile(FilePath, pSourceCode);

		ProprecessLenth = CodeProprecess(pSourceCode);
	#ifdef _DEBUG
		//display(*((char**)pSourceCode), 0, 0);
	#endif

		strcpy_s(pSourceCodeFile->FilePath, FilePath);
		CheckSourceFileType(FilePath, &tempLanguageType);
		pSourceCodeFile->FileType = LinkWithLibrary;          //Ӳ����
		pSourceCodeFile->MacroNum = 0;						  //Ӳ����
		pSourceCodeFile->FunctionNum = 0;
		pSourceCodeFile->VariableNum = 0;
		pSourceCodeFile->FileLanguageType = tempLanguageType;
		InitSourceFileLanguageCharacterInfo(pSourceCodeFile, tempLanguageType);

		/*if((*((char**)pSourceCode))[tempIndex])*/

		return 1;
	}

	//����-1��ʾδ���ҵ��������������ֱ�ʾ���ҵ�Ŀ��token
	int FindCodeElementsNo(char* target, char* token, char*** pPar, int ParNum)
	{
		char tempNumber[5];

		for (int i = 0; i < pInterMediateArray->ArrayNum; i++)
		{
			for (int z = 0; z < pInterMediateArray->Array[i]->CodeElementsNum; z++)
			{
				if (!strcmp(target, ((pInterMediateArray->Array)[i]->CodeElements)[z].Name))
				{
					strcpy(token, pInterMediateArray->Array[i]->Token);
					IntToStr(z, tempNumber);
					strcat(token, "_");
					strcat(token, tempNumber);
					return i;
				}
			}
		}

		for (int i = 0; i < pSourceCodeFile->FunctionNum; i++)
		{
			if (!strcmp(target, ((pSourceCodeFile->Function)[i])->FunctionName))
			{
				strcpy(token, "USERDEFFUNC_");
				IntToStr(i, tempNumber);
				strcat(token, tempNumber);
				return i;
			}
		}

		for (int i = 0; i < ParNum; i++)
		{
			if (!strcmp(target, (pPar[i])[0]))
			{
				strcpy(token, (pPar[i])[1]);
				return -2;
			}
		}
		strcpy(token, target);
		return -1;
	}

	//����-1��ʾû���ҵ�
	int CheckElement(void** Code, int* index, char* Name, bool* bPar, char* pPar, bool* bPro, char* pPro, char* token, char*** pParArray, int ParNum)
	{
		int tempIndex;
		int tempIndex2 = 0;
		char tempCode;
		char* tempSubCode;
		char** tempInputCode;
		int tempLBracket = 0;
		int tempRBracket = 0;
		int i;
		bool tempbPar = false;
		bool bFirst = true;
		bool bProfix = false;
		tempInputCode = new char*;
		tempSubCode = new char[100];

		tempIndex = *index;
		*bPar = false;
		*bPro = false;

		memset(tempSubCode, 0x0, 100);

		while ((*((char**)Code))[tempIndex] != 0x0)
		{
			tempCode = (*((char**)Code))[tempIndex - 1];

			if (tempCode == '(')
			{
				if (tempIndex == 0)
				{
					*bPro = true;
					bProfix = true;
					bFirst = false;
				}
				tempLBracket++;
			}
			if (tempCode == ')')
			{
				tempRBracket++;
				if (tempLBracket == tempRBracket)
				{
					if (tempbPar)
					{
						pPar[tempIndex2++] = ')';
						pPar[tempIndex2] = 0x0;
					}
					if (bProfix)
					{
						pPro[tempIndex2++] = ')';
						pPro[tempIndex2] = 0x0;
						tempIndex2 = 0;
						bProfix = false;
						bFirst = true;
					}
					tempLBracket = 0;
					tempRBracket = 0;
					tempbPar = false;
				}
			}
			if ((*((char**)Code))[tempIndex] == '(' && CheckNamableCharacter(&tempCode) && bFirst)
			{
				for (i = 0; tempIndex - 1 - i >= 0; i++)
				{
					if (CheckNamableCharacter(&((*((char**)Code))[tempIndex - 1 - i])))
					{
						tempSubCode[i] = (*((char**)Code))[tempIndex - 1 - i];
					}
				}
				*tempInputCode = tempSubCode;
				strcpy(Name, tempSubCode);
				CodeTransposition((void**)&tempSubCode, strlen(tempSubCode) - 1);
				//CodeTransposition((void**)tempInputCode, strlen(tempSubCode) - 1);
				*bPar = true;
				tempbPar = true;
				bFirst = false;
				tempIndex++;
				continue;
			}
			tempIndex++;
			if (tempbPar)
			{
				pPar[tempIndex2++]= tempCode;
			}
			if (bProfix)
			{
				pPro[tempIndex2++] = tempCode;
			}
		}

		return FindCodeElementsNo(tempSubCode, token, pParArray, ParNum);
	}

	int TranslateSubCode(void** Code, int* index, char* SubCode, char*** pPar, int ParNum)
	{
		int tempIndex = 0;
		int tempLength = 0;
		int** tempBracket;
		int tempBracketNum = 0;
		int tempBracketNo = 0;
		char tempCode;
		bool bName = false;
		int temp = 0;
		int tempIndex2 = 0;
		char* tempSubCode;
		int tempLBracketNo = 0;
		int tempRBracketNo = 0;
		bool btempBracket = false;
		char tempName[50];
		bool btempPar;
		char ptempPar[20];
		bool btempPro;
		char ptempPro[20];
		char temptoken[100];
		tempBracket = new int* [10];
		tempSubCode = new char[100];
		tempIndex = *index;
		for (int i = 0; i < 10; i++)
		{
			tempBracket[i] = new int[3];
		}

		tempLength = strlen(*(char**)Code);
		while (tempIndex < tempLength)
		{
			if (CheckNamableCharacter(&(*(char**)Code)[tempIndex]))
			{
				tempSubCode[tempIndex2++] = (*(char**)Code)[tempIndex];
				bName = true;
			}
			else
			{
				if (bName)
				{
					tempSubCode[tempIndex2] = 0x0;
					tempIndex2 = 0;
					bName = false;
					FindCodeElementsNo(tempSubCode, temptoken, pPar, ParNum);
					strcpy(&(SubCode[temp]), temptoken);
					temp += strlen(temptoken);
				}
				SubCode[temp++] = (*(char**)Code)[tempIndex];
			}
			tempIndex++;
		}
		if (bName)
		{
			tempSubCode[tempIndex2] = 0x0;
			FindCodeElementsNo(tempSubCode, temptoken, pPar, ParNum);
			strcpy(&(SubCode[temp]), temptoken);
			temp += strlen(temptoken);
		}
		SubCode[temp] = 0x0;
		
		for (int i = 0; i < 10; i++)
		{
			delete [] tempBracket[i];
		}
		delete [] tempSubCode;
		delete [] tempBracket;

		return 1;
	}

	int IntToStr(int n, char* str)
	{
		int h = n / 100;
		int t = (n % 100) / 10;
		int o = (n % 10);
		str[0] = h + 48;
		str[1] = t + 48;
		str[2] = o + 48;
		str[3] = 0x0;
		return 1;
	}

	int Translate(void** Code, int* index)
	{
		int tempIndex = 0;
		int temp = 1;
		char** tempInputCode;
		int tempCodeLineNo = 0;
		int tempFunctionNo = 0;
		int tempCodeLineLength = 0;
		int tempCodeElementsNo = -1;
		char tempCode;
		char tempSubCode[100];
		int elementNo = -1;
		int x;
		char temptoken[50];
		int tempMiddleCode = 0;
		int tempCodeLength = 0;
		char tempName[100];
		char tempPro[20];
		char tempPar[100];
		bool btempPro = false;
		bool btempPar = false;
		char tempFuncVar[20][2];
		char*** ptempPar;
		char tempNumber[5];
		int tempParNum = 0;
		int tempFuncVarNo = 0;
		char* ptempbuff;
		ptempPar = new char** [20];
		tempInputCode = new char*;
		for (int i = 0; i < 20; i++)
		{
			ptempPar[i] = new char* [2];
			for (int z = 0; z < 2; z++)
			{
				(ptempPar[i])[z] = new char[20];
			}
		}

		for (int i = 0; i < pSourceCodeFile->VariableNum; i++)
		{
			strcpy((ptempPar[tempParNum])[0], ((pSourceCodeFile->Variable)[i])->Name);
			strcpy((ptempPar[tempParNum])[1], "Var_");
			IntToStr(i, tempNumber);
			strcat((ptempPar[tempParNum])[1], tempNumber);
			tempParNum++;
		}

		for (int i = 0; i < pSourceCodeFile->FunctionNum; i++)
		{
			pSourceCodeFile->ReadFunctionNo = 0;
			for (int z = 0; z < ((pSourceCodeFile->Function)[i])->VariableNum; z++)
			{
				strcpy((ptempPar[tempParNum])[0], ((((pSourceCodeFile->Function)[i])->Variable)[z])->Name);
				strcpy((ptempPar[tempParNum])[1], "Var_");
				IntToStr(z + pSourceCodeFile->VariableNum, tempNumber);
				strcat((ptempPar[tempParNum])[1], tempNumber);
				tempParNum++;
			}
			for (int z = 0; z < (pSourceCodeFile->Function[i])->CodeLineNum; z++)
			{
				ptempbuff = ((pSourceCodeFile->Function[i])->CodeLine[z])->buffer;
				TranslateSubCode((void**)(&ptempbuff), &tempIndex, (((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer, ptempPar, tempParNum);
				//tempIndex = 0;
				///*memset(tempSubCode, 0x0, 20);*/
				//x = 0;
				//tempMiddleCode = 0;

				//tempCodeLineLength = strlen(((pSourceCodeFile->Function[i])->CodeLine[z])->buffer);
				////for (int x = 0; x < tempCodeLineLength; x++)
				////{
				////	if ((((pSourceCodeFile->Function[i])->CodeLine[z])->PSyntaxCode)->buffer[x] == ' ')
				////	{
				////		tempIndex = x + 1;
				////	}
				////	tempCode = (((pSourceCodeFile->Function[i])->CodeLine[z])->PSyntaxCode)->buffer[x - 1];
				////	if ((((pSourceCodeFile->Function[i])->CodeLine[z])->PSyntaxCode)->buffer[x] == '(' && CheckNamableCharacter(&tempCode))
				////	{
				////		for (int c = tempIndex; c < x; c++)
				////		{
				////			tempSubCode[c - tempIndex] = (((pSourceCodeFile->Function[i])->CodeLine[z])->PSyntaxCode)->buffer[c];
				////		}

				////		tempCodeElementsNo = FindCodeElementsNo(tempSubCode);
				////	}

				////	/*(((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)*/
				////}

				//while (x < tempCodeLineLength)
				//{
				//	memset(tempSubCode, 0x0, 100);
				//	*tempInputCode = ((pSourceCodeFile->Function[i])->CodeLine[z])->buffer;
				//	if (CheckCodeBlank((void**)tempInputCode, &x) != -1)
				//	{
				//		tempCodeLength = DivisionCodeByBlank((void**)tempInputCode, &x, tempSubCode);
				//		x += tempCodeLength;
				//	}
				//	else
				//	{
				//		tempCodeLength = strlen(&(((pSourceCodeFile->Function[i])->CodeLine[z])->buffer[x]));
				//		strcpy(tempSubCode, &(((pSourceCodeFile->Function[i])->CodeLine[z])->buffer[x]));
				//		x = x + tempCodeLength + 1;
				//	}

				//	*tempInputCode = tempSubCode;
				//	memset(tempName, 0x0, 100);
				//	memset(tempPar, 0x0, 100);
				//	memset(tempPro, 0x0, 20);
				//	elementNo = CheckElement((void**)tempInputCode, &temp, tempName, &btempPar, tempPar, &btempPro, tempPro, temptoken);
				//	if (elementNo != -1)
				//	{
				//		if (btempPro)
				//		{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), tempPro);
				//			tempMiddleCode += strlen(tempPro);
				//		}
				//	}
				//	switch (elementNo)
				//	{
				//	/*case -1:
				//	{
				//		strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), tempSubCode);
				//		tempMiddleCode += tempCodeLength;
				//		break;
				//	}
				//	case 0:
				//	{
				//		strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "Input");
				//		tempMiddleCode += 5;
				//		break;
				//	}
				//	case 1:
				//	{
				//		strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "Sanit_f");
				//		tempMiddleCode += 7;
				//		break;
				//	}
				//	case 2:
				//	{
				//		strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "ss");
				//		tempMiddleCode += 2;
				//		break;
				//	}
				//	case 3:
				//	{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "Type_chk");
				//			tempMiddleCode += 8;
				//			break;
				//		}
				//	case 4:
				//	{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "char5");
				//			tempMiddleCode += 5;
				//			break;
				//		}
				//	case 5:
				//	{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "char6");
				//			tempMiddleCode += 5;
				//			break;
				//		}
				//	case 6:
				//	{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "cond");
				//			tempMiddleCode += 4;
				//			break;
				//		}
				//	case 7:
				//	{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "conc");
				//			tempMiddleCode += 4;
				//			break;
				//		}
				//	case 8:
				//	{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "var");
				//			tempMiddleCode += 3;
				//			break;
				//		}
				//	case 9:
				//	{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "Var_vv");
				//			tempMiddleCode += 6;
				//			break;
				//		}
				//	case 10:
				//	{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), "miss");
				//			tempMiddleCode += 4;
				//			break;
				//		}*/
				//	default:
				//	{
				//		strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), temptoken);
				//		tempMiddleCode += strlen(temptoken);
				//		break;
				//	}
				//	}
				//	if (elementNo != -1)
				//	{
				//		if (btempPar)
				//		{
				//			strcpy(&((((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode]), tempPar);
				//			tempMiddleCode += strlen(tempPar);
				//		}
				//	}

				//	while (((pSourceCodeFile->Function[i])->CodeLine[z])->buffer[x] == ' ')
				//	{
				//		(((pSourceCodeFile->Function[i])->CodeLine[z])->PMiddleCode)->buffer[tempMiddleCode++] = ' ';
				//		x++;
				//	}
				//}
				//tempCodeElementsNo = FindCodeElementsNo(tempSubCode);
			}
			tempParNum -= ((pSourceCodeFile->Function)[i])->VariableNum;
		}

		for (int i = 0; i < 20; i++)
		{
			for (int z = 0; z < 2; z++)
			{
				delete [] (ptempPar[i])[z];
			}
			delete [] ptempPar[i];
		}
		delete tempInputCode;
		delete[] ptempPar;

		return 1;
	}

	//�˺��������¸�ֵBraceNumΪ0
	int GetBrace(void** Code, int* index, int** RNO, int** LNO, int* RBraceNum,int* LBraceNum)
	{
		int tempIndex = 0;
		int tempRNO = 0;
		int tempLNO = 0;
		*RBraceNum = *LBraceNum = 0;
		while (*LBraceNum == 0 || (*LBraceNum) != (*RBraceNum))
		{
			if ((*((char**)Code))[*index + tempIndex] == '{')
			{
				*(LNO[tempLNO++]) = tempIndex;
				(*LBraceNum)++;
			}
			if ((*((char**)Code))[*index + tempIndex] == '}')
			{
				*(RNO[tempRNO++]) = tempIndex;
				(*RBraceNum)++;
			}
			tempIndex++;
		}

		return tempIndex;
	}

	//return -1 == error, ��������᷵�� Code ��*index��ʼ�ĵ�һ��()�е����ݣ����ص���ʽΪ�������ݵ���ʼλ�ô����start��end��
	int GetBracketContent(void** Code, int* index, int* start, int* end)
	{
		int tempIndex = 0;
		int tempLBracket = 0;
		int tempRBracket = 0;

		if ((*((char**)Code))[*index + tempIndex] == '(' && (*((char**)Code))[*index + tempIndex + 1] == ')')
		{
			return -1;
		}
		while ((*((char**)Code))[*index + tempIndex] == ' ')
		{
			tempIndex++;
		}
		if ((*((char**)Code))[*index + tempIndex] == '(')
		{
			tempIndex++;
			tempLBracket++;
		}
		else
		{
			return -1;
		}
		*start = *index + tempIndex;
		while (tempLBracket != tempRBracket)
		{
			if ((*((char**)Code))[*index + tempIndex] == ')')
			{
				tempRBracket++;
			}
			if ((*((char**)Code))[*index + tempIndex] == '(')
			{
				tempLBracket++;
			}
			tempIndex++;
		}
		*end = *index + tempIndex - 2;

		return tempIndex;
	}

	//���ش�start��end�м������BYTE
	int GetSubCode(void** Code, int start, int end, void** SubCode)
	{
		int i = 0;
		for (; i <= end - start; i++)
		{
			(*((char**)SubCode))[i] = (*((char**)Code))[start + i];
		}

		return i;
	}

	//return -1 == error �˺������� { ����λ��
	int CheckBrace(void** Code, int* index)
	{
		int tempIndex = 0;
		while ((*((char**)Code))[*index + tempIndex] != '{')
		{
			if ((*((char**)Code))[*index + tempIndex] == ' ' || ((*((char**)Code))[*index + tempIndex] == '\r' && (*((char**)Code))[*index + tempIndex + 1] == '\n') || ((*((char**)Code))[*index + tempIndex] == '\n' && (*((char**)Code))[*index + tempIndex - 1] == '\r'))
			{
				tempIndex++;
			}
			else
			{
				return -1;
			}
		}

		return tempIndex;
	}

	int GetLineFeedNum(void** Code, int start, int end)
	{
		int tempIndex = 0;
		for (int i = start; i <= end; i++)
		{
			if (((*(char**)Code))[i] == '\r' && ((*(char**)Code))[i + 1] == '\n')
				tempIndex++;
		}

		return tempIndex;
	}

	//������Ƭ���Ƿ�Ϊ��������/��ֵ����
	bool CheckVarDefen(void** Code, int CodeLength)
	{
		int tempNum1 = 0;
		int tempNum2 = 0;
		char tempStr[10];

		//�˴�������bug:���� for(;i == z;i = a)
		//					{
		//						a++;
		//                  }
		strcpy(tempStr, "=");
		tempNum1 = CheckAscii(Code, CodeLength, tempStr);
		strcpy(tempStr, "==");
		tempNum2 = CheckAscii(Code, CodeLength, tempStr);
		if (tempNum1 > tempNum2 * 2)
		{
			return true;
		}

		tempNum1 = 0;
		tempNum2 = 0;
		strcpy(tempStr, "++");
		tempNum1 = CheckAscii(Code, CodeLength, tempStr);
		strcpy(tempStr, "--");
		tempNum2 = CheckAscii(Code, CodeLength, tempStr);
		if (tempNum1 > 0 || tempNum2 > 0)
		{
			return true;
		}

		return false;
	}

	//���д����bug��û�жԱ����Ĺ�������ܺõĶ��壬����: int i; for(int i){};����0��ʾδ�ҵ�������1��ʾ��CodeLine�У�����2��ʾ��Function�У�����3��ʾȫ��
	int FindDefindedValue(char* Name, PVariable* pVar, bool bInFunc, PSourceFunction pFunc, bool bInCodeLine, PSourceLine pSourceLine)
	{
		int tempIndex = 0;

		if (bInCodeLine)
		{
			for (int i = 0; i < pSourceLine->VariableNum; i++)
			{
				if (strcmp(((pSourceLine->Variable)[i])->Name, Name) == 0)
				{
					*pVar = (pSourceLine->Variable)[i];
					return 1;
				}
			}
		}
		if (bInFunc)
		{
			for (int i = 0; i < pFunc->VariableNum; i++)
			{
				if (strcmp(((pFunc->Variable)[i])->Name, Name) == 0)
				{
					*pVar = (pFunc->Variable)[i];
					return 2;
				}
			}
		}

		for (int i = 0; i < pSourceCodeFile->VariableNum; i++)
		{
			if (strcmp(((pSourceCodeFile->Variable)[i])->Name, Name) == 0)
			{
				*pVar = (pSourceCodeFile->Variable)[i];
				return 3;
			}
		}
		*pVar = NULL;

		return 0;
	}

	//������궨��/��������/��������/��������/��������,�﷨���ûд��
	int CheckCodeLineType(void** Code, bool bSyntax, int CodeLength)
	{
		Sign LastSign, SecondLastSign;
		char tempStr[10];
		int temp = 0;
		int tempIndex = 0;
		int tempIndex1 = 0;
		ProfixType tempProfixType;
		ReturnType tempReturnType;
		PUserDefStruct temppUserDefStruct;
		TypedefType tempTypedefReturn;

		RemoveStringEndBlank(*(char**)Code);

		if (!bSyntax)
		{
			//�궨����
			if ((*((char**)Code))[0] == '#')
			{
				return CodeLineType::MacroType;
			}
			if ((*((char**)Code))[0] == '{')
			{
				return CodeLineType::LBraceType;
			}
			if ((*((char**)Code))[0] == '}')
			{
				return CodeLineType::RBraceType;
			}

			//����Ƿ�Ϊ��������
			LastSign = CheckCodeSign(Code, CodeLength - 1);
			SecondLastSign = CheckCodeSign(Code, CodeLength - 2);
			if (LastSign == Sign::Rbracket)
			{
				return CodeLineType::FunctionDefine;
			}

			//����Ƿ�Ϊ��������
			if (CheckVarDefen(Code, CodeLength))
			{
				return CodeLineType::VariableDefine;
			}

			tempIndex = CheckProfixType(Code, &temp, &tempProfixType);
			tempIndex1 = CheckReturnType(Code, &temp, &tempReturnType, &temppUserDefStruct);

			switch (tempProfixType)
			{
			case ProfixType_unknownType:
				break;
			case staticType:
				break;
			case typedefType:
			{
				temp += tempIndex;
				MoveCodeIndexUntillNoBlank(Code, &temp);
				CheckTypedefType(Code, &temp, &tempTypedefReturn);
				switch (tempTypedefReturn)
				{
				case TypedefType_unknownType:
				{
					return CodeLineType::CodeLineType_unknownType;
				}
				case StructType:
				{
					return CodeLineType::StructDefType;
				}
				case UnionType:
				{
					return CodeLineType::UnionDefType;
				}
				default:
					break;
				}
				break;
			}
			case staticconstType:
				break;
			case namespaceType:
			{
				return CodeLineType::namespaceDefType;
				break;
			}
			case usingType:
			{
				return CodeLineType::usingKeywordType;
				break;
			}
			case usingnamespaceType:
			{
				return CodeLineType::usingnamespaceKeywordType;
				break;
			}
			case externType:
			{
				return CodeLineType::externKeywordType;
				break;
			}
			default:
				break;
			}

			/*if (tempProfixType == ProfixType::typedefType)
			{
				temp += tempIndex;
				MoveCodeIndexUntillNoBlank(Code, &temp);
				CheckTypedefType(Code, &temp, &tempTypedefReturn);
				switch (tempTypedefReturn)
				{
				case TypedefType_unknownType:
				{
					return CodeLineType::CodeLineType_unknownType;
				}
				case StructType: 
				{
					return CodeLineType::StructDefType;
				}
				case UnionType:	
				{
					return CodeLineType::UnionDefType;
				}
				default:
					break;
				}
			}*/

			//����Ƿ�Ϊ��������������bug��������a+b��;
			strcpy(tempStr, "(");
			if (CheckAscii(Code, CodeLength, tempStr) > 0)
			{
				if (tempProfixType != ProfixType::ProfixType_unknownType || tempReturnType != ReturnType::ReturnType_unknownType)
				{
					return CodeLineType::FunctionDeclare;
				}
				else
				{
					return CodeLineType::OnlyFunctionCall;
				}
			}

			//����Ƿ�Ϊ��������
			if (tempProfixType != ProfixType::ProfixType_unknownType || tempReturnType != ReturnType::ReturnType_unknownType)
			{
				return CodeLineType::VariableDeclare;
			}
			else
			{
#ifdef _DEBUG
				std::cout << "CheckCodeLineType Fail, content:\n";
				std::cout << *(char**)Code << std::endl;
#endif
				return CodeLineType::CodeLineType_unknownType;
			}
		}
		else
		{

		}

		return CodeLineType::CodeLineType_unknownType;
	}

	//��ȡ��Χ�����п��õ����֣������������������⺯�������ؼ��֣�int�������п�Ϊ���ֵ��б�,�˺����Ὣ�»�ȡ�����ַ���Name���������,Ҳ���ȡ����[�е�����](������'['��']')
	int GetName(void** Code, int* index, int start, int end, char** Name, int* NameNum, char** Array, int* ArrayNum,int* ArrayIndex)
	{
		int tempIndex = 0;
		bool bName = false;
		bool bSquareBracket = false;
		char tempSubCode[20];
		int tempSubCodeNo = 0;
		int tempNum = 0;
		int temp = 0;
		int LSquareBrackets = 0;
		int RSquareBrackets = 0;

		for (int i = start; i <= end; i++)
		{
			if (CheckNamableCharacter(&((*(char**)Code)[i])) && !bSquareBracket)
			{
				Name[*NameNum + tempNum][tempIndex++] = (*(char**)Code)[i];
				bName = true;
			}
			else
			{
				if ((*(char**)Code)[i] == '[')
				{
					LSquareBrackets++;
					bSquareBracket = true;
					ArrayIndex[*ArrayNum] = tempNum;                //fix bug at 22.10.1 /*tempNum - 1;*/
				}
				if ((*(char**)Code)[i] == ']')
				{
					RSquareBrackets++;
					(Array[*ArrayNum])[tempSubCodeNo] = 0x0;
					//tempSubCode[tempSubCodeNo] = 0x0;
					tempSubCodeNo = 0;
					//strcpy(Array[*ArrayNum], tempSubCode);
					bSquareBracket = false;
					(*ArrayNum)++;
					if (LSquareBrackets == RSquareBrackets)
					{
						LSquareBrackets = 0;
						RSquareBrackets = 0;
					}
					else
					{
						printf("Get Name Error\n");
					}
				}
				if (bName)
				{
					Name[*NameNum + tempNum][tempIndex] = 0x0;
					tempNum++;
					tempIndex = 0;
					bName = false;
				}
			}
			if (bSquareBracket)
			{
				if ((*(char**)Code)[i] != '[')
				{
					(Array[*ArrayNum])[tempSubCodeNo++] = (*(char**)Code)[i];
				}
			}
			if (LSquareBrackets - RSquareBrackets > 1 || LSquareBrackets - RSquareBrackets < 0)
			{
				std::cout << "error" << std::endl;
			}
		}
		//����ַ������һ���ַ��Ƿ�Ϊ��д�ַ����������������һ��Nameû����ֹ�ַ�
		if (CheckNamableCharacter(&((*(char**)Code)[end])))
		{
			Name[*NameNum + tempNum][tempIndex] = 0x0;
			tempNum++;
		}

		temp = tempNum + *NameNum;
		tempNum -= AdjustName(Name, &temp, *NameNum, temp - 1);

		(*NameNum) += tempNum;

		DeleteStrArrayRepetStr(Name, NameNum);

		return tempNum;
	}

	//��ȡ�ַ��������п��õ����֣������������������⺯�������ؼ��֣�int�������п�Ϊ���ֵ��б�,�˺����Ὣ�»�ȡ�����ַ���Name���������
	int GetSubCodeName(void** Code, int* index, char** Name, int* NameNum, char** Array, int* ArrayNum, int* ArrayIndex)
	{
		int tempCodeLength = 0;
		int tempNameNum = 0;

		tempCodeLength = strlen(&((*(char**)Code)[*index]));
		tempNameNum = GetName(Code, index, *index, *index + tempCodeLength - 1, Name, NameNum, Array, ArrayNum, ArrayIndex);

		return tempNameNum;
	}

	//�ӱ����ַ�������ȡ����Ӧ�����֡����͡�����ֵ�ȣ����ӵĴ������ˣ�(int)(a + 4)
	int GetVariableName(void** Code, int* index, char* Name, char* Type, char* Array)
	{
		int tempIndex = 0;
		bool btempName = false;
		bool btempType = false;
		bool btempArray = false;
		int temp = 0;

		while ((*(char**)Code)[*index + tempIndex] != 0x0)
		{
			if ((*(char**)Code)[*index + tempIndex] == '(' && !btempType && !btempArray && !btempName)
			{
				btempType = true;
				temp = 0;
			}
			else if ((*(char**)Code)[*index + tempIndex] == ')' && btempType)
			{
				btempType = false;
				Type[temp] = 0x0;
			}
			else if ((*(char**)Code)[*index + tempIndex] == '[' && !btempType && !btempArray && !btempName)
			{
				btempArray = true;
				temp = 0;
			}
			else if ((*(char**)Code)[*index + tempIndex] == ']' && btempArray)
			{
				btempArray = false;
				Array[temp] = 0x0;
			}
			else if (CheckNamableCharacter(&(*(char**)Code)[*index + tempIndex]) && !btempType && !btempArray && !btempName)
			{
				btempName = true;
				temp = 0;
			}
			else if (!CheckNamableCharacter(&(*(char**)Code)[*index + tempIndex]) && btempName)
			{
				btempName = false;
				Name[temp] = 0x0;
			}

			if (btempType)
			{
				Type[temp++] = (*(char**)Code)[*index + tempIndex];
			}
			else if (btempArray)
			{
				Array[temp++] = (*(char**)Code)[*index + tempIndex];
			}
			else if (btempName)
			{
				Name[temp++] = (*(char**)Code)[*index + tempIndex];
			}

			tempIndex++;
		}

		return 1;
	}

	//�������ô���һ�д���
	//�Կո񼰻����ж��Ƿ�ָ��ַ����������ո���зָ��һ�����ַ������������Ի��зָ�������ַ����н�β��;��β����������ɾ��;
	//���жϷָ��ַ����Ĺ����м�¼( �� )����Ŀ���ָ���ַ����� ( �� ) ��Ŀ����ƥ�䣬��ƥ����������ָ���Ǳ��������ո���зָ��˼��
	//�������ָ�����ַ�����ǰһ�����ַ�����ϣ������鿴�� �ͣ�����Ŀ�Ƿ�ƥ�䣬��ƥ���������ƥ��������Ϊһ�����ַ�����
	//�ѵ������ĺ��������Ƚ����������ַ����ĵ�һ�����ѵ��������Ϊ�����е����ݺͣ����������,��Ϊ���������������������Ϊ������/������/[]����������������������������������һ�����ݽṹ����
	//�����е�����Ϊ���ַ��������ָ�ֱ��û�У���Ϊֹ�����е���ɿ���ΪԤ���壬�������ͣ����������������������
	//��⣨����Ӧ����ĺ�������⣨��Ӧ�ģ�����Ϊ��ͨ�������һ����⵽�ģ����Ƿ�Ϊ��������Ǿͱպϣ����ǵݹ����
	int DivisionCode(void** Code, int* index, PSubCode pSubCode, int* SubCodeNum)
	{
		int tempIndex = 0;
		int tempLBracket = 0;
		int tempRBracket = 0;
		char tempSubCode[50];
		int tempSubCodeIndex = 0;

		while ((*(char**)Code)[*index + tempIndex] != 0x0)
		{
			if ((*(char**)Code)[*index + tempIndex] == '(')
			{
				tempLBracket++;
			}
			if ((*(char**)Code)[*index + tempIndex] == ')')
			{
				tempRBracket++;
			}
			if ((*(char**)Code)[*index + tempIndex] == ' ' || (*(char**)Code)[*index + tempIndex] == '\r' && (*(char**)Code)[*index + tempIndex] == '\n' || (*(char**)Code)[*index + tempIndex + 1] == 0x0)
			{
				if (tempLBracket == tempRBracket)
				{
					tempSubCode[tempSubCodeIndex] = 0x0;
					for (int z = 1; tempSubCode[tempSubCodeIndex - z] == ';'; z++)
					{
						tempSubCode[tempSubCodeIndex - z] = 0x0;
					}
					if (tempLBracket > 0)
					{
						(pSubCode[*SubCodeNum]).bSubCode = true;
						(pSubCode[*SubCodeNum]).subCodeNum = 0;
						InitSubCodeArray((pSubCode[*SubCodeNum]).subCode);

						if (tempSubCode[0] == '(' && tempSubCode[tempSubCodeIndex - 1] == ')')
						{
							if (*SubCodeNum - 1 >= 0)
							{
								if ((pSubCode[*SubCodeNum - 1]).Bracket == 1)
								{
									(pSubCode[*SubCodeNum - 1]).Bracket = 2;
								}
								else
								{
									(pSubCode[*SubCodeNum - 1]).Bracket = -1;
								}
							}
							(pSubCode[*SubCodeNum]).Bracket = 0;
							if (*SubCodeNum + 1 <= 10)
							{
								(pSubCode[*SubCodeNum + 1]).Bracket = 1;
							}
						}
					}
					else
					{
						(pSubCode[*SubCodeNum]).bSubCode = false;
					}
					strcpy((pSubCode[*SubCodeNum]).buff, tempSubCode);

					*SubCodeNum++;
					tempLBracket = 0;
					tempRBracket = 0;
					tempSubCodeIndex = 0;
					tempIndex++;

					continue;
				}
				else
				{
					if ((*(char**)Code)[*index + tempIndex + 1] == 0x0)
					{
						std::cout << "division code error" << std::endl;
					}
				}
			}

			tempSubCode[tempSubCodeIndex++] = (*(char**)Code)[*index + tempIndex];
			tempIndex++;
		}

		return tempIndex;
	}

	int InitSubCodeArray(PSubCode subCode)
	{
		for (int i = 0; i < 10; i++)
		{
			((subCode[i]).buff)[0] = 0x0;
			(subCode[i]).subCode = NULL;
			(subCode[i]).subCodeNum = 0;
			(subCode[i]).bSubCode = false;
		}

		return 1;
	}

	//�ѣ������Ƚ��ԣ���ͷ�Ҷ�Ӧ)��β�ģ����ѵ���ֱ��������ͷ�����÷ָ������Ƿ񻹿������ַ����ָ����1��ʾû�����ַ����ָ�
	//�������ַ���ֵ����1�����ַ�������������������ѣ�������������1���ѵ���һ�������������Ϊ�������С��ҵ����ַ������������к����ַ����ָ�Ĺ����м���Ƿ��У�����������
	//���ַ����Դ������ַ���
	int ProcessSubCodeBrackets(PSubCode pSubCode)
	{
		int tempLength = 0;
		int tempIndex = 0;
		int tempIndex2 = 0;
		int tempSubCodeNo = 0;
		int tempBrackerNum = 0;
		int** tempBracketIndex;
		int tempLBracket = 0;
		int tempRBracket = 0;
		int i;

		tempBracketIndex = new int* [10];
		for (i = 0; i < 10; i++)
		{
			tempBracketIndex[i] = new int[3];
		}

		tempLength = strlen(pSubCode->buff);

		GetBracketIndex((void**)&(pSubCode->buff), &tempIndex, tempBracketIndex, &tempBrackerNum);

		while (tempBracketIndex[tempIndex2++][0] == 1 && tempBracketIndex[tempIndex2++][1] == 0 && tempBracketIndex[tempIndex2++][2] == tempLength - 1)
		{
			for (i = 0; i < tempLength - 2; i++)
			{
				(pSubCode->buff)[i] = (pSubCode->buff)[i + 1];
			}
			(pSubCode->buff)[i] = 0x0;
			tempLength -= 2;
			tempBrackerNum--;
		}

		if (tempBrackerNum > 0)
		{
			//pSubCode->subCode = new SubCode[10];
			//pSubCode->bSubCode = true;
			//pSubCode->subCodeNum = 0;

			DivisionCode((void**)(&(pSubCode->buff)), &tempIndex, pSubCode->subCode, &(pSubCode->subCodeNum));
			if (pSubCode->subCodeNum == 1)
			{
				tempIndex2 = 0;
				tempSubCodeNo = 0;

				for (i = 0; i < tempLength; i++)
				{
					if ((pSubCode->buff)[i] == '(' || (pSubCode->buff)[i] == ')')
					{
						if ((pSubCode->buff)[i] == '(')
						{
							tempLBracket++;
						}
						else
						{
							tempRBracket++;
						}
						if (tempLBracket != tempRBracket && tempLBracket != 1)
						{
							(((pSubCode->subCode)[tempSubCodeNo]).buff)[tempIndex2++] = (pSubCode->buff)[i];

							continue;
						}
						if (i == 0)
						{
							continue;
						}
						if ((pSubCode->buff)[i] == '(')
						{
							if (((pSubCode->subCode)[tempSubCodeNo]).Bracket == 1)
							{
								((pSubCode->subCode)[tempSubCodeNo]).Bracket = 2;
							}
							else
							{
								((pSubCode->subCode)[tempSubCodeNo]).Bracket = -1;
							}
						}
						else
						{
							((pSubCode->subCode)[tempSubCodeNo]).Bracket = 0;
							((pSubCode->subCode)[tempSubCodeNo + 1]).Bracket = 1;
						}
						if ((pSubCode->buff)[i] == ')' && tempLBracket != 1)
						{
							((pSubCode->subCode)[tempSubCodeNo]).bSubCode = true;
							(((pSubCode->subCode)[tempSubCodeNo]).buff)[tempIndex2] = 0x0;
							ProcessSubCodeBrackets(&(pSubCode->subCode)[tempSubCodeNo]);
						}
						else
						{
							((pSubCode->subCode)[tempSubCodeNo]).bSubCode = false;
							free(((pSubCode->subCode)[tempSubCodeNo]).subCode);
							((pSubCode->subCode)[tempSubCodeNo]).subCodeNum = 0;
						}
						if ((pSubCode->buff)[i] == ')')
						{
							tempLBracket = 0;
							tempRBracket = 0;
						}

						(((pSubCode->subCode)[tempSubCodeNo]).buff)[tempIndex2] = 0x0;
						tempSubCodeNo++;
						tempIndex2 = 0;

						continue;
					}
					(((pSubCode->subCode)[tempSubCodeNo]).buff)[tempIndex2++] = (pSubCode->buff)[i];
				}
				if ((pSubCode->buff)[tempLength - 1] != ')')
				{
					((pSubCode->subCode)[tempSubCodeNo]).bSubCode = false;
					free(((pSubCode->subCode)[tempSubCodeNo]).subCode);
					((pSubCode->subCode)[tempSubCodeNo]).subCodeNum = 0;
					((pSubCode->subCode)[tempSubCodeNo]).Bracket = 1;
				}
				else
				{
					tempSubCodeNo--;
				}
				pSubCode->subCodeNum = tempSubCodeNo;
			}
			else
			{
				for (i = 0; i < pSubCode->subCodeNum; i++)
				{
					if (((pSubCode->subCode)[i]).bSubCode)
					{
						ProcessSubCodeBrackets(&(pSubCode->subCode)[i]);
					}
				}
			}
		}

		return 1;
	}

	//��ȡ�����ĺ���������������ǰ׺
	int GetFunctionNameAndPara(void** Code, int* index, bool bFuncCall, char* Name, PVariable* pVar, int* VarNum, char* Profix)
	{
		int tempIndex = 0;
		bool bName = true;
		bool bVar = false;
		bool bType = true;
		bool bProfix = false;
		bool bArray = false;
		int temp = 0;
		int temp2 = 0;
		int tempVarNo = 0;
		char tempArray[50];
		int tempArrayIndex = 0;
		ReturnType tempReturnType;
		PUserDefStruct temppUserDefStruct;
		PVariable temppVar;

		while ((*(char**)Code)[*index + tempIndex] != ')' && (*(char**)Code)[*index + tempIndex + 1] != 0x0)
		{
			if (tempIndex == 0 && (*(char**)Code)[*index + tempIndex] == '(')    //ԭΪ!=
			{
				bProfix = true;
				tempIndex++;
				continue;
			}
			if (bProfix)
			{
				if ((*(char**)Code)[*index + tempIndex] == ')')
				{
					Profix[temp] = 0x0;
					temp = 0;
					bProfix = false;
				}
				else
				{
					Profix[temp++] = (*(char**)Code)[*index + tempIndex];
				}
				tempIndex++;
				continue;
			}
			if ((*(char**)Code)[*index + tempIndex] == ' ')
			{
				tempIndex++;
				continue;
			}
			if ((*(char**)Code)[*index + tempIndex] == '(' && bName)
			{
				Name[temp] = 0x0;
				bName = false;
				bVar = true;
				temp = 0;
				tempIndex++;
				continue;
			}
			if ((*(char**)Code)[*index + tempIndex] == '.' && bVar)
			{
				tempIndex++;
				continue;
			}
			if ((*(char**)Code)[*index + tempIndex] == ',' && bVar)
			{
				((pVar[tempVarNo])->Name)[temp] = 0x0;
				if (!bArray)
				{
					(pVar[tempVarNo])->bArray = false;
					(pVar[tempVarNo])->bPointerType = false;
					(pVar[tempVarNo])->PointerPointMemSize = 0;
				}
				bArray = false;
				tempVarNo++;
				temp = 0;
				bType = true;
				tempIndex++;
				continue;
			}

			if (bName)
			{
				Name[temp++] = (*(char**)Code)[*index + tempIndex];
			}
			if (bVar)
			{
				(pVar[tempVarNo])->bParameter = true;
				if (bFuncCall)
				{
					(pVar[tempVarNo])->bFunctionCall = true;
					((pVar[tempVarNo])->Name)[temp++]= (*(char**)Code)[*index + tempIndex];
				}
				else
				{
					(pVar[tempVarNo])->bFunctionCall = false;
					if (bType)
					{
						temp2 = *index + tempIndex;
						tempIndex += CheckReturnType(Code, &temp2, &tempReturnType, &temppUserDefStruct);
						(pVar[tempVarNo])->returnType = tempReturnType;
						if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
						{
							(pVar[tempVarNo])->bUserDefStruct = true;
							(pVar[tempVarNo])->ContentNum = temppUserDefStruct->ContentNum;
							(pVar[tempVarNo])->pUserDefStruct = temppUserDefStruct;
						}
						else
						{
							(pVar[tempVarNo])->bUserDefStruct = false;
							(pVar[tempVarNo])->ContentNum = 0;
							(pVar[tempVarNo])->pUserDefStruct = NULL;
						}
						/*(pVar[tempVarNo])->bUserDefStruct = true;*/
						bType = false;
					}
					else
					{
						if (CheckNamableCharacter(&(*(char**)Code)[*index + tempIndex]) && !bArray)
						{
							((pVar[tempVarNo])->Name)[temp++] = (*(char**)Code)[*index + tempIndex];
						}
						else
						{
							if ((*(char**)Code)[*index + tempIndex] == '[')
							{
								bArray = true;
								(pVar[tempVarNo])->bArray = true;
								(pVar[tempVarNo])->bParameter = true;
								tempArrayIndex = 0;
							}
							else if ((*(char**)Code)[*index + tempIndex] == ']')
							{
								tempArray[tempArrayIndex] = 0x0;
								(pVar[tempVarNo])->PointerPointMemSize = GetReturnTypeSize((pVar[tempVarNo])->returnType) * StrToInt(tempArray);
							}
							else if (CheckNamableCharacter(&(*(char**)Code)[*index + tempIndex]))
							{
								tempArray[tempArrayIndex++] = (*(char**)Code)[*index + tempIndex];
							}
							else
							{
								std::cout << "GetFunctionNameAndPara fail \n";
							}
						}
					}
				}
				
			}

			tempIndex++;
		}
		if (temp != 0)
		{
			((pVar[tempVarNo])->Name)[temp] = 0x0;
			tempVarNo++;
		}

		*VarNum = tempVarNo;

		return 1;
	}

	//��������
	int AnalysisCode(void** Code, int* index, PSubCode pSubCode)
	{
		int tempIndex = 0;
		int tempSubCodeNum = 0;
		int temp = 0;

		tempIndex = DivisionCode(Code, &temp, pSubCode, &tempSubCodeNum);

		for (int i = 0; i < tempSubCodeNum; i++)
		{
			if ((pSubCode[i]).bSubCode)
			{
				ProcessSubCodeBrackets(&(pSubCode[i]));
			}
		}

		return 1;
	}

	int GetBracketIndex(void** Code, int* index, int** BracketIndex, int* BracketNum)
	{
		int tempIndex = 0;
		int tempLBracketNum = 0;
		int tempRBracketNum = 0;
		int i;

		while ((*(char**)Code)[*index + tempIndex] != 0x0)
		{
			if ((*(char**)Code)[*index + tempIndex] == '(')
			{
				(BracketIndex[tempLBracketNum++])[1] = tempIndex;
			}
			if ((*(char**)Code)[*index + tempIndex] == ')')
			{
				for (i = 0; i < tempLBracketNum; i++)
				{
					if ((BracketIndex[tempLBracketNum - i - 1])[0] != 1)
					{
						(BracketIndex[tempLBracketNum - i - 1])[2] = tempIndex;
						(BracketIndex[tempLBracketNum - i - 1])[0] = 1;
						tempRBracketNum++;
						*BracketNum++;
					}
				}
			}
		}

		return 1;
	}

	//����1��ʾ�ɹ�
	int AnalysisFile(void** Code, int* index, PSourceCodeFile pFile)
	{
		int tempIndex = 0;
		int tempReturnLength = 0;
		int temp = 0;
		int tempInt = 0;
		int tempNameNum;
		int tempFunctionParNo = 0;
		char* SubCode;
		SubCode = new char[400];
		ProfixType tempProfixType;
		ReturnType tempReturnType;
		char** Name;
		int NameNum = 0;
		char** tempArray;
		int tempArrayNum = 0;
		int* tempArrayIndex;
		int tempAssigningOperatorNum = 0;
		int* tempAssigningOperatorIndex;
		char tempValue[100];
		char tempName[200];
		char tempCode[80];
		PVariable ptempVar[10];
		char ptempPro[20];
		int tempVarNum = 0;
		PSubCode tempSubCode;
		tempSubCode = new _SubCode[10];
		PVariable tempVar;
		PSourceLine pSourceLine;
		PUserDefStruct temppUserDefStruct;
		PSourceFunction temppFunction;
		bool bInNameSpaceDef = false;
		int tempWriteNameSpaceNo = 0;

		tempArray = new char* [20];
		tempArrayIndex = new int[20];
		tempAssigningOperatorIndex = new int[10];
		InitSubCodeArray(tempSubCode);
		for (int i = 0; i < 10; i++)
		{
			ptempVar[i] = new Variable;
		}

		for (int i = 0; i < 20; i++)
		{
			tempArray[i] = new char[50];
		}
		
		Name = new char* [10];
		for (int i = 0; i < 10; i++)
		{
			Name[i] = new char[100];
		}
		AnalysisCodeLineNo = 0;

		while ((*(char**)Code)[*index] != 0x0)
		{
			temp = 0;
			tempInt = 0;
			NameNum = 0;
			memset(SubCode, 0x0, 400);
			memset(tempValue, 0x0, 100);
			memset(tempName, 0x0, 200);
			memset(tempCode, 0x0, 80);
			tempReturnLength = DivisionCodeByLineFeed(Code, index, SubCode);

			//���ú����м�麯��������Ǳ�����������������Ǻ���������
			//���������������2
			//û�жԺ����������궨�塢�������弰����������ϸ����
 			switch (CheckCodeLineType((void**)(&SubCode), false, tempReturnLength))
			{
			case CodeLineType::StructDefType:
			{
				//tempIndex = DivisionCodeByBlank((void**)(&SubCode), &temp, tempCode);
				//temp += tempIndex;
				//MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				//tempIndex = DivisionCodeByBlank((void**)(&SubCode), &temp, tempCode);
				//temp += tempIndex;
				//MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				//strcpy(((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Name, &(SubCode[temp]));
				//((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->ContentNum = 0;
				//((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->AnotherNameNum = 0;
				//((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->PointerNameNum = 0;
				//((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->DefStartGlobalLineNo = AnalysisCodeLineNo;
				//*index = *index + tempReturnLength + 2;
				//tempReturnLength = DivisionCodeByLineFeed(Code, index, SubCode);
				//*index = *index + tempReturnLength + 2;
				//AnalysisCodeLineNo += 2;             //�����д��û�п���ͨ���ԣ��̶�����Ϊtypedef struct xxx\r\n{\r\n xxx ����ʽ����
				//tempIndex = DivisionCodeByBlank((void**)(&SubCode), &temp, tempCode);
				AddTypeDefStruct(Code, index);

				break;
			}
			case CodeLineType::UnionDefType:
			{
				AddTypedefUnion(Code, index);

				break;
			}
			case CodeLineType::namespaceDefType:
			{

				AddNameSpaceDefInfo(Code, index);
				bInNameSpaceDef = true;
				break;
			}
			case CodeLineType::RBraceType:
			{
				if (bInNameSpaceDef)
				{
					//����Ĳ�����ʵӦ���ڽ���namespace�ռ�ĺ����н��еģ���������Ŀǰ����namespace�ռ���м򵥵Ľ��������Ծ�����ôд��
					tempWriteNameSpaceNo = ((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->WriteNameSpaceNo;
					((((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->pStoreNameSpaceInfo)[tempWriteNameSpaceNo])->StopGlobalLineNo = AnalysisCodeLineNo;
					
					((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->WriteNameSpaceNo++;
					((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->NameSpaceNum++;
					bInNameSpaceDef = false;
				}
				else
				{
					std::cout << "Analysis File Fail Have RBrace But Not In Name Space Def" << AnalysisCodeLineNo << std::endl;
				}
				((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
				((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
				((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::namespaceDefType;
				strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, SubCode);
				pSourceCodeFile->SourceCodeLineNum++;
				pSourceCodeFile->WriteSourceCodeLineNo++;

				*index = *index + tempReturnLength + 2;
				AnalysisCodeLineNo++;
				break;
			}
			case CodeLineType::usingKeywordType:
			{
				std::cout << "Analysis File Fail using keyword only" << AnalysisCodeLineNo << std::endl;
				break;
			}
			case CodeLineType::usingnamespaceKeywordType:
			{
				AddUseNameSpaceInfo(Code, index);

				break;
			}
			case CodeLineType::FunctionDeclare:
			{
				/*strcpy((pFile->Unknown)[pFile->WriteUnknownNo], SubCode);
				pFile->WriteUnknownNo++;
				pFile->UnknownNum++;*/

				tempIndex = CheckProfixType((void**)(&SubCode), &temp, &tempProfixType);
				if (tempProfixType != ProfixType::ProfixType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				}

				tempIndex = CheckReturnType((void**)(&SubCode), &temp, &tempReturnType, &temppUserDefStruct);
				if (tempReturnType != ReturnType::ReturnType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				}

#ifdef _data1
				* index = *index + tempReturnLength + 2;
				AnalysisCodeLineNo++;
				tempReturnLength = DivisionCodeByLineFeed(Code, index, SubCode);
#endif
				
				tempVarNum = 0;
				GetFunctionNameAndPara((void**)(&SubCode), &temp, false, tempName, ptempVar, &tempVarNum, ptempPro);

				temppFunction = (pFile->Function)[pFile->WriteFunctionNo];
				strcpy((temppFunction)->FunctionName, tempName);
				(temppFunction)->bDeclare = true;
				(temppFunction)->DeclareGlobalLineNo = AnalysisCodeLineNo;
				(temppFunction)->FunctionNo = pFile->WriteFunctionNo;

				(temppFunction)->returnType = tempReturnType;
				if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
				{
					(temppFunction)->bReturnUserDefStruct = true;
					(temppFunction)->pReturnUserDefStruct = temppUserDefStruct;
				}
				else
				{
					(temppFunction)->bReturnUserDefStruct = false;
					(temppFunction)->pReturnUserDefStruct = NULL;
				}

				pSourceLine = ((pFile)->SourceCodeLine)[((pFile)->WriteSourceCodeLineNo)++];
				strcpy(pSourceLine->buffer, SubCode);
				pSourceLine->CodeType = FunctionDeclare;
				pSourceLine->Syntax = -1;
				pSourceLine->FunctionNo = pFile->WriteFunctionNo;
				pSourceLine->CodeLineNo = AnalysisCodeLineNo;
				pSourceLine->GlobalLineNo = AnalysisCodeLineNo;
				pSourceLine->LocalLineNo = 0;
				(pFile)->SourceCodeLineNum++;

				*index = *index + tempReturnLength + 2;
				AnalysisCodeLineNo++;
				pFile->WriteFunctionNo++;
				pFile->FunctionNum++;

				break;
			}
			case CodeLineType::FunctionDefine:
			{
				/*strcpy(((pFile->Function)[pFile->WriteFunctionNo])->Value, SubCode);*/
				tempIndex = CheckProfixType((void**)(&SubCode), &temp, &tempProfixType);
				if (tempProfixType != ProfixType::ProfixType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				}

				tempIndex = CheckReturnType((void**)(&SubCode), &temp, &tempReturnType, &temppUserDefStruct);
				if (tempReturnType != ReturnType::ReturnType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				}
				/*((pFile->Function)[pFile->WriteFunctionNo])->bDefinition = true;
				((pFile->Function)[pFile->WriteFunctionNo])->FunctionNo = pFile->WriteFunctionNo;
				((pFile->Function)[pFile->WriteFunctionNo])->StartGlobalLineNo = AnalysisCodeLineNo;
				((pFile->Function)[pFile->WriteFunctionNo])->returnType = tempReturnType;
				if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
				{
					((pFile->Function)[pFile->WriteFunctionNo])->bReturnUserDefStruct = true;
					((pFile->Function)[pFile->WriteFunctionNo])->pReturnUserDefStruct = temppUserDefStruct;
				}
				else
				{
					((pFile->Function)[pFile->WriteFunctionNo])->bReturnUserDefStruct = false;
					((pFile->Function)[pFile->WriteFunctionNo])->pReturnUserDefStruct = NULL;
				}*/
#ifdef _data1
				* index = *index + tempReturnLength + 2;
				AnalysisCodeLineNo++;
				tempReturnLength = DivisionCodeByLineFeed(Code, index, SubCode);
#endif

				tempVarNum = 0;
				GetFunctionNameAndPara((void**)(&SubCode), &temp, false, tempName, ptempVar, &tempVarNum, ptempPro);
				
				if (CheckFuncExist(tempName, &temppFunction) == 0)
				{
					temppFunction = (pFile->Function)[pFile->WriteFunctionNo];
					strcpy((temppFunction)->FunctionName, tempName);
					(temppFunction)->FunctionNo = pFile->WriteFunctionNo;
				}

				strcpy((temppFunction)->Value, SubCode);
				(temppFunction)->bDefinition = true;
				/*(temppFunction)->FunctionNo = pFile->WriteFunctionNo;*/
				(temppFunction)->StartGlobalLineNo = AnalysisCodeLineNo;
				(temppFunction)->returnType = tempReturnType;
				if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
				{
					(temppFunction)->bReturnUserDefStruct = true;
					(temppFunction)->pReturnUserDefStruct = temppUserDefStruct;
				}
				else
				{
					(temppFunction)->bReturnUserDefStruct = false;
					(temppFunction)->pReturnUserDefStruct = NULL;
				}

				//strcpy(((pFile->Function)[pFile->WriteFunctionNo])->FunctionName, tempName);
				pSourceLine = ((temppFunction)->CodeLine)[((temppFunction)->WriteCodeLineNo)++];
				strcpy(pSourceLine->buffer, SubCode);
				pSourceLine->CodeType = FunctionDefine;
				pSourceLine->Syntax = -1;
				pSourceLine->FunctionNo = pFile->WriteFunctionNo;
				pSourceLine->CodeLineNo = AnalysisCodeLineNo;
				pSourceLine->GlobalLineNo = AnalysisCodeLineNo;
				pSourceLine->LocalLineNo = 0;
				(temppFunction)->CodeLineNum++;
				for (int i = 0; i < tempVarNum; i++)
				{
					if ((ptempVar[i])->bParameter)
					{
						(temppFunction)->bHavePar = true;
						(temppFunction)->ParNum++;
						((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->ParNo = tempFunctionParNo++;
					}
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->bParameter = (ptempVar[i])->bParameter;
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->bFunctionCall = (ptempVar[i])->bFunctionCall;
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->returnType = (ptempVar[i])->returnType;
					strcpy(((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->Name, (ptempVar[i])->Name);
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->bUserDefStruct = (ptempVar[i])->bUserDefStruct;
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->ContentNum = (ptempVar[i])->ContentNum;
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->pUserDefStruct = (ptempVar[i])->pUserDefStruct;
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->bArray = (ptempVar[i])->bArray;
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->bPointerType = (ptempVar[i])->bPointerType;
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->PointerPointMemSize = (ptempVar[i])->PointerPointMemSize;
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->CodeLineNo = AnalysisCodeLineNo;
					((temppFunction)->Variable[(temppFunction)->WriteVariableNo])->DefCodeLineGlobalNo = AnalysisCodeLineNo;
					
					(temppFunction)->WriteVariableNo++;
					(temppFunction)->VariableNum++;
				}
				*index = *index + tempReturnLength + 2;
				AnalysisCodeLineNo++;
				temp = AnalysisFunction(Code, index, temppFunction);
				if (temp) //����1��ʾ�ɹ�
				{
					*index += temp;
					pFile->WriteFunctionNo++;
					pFile->FunctionNum++;
				}
				else
				{
					std::cout << "AnalysisFuction " << pFile->WriteFunctionNo << " Fail" << std::endl;
					return 0;
				}

				break;
			}
			case CodeLineType::MacroType:
			{
				tempIndex = DivisionCodeByBlank((void**)(&SubCode), &temp, tempCode);
				temp += tempIndex;
				MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				tempIndex = DivisionCodeByBlank((void**)(&SubCode), &temp, tempCode);
				strcpy(((pFile->Macro)[pFile->WriteMacroNo])->Name, tempCode);
				temp += tempIndex;
				MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				strcpy(((pFile->Macro)[pFile->WriteMacroNo])->Value, &(SubCode[temp]));
				((pFile->Macro)[pFile->WriteMacroNo])->DefCodeLineGlobalNo = AnalysisCodeLineNo;

				((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
				((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
				((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::MacroType;
				strcpy(((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->buffer, SubCode);

				pFile->SourceCodeLineNum++;
				pFile->WriteSourceCodeLineNo++;
				pFile->WriteMacroNo++;
				pFile->MacroNum++;
				*index = *index + tempReturnLength + 2;
				AnalysisCodeLineNo++;

				break;
			}
			case CodeLineType::externKeywordType:        //Ŀǰ������extern�ؼ��ִ����еĴ�����ʽ�봦�����������ķ�����ͬ(��ʵ���߱���Ӧ��Ҳ����ͬ��,���Կ�������ͬ�ķ�������)
			case CodeLineType::VariableDeclare: 
			{
				tempIndex = CheckProfixType((void**)(&SubCode), &temp, &tempProfixType);
				if (tempProfixType != ProfixType::ProfixType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				}

				tempIndex = CheckReturnType((void**)(&SubCode), &temp, &tempReturnType, &temppUserDefStruct);
				if (tempReturnType != ReturnType::ReturnType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				}

				/*strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Name, &(SubCode[temp]));*/
				//�˴��⴦�������Ľ������㷨���ʺϱ���������������a[b + c]����������Ĵ��������л�������������:a,b,c ���ڱ�������������������Ӧ�ò������
				tempArrayNum = 0;
				tempNameNum = GetSubCodeName((void**)(&SubCode), &temp, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
				for (int i = 0; i < tempNameNum; i++)
				{
					((pFile->Variable)[pFile->WriteVariableNo])->CodeLineNo = AnalysisCodeLineNo;
					((pFile->Variable)[pFile->WriteVariableNo])->FunctionNo = -1;
					((pFile->Variable)[pFile->WriteVariableNo])->Value[0] = 0x0;
					((pFile->Variable)[pFile->WriteVariableNo])->VariableNo = pFile->WriteVariableNo;
					((pFile->Variable)[pFile->WriteVariableNo])->profixType = tempProfixType;
					((pFile->Variable)[pFile->WriteVariableNo])->returnType = tempReturnType;
					
					((pFile->Variable)[pFile->WriteVariableNo])->bGlobal = true;
					((pFile->Variable)[pFile->WriteVariableNo])->DefCodeLineGlobalNo = AnalysisCodeLineNo;

					strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Name, Name[i]);
					
					if (tempArrayNum > 0)
					{
						if ((i + tempInt) == tempArrayIndex[tempInt])
						{
							((pFile->Variable)[pFile->WriteVariableNo])->bArray = true;
							temp = 0;
							AddPointerTypeVarInfo((void**)(&(tempArray[tempInt])), &temp, (pFile->Variable)[pFile->WriteVariableNo], NULL);
							strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Array, tempArray[tempInt]);
							tempInt++;
							tempArrayNum--;
						}
					}

					if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
					{
						/*tempVar = (pFile->Variable)[pFile->WriteVariableNo];*/
						((pFile->Variable)[pFile->WriteVariableNo])->bUserDefStruct = true;
						((pFile->Variable)[pFile->WriteVariableNo])->ContentNum = temppUserDefStruct->ContentNum;
						((pFile->Variable)[pFile->WriteVariableNo])->pUserDefStruct = temppUserDefStruct;
					}
					else
					{
						((pFile->Variable)[pFile->WriteVariableNo])->bUserDefStruct = false;
						((pFile->Variable)[pFile->WriteVariableNo])->ContentNum = 0;
						((pFile->Variable)[pFile->WriteVariableNo])->pUserDefStruct = NULL;
					}
					pFile->WriteVariableNo++;
					pFile->VariableNum++;
				}

				((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
				((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
				((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::VariableDeclare;
				strcpy(((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->buffer, SubCode);

				pFile->SourceCodeLineNum++;
				pFile->WriteSourceCodeLineNo++;

				*index = *index + tempReturnLength + 2;
				AnalysisCodeLineNo++;

				break;
			}
			case CodeLineType::VariableDefine:
			{
				//add at 22.9.30
				((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
				((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
				((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::VariableDefine;
				strcpy(((pFile->SourceCodeLine)[pFile->WriteSourceCodeLineNo])->buffer, SubCode);

				tempAssigningOperatorNum = CheckLincCodeAssigningOperator((void**)(&SubCode), tempAssigningOperatorIndex);
				temp = 0;
				for (int i = tempAssigningOperatorIndex[tempAssigningOperatorNum - 1]; i < tempReturnLength; i++)
				{
					tempValue[temp++] = SubCode[i];
				}
				tempValue[temp - 1] = 0x0;
				SubCode[tempAssigningOperatorIndex[tempAssigningOperatorNum - 1]] = 0x0;
				temp = 0;
				tempIndex = CheckProfixType((void**)(&SubCode), &temp, &tempProfixType);
				if (tempProfixType != ProfixType::ProfixType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);
				}

				tempIndex = CheckReturnType((void**)(&SubCode), &temp, &tempReturnType, &temppUserDefStruct);
				if (tempReturnType != ReturnType::ReturnType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank((void**)(&SubCode), &temp);

					tempArrayNum = 0;
					tempNameNum = GetSubCodeName((void**)(&SubCode), &temp, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
					for (int i = 0; i < tempNameNum; i++)
					{
						((pFile->Variable)[pFile->WriteVariableNo])->CodeLineNo = AnalysisCodeLineNo;
						((pFile->Variable)[pFile->WriteVariableNo])->FunctionNo = -1;
						strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Value, tempValue);
						((pFile->Variable)[pFile->WriteVariableNo])->VariableNo = pFile->WriteVariableNo;
						((pFile->Variable)[pFile->WriteVariableNo])->profixType = tempProfixType;
						((pFile->Variable)[pFile->WriteVariableNo])->returnType = tempReturnType;
						strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Name, Name[i]);
						
						((pFile->Variable)[pFile->WriteVariableNo])->bGlobal = true;
						((pFile->Variable)[pFile->WriteVariableNo])->DefCodeLineGlobalNo = AnalysisCodeLineNo;
						
						if (tempArrayNum > 0)
						{
							if ((i + tempInt) == tempArrayIndex[tempInt])
							{
								((pFile->Variable)[pFile->WriteVariableNo])->bArray = true;
								temp = 0;
								AddPointerTypeVarInfo((void**)(&(tempArray[tempInt])), &temp, (pFile->Variable)[pFile->WriteVariableNo], NULL);
								strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Array, tempArray[tempInt]);
								tempInt++;
								tempArrayNum--;
							}
						}

						if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
						{
							((pFile->Variable)[pFile->WriteVariableNo])->bUserDefStruct = true;
							((pFile->Variable)[pFile->WriteVariableNo])->ContentNum = temppUserDefStruct->ContentNum;
							((pFile->Variable)[pFile->WriteVariableNo])->pUserDefStruct = temppUserDefStruct;
						}
						else
						{
							((pFile->Variable)[pFile->WriteVariableNo])->bUserDefStruct = false;
							((pFile->Variable)[pFile->WriteVariableNo])->ContentNum = 0;
							((pFile->Variable)[pFile->WriteVariableNo])->pUserDefStruct = NULL;
						}
						//��ֵ����ʽ������
						ProcessExpression(tempValue);
						CheckVarValueChange(tempValue, (pFile->Variable)[pFile->WriteVariableNo], NULL);

						pFile->WriteVariableNo++;
						pFile->VariableNum++;
					}
				}
				else
				{
					tempArrayNum = 0;
					tempNameNum = GetSubCodeName((void**)(&SubCode), &temp, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
					for (int i = 0; i < tempNameNum; i++)
					{
						if (FindDefindedValue(Name[i], &tempVar, false, NULL, false, NULL) == 1)
						{
							//��ֵ����ʽ������
							ProcessExpression(tempValue);
							CheckVarValueChange(tempValue, tempVar, NULL);
							//���д��뱣���Űɣ�ȫ�ֱ�����ôдûʲô���⣨�����ǻ�һֱ���±�����ǰ��ֵ�����ں�����д�����Ƭʱû���ã���Ϊ����ֵ�������µı���ֵ����������Ƭʱ���ǲ�һ����Ҫ���µ�ֵ��
							strcpy(tempVar->Value, tempValue);
						}
						else
						{
							std::cout << "find var error" << std::endl;
						}
					}
				}

				pFile->SourceCodeLineNum++;
				pFile->WriteSourceCodeLineNo++;

				*index = *index + tempReturnLength + 2;
				AnalysisCodeLineNo++;

				break;
			}
			default:
			{
#ifdef _DEBUG
				std::cout << "Analysis File Error " << AnalysisCodeLineNo << std::endl;
#endif
				if (func::Mod == 1)
				{
					return 0;
				}
				break;
			}
			}
		}

		for (int i = 0; i < 10; i++)
		{
			delete []Name[i];
		}
		delete []Name;
		for (int i = 0; i < 20; i++)
		{
			delete []tempArray[i];
		}
		delete []tempArray;

		return 0;
	}

	int AnalysisFunction(void** Code, int* index, PSourceFunction pFunction)
	{
		int tempIndex = 0;
		int tempLBrace = 0;
		int tempRBrace = 0;
		int tempReturnLBrace;
		int tempReturnRBrace;
		int tempReturnBraceType;
		char* SubCode;
		char** temppSubCode;
		int tempReturnLength = 0;
		int temp = 0;
		int tempMasterType[10];
		int tempMasterLineNo[10];
		int tempMasterIndex = 0;
		int* ControlDependenceArray[50];
		int ControlDependenceNum = 0;
		int ControlDependenceArrayLBraceNumArray[50];
		int* ControlDependenceType[50];
		SubCode = new char[400];
		temppSubCode = new char*;
		tempMasterType[tempMasterIndex] = 2;
		pFunction->StartIndex = *index;

		for (int i = 0; i < 50; i++)
		{
			ControlDependenceArray[i] = new int[5];
		}
		for (int i = 0; i < 50; i++)
		{
			ControlDependenceType[i] = new int[2];
		}

		(ControlDependenceArray[0])[0] = AnalysisCodeLineNo - 1;
		/*ControlDependenceNum++;*/
		ControlDependenceArrayLBraceNumArray[0] = 0;
		(ControlDependenceType[0])[0] = 0;

		while (true)
		{
			memset(SubCode, 0x0, 400);
			temp = *index + tempIndex;
			tempIndex += MoveCodeIndexUntillNoBlank(Code, &temp);
			tempReturnLength = DivisionCodeByLineFeed(Code, &temp, SubCode);
			temp = 0;
			temppSubCode = &SubCode;
			tempReturnBraceType = CheckCodeLineHaveBrace((void**)temppSubCode, &temp, &tempReturnLBrace, &tempReturnRBrace);                   //change 22.10.1
			if (tempReturnBraceType == -1 || tempReturnBraceType == 0)
			{
				tempMasterLineNo[tempMasterIndex] = AnalysisCodeLineNo - 1;
				if (tempMasterIndex > 0)
				{
					if (((pFunction->CodeLine)[pFunction->WriteCodeLineNo - 1])->Syntax == 1)
					{
						tempMasterType[tempMasterIndex] = 1;
						(((pFunction->CodeLine)[pFunction->WriteCodeLineNo - 1])->PSyntaxCode)->bbrace = true;
						(((pFunction->CodeLine)[pFunction->WriteCodeLineNo - 1])->PSyntaxCode)->FirstContentLineNo = AnalysisCodeLineNo;
					}
					else
					{
						tempMasterType[tempMasterIndex] = 0;
						(((pFunction->CodeLine)[pFunction->WriteCodeLineNo - 1])->PSyntaxCode)->bbrace = true;
						(((pFunction->CodeLine)[pFunction->WriteCodeLineNo - 1])->PSyntaxCode)->FirstContentLineNo = AnalysisCodeLineNo;
						//tempMasterLineNo[tempMasterIndex] = AnalysisCodeLineNo;           fix bug     22.9.29
					}
				}
				else
				{
					//update at 22.10.4          �Ժ�����������������������������Ϣ��¼
					(((pFunction->CodeLine)[pFunction->WriteCodeLineNo - 1])->PSyntaxCode)->bbrace = true;
					(((pFunction->CodeLine)[pFunction->WriteCodeLineNo - 1])->PSyntaxCode)->FirstContentLineNo = AnalysisCodeLineNo;
				}
				tempMasterIndex++;
				tempLBrace += tempReturnLBrace;
			}
			temp = 0;
			temppSubCode = &SubCode;
			if (tempReturnBraceType == 1 || tempReturnBraceType == 0)
			{
				tempMasterIndex--;
				if (tempMasterLineNo[tempMasterIndex] >= 0)                  //update at 22.10.4     �����д������Ϣ��¼,�����ǲ����﷨��֧�����,��������Ϣ��¼   if (tempMasterLineNo[tempMasterIndex] >= 0 && ((pFunction->CodeLine)[tempMasterLineNo[tempMasterIndex] - pFunction->StartGlobalLineNo])->Syntax == 1)
				{
					(((pFunction->CodeLine)[tempMasterLineNo[tempMasterIndex] - pFunction->StartGlobalLineNo])->PSyntaxCode)->FinalContentLineNo = AnalysisCodeLineNo;
					(((pFunction->CodeLine)[tempMasterLineNo[tempMasterIndex] - pFunction->StartGlobalLineNo])->PSyntaxCode)->BraceContentFeedLineNum = AnalysisCodeLineNo - (((pFunction->CodeLine)[tempMasterLineNo[tempMasterIndex] - pFunction->StartGlobalLineNo])->PSyntaxCode)->FirstContentLineNo + 1;
				}

				tempRBrace += tempReturnRBrace;
			}
			temp = 0;
			temppSubCode = &SubCode;
			AnalysisCodeLine((void**)temppSubCode, &temp, (pFunction->CodeLine)[pFunction->WriteCodeLineNo], true, pFunction, tempMasterType[tempMasterIndex - 1], tempMasterLineNo[tempMasterIndex - 1], ControlDependenceArray, &ControlDependenceNum, ControlDependenceArrayLBraceNumArray, ControlDependenceType);
			temp = 0;
			temppSubCode = &SubCode;
			if ((tempReturnBraceType == 1 || tempReturnBraceType == 0) && tempLBrace == tempRBrace)
			{
				tempIndex += tempReturnLength + 2;
				AnalysisCodeLineNo++;
				pFunction->WriteCodeLineNo++;
				pFunction->CodeLineNum++;

				break;
			}
			tempIndex += tempReturnLength + 2;
			AnalysisCodeLineNo++;
			pFunction->WriteCodeLineNo++;
			pFunction->CodeLineNum++;
			if ((*(char**)Code)[*index + tempIndex] == 0x0)
			{
				break;
			}
		}
		pFunction->StopIndex = *index + tempIndex - 1;
		pFunction->StopGlobalLineNo = AnalysisCodeLineNo - 1;
		//GetCFG(pFunction, Code);

		//delete SubCode;

		for (int i = 0; i < 50; i++)
		{
			delete [] ControlDependenceArray[i];
			delete[] ControlDependenceType[i];
		}

		return tempIndex;
	}

	int AnalysisCodeLine(void** Code, int* index, PSourceLine pCodeLine, bool bFunction, PSourceFunction pFunction, int MasterType, int MasterLineNo, int** ControlDependenceArray, int* ControlDependenceNum, int* ControlDependenceArrayLBraceArray, int** ControlDependenceType)
	{
		int tempIndex = 0;
		int temp = 0;
		int tempNameNum = 0;
		ProfixType tempProfixType;
		PVariable temppVar;
		ReturnType tempReturnType;
		SyntaxKey syntaxKey1;
		SyntaxKey syntaxKey2;
		PUserDefStruct temppUserDefStruct;
		char** Name;
		char temppSubCode[400];
		char** tempppSubCode;
		char tempValue[200];
		int NameNum = 0;
		char* tempArray[20];
		int tempArrayNum = 0;
		int* tempArrayIndex;
		int tempInt = 0;
		int tempAssigningOperatorNum = 0;
		int* tempAssigningOperatorIndex;
		int tempReturnLength;

		tempppSubCode = new char*;
		*tempppSubCode = temppSubCode;

		/*temppSubCode = new char*;
		*temppSubCode = new char[100];*/
		tempAssigningOperatorIndex = new int[10];
		tempArrayIndex = new int[20];
		for (int i = 0; i < 20; i++)
		{
			tempArray[i] = new char[80];
		}

		Name = new char* [20];
		for (int i = 0; i < 20; i++)
		{
			Name[i] = new char[150];
		}

		strcpy(pCodeLine->buffer, *(char**)Code);
		tempIndex += CheckSyntaxKey(Code, index, &syntaxKey1, &syntaxKey2);
		MoveCodeIndexUntillNoBlank(Code, &tempIndex);
		CheckCodeLineHaveFunctionCallAndMarkInParAndMarkInFunctionInfo(Code, pFunction);
		CheckDataDependence(Code, pCodeLine, pFunction);
		CheckControlDependence(Code, pCodeLine, pFunction, ControlDependenceArray, ControlDependenceNum, ControlDependenceArrayLBraceArray, ControlDependenceType);
		CheckCodeLineHaveMemoryAlloc(Code, pCodeLine, pFunction);
		AddVarAsArrayIndexInfo(Code, &tempIndex, pFunction);

		if (syntaxKey1 != SyntaxKey::SyntaxKey_unknownType)
		{
			pCodeLine->Syntax = 1;
			pCodeLine->CodeType = CodeLineType::Syntax;
			(pCodeLine->PSyntaxCode)->SyntaxKeyType = syntaxKey1;
			(pCodeLine->PUnSyntaxCode)->MasterLineNo = MasterLineNo;
			(pCodeLine->PUnSyntaxCode)->MasterType = MasterType;

			if (syntaxKey1 != breakType && syntaxKey1 != continueType && syntaxKey1 != returnType)
			{
				EncounterSyntaxKsyAddSyntaxChainInfo(pCodeLine, pFunction);        //Add at 22.9.30 , fix at 22.10.1
			}

			if ((*(char**)Code)[*index + tempIndex] == '(')
			{
				(pCodeLine->PSyntaxCode)->bCondition = true;
				strcpy((pCodeLine->PSyntaxCode)->Condition, &(*(char**)Code)[*index + tempIndex]);
				tempNameNum = GetSubCodeName(Code, &tempIndex, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
				for (int i = 0; i < tempNameNum; i++)
				{
					if (CheckVarExist(Name[i], pFunction, &temppVar) == 1)
					{
						/*temppVar->bInSyntaxBlock = true;
						temppVar->SyntaxCodeLineNoArray[temppVar->SyntaxCodeLineNum] = AnalysisCodeLineNo;
						(temppVar->SyntaxCodeLineNum)++;*/
						AddVarStructSyntaxKeyInfo(temppVar, pCodeLine);
					}
					/*((pFile->Variable)[pFile->WriteVariableNo])->CodeLineNo = AnalysisCodeLineNo;
					((pFile->Variable)[pFile->WriteVariableNo])->FunctionNo = -1;
					strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Value, tempValue);
					((pFile->Variable)[pFile->WriteVariableNo])->VariableNo = pFile->WriteVariableNo;
					((pFile->Variable)[pFile->WriteVariableNo])->profixType = tempProfixType;
					((pFile->Variable)[pFile->WriteVariableNo])->returnType = tempReturnType;
					strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Name, Name[i]);
					pFile->WriteVariableNo++;
					pFile->VariableNum++;
					if (tempArrayNum > 0)
					{
						if ((i + tempInt) == tempArrayIndex[tempInt])
						{
							((pFile->Variable)[pFile->WriteVariableNo])->bArray = true;
							strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Array, tempArray[tempInt]);
							tempInt++;
							tempArrayNum--;
						}
					}*/
				}
			}
			else
			{
				(pCodeLine->PSyntaxCode)->bCondition = false;
			}

		}
		else
		{
			pCodeLine->Syntax = 0;
			(pCodeLine->PUnSyntaxCode)->MasterLineNo = MasterLineNo;
			(pCodeLine->PUnSyntaxCode)->MasterType = MasterType;
			temp = strlen(&(*(char**)Code)[*index + tempIndex]);
			strcpy(temppSubCode, &(*(char**)Code)[*index + tempIndex]);
			pCodeLine->CodeType = (CodeLineType)CheckCodeLineType((void**)tempppSubCode, false, temp);
			//���ú����м�麯��������Ǳ�����������������Ǻ���������
			//���������������2
			//û�жԺ����������궨�塢�������弰����������ϸ����
			switch (pCodeLine->CodeType)
			{
			case CodeLineType::FunctionDeclare:
			case CodeLineType::FunctionDefine:
			case CodeLineType::MacroType:
			case CodeLineType::LBraceType:
			case CodeLineType::RBraceType:
			{
				//printf("Anysis Code Line Fail\n");
				break;
			}
			case CodeLineType::VariableDeclare:
			{
				
				temp = CheckProfixType(Code, &tempIndex, &tempProfixType);
				if (tempProfixType != ProfixType::ProfixType_unknownType)
				{
					tempIndex += temp;
					MoveCodeIndexUntillNoBlank(Code, &tempIndex);
				}

				temp = CheckReturnType(Code, &tempIndex, &tempReturnType, &temppUserDefStruct);
				if (tempReturnType != ReturnType::ReturnType_unknownType)
				{
					tempIndex += temp;
					MoveCodeIndexUntillNoBlank(Code, &tempIndex);
				}

				/*strcpy(((pFile->Variable)[pFile->WriteVariableNo])->Name, &(SubCode[temp]));*/
				//�˴��⴦�������Ľ������㷨���ʺϱ���������������a[b + c]����������Ĵ��������л�������������:a,b,c ���ڱ�������������������Ӧ�ò������
				tempArrayNum = 0;
				tempNameNum = GetSubCodeName(Code, &tempIndex, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
				for (int i = 0; i < tempNameNum; i++)
				{
					((pFunction->Variable)[pFunction->WriteVariableNo])->CodeLineNo = AnalysisCodeLineNo;
					((pFunction->Variable)[pFunction->WriteVariableNo])->DefCodeLineGlobalNo = AnalysisCodeLineNo;
					((pFunction->Variable)[pFunction->WriteVariableNo])->FunctionNo = pFunction->FunctionNo;
					((pFunction->Variable)[pFunction->WriteVariableNo])->Value[0] = 0x0;
					((pFunction->Variable)[pFunction->WriteVariableNo])->VariableNo = pFunction->WriteVariableNo;
					((pFunction->Variable)[pFunction->WriteVariableNo])->profixType = tempProfixType;
					((pFunction->Variable)[pFunction->WriteVariableNo])->returnType = tempReturnType;
					strcpy(((pFunction->Variable)[pFunction->WriteVariableNo])->Name, Name[i]);
					
					//��bug�������д�������
					/*pFunction->WriteVariableNo++;
					pFunction->VariableNum++;*/
					if (tempArrayNum > 0)
					{
						//fix bug at 23.3.9
						if (i == tempArrayIndex[tempInt])
						{
							((pFunction->Variable)[pFunction->WriteVariableNo])->bArray = true;
							temp = 0;
							AddPointerTypeVarInfo((void**)(&(tempArray[tempInt])), &temp, (pFunction->Variable)[pFunction->WriteVariableNo], NULL);
							strcpy(((pFunction->Variable)[pFunction->WriteVariableNo])->Array, tempArray[tempInt]);
							
							//fix bug at 22.10.1
							*tempppSubCode = tempArray[tempInt];                                                                        //Ӧ��ֻ�����������һ����������ʱ�䶨��Ż������������й�ϵ
							CheckVarDefByOtherVarStatus(tempppSubCode, (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);			
							//add at 22.10.11
							temp = 0;
							CheckArrayIndexIsVarAndAddInfo(tempArray[tempInt], &temp, (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);

							tempInt++;
							tempArrayNum--;
						}
						//*tempppSubCode = tempArray[tempInt];                                                                        //Ӧ��ֻ�����������һ����������ʱ�䶨��Ż������������й�ϵ
						//CheckVarDefByOtherVarStatus(tempppSubCode, (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);
					}

					if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
					{
						((pFunction->Variable)[pFunction->WriteVariableNo])->bUserDefStruct = true;
						((pFunction->Variable)[pFunction->WriteVariableNo])->ContentNum = temppUserDefStruct->ContentNum;
						((pFunction->Variable)[pFunction->WriteVariableNo])->pUserDefStruct = temppUserDefStruct;
					}
					else
					{
						((pFunction->Variable)[pFunction->WriteVariableNo])->bUserDefStruct = false;
						((pFunction->Variable)[pFunction->WriteVariableNo])->ContentNum = 0;
						((pFunction->Variable)[pFunction->WriteVariableNo])->pUserDefStruct = NULL;
					}

					//��һ�еĺ�������Ӧ������Ϊ���鶨��ʱ���������������ʱ���õģ�����������ж�tempArrayNum���Ƿ������鶨���йأ�����й�Ӧ�ý���һ�д����ƶ���if��֧��
					//CheckVarDefByOtherVarStatus(&(tempArray[tempInt]), (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);
				
					pFunction->WriteVariableNo++;
					pFunction->VariableNum++;
				}

				break;
			}
			case CodeLineType::VariableDefine:
			{
				tempAssigningOperatorNum = CheckLincCodeAssigningOperator(Code, tempAssigningOperatorIndex);
				temp = 0;
				tempReturnLength = strlen(*(char**)Code);
				for (int i = tempAssigningOperatorIndex[tempAssigningOperatorNum - 1] + 2; i < tempReturnLength; i++)
				{
					tempValue[temp++] = (* (char**)Code)[i];
				}
				tempValue[temp - 1] = 0x0;
				RemoveStringFrontBlank(tempValue);
				(*(char**)Code)[tempAssigningOperatorIndex[tempAssigningOperatorNum - 1]] = 0x0;
				temp = 0;
				tempIndex = CheckProfixType(Code, &temp, &tempProfixType);
				if (tempProfixType != ProfixType::ProfixType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank(Code, &temp);
				}

				tempIndex = CheckReturnType(Code, &temp, &tempReturnType, &temppUserDefStruct);
				if (tempReturnType != ReturnType::ReturnType_unknownType)
				{
					temp += tempIndex;
					MoveCodeIndexUntillNoBlank(Code, &temp);

					tempArrayNum = 0;
					tempNameNum = GetSubCodeName(Code, &temp, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
					for (int i = 0; i < tempNameNum; i++)
					{
						((pFunction->Variable)[pFunction->WriteVariableNo])->CodeLineNo = AnalysisCodeLineNo;
						((pFunction->Variable)[pFunction->WriteVariableNo])->DefCodeLineGlobalNo = AnalysisCodeLineNo;
						((pFunction->Variable)[pFunction->WriteVariableNo])->FunctionNo = pFunction->FunctionNo;
						strcpy(((pFunction->Variable)[pFunction->WriteVariableNo])->Value, tempValue);
						((pFunction->Variable)[pFunction->WriteVariableNo])->VariableNo = pFunction->WriteVariableNo;
						((pFunction->Variable)[pFunction->WriteVariableNo])->profixType = tempProfixType;
						((pFunction->Variable)[pFunction->WriteVariableNo])->returnType = tempReturnType;
						strcpy(((pFunction->Variable)[pFunction->WriteVariableNo])->Name, Name[i]);
						if (tempArrayNum > 0)
						{
							if ((i + tempInt) == tempArrayIndex[tempInt])
							{
								((pFunction->Variable)[pFunction->WriteVariableNo])->bArray = true;
								temp = 0;
								AddPointerTypeVarInfo((void**)(&(tempArray[tempInt])), &temp, (pFunction->Variable)[pFunction->WriteVariableNo], NULL);
								strcpy(((pFunction->Variable)[pFunction->WriteVariableNo])->Array, tempArray[tempInt]);
								
								//fix bug at 22.10.1
								*tempppSubCode = tempArray[tempInt];                                                                        //Ӧ��ֻ�����������һ����������ʱ�䶨��Ż������������й�ϵ
								CheckVarDefByOtherVarStatus(tempppSubCode, (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);
								//add at 22.10.11
								temp = 0;
								CheckArrayIndexIsVarAndAddInfo(tempArray[tempInt], &temp, (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);

								tempInt++;
								tempArrayNum--;
							}
							//*tempppSubCode = tempArray[tempInt];                                                                        //Ӧ��ֻ�����������һ����������ʱ�䶨��Ż������������й�ϵ
							//CheckVarDefByOtherVarStatus(tempppSubCode, (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);
						}
						if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
						{
							((pFunction->Variable)[pFunction->WriteVariableNo])->bUserDefStruct = true;
							((pFunction->Variable)[pFunction->WriteVariableNo])->ContentNum = temppUserDefStruct->ContentNum;
							((pFunction->Variable)[pFunction->WriteVariableNo])->pUserDefStruct = temppUserDefStruct;
						}
						else
						{
							((pFunction->Variable)[pFunction->WriteVariableNo])->bUserDefStruct = false;
							((pFunction->Variable)[pFunction->WriteVariableNo])->ContentNum = 0;
							((pFunction->Variable)[pFunction->WriteVariableNo])->pUserDefStruct = NULL;
						}
						/**temppSubCode = tempArray[tempInt];
						CheckVarDefByOtherVarStatus(temppSubCode, (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);*/
						//��ֵ����ʽ������
						ProcessExpression(tempValue);
						//�����ֵ�ı�ļ�¼�ʹ���
						CheckVarValueChange(tempValue, (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);
					
						pFunction->WriteVariableNo++;
						pFunction->VariableNum++;
					}
				}
				else
				{
					tempArrayNum = 0;
					tempNameNum = GetSubCodeName(Code, &temp, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
					for (int i = 0; i < tempNameNum; i++)
					{
						/*if (FindDefindedValue(Name[i], &tempVar, false, NULL, false, NULL) == 1)
						{
							strcpy(tempVar->Value, tempValue);
						}
						else
						{
							std::cout << "find var error" << std::endl;
						}*/
						if (CheckVarExist(Name[i], pFunction, &temppVar) == 1)
						{
							//��ֵ����ʽ������
							ProcessExpression(tempValue);
							CheckVarValueChange(tempValue, temppVar, pFunction);
							if (tempArrayNum > 0)
							{
								if ((i + tempInt) == tempArrayIndex[tempInt])
								{
									//add at 22.10.11
									temp = 0;
									CheckArrayIndexIsVarAndAddInfo(tempArray[tempInt], &temp, temppVar, pFunction);

									tempInt++;
									tempArrayNum--;
								}
								//*tempppSubCode = tempArray[tempInt];                                                                        //Ӧ��ֻ�����������һ����������ʱ�䶨��Ż������������й�ϵ
								//CheckVarDefByOtherVarStatus(tempppSubCode, (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);
							}
						}
					}
				}

				*index = *index + tempReturnLength + 2;
				//AnalysisCodeLineNo++;                         //���ﱻע�͵��ˣ�����ҲӦ�����

				break;
			}
			case CodeLineType::OnlyFunctionCall:
			{
				//std::cout << "Only Function Call: \n";
				break;
			}
			default:
			{
#ifdef _DEBUG
				std::cout << "Analysis File Error " << AnalysisCodeLineNo << "\n";
#endif
				break;
			}
			}
		}
		pCodeLine->CodeLineNo = AnalysisCodeLineNo;
		pCodeLine->GlobalLineNo = AnalysisCodeLineNo;
		pCodeLine->FunctionNo = pFunction->FunctionNo;

		for (int i = 0; i < 10; i++)
		{
			if (strlen(Name[i]) != 0)
			{
				delete[]Name[i];
			}
		}
		delete []Name;
		for (int i = 0; i < 20; i++)
		{
			if (strlen(tempArray[i]) != 0)
			{
				delete[] tempArray[i];
			}
		}
		delete tempppSubCode;

		return tempIndex;
	}

	int AnalysisSyntaxCodeLine(void** Code, int* index, PSyntaxCodeLine pSyntaxCodeLine)
	{
		return 0;
	}

	int AnalysisUnSyntaxSourceLine(void** Code, int* index, PUnSyntaxSourceLine pUnSyntaxSourceLine)
	{
		return 0;
	}

	int GetCFG(PSourceFunction pFunction, void** Code)
	{
		InitCodeBlock(&(pFunction->pCodeBlock));
		(pFunction->pCodeBlock)->StartGlobalLineNo = pFunction->StartGlobalLineNo;
		(pFunction->pCodeBlock)->StopGlobalLineNo = pFunction->StopGlobalLineNo;
		DivisionCodeBlock(Code, &(pFunction->StartIndex), &(pFunction->StopIndex), 0, pFunction->pCodeBlock);
		
		return 1;
	}

	int InitCodeBlock(PCodeBlock* pCodeBlock)
	{
		*pCodeBlock = new CodeBlock;
		(*pCodeBlock)->bChildBlock = false;
		(*pCodeBlock)->pChildBlock = NULL;
		(*pCodeBlock)->bFunctionCall = false;
		(*pCodeBlock)->pFunctionInfo = NULL;
		(*pCodeBlock)->bParent = false;
		(*pCodeBlock)->pParent = NULL;
		(*pCodeBlock)->pNext = NULL;
		(*pCodeBlock)->ChildBlockNum = 0;
		(*pCodeBlock)->StartGlobalLineNo = 0;
		(*pCodeBlock)->StopGlobalLineNo = 0;
		(*pCodeBlock)->CodeBlockType = 0;
		(*pCodeBlock)->bReturn = false;
		(*pCodeBlock)->ReturnNum = 0;

		return 1;
	}

	//�������ԭ��û�����ÿ��tempLocalLineNo + 1 ���Ǵ���ģ����ŵ��Է��ֵ������ڽ�����ǰ�����Ĵ�����ʱ��tempLocalLineNo��ʾ�Ѿ������Ĵ�������������������ǰ�����Ĵ����У�����Ӧ���� + 1
	int DivisionCodeBlock(void** Code, int* index, int* endindex, int CodeBlockType, PCodeBlock pCodeBlock)
	{
		int tempIndex = 0;
		int tempLocalLineNo = 0;
		int tempChildBlockNum = 0;
		int tempReturnLength = 0;
		int temp = 0;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempChildeCodeLineNo[10][5]; //0: startGlobalLineNo; 1: EndGlobalLineNo; 2: CodeBlockType; 3:startIndexNo; 4: endIndexNo
		char SubCode[100];
		char** tempSubCode;
		char* temppSubCode;
		bool tempif = false;
		bool tempswitch = false;
		bool tempif2 = false;
		bool tempStatus = false;
		SyntaxKey syntaxKey1;
		SyntaxKey syntaxKey2;
		PCodeBlock ptempCodeBlock;
		tempSubCode = new char*;

		tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo;
		tempChildeCodeLineNo[tempChildBlockNum][2] = 0;
		tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;

		while (*index + tempIndex <= *endindex)
		{
			memset(SubCode, 0x0, 100);
			temp = *index + tempIndex;
			tempIndex += MoveCodeIndexUntillNoBlank(Code, &temp);
			tempReturnLength = DivisionCodeByLineFeed(Code, &temp, SubCode);
			temp = 0;
			*tempSubCode = SubCode;
			CheckSyntaxKey((void**)tempSubCode, &temp, &syntaxKey1, &syntaxKey2);
			switch (syntaxKey1)
			{
			case ifType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				if (tempif2)
				{
					tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index - 1;
					tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo - 1 + 1;
					tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
					tempChildeCodeLineNo[tempChildBlockNum][2] = 0;
					tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;
					tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index + tempReturnLength + 2;
					tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
					tempif2 = false;
				}
				else
				{
					tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index + tempReturnLength + 2;
					tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
				}
				tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1 + 1;
				tempChildeCodeLineNo[tempChildBlockNum][2] = ifType;
				tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index + tempReturnLength + 3;
				tempif = true;
				tempLBraceNum = 0;
				tempRBraceNum = 0;
				tempStatus = true;
				break;
			}
			case switchType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				if (tempif2)
				{
					tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index - 1;
					tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo - 1 + 1;
					tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
					tempChildeCodeLineNo[tempChildBlockNum][2] = 0;
					tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;
					tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index + tempReturnLength + 2;
					tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
					tempif2 = false;
				}
				else
				{
					tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index + tempReturnLength + 2;
					tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
				}
				tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1 + 1;
				tempChildeCodeLineNo[tempChildBlockNum][2] = switchType;
				tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index + tempReturnLength + 3;
				tempswitch = true;
				tempLBraceNum = 0;
				tempRBraceNum = 0;
				tempStatus = true;
				break;
			}
			case elseType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				tempLBraceNum = 0;
				tempRBraceNum = 0;
				break;
			}
			case elseifType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				if (CodeBlockType == ifType)
				{
					tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index - 1;
					tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo - 1 + 1;
					tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
					tempChildeCodeLineNo[tempChildBlockNum][2] = 0;
					tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;
					tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index + tempReturnLength + 2;
					tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
				}
				tempLBraceNum = 0;
				tempRBraceNum = 0;
				break;
			}
			case caseType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				tempLBraceNum = 0;
				tempRBraceNum = 0;
				break;
			}
			case defaultType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				tempLBraceNum = 0;
				tempRBraceNum = 0;
				break;
			}
			default:
			{
				break;
			}
			}
			if ((*(char**)Code)[*index + tempIndex] == '{' && tempStatus)
			{
				tempLBraceNum++;
			}
			if ((*(char**)Code)[*index + tempIndex] == '}' && tempStatus)
			{
				tempRBraceNum++;
			}
			if (tempswitch && tempLBraceNum == tempRBraceNum)
			{
				tempswitch = false;
				tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index + tempReturnLength + 2;
				tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
				tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1 + 1;
				tempChildeCodeLineNo[tempChildBlockNum][2] = 0;
				tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index + tempReturnLength + 3;
				tempStatus = false;
			}
			if (tempif2)
			{
				if (syntaxKey1 == elseType || syntaxKey1 == elseifType)
				{
					tempif = true;
				}
				else
				{
					tempif = false;
					tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index - 1;
					tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo - 1 + 1;
					tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
					tempChildeCodeLineNo[tempChildBlockNum][2] = 0;
					tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;
					tempStatus = false;
				}
				tempif2 = false;
			}
			else
			{
				if (tempif && tempLBraceNum == tempRBraceNum && tempLBraceNum != 0)
				{
					tempif = false;
					tempif2 = true;
				}
			}
			/*if (tempif && tempLBraceNum == tempRBraceNum && tempLBraceNum != 0)
			{
				tempif = false;
				tempif2 = true;
			}*/
			temppSubCode = SubCode;
			if (CheckReturnCodeLine(&temppSubCode))
			{
				pCodeBlock->bReturn = true;
				pCodeBlock->ReturnGlobalLineNo[pCodeBlock->ReturnNum++] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;     //ԭ��û�� + 1 ������Ϊ�ڽ�����ǰ�����Ĵ����У�tempLocalLineNo��ʾ�Ѿ������Ĵ�������������������ǰ�����Ĵ����У�����Ӧ���� + 1

			}

			tempLocalLineNo++;
			tempIndex += tempReturnLength + 2;
		}

		tempChildeCodeLineNo[tempChildBlockNum][4] = *endindex;
		tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StopGlobalLineNo;
		if (tempChildBlockNum > 1)
		{
			pCodeBlock->bChildBlock = true;
			pCodeBlock->ChildBlockNum = tempChildBlockNum;
			InitCodeBlock(&(pCodeBlock->pChildBlock));
			ptempCodeBlock = pCodeBlock->pChildBlock;
			ptempCodeBlock->bParent = true;
			ptempCodeBlock->pParent = pCodeBlock;
			for (int i = 0; i < tempChildBlockNum - 1; i++)
			{
				InitCodeBlock(&(ptempCodeBlock->pNext));
				ptempCodeBlock->StartGlobalLineNo = tempChildeCodeLineNo[i][0];
				ptempCodeBlock->StopGlobalLineNo = tempChildeCodeLineNo[i][1];
				ptempCodeBlock->CodeBlockType = tempChildeCodeLineNo[i][2];
				if (tempChildeCodeLineNo[i][2] == ifType)
				{
					ProcessIfBranch(Code, &tempChildeCodeLineNo[i][3], &tempChildeCodeLineNo[i][4], tempChildeCodeLineNo[i][2], ptempCodeBlock);
				}
				if (tempChildeCodeLineNo[i][2] == switchType)
				{
					ProcessSwitchBrach(Code, &tempChildeCodeLineNo[i][3], &tempChildeCodeLineNo[i][4], tempChildeCodeLineNo[i][2], ptempCodeBlock);
				}
				/*DivisionCodeBlock(Code, &tempChildeCodeLineNo[i][3], &tempChildeCodeLineNo[i][4], ptempCodeBlock);*/
				ptempCodeBlock = ptempCodeBlock->pNext;
				ptempCodeBlock->bParent = true;
				ptempCodeBlock->pParent = pCodeBlock;
			}
			ptempCodeBlock->StartGlobalLineNo = tempChildeCodeLineNo[tempChildBlockNum - 1][0];
			ptempCodeBlock->StopGlobalLineNo = tempChildeCodeLineNo[tempChildBlockNum - 1][1];
			ptempCodeBlock->CodeBlockType = tempChildeCodeLineNo[tempChildBlockNum - 1][2];
			if (tempChildeCodeLineNo[tempChildBlockNum - 1][2] == ifType)
			{
				ProcessIfBranch(Code, &tempChildeCodeLineNo[tempChildBlockNum - 1][3], &tempChildeCodeLineNo[tempChildBlockNum - 1][4], tempChildeCodeLineNo[tempChildBlockNum - 1][2], ptempCodeBlock);
			}
			if (tempChildeCodeLineNo[tempChildBlockNum - 1][2] == switchType)
			{
				ProcessSwitchBrach(Code, &tempChildeCodeLineNo[tempChildBlockNum - 1][3], &tempChildeCodeLineNo[tempChildBlockNum - 1][4], tempChildeCodeLineNo[tempChildBlockNum - 1][2], ptempCodeBlock);
			}
			/*DivisionCodeBlock(Code, &tempChildeCodeLineNo[tempChildBlockNum - 1][3], &tempChildeCodeLineNo[tempChildBlockNum - 1][4], ptempCodeBlock);*/
		}
		else
		{
			pCodeBlock->bChildBlock = false;
			pCodeBlock->pChildBlock = NULL;
			pCodeBlock->ChildBlockNum = 0;
		}

		return 1;
	}

	int ProcessIfBranch(void** Code, int* index, int* endindex, int CodeBockType, PCodeBlock pCodeBlock)
	{
		int tempIndex = 0;
		int tempChildBlockNum = 0;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempLocalLineNo = 0;
		int tempChildeCodeLineNo[10][5]; //0: startGlobalLineNo; 1: EndGlobalLineNo; 2: CodeBlockType; 3:startIndexNo; 4: endIndexNo
		char SubCode[100];
		char* temppSubCode;
		int temp = 0;
		int tempReturnLength = 0;
		bool tempStatus = false;
		SyntaxKey syntaxKey1;
		SyntaxKey syntaxKey2;
		PCodeBlock ptempCodeBlock;

		tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo;
		tempChildeCodeLineNo[tempChildBlockNum][2] = ifType;
		tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;

		while (*index + tempIndex <= *endindex)
		{
			memset(SubCode, 0x0, 100);
			temp = *index + tempIndex;
			tempIndex += MoveCodeIndexUntillNoBlank(Code, &temp);
			tempReturnLength = DivisionCodeByLineFeed(Code, &temp, SubCode);
			temp = 0;
			temppSubCode = SubCode;
			CheckSyntaxKey((void**)(&temppSubCode), &temp, &syntaxKey1, &syntaxKey2);
			switch (syntaxKey1)
			{
			case elseType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index - 1;
				tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo - 1;
				
				tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo;
				tempChildeCodeLineNo[tempChildBlockNum][2] = elseType;
				tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;

				tempLBraceNum = 0;
				tempRBraceNum = 0;
				tempStatus = true;
				break;
			}
			case elseifType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index - 1;
				tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo - 1;
				tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo;
				tempChildeCodeLineNo[tempChildBlockNum][2] = 0;
				tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;
				tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index + tempReturnLength + 2;
				tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo;
				
				tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
				tempChildeCodeLineNo[tempChildBlockNum][2] = elseifType;
				tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index + tempReturnLength + 3;

				tempLBraceNum = 0;
				tempRBraceNum = 0;
				tempStatus = true;
				break;
			}
			default:
			{
				break;
			}
			}
			if ((*(char**)Code)[*index + tempIndex] == '{' && tempStatus)
			{
				tempLBraceNum++;
			}
			if ((*(char**)Code)[*index + tempIndex] == '}' && tempStatus)
			{
				tempRBraceNum++;
			}

			if (tempLBraceNum == tempRBraceNum)
			{
				tempLBraceNum = 0;
				tempRBraceNum = 0;
			}

			temppSubCode = SubCode;
			if (CheckReturnCodeLine(&temppSubCode))
			{
				pCodeBlock->bReturn = true;
				pCodeBlock->ReturnGlobalLineNo[pCodeBlock->ReturnNum++] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo;

			}

			tempLocalLineNo++;
			tempIndex += tempReturnLength + 2;
		}

		tempChildeCodeLineNo[tempChildBlockNum][4] = *endindex;
		tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StopGlobalLineNo;

		if (tempChildBlockNum > 1)
		{
			pCodeBlock->bChildBlock = true;
			pCodeBlock->ChildBlockNum = tempChildBlockNum;
			InitCodeBlock(&(pCodeBlock->pChildBlock));
			ptempCodeBlock = pCodeBlock->pChildBlock;
			ptempCodeBlock->bParent = true;
			ptempCodeBlock->pParent = pCodeBlock;
			for (int i = 0; i < tempChildBlockNum - 1; i++)
			{
				InitCodeBlock(&(ptempCodeBlock->pNext));
				ptempCodeBlock->StartGlobalLineNo = tempChildeCodeLineNo[i][0];
				ptempCodeBlock->StopGlobalLineNo = tempChildeCodeLineNo[i][1];
				ptempCodeBlock->CodeBlockType = tempChildeCodeLineNo[i][2];
				DivisionCodeBlock(Code, &tempChildeCodeLineNo[i][3], &tempChildeCodeLineNo[i][4], tempChildeCodeLineNo[i][2], ptempCodeBlock);
				ptempCodeBlock = ptempCodeBlock->pNext;
				ptempCodeBlock->bParent = true;
				ptempCodeBlock->pParent = pCodeBlock;
			}
			ptempCodeBlock->StartGlobalLineNo = tempChildeCodeLineNo[tempChildBlockNum - 1][0];
			ptempCodeBlock->StopGlobalLineNo = tempChildeCodeLineNo[tempChildBlockNum - 1][1];
			ptempCodeBlock->CodeBlockType = tempChildeCodeLineNo[tempChildBlockNum - 1][2];
			DivisionCodeBlock(Code, &tempChildeCodeLineNo[tempChildBlockNum - 1][3], &tempChildeCodeLineNo[tempChildBlockNum - 1][4], tempChildeCodeLineNo[tempChildBlockNum - 1][2], ptempCodeBlock);

		}
		else
		{
			pCodeBlock->bChildBlock = false;
			pCodeBlock->pChildBlock = NULL;
			pCodeBlock->ChildBlockNum = 0;
		}

		return 1;
	}

	int ProcessSwitchBrach(void** Code, int* index, int* endindex, int CodeBockType, PCodeBlock pCodeBlock)
	{
		int tempIndex = 0;
		int tempChildBlockNum = 0;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempLocalLineNo = 0;
		int tempChildeCodeLineNo[10][5]; //0: startGlobalLineNo; 1: EndGlobalLineNo; 2: CodeBlockType; 3:startIndexNo; 4: endIndexNo
		char SubCode[100];
		char* temppSubCode;
		int temp = 0;
		int tempReturnLength = 0;
		bool tempStatus = false;
		SyntaxKey syntaxKey1;
		SyntaxKey syntaxKey2;
		PCodeBlock ptempCodeBlock;

		tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo;
		tempChildeCodeLineNo[tempChildBlockNum][2] = switchType;
		tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;

		while (*index + tempIndex <= *endindex)
		{
			memset(SubCode, 0x0, 100);
			temp = *index + tempIndex;
			tempIndex += MoveCodeIndexUntillNoBlank(Code, &temp);
			tempReturnLength = DivisionCodeByLineFeed(Code, &temp, SubCode);
			temp = 0;
			temppSubCode = SubCode;
			CheckSyntaxKey((void**)(&temppSubCode), &temp, &syntaxKey1, &syntaxKey2);
			switch (syntaxKey1)
			{
			case caseType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index - 1;
				tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo - 1;
				tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo;
				tempChildeCodeLineNo[tempChildBlockNum][2] = 0;
				tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;
				tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index + tempReturnLength + 2;
				tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo;

				tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo + 1;
				tempChildeCodeLineNo[tempChildBlockNum][2] = caseType;
				tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index + tempReturnLength + 3;

				tempLBraceNum = 0;
				tempRBraceNum = 0;
				tempStatus = true;
				break;
			}
			case defaultType:
			{
				if (tempLBraceNum != 0)
				{
					break;
				}
				tempChildeCodeLineNo[tempChildBlockNum][4] = tempIndex + *index - 1;
				tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo - 1;

				tempChildeCodeLineNo[tempChildBlockNum][0] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo;
				tempChildeCodeLineNo[tempChildBlockNum][2] = defaultType;
				tempChildeCodeLineNo[tempChildBlockNum][3] = tempIndex + *index;

				tempLBraceNum = 0;
				tempRBraceNum = 0;
				tempStatus = true;
				break;
			}
			default:
			{
				break;
			}
			}
			if ((*(char**)Code)[*index + tempIndex] == '{' && tempStatus)
			{
				tempLBraceNum++;
			}
			if ((*(char**)Code)[*index + tempIndex] == '}' && tempStatus)
			{
				tempRBraceNum++;
			}

			if (tempLBraceNum == tempRBraceNum)
			{
				tempLBraceNum = 0;
				tempRBraceNum = 0;
			}

			temppSubCode = SubCode;
			if (CheckReturnCodeLine(&temppSubCode))
			{
				pCodeBlock->bReturn = true;
				pCodeBlock->ReturnGlobalLineNo[pCodeBlock->ReturnNum++] = pCodeBlock->StartGlobalLineNo + tempLocalLineNo;

			}

			tempLocalLineNo++;
			tempIndex += tempReturnLength + 2;
		}

		tempChildeCodeLineNo[tempChildBlockNum][4] = *endindex;
		tempChildeCodeLineNo[tempChildBlockNum++][1] = pCodeBlock->StopGlobalLineNo;

		if (tempChildBlockNum > 1)
		{
			pCodeBlock->bChildBlock = true;
			pCodeBlock->ChildBlockNum = tempChildBlockNum;
			InitCodeBlock(&(pCodeBlock->pChildBlock));
			ptempCodeBlock = pCodeBlock->pChildBlock;
			ptempCodeBlock->bParent = true;
			ptempCodeBlock->pParent = pCodeBlock;
			for (int i = 0; i < tempChildBlockNum - 1; i++)
			{
				InitCodeBlock(&(ptempCodeBlock->pNext));
				ptempCodeBlock->StartGlobalLineNo = tempChildeCodeLineNo[i][0];
				ptempCodeBlock->StopGlobalLineNo = tempChildeCodeLineNo[i][1];
				ptempCodeBlock->CodeBlockType = tempChildeCodeLineNo[i][2];
				DivisionCodeBlock(Code, &tempChildeCodeLineNo[i][3], &tempChildeCodeLineNo[i][4], tempChildeCodeLineNo[i][2], ptempCodeBlock);
				ptempCodeBlock = ptempCodeBlock->pNext;
				ptempCodeBlock->bParent = true;
				ptempCodeBlock->pParent = pCodeBlock;
			}
			ptempCodeBlock->StartGlobalLineNo = tempChildeCodeLineNo[tempChildBlockNum - 1][0];
			ptempCodeBlock->StopGlobalLineNo = tempChildeCodeLineNo[tempChildBlockNum - 1][1];
			ptempCodeBlock->CodeBlockType = tempChildeCodeLineNo[tempChildBlockNum - 1][2];
			DivisionCodeBlock(Code, &tempChildeCodeLineNo[tempChildBlockNum - 1][3], &tempChildeCodeLineNo[tempChildBlockNum - 1][4], tempChildeCodeLineNo[tempChildBlockNum - 1][2], ptempCodeBlock);

		}
		else
		{
			pCodeBlock->bChildBlock = false;
			pCodeBlock->pChildBlock = NULL;
			pCodeBlock->ChildBlockNum = 0;
		}

		return 1;
	}

	bool CheckReturnCodeLine(char** Code)
	{
		int temp = 0;
		char tempSubCode[80];
		memset(tempSubCode, 0x0, 80);
		DivisionCodeByBlank((void**)Code, &temp, tempSubCode);
		if (strcmp(tempSubCode, "return") == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	int CheckVarDefByOtherVarStatus(char** Code, PVariable pVar, PSourceFunction pFunc)
	{
		int tempOtherVarNum = 0;
		int tempOtherMacroNum = 0;
		int tempIndex = 0;
		int tempReturnLength = 0;
		int i;
		int tempInt = 0;
		int tempReturnVarNameNum = 0;
		char tempSubCode[50];
		char** temppSubCode;
		PVariable temppVar;
		PMacro temppMacro;
		PStoreVarDefInfo temppStore;
		PStoreVarDefInfo temppStore1;
		PStoreMacroDefInfo temppStoreMacro;
		PStoreMacroDefInfo temppStoreMacro1;
		PStoreVarNameInfo temppReturnVarName[5];

		temppSubCode = new char*;
		*temppSubCode = tempSubCode;
		for (int i = 0; i < 5; i++)
		{
			temppReturnVarName[i] = new StoreVarNameInfo;
		}

		//temppVar = new Variable;
		//temppMacro = new Macro;
		//temppStore = new StoreVarDefInfo;
		pVar->bDefByOthersVar = false;

		while (true)
		{
			memset(tempSubCode, 0x0, 50);
			tempReturnLength = CheckCodeBlank((void**)Code, &tempIndex);
			
			//�ⲿ�����޸Ĺ�bug�����Ƿ���ȷ�д�ʵ�����
			if (tempReturnLength != -1)
			{
				for (i = 0; i < tempReturnLength; i++)
				{
					tempSubCode[i] = (*Code)[tempIndex + i];
				}
				tempSubCode[i] = 0x0;
				tempIndex = tempIndex + tempReturnLength;
				MoveCodeIndexUntillNoBlank((void**)Code, &tempIndex);
			}
			else
			{
				if (CheckNamableCharacter(&((*Code)[tempIndex])) == 1)
				{
					strcpy(tempSubCode, &((*Code)[tempIndex]));
				}
			}
			//�޸Ĺ�bug����

			//�������д�����Ϊ����ȡ���ж༶���ƽṹ�ı���׼���ģ�������δ��ʹ�ã�ֻ��д���⹩֮��ʹ�� 22.9.28
			tempInt = 0;
			ProcessVar((void**)temppSubCode, &tempInt, temppReturnVarName, &tempReturnVarNameNum);
			//
			if (CheckVarExist(tempSubCode, pFunc, &temppVar) == 1)
			{
				pVar->bDefByOthersVar = true;
				/*temppStore = pVar->pDefOthersVar;
				for (int i = 0; i < pVar->DefByOthersVarNum; i++)
				{
					temppStore = temppStore->pNext;
				}*/
				temppStore = new StoreVarDefInfo;
				if (pVar->DefByOthersVarNum == 0)
				{
					pVar->pDefOthersVar = temppStore;
				}
				else
				{
					temppStore1 = pVar->pDefOthersVar;
					for (int i = 1; i < pVar->DefByOthersVarNum; i++)
					{
						temppStore1 = temppStore1->pNext;
					}
					temppStore1->pNext = temppStore;
				}
				strcpy(temppStore->Name, temppVar->Name);
				temppStore->DefGlobalLineNo = AnalysisCodeLineNo;
				temppStore->pParent = pVar;
				temppStore->pVarDef = temppVar;
				temppStore->InFunctionNo = pFunc->FunctionNo;

				pVar->DefByOthersVarNum++;
				tempOtherVarNum++;
			}

			if (CheckMacroExist(tempSubCode, pFunc, &temppMacro) == 1)
			{
				pVar->bDefByOthersMacro = true;
				temppStoreMacro = new StoreMacroDefInfo;
				if (pVar->DefByOthersMacroNum == 0)
				{
					pVar->pDefOthersMacro = temppStoreMacro;
				}
				else
				{
					temppStoreMacro1 = pVar->pDefOthersMacro;
					for (int i = 1; i < pVar->DefByOthersMacroNum; i++)
					{
						temppStoreMacro1 = temppStoreMacro1->pNext;
					}
					temppStoreMacro1->pNext = temppStoreMacro;
				}
				strcpy(temppStoreMacro->Name, temppMacro->Name);
				temppStoreMacro->DefGlobalLineNo = AnalysisCodeLineNo;
				temppStoreMacro->bChangeOtherVar = false;
				temppStoreMacro->ChangeGlobalLineNo = AnalysisCodeLineNo;
				temppStoreMacro->InFunctionNo = pFunc->FunctionNo;
				temppStoreMacro->pParent = pVar;
				temppStoreMacro->pMacroDef = temppMacro;
				temppStoreMacro->pNext = NULL;

				pVar->DefByOthersMacroNum++;
				tempOtherMacroNum++;
			}	

			if (tempReturnLength == -1)
			{
				break;
			}
		}

		for (int i = 0; i < 5; i++)
		{
			delete temppReturnVarName[i];
		}
		delete temppSubCode;

		return tempOtherVarNum + tempOtherMacroNum;
	}

	int CheckVarExist(char* pVar, PSourceFunction pFunc, PVariable* pReturn)
	{
		int tempVarNum = 0;
		int tempIndex = 0;
		int tempArrayLength = 0;
		int tempArrayIndex[10];
		int tempSubCodeNameNum = 0;
		int tempSubCodeNameReturn = 0;
		char** tempName;
		char** tempArray;
		char** tempppVar;
		tempppVar = new char*;
		*tempppVar = pVar;
		
		tempName = new char* [10];
		tempArray = new char* [10];
		for (int i = 0; i < 10; i++)
		{
			tempName[i] = new char[50];
			tempArray[i] = new char[50];
		}

		//����xxx.xxx / xxx->xxx�������͵ı����ͽ��м򵥴����ˣ�
		//tempSubCodeNameReturn = GetSubCodeName((void**)tempppVar, &tempIndex, tempName, &tempSubCodeNameNum, tempArray, &tempArrayLength, tempArrayIndex);
		tempVarNum = pSourceCodeFile->VariableNum;
		for (int i = 0; i < tempVarNum; i++)
		{
			if (strcmp(pVar, ((pSourceCodeFile->Variable)[i])->Name) == 0)
			{
				*pReturn = (pSourceCodeFile->Variable)[i];
				return 1;
			}
		}

		if (pFunc != NULL)
		{
			tempVarNum = pFunc->VariableNum;
			for (int i = 0; i < tempVarNum; i++)
			{
				if (strcmp(pVar, ((pFunc->Variable)[i])->Name) == 0)
				{
					*pReturn = (pFunc->Variable)[i];
					return 1;
				}
			}
		}

		for (int i = 0; i < 10; i++)
		{
			if (strlen(tempName[i]) != 0)
			{
				delete [] tempName[i];
			}
			if (strlen(tempArray[i]) != 0)
			{
				delete [] tempArray[i];
			}
		}
		delete[] tempName;
		delete[] tempArray;

		return 0;
	}

	int CheckMacroExist(char* pMacro, PSourceFunction pFunc, PMacro* pReturn)
	{
		int tempMacroNum = 0;

		tempMacroNum = pSourceCodeFile->MacroNum;
		for (int i = 0; i < tempMacroNum; i++)
		{
			if (strcmp(pMacro, ((pSourceCodeFile->Macro)[i])->Name) == 0)
			{
				*pReturn = (pSourceCodeFile->Macro)[i];
				return 1;
			}
		}
		//���ܺ�����Ҳ���ڶ���ĺ궨��

		return 0;
	}

	int CheckFuncExist(char* pFunc, PSourceFunction* pReturn)
	{
		int tempMacroNum = 0;

		tempMacroNum = pSourceCodeFile->FunctionNum;
		for (int i = 0; i < tempMacroNum; i++)
		{
			if (strcmp(pFunc, ((pSourceCodeFile->Function)[i])->FunctionName) == 0)
			{
				*pReturn = (pSourceCodeFile->Function)[i];
				return 1;
			}
		}

		return 0;
	}

	//��鴫������Code���Ƿ����Ѷ���ı������ߺ������ã��������ö�Ӧ���Ӵ���������Ŀ�������ֵ�ı���м�¼
	int CheckVarValueChange(char* Code, PVariable pVar, PSourceFunction pFunc)
	{
		int tempIndex = 0;
		int tempOtherVarOrFunctionCallReturnNum = 0;
		int tempReturnLength = 0;
		char tempSubCode[150];
		char* temppSubCode;
		int tempFunctionCallArray[5];
		int tempFunctionCallNum;
		int tempParNum = 0;
		int tempLBraceNum;
		int tempRBraceNum;
		int tempSubCodeLength;
		char tempFunctionName[80];
		int tempIndexStart;
		int tempIndexStop;
		char** tempParName;
		int tempInt = 0;
		int tempCodeLength = 0;

		tempParName = new char* [15];
		for (int i = 0; i < 15; i++)
		{
			tempParName[i] = new char[100];
			strcpy(tempParName[i], "");
		}

		temppSubCode = tempSubCode;
		tempCodeLength = strlen(Code);

		while (true)
		{
			if (tempIndex > tempCodeLength)
			{
				break;
			}
			memset(tempSubCode, 0x0, 150);
			tempReturnLength = CheckCodeBlankNew((void**)&Code, &tempIndex, tempSubCode);
			tempIndex = tempIndex + tempReturnLength + 1;
			//tempReturnLength = CheckCodeBlank((void**)&Code, &tempIndex);

			//if (tempReturnLength == -1)
			//{
			//	strcpy(tempSubCode, &(Code[tempIndex]));
			//}
			//else
			//{
			//	for (int i = 0; i < tempReturnLength; i++)
			//	{
			//		tempSubCode[i] = Code[tempIndex + i];
			//	}
			//	tempSubCode[tempReturnLength] = 0x0;
			//}
			//tempIndex = tempIndex + tempReturnLength + 1;
			//
			////fix bug at 23.3.15
			//if (tempReturnLength != -1)
			//{
			//	tempInt = 0;
			//	tempLBraceNum = 1;
			//	tempRBraceNum = 0;
			//	tempIndex--;
			//	tempSubCodeLength = tempReturnLength;
			//	while (true)
			//	{
			//		if (Code[tempIndex] == '(')
			//		{
			//			tempLBraceNum++;
			//		}
			//		if (Code[tempIndex] == ')')
			//		{
			//			tempRBraceNum++;
			//		}

			//		tempSubCode[tempSubCodeLength++] = Code[tempIndex];

			//		if (Code[tempIndex] == ')' && CheckCodeBracketIsCompletion((void**)(&temppSubCode), &tempInt, &tempSubCodeLength))
			//		{
			//			tempIndex++;
			//			break;
			//		}

			//		tempIndex++;
			//	}
			//	tempSubCode[tempSubCodeLength] = 0x0;
			//}

			//updata at 23.1.6
			//pVar->bChangVar = true;

			/*temppSubCode = tempSubCode;*/
			tempFunctionCallNum = CheckFunctionCall((void**)(&temppSubCode), 0, strlen(tempSubCode), tempFunctionCallArray);
			if (tempFunctionCallNum == 0)
			{
				CheckVarValueChangeByOtherVar(tempSubCode, pVar, pFunc);
			}
			else
			{
				// Update at 22.10.1����ԭ�е�ֻ����CheckVarValueChangeByFunctionCallReturn(tempSubCode, pVar, pFunc);
				//����Ϊ���´��룬��ΪCheckVarValueChangeByFunctionCallReturn�����Ǽ�鴫��ȥ�ĵ�һ�������Ƿ��Ǻ���
				//���Ե�һ������ֱ�ӽ������к�����飬��������������ִ����ȡ������tempSubCodeҪô�����������������
				//Ҫô�Ǵ���һ������(�͵�һ�������Ķ����������Ĳ����ã����Խ��д�����£�������CheckVarValueChangeByFunctionCallReturn
				//��һ�����������ȥ���Ǻ���������ֱ�ӶԺ��������м�飬�鿴�Ƿ�Ϊ�Ѷ���ĺ�����Ȼ�������ز�����Ŀǰ������˼����
				//���ú����Ĳ���Ҳ�����ı䷵��ֵ����ֵ�ı�������Ϊ���Ӹı��˷���ֵ������ֵ�������Ժ�������ѭ��������������Ϊ�ı�
				//����ֵ�ı�����������ص���Ϣ
				/*if (tempReturnLength != -1)
				{
					tempInt = 0;
					tempLBraceNum = 1;
					tempRBraceNum = 0;
					tempIndex--;
					tempSubCodeLength = tempReturnLength;
					while (true)
					{
						if (Code[tempIndex] == '(')
						{
							tempLBraceNum++;
						}
						if (Code[tempIndex] == ')')
						{
							tempRBraceNum++;
						}

						tempSubCode[tempSubCodeLength++] = Code[tempIndex];

						if (Code[tempIndex] == ')' && CheckCodeBracketIsCompletion((void**)(&temppSubCode), &tempInt, &tempSubCodeLength))
						{
							tempIndex++;
							break;
						}

						tempIndex++;
					}
					tempSubCode[tempSubCodeLength] = 0x0;
				}*/
				for (int i = 0; i < tempFunctionCallNum; i++)
				{
					tempParNum = 0;
					GetNameFromLastNamePos((void**)(&temppSubCode), tempFunctionCallArray[i], tempFunctionName);
					tempFunctionCallArray[i]++;
					if (GetBracketContent((void**)(&temppSubCode), &(tempFunctionCallArray[i]), &tempIndexStart, &tempIndexStop) == -1)
					{
						//std::cout << "CodeLineHaveFunctionCallAndMarkInPar fail no Par" << std::endl;
					}
					else
					{
						GetFunctionCallParName((void**)(&temppSubCode), &tempIndexStart, &tempIndexStop, tempParName, &tempParNum);
					}
					CheckVarValueChangeByFunctionCallReturn(tempFunctionName, pVar, pFunc);
					for (int z = 0; z < tempParNum; z++)
					{
						CheckVarValueChangeByOtherVar(tempParName[z], pVar, pFunc);
					}
				}
				/*CheckVarValueChangeByFunctionCallReturn(tempSubCode, pVar, pFunc);*/
			}

			if (tempReturnLength == -1)
			{
				break;
			}
		}

		for (int i = 0; i < 15; i++)
		{
			if (strlen(tempParName[i]) != 0)
			{
				delete[] tempParName[i];;
			}
		}
		delete[] tempParName;

		return 1;
	}

	//��鴫������Code���Ƿ��к������÷��أ�������Ŀ�������ֵ�ı���м�¼�� update at 22.10.1��Code ��ʵ����Function Name
	int CheckVarValueChangeByFunctionCallReturn(char* Code, PVariable pVar, PSourceFunction pFunc)
	{
		int tempIndex;
		PSourceFunction temppFunc;
		PStoreFunctionDefInfo tempStoreFunc;
		PStoreFunctionDefInfo tempStoreFunc1;
		PStoreFunctionDefInfo tempStoreFunc2;

		pVar->bFunctionCallReturn = true;
		tempStoreFunc = new StoreFunctionDefInfo;
		if (pVar->FunctionCallReturnNum == 0)
		{
			pVar->pFunctionCallReturn = tempStoreFunc;
		}
		else
		{
			tempStoreFunc1 = pVar->pFunctionCallReturn;
			for (int i = 1; i < pVar->FunctionCallReturnNum; i++)
			{
				tempStoreFunc1 = tempStoreFunc1->pNext;
			}
			tempStoreFunc1->pNext = tempStoreFunc;
		}
		
		if (CheckFuncExist(Code, &temppFunc) == 1)
		{
			strcpy(tempStoreFunc->Name, temppFunc->FunctionName);
			tempStoreFunc->bUserDefFunction = true;
			tempStoreFunc->pFuncDef = temppFunc;
		}
		else
		{
			strcpy(tempStoreFunc->Name, Code);
			tempStoreFunc->pFuncDef = NULL;
		}
		tempStoreFunc->FunctionCallGlobalLineNo = AnalysisCodeLineNo;
		tempStoreFunc->pParent = pVar;
		tempStoreFunc->ParNo = -1;

		pVar->FunctionCallReturnNum++;

		return 1;
	}

	//��鴫������Code���Ƿ����Ѷ���ı�����������Ŀ�������ֵ�ı���м�¼
	int CheckVarValueChangeByOtherVar(char* Code, PVariable pVar, PSourceFunction pFunc)
	{
		PVariable temppVar;
		PMacro temppMacro;
		PStoreVarDefInfo temppStore;
		PStoreVarDefInfo temppStore1;
		PStoreVarDefInfo temppStore2;
		PStoreMacroDefInfo temppStoreMacro;
		PStoreMacroDefInfo temppStoreMacro1;
		int tempIndex = 0;
		int tempArrayLength = 0;
		int tempArrayIndex[10];
		int tempSubCodeNameNum = 0;
		int tempSubCodeNameReturn = 0;
		char** tempName;
		char** tempArray;
		char** tempppVar;
		tempppVar = new char*;
		*tempppVar = Code;

		tempName = new char* [10];
		tempArray = new char* [10];
		for (int i = 0; i < 10; i++)
		{
			tempName[i] = new char[80];
			tempArray[i] = new char[80];
		}

		/*pVar->bChangVar = false;
		pVar->ChangeVarNum = 0;*/
		
		//�������㷨���£��µ��㷨�߼��ǣ��ȼ��ı����ֵ�������Ƿ��Ǻ궨�壬��������������Ϣ��������������ԭ���Ĵ����߼����ȼ���Ƿ����Ѿ�����ı���������д����������Ϣ������������д��һЩ������Ϣ��
		tempSubCodeNameReturn = GetSubCodeName((void**)tempppVar, &tempIndex, tempName, &tempSubCodeNameNum, tempArray, &tempArrayLength, tempArrayIndex);
		for (int i = 0; i < tempSubCodeNameReturn; i++)
		{
			if (CheckMacroExist(tempName[i], pFunc, &temppMacro) == 1)
			{
				pVar->bChangeByOthersMacro = true;
				temppStoreMacro = new StoreMacroDefInfo;
				if (pVar->ChangeByOthersMacroNum == 0)
				{
					pVar->pChangeOtherMacro = temppStoreMacro;
				}
				else
				{
					temppStoreMacro1 = pVar->pChangeOtherMacro;
					for (int i = 1; i < pVar->ChangeByOthersMacroNum; i++)
					{
						temppStoreMacro1 = temppStoreMacro1->pNext;
					}
					temppStoreMacro1->pNext = temppStoreMacro;
				}

				strcpy(temppStoreMacro->Name, temppMacro->Name);
				temppStoreMacro->pMacroDef = temppMacro;
				temppStoreMacro->ChangeGlobalLineNo = AnalysisCodeLineNo;
				temppStoreMacro->pParent = pVar;
				if (pFunc != NULL)
				{
					temppStoreMacro->InFunctionNo = pFunc->FunctionNo;
				}
				else
				{
					temppStoreMacro->InFunctionNo = -1;
				}
				temppStoreMacro->bChangeOtherVar = true;

				pVar->ChangeByOthersMacroNum++;
			}
			else
			{
				pVar->bChangVar = true;
				temppStore = new StoreVarDefInfo;
				if (pVar->ChangeVarNum == 0)
				{
					pVar->pChangVar = temppStore;
				}
				else
				{
					temppStore1 = pVar->pChangVar;
					for (int i = 1; i < pVar->ChangeVarNum; i++)
					{
						temppStore1 = temppStore1->pNext;
					}
					temppStore1->pNext = temppStore;
				}

				if (CheckVarExist(tempName[i], pFunc, &temppVar) == 1)
				{

					strcpy(temppStore->Name, temppVar->Name);
					temppStore->pVarDef = temppVar;

					//��鵽����ֵ�Ǳ�һ���Ѷ���ı������ĵģ���ôͬʱҲҪ�޸ĶԷ������޸�����ֵ���������ֵ
					temppStore2 = new StoreVarDefInfo;
					temppVar->bChangeOtherVar = true;
					if (temppVar->ChangeOtherVarNum == 0)
					{
						temppVar->pChangeOtherVar = temppStore2;
					}
					else
					{
						temppStore1 = temppVar->pChangeOtherVar;
						for (int i = 1; i < temppVar->ChangeOtherVarNum; i++)
						{
							temppStore1 = temppStore1->pNext;
						}
						temppStore1->pNext = temppStore2;
					}
					temppVar->ChangeOtherVarNum++;

					strcpy(temppStore2->Name, pVar->Name);
					temppStore2->bChangeOtherVar = true;
					temppStore2->bChangVar = false;
					temppStore2->ChangGlobalLineNo = AnalysisCodeLineNo;
					if (pFunc != NULL)
					{
						temppStore2->InFunctionNo = pFunc->FunctionNo;
					}
					else
					{
						temppStore2->InFunctionNo = -1;
					}
					temppStore2->pParent = temppVar;
					temppStore2->pVarDef = pVar;
				}
				else
				{
					strcpy(temppStore->Name, tempName[i]);
					temppStore->pVarDef = NULL;
				}
				temppStore->ChangGlobalLineNo = AnalysisCodeLineNo;
				temppStore->pParent = pVar;
				if (pFunc != NULL)
				{
					temppStore->InFunctionNo = pFunc->FunctionNo;
				}
				else
				{
					temppStore->InFunctionNo = -1;
				}
				temppStore->bChangVar = true;
				temppStore->bChangeOtherVar = false;

				pVar->ChangeVarNum++;
			}
		}

		//update at 23.3.13
		if (tempSubCodeNameReturn == 0)
		{
			pVar->bChangVar = true;
			temppStore = new StoreVarDefInfo;
			if (pVar->ChangeVarNum == 0)
			{
				pVar->pChangVar = temppStore;
			}
			else
			{
				temppStore1 = pVar->pChangVar;
				for (int i = 1; i < pVar->ChangeVarNum; i++)
				{
					temppStore1 = temppStore1->pNext;
				}
				temppStore1->pNext = temppStore;
			}

			strcpy(temppStore->Name, *tempppVar);
			temppStore->pVarDef = NULL;
			temppStore->ChangGlobalLineNo = AnalysisCodeLineNo;
			temppStore->pParent = pVar;
			if (pFunc != NULL)
			{
				temppStore->InFunctionNo = pFunc->FunctionNo;
			}
			else
			{
				temppStore->InFunctionNo = -1;
			}
			temppStore->bChangVar = true;
			temppStore->bChangeOtherVar = false;

			pVar->ChangeVarNum++;
		}

		for (int i = 0; i < 10; i++)
		{
			if (strlen(tempName[i]) != 0)
			{
				delete[] tempName[i];
			}
			if (strlen(tempArray[i]) != 0)
			{
				delete[] tempArray[i];
			}
		}
		delete[] tempName;
		delete[] tempArray;

		return 1;
	}

	int GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(PVariable target, PVariable* pVarArray, PCodeExePathBlock pCodeBlock)
	{
		PStoreVarDefInfo temppStoreVarDefInfo;
		PStoreMacroDefInfo temppStoreMacroDefInfo;
		PSourceLine tempCodeLine;
		PSourceFunction tempFunc;
		int tempIntIndexArray[10];
		int tempIntIndexArrayLength = 0;

		if (target->bDefByOthersVar)
		{
			temppStoreVarDefInfo = target->pDefOthersVar;
			for (int i = 0; i < target->DefByOthersVarNum; i++)
			{
				if (i == pCodeBlock->VarDefByOtherVarNum)
				{
					break;
				}
				pVarArray[(pCodeBlock->BlockRealVarDefByOtherVarNum)++] = temppStoreVarDefInfo->pVarDef;
				(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->DefGlobalLineNo;

				GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(temppStoreVarDefInfo->pVarDef, pVarArray, pCodeBlock);

				temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
			}
		}
		if (target->bDefByOthersMacro)
		{
			temppStoreMacroDefInfo = target->pDefOthersMacro;
			for (int i = 0; i < target->DefByOthersMacroNum; i++)
			{
				if (i == pCodeBlock->VarDefByOtherMacroNum)
				{
					break;
				}
				//�����û�������洦���������������������궨��ṹ���ػ�ȥ�������Ҫ��Ҫ���Ӻ����������淵�صĺ궨��ṹ
				(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreMacroDefInfo->DefGlobalLineNo;

				temppStoreMacroDefInfo = temppStoreMacroDefInfo->pNext;
			}
		}
		pVarArray[(pCodeBlock->BlockRealVarDefByOtherVarNum)++] = target;
		(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = target->DefCodeLineGlobalNo;

		//update at 2023.1.2
		//���ӶԱ����������ڴ����н��н���������������ڴ����д��ڸ�ֵ��Ϊ����ô�Ը�ֵ�ı�����궨��ȡ�䶨�����ڴ�����
		GetCodeLineStruct(target->DefCodeLineGlobalNo, &tempCodeLine, &tempFunc);
		CheckVarDefCodeLineValueAssignmentVarOrMacroDefInfo(tempCodeLine, tempFunc, tempIntIndexArray, &tempIntIndexArrayLength);
		for (int i = 0; i < tempIntIndexArrayLength; i++)
		{
			(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = tempIntIndexArray[i];
		}
		
		//updata at 23.1.6
		if (target->bAllocMemory)
		{
			GetVarAllocInfo(target, pCodeBlock);
		}

		return 1;
	}

	int GetVarChangeByOtherVar(PVariable target, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeBlock)
	{
		PStoreVarDefInfo temppStoreVarDefInfo;
		
		if (target->bChangVar)
		{
			temppStoreVarDefInfo = target->pChangVar;

			if (temppStoreVarDefInfo->ChangGlobalLineNo > CodeLineNo)
			{
				//�о���Ӧ���������������Ķ�����صĴ�������ȡ����Ƭ�У��������Ӧ����ר����ȡ�����������صĴ����к������еģ��е㹦�������
				GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(target, pVarArray, pCodeBlock);
				return 1;
			}

			for (int i = 0; i < target->ChangeVarNum; i++)
			{
				if (temppStoreVarDefInfo->pNext == NULL)
				{
					break;
				}
				else
				{
					if ((temppStoreVarDefInfo->pNext)->ChangGlobalLineNo > CodeLineNo)
					{
						break;
					}
					temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
				}
			}
			//Ӧ������_CodeExePathBlock�ṹ��������һ��BlockRealVarChangeByOthersVarNum��VarChangeByOthersVarNum�ֶΣ���������һ�д��룬������û��ǰ��˵���ֶε�ԭ���ˣ�Ӧ��������ȡ������Ƭʱ�ı����ֵ�������������ص���Ϣû�й�������ְ�
			pVarArray[(pCodeBlock->BlockRealVarDefByOtherVarNum)++] = temppStoreVarDefInfo->pVarDef;
			(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;

			if (temppStoreVarDefInfo->pVarDef == NULL)
			{
				return 1;
			}

			GetVarChangeByOtherVar(temppStoreVarDefInfo->pVarDef, pVarArray, temppStoreVarDefInfo->ChangGlobalLineNo, pCodeBlock);
		}
		else
		{
			//�о���Ӧ���������������Ķ�����صĴ�������ȡ����Ƭ�У��������Ӧ����ר����ȡ�����������صĴ����к������еģ��е㹦�������
			GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(target, pVarArray, pCodeBlock);
		}

		return 1;
	}

	int GetVarChangeOtherVar(PVariable target, PSourceFunction pFunc, int* ArrayLenth, PVariable* pVarArray, int* CodeLineNoArray, int CodeLineNoStart, int CodeLineNoStop)
	{
		PStoreVarDefInfo temppStoreVarDefInfo;

		if (target->bChangeOtherVar)
		{
			temppStoreVarDefInfo = target->pChangeOtherVar;
			for (int i = 0; i < target->ChangeOtherVarNum; i++)
			{
				if (temppStoreVarDefInfo->ChangGlobalLineNo >= CodeLineNoStart && temppStoreVarDefInfo->ChangGlobalLineNo <= CodeLineNoStop)
				{
					pVarArray[(*ArrayLenth)] = temppStoreVarDefInfo->pVarDef;
					CodeLineNoArray[(*ArrayLenth)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
				}
				temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
			}
		}
		
		return 1;
	}

	int CheckCodeLineHaveImportAPI(PStoreSensitiveAPIInfo pStoreSSAPIInfo, int AlgorithmType)
	{
		int tempFunctionCallNum = 0;
		int tempFunctionCallIndex[5];
		int tempParNum = 0;
		int tempIndexStart = 0;
		int tempIndexStop = 0;
		int tempRealFunctionCallNum = 0;
		int tempRealVarChangeNum = 0;
		int tempArrayLenth;
		int tempCodeLineNoArray[500];                      //�������������ã��洢���ٵ���·��
		char* Code;
		char** temppCode;
		char tempFunctionName[80];
		char** tempParName;
		PVariable temppVarArray[20];
		PStoreVarDefInfo temppReturnVar[20];
		PStoreFunctionDefInfo temppReturnFunc[20];

		Code = (pStoreSSAPIInfo->pSourceLine)->buffer;
		temppCode = &Code;

		tempParName = new char* [9];
		for (int i = 0; i < 9; i++)
		{
			tempParName[i] = new char[100];
		}

		tempFunctionCallNum = CheckLineFunctionCall((void**)temppCode, tempFunctionCallIndex);
		for (int i = 0; i < tempFunctionCallNum; i++)
		{
			pStoreSSAPIInfo->RealFunctionCallNum = 0;
			pStoreSSAPIInfo->RealVarChangeNum = 0;
			pStoreSSAPIInfo->RealVarDefByOtherVarNum = 0;
			pStoreSSAPIInfo->RealMacroChangeNum = 0;
			pStoreSSAPIInfo->RealVarDefByOtherMacroNum = 0;
			for (int x = 0; x < 5; x++)
			{
				pStoreSSAPIInfo->CodePathBlockNum[x] = 0;
				pStoreSSAPIInfo->ReturnVarCodePathBlockNum[x] = 0;
			}
			GetNameFromLastNamePos((void**)temppCode, tempFunctionCallIndex[i], tempFunctionName);
			strcpy(pStoreSSAPIInfo->APIName, tempFunctionName);
			tempFunctionCallIndex[i]++;
			if (GetBracketContent((void**)temppCode, &(tempFunctionCallIndex[i]), &tempIndexStart, &tempIndexStop) == -1)
			{
				//std::cout << "CheckCodeLineHaveImportAPI fail no Par" << std::endl;
				//return 0;
			}
			else
			{
				//fix at 23.3.13
				tempParNum = 0;

				GetFunctionCallParName((void**)temppCode, &tempIndexStart, &tempIndexStop, tempParName, &tempParNum);
			}
			/*GetFunctionCallParName((void**)temppCode, &tempIndexStart, &tempIndexStop, tempParName, &tempParNum);*/
			if (GetForwardOrBackAPI(tempFunctionName, &tempParNum, tempParName, &tempArrayLenth, temppVarArray, (pStoreSSAPIInfo->pSourceLine)->GlobalLineNo, temppReturnVar, temppReturnFunc, pStoreSSAPIInfo, AlgorithmType) == 1)
			{
				//���������Ƕ��ҵ��ĸ���·�����в�����
				BaseCodeExePathGenerateCodeSlice(pStoreSSAPIInfo);
			}
			else
			{
				//std::cout << " CheckCodeLineHaveImportAPI fail: Not Have Impot API" << std::endl;
			}
		}

		for (int i = 0; i < 9; i++)
		{
			delete [] tempParName[i];
		}
		delete [] tempParName;

		return 1;
	}

	//
	int GetForwardOrBackAPI(char* target, int* ParNum, char** pPar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PStoreSensitiveAPIInfo pSSAPIInfo, int AlgorithmType)
	{
		PInterMediateFunctionInfo temppFunctionInfo;

		if (CheckFunctionInOneTypeInterMediate(target, 0, &temppFunctionInfo) == 0)       //����Ƿ���Input����InterMediate
		{
			if (CheckFunctionInOneTypeInterMediate(target, 1, &temppFunctionInfo) == 0)            //����Ƿ���SS����InterMediate
			{
				return 0;
			}
		}
		pSSAPIInfo->ParNum = temppFunctionInfo->FunctionParNum;

		if (temppFunctionInfo->FunctionParNum != *ParNum)
		{
#ifdef _DEBUG
			std::cout << "Get Forward Or Back API Fail , API Name: " << pSSAPIInfo->APIName<< std::endl;
#endif
			return 0;
		}

		//��ΪĿǰ���������ķ���ֵ�����ǵ���Ƭ��Ӱ��Ľ���������ǰAPI�У����Ծͽ����Դ�����ǰAPI�Ĺ����н������⴦���������������Ҫ�Ļ�����ֱ���ڴ˴���API���ú�Ӱ��ı������ӵ�����������Ƭ�����ı���������
		switch (temppFunctionInfo->FunctionDirect)
		{
		case -1:            //forward
		{
			switch (AlgorithmType)
			{
			case 0:
			case 1:
			{
				GetForwardAPI(target, ParNum, pPar, temppFunctionInfo, ArrayLenth, pVarArray, CodeLineNo, pReturnVar, pReturnFunc, pSSAPIInfo);
				break;
			}
			default:
				break;
			}
			break;
		}
		case 1:            //back
		{
			switch (AlgorithmType)
			{
			case 0:
			{
				GetBackAPI(target, ParNum, pPar, temppFunctionInfo, ArrayLenth, pVarArray, CodeLineNo, pSSAPIInfo);
				break;
			}
			case 1:
			{
				GetBackAPINew(target, ParNum, pPar, temppFunctionInfo, ArrayLenth, pVarArray, CodeLineNo, pSSAPIInfo);
				break;
			}
			default:
				break;
			}
			//GetBackAPI(target, ParNum, pPar, temppFunctionInfo, ArrayLenth, pVarArray, CodeLineNo, pSSAPIInfo);
			break;
		}
		default:
			break;
		}

		return 1;
	}

	int GetForwardAPI(char* target, int* ParNum, char** pPar, PInterMediateFunctionInfo pFuncInfo, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PStoreSensitiveAPIInfo pSSAPIInfo)
	{
		PCodeExePathBlock temppCodeBlock;
		char** temppStr;
		int tempVarNum = 0;
		PVariable temppVarArray[5];
		temppStr = new char*;
		/*temppCodeBlock = new PCodeExePathBlock;*/

		//��ʵ��ǰ��ƬҲӦ�ü�����Ǳ������ݹ����еı����Ƿ�Ϊ�������������Ǻ�������ֵ������Ǻ����������ټ�����Ƿ�Ὣ�ı��ֵ���ݻ�ȥ������ǻ��Ƿ���ֵ����ôӦ����������Դ�����øú����ĺ������������ݹ��̣�����Ŀǰ��ûд

		pSSAPIInfo->ParNum = pFuncInfo->FunctionParNum;
		for (int i = 0; i < pFuncInfo->FunctionParNum; i++)
		{
			//����������Ӹ���ϸ�ĸ��ݱ��������ͽ���һϵ�еĲ�����Ŀǰ�ʹֲڵĲ�����
			InitCodeExePathBlock(pSSAPIInfo, pSSAPIInfo->pFunc, &temppCodeBlock, pSSAPIInfo->PathTraceDeepth, pSSAPIInfo->VarDefByOtherVarNum, pSSAPIInfo->VarChangeNum, pSSAPIInfo->FunctionCallNum, pSSAPIInfo->MacroChangeNum, pSSAPIInfo->VarDefByOtherMacroNum, i, true);
			GetForwardAPIOnePar(pPar[i], &(pFuncInfo->pPar[i]), ArrayLenth, pVarArray, CodeLineNo, pReturnVar, pReturnFunc, (pSSAPIInfo->pCodePathBlock)[i], true);
		}

		if (pFuncInfo->FunctionType != 1)
		{
			*temppStr = (pSSAPIInfo->pSourceLine)->buffer;
			GetFunctionCallReturnVarInOneCodeLine((void**)temppStr, pSSAPIInfo->pFunc, &tempVarNum, temppVarArray);
			pSSAPIInfo->ReturnVarNum = tempVarNum;
			for (int i = 0; i < tempVarNum; i++)
			{
				InitCodeExePathBlock(pSSAPIInfo, pSSAPIInfo->pFunc, &temppCodeBlock, pSSAPIInfo->PathTraceDeepth, pSSAPIInfo->VarDefByOtherVarNum, pSSAPIInfo->VarChangeNum, pSSAPIInfo->FunctionCallNum, pSSAPIInfo->MacroChangeNum, pSSAPIInfo->VarDefByOtherMacroNum, i, false);
				//���ӶԱ������͵��жϣ��ж����Ƿ�Ϊ�û��Զ���ı������ͣ�������ҳ��û��Զ���ı������Ͷ������ڵĴ�����         22.9.30
				AddUserDefVarTypeInfoInCodeExePathBlock(temppVarArray[i], (pSSAPIInfo->pReturnVarCodePathBlock)[i]);
				GetVarChangeVarAndFunctionCallPathDefInfo(temppVarArray[i], ArrayLenth, pVarArray, CodeLineNo, pReturnVar, pReturnFunc, (pSSAPIInfo->pReturnVarCodePathBlock)[i], false);
			}
		}

		//delete temppCodeBlock;

		return 1;
	}

	int GetBackAPI(char* target, int* ParNum, char** pPar, PInterMediateFunctionInfo pFuncInfo, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreSensitiveAPIInfo pSSAPIInfo)
	{
		PCodeExePathBlock temppCodeBlock;

		for (int i = 0; i < pFuncInfo->FunctionParNum; i++)
		{
			//����������Ӹ���ϸ�ĸ��ݱ��������ͽ���һϵ�еĲ�����Ŀǰ�ʹֲڵĲ�����,�˴���ֱ�Ӷ���һ�е�Init��������дtrue�ˣ���Ϊ�������Ƭ��Ŀǰ����Ѱ�Һ�������ֵӰ��ı��������Ծ�ֻѰ�Һ�������������
			InitCodeExePathBlock(pSSAPIInfo, pSSAPIInfo->pFunc, &temppCodeBlock, pSSAPIInfo->PathTraceDeepth, pSSAPIInfo->VarDefByOtherVarNum, pSSAPIInfo->VarChangeNum, pSSAPIInfo->FunctionCallNum, pSSAPIInfo->MacroChangeNum, pSSAPIInfo->VarDefByOtherMacroNum, i, true);
			GetBackAPIOnePar(pPar[i], &(pFuncInfo->pPar[i]), ArrayLenth, pVarArray, CodeLineNo, (pSSAPIInfo->pCodePathBlock)[i], true);
		}
		
		return 1;
	}

	//��ǰAPI��Ƭ���ɵ���Ҫ����
	int GetVarChangeVarAndFunctionCallPathDefInfo(PVariable pVar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PCodeExePathBlock pCodeBlock, bool bIsPar)
	{
		int tempIndex;
		int tempReturnVarChangeNum = pCodeBlock->BlockRealVarChangeNum;
		int tempReturnFunctionCallNum = pCodeBlock->BlockRealFunctionCallNum;
		PStoreFunctionDefInfo temppStoreFunctionDefInfo;
		PStoreVarDefInfo temppStoreVarDefInfo;
		PCodeExePathBlock temppCodeExeBlock;
		PCodeExePathBlock tempppCodeExeBlock;
		//tempppCodeExeBlock = new PCodeExePathBlock;
		PStoreVarDefInfo temppReturnVar[20];
		PStoreFunctionDefInfo temppReturnFunc[20];
		PVariable temppVarArray[20];
		
		if (pCodeBlock->PathTraceDeepth == 0)
		{
			return 1;
		}

		if (pVar->bChangeOtherVar || pVar->bIsFunctionCallPar)
		{
			GetVarSpreadPath(pVar, CodeLineNo, (pCodeBlock->pFunc)->StopGlobalLineNo, pReturnVar, pReturnFunc, pCodeBlock);
			*ArrayLenth = pCodeBlock->BlockRealFunctionCallNum + pCodeBlock->BlockRealVarChangeNum;
		}
		if (bIsPar)
		{
			for (int i = 0; i < pCodeBlock->BlockRealVarChangeNum - tempReturnVarChangeNum; i++)
			{
				temppStoreVarDefInfo = pReturnVar[i + tempReturnVarChangeNum];
				InitCodeExePathBlock(pCodeBlock->pParent, pCodeBlock->pFunc, &tempppCodeExeBlock, pCodeBlock->PathTraceDeepth - 1, pCodeBlock->VarDefByOtherVarNum, pCodeBlock->VarChangeNum, pCodeBlock->FunctionCallNum, pCodeBlock->MacroChangeNum, pCodeBlock->VarDefByOtherMacroNum, pCodeBlock->ParNo, bIsPar);
				temppCodeExeBlock = ((pCodeBlock->pParent)->pCodePathBlock[pCodeBlock->ParNo])->pForward;                                    //������ȷ��д������ʵԭInitCodeExePathBlock������ô�þ��У����ü�PCodeExePathBlock*����
				AddUserDefVarTypeInfoInCodeExePathBlock(temppStoreVarDefInfo->pVarDef, temppCodeExeBlock);
				GetVarChangeVarAndFunctionCallPathDefInfo(temppStoreVarDefInfo->pVarDef, ArrayLenth, temppVarArray, temppStoreVarDefInfo->ChangGlobalLineNo, temppReturnVar, temppReturnFunc, temppCodeExeBlock, bIsPar);
			}
			for (int i = 0; i < pCodeBlock->BlockRealFunctionCallNum - tempReturnFunctionCallNum; i++)
			{
				temppStoreFunctionDefInfo = pReturnFunc[i + tempReturnFunctionCallNum];
				if (temppStoreFunctionDefInfo->bUserDefFunction)
				{
					if ((temppStoreFunctionDefInfo->pFuncDef)->bDeclare)                    //update at 22.10.9
					{
						(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = (temppStoreFunctionDefInfo->pFuncDef)->DeclareGlobalLineNo;
					}
					if ((temppStoreFunctionDefInfo->pFuncDef)->bDefinition)
					{
						(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = (temppStoreFunctionDefInfo->pFuncDef)->StartGlobalLineNo;
					}

					//fix bug at 23.3.14 , ���Դ���bug
					if (temppStoreFunctionDefInfo->pFuncDef->ParNum > temppStoreFunctionDefInfo->ParNo)
					{
						InitCodeExePathBlock(pCodeBlock->pParent, temppStoreFunctionDefInfo->pFuncDef, &tempppCodeExeBlock, pCodeBlock->PathTraceDeepth - 1, pCodeBlock->VarDefByOtherVarNum, pCodeBlock->VarChangeNum, pCodeBlock->FunctionCallNum, pCodeBlock->MacroChangeNum, pCodeBlock->VarDefByOtherMacroNum, pCodeBlock->ParNo, bIsPar);
						temppCodeExeBlock = ((pCodeBlock->pParent)->pCodePathBlock[pCodeBlock->ParNo])->pForward;
						AddUserDefVarTypeInfoInCodeExePathBlock((temppStoreFunctionDefInfo->pFuncDef->Variable)[temppStoreFunctionDefInfo->ParNo], temppCodeExeBlock);
						GetVarChangeVarAndFunctionCallPathDefInfo((temppStoreFunctionDefInfo->pFuncDef->Variable)[temppStoreFunctionDefInfo->ParNo], ArrayLenth, temppVarArray, (temppStoreFunctionDefInfo->pFuncDef)->StartGlobalLineNo, temppReturnVar, temppReturnFunc, temppCodeExeBlock, bIsPar);
					}
				}
				else
				{
					//update at 23.3.11 �˴����������Ϊ��Uncontrolled_Format_String����©����ĳһ���ִ���Ƭ����ȡ�����ӵ�
					ExtractStrchrFuncInfo(temppStoreFunctionDefInfo, pCodeBlock);
				
					//update at 23.3.14 �˴����������Ϊ��CWE134_Uncontrolled_Format_String ����©����ĳһ���ִ���Ƭ����ȡ�����ӵ�
					ExtractVfprintfFuncInfo(temppStoreFunctionDefInfo, pCodeBlock);
				}
			}
		}
		else
		{
			for (int i = 0; i < pCodeBlock->BlockRealVarChangeNum - tempReturnVarChangeNum; i++)
			{
				temppStoreVarDefInfo = pReturnVar[i + tempReturnVarChangeNum];
				InitCodeExePathBlock(pCodeBlock->pParent, pCodeBlock->pFunc, &tempppCodeExeBlock, pCodeBlock->PathTraceDeepth - 1, pCodeBlock->VarDefByOtherVarNum, pCodeBlock->VarChangeNum, pCodeBlock->FunctionCallNum, pCodeBlock->MacroChangeNum, pCodeBlock->VarDefByOtherMacroNum, pCodeBlock->ReturnVarNo, bIsPar);
				temppCodeExeBlock = ((pCodeBlock->pParent)->pReturnVarCodePathBlock[pCodeBlock->ReturnVarNo])->pForward;                                    //������ȷ��д������ʵԭInitCodeExePathBlock������ô�þ��У����ü�PCodeExePathBlock*����
				AddUserDefVarTypeInfoInCodeExePathBlock(temppStoreVarDefInfo->pVarDef, temppCodeExeBlock);
				GetVarChangeVarAndFunctionCallPathDefInfo(temppStoreVarDefInfo->pVarDef, ArrayLenth, temppVarArray, temppStoreVarDefInfo->ChangGlobalLineNo, temppReturnVar, temppReturnFunc, temppCodeExeBlock, bIsPar);
			}
			for (int i = 0; i < pCodeBlock->BlockRealFunctionCallNum - tempReturnFunctionCallNum; i++)
			{
				temppStoreFunctionDefInfo = pReturnFunc[i + tempReturnFunctionCallNum];
				if (temppStoreFunctionDefInfo->bUserDefFunction)
				{
					if ((temppStoreFunctionDefInfo->pFuncDef)->bDeclare)                    //update at 22.10.9
					{
						(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = (temppStoreFunctionDefInfo->pFuncDef)->DeclareGlobalLineNo;
					}
					if ((temppStoreFunctionDefInfo->pFuncDef)->bDefinition)
					{
						(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = (temppStoreFunctionDefInfo->pFuncDef)->StartGlobalLineNo;
					}

					//fix bug at 23.3.14 , ���Դ���bug
					if (temppStoreFunctionDefInfo->pFuncDef->ParNum > temppStoreFunctionDefInfo->ParNo)
					{
						InitCodeExePathBlock(pCodeBlock->pParent, temppStoreFunctionDefInfo->pFuncDef, &tempppCodeExeBlock, pCodeBlock->PathTraceDeepth - 1, pCodeBlock->VarDefByOtherVarNum, pCodeBlock->VarChangeNum, pCodeBlock->FunctionCallNum, pCodeBlock->MacroChangeNum, pCodeBlock->VarDefByOtherMacroNum, pCodeBlock->ReturnVarNo, bIsPar);
						temppCodeExeBlock = ((pCodeBlock->pParent)->pReturnVarCodePathBlock[pCodeBlock->ReturnVarNo])->pForward;
						AddUserDefVarTypeInfoInCodeExePathBlock((temppStoreFunctionDefInfo->pFuncDef->Variable)[temppStoreFunctionDefInfo->ParNo], temppCodeExeBlock);
						GetVarChangeVarAndFunctionCallPathDefInfo((temppStoreFunctionDefInfo->pFuncDef->Variable)[temppStoreFunctionDefInfo->ParNo], ArrayLenth, temppVarArray, (temppStoreFunctionDefInfo->pFuncDef)->StartGlobalLineNo, temppReturnVar, temppReturnFunc, temppCodeExeBlock, bIsPar);
					}
				}
				else
				{
					//update at 23.3.11 �˴����������Ϊ��Uncontrolled_Format_String����©����ĳһ���ִ���Ƭ����ȡ�����ӵ�
					ExtractStrchrFuncInfo(temppStoreFunctionDefInfo, pCodeBlock);
				
					//update at 23.3.14 �˴����������Ϊ��CWE134_Uncontrolled_Format_String ����©����ĳһ���ִ���Ƭ����ȡ�����ӵ�
					ExtractVfprintfFuncInfo(temppStoreFunctionDefInfo, pCodeBlock);
				}
			}
		}
		GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(pVar, pVarArray, pCodeBlock);
		GetVarAsArrayIndexUseInfo(pVar, pCodeBlock, CodeLineNo);

		return 1;
	}

	int GetForwardAPIOnePar(char* target, PInterMediateParInfo pPar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PCodeExePathBlock pCodeExeBlock, bool bIsPar)
	{
		PVariable temppVar;
		PMacro temppMacro;
		char** temppSubCode;
		int tempInt;
		int tempReturnVarNameNum;
		PStoreVarNameInfo temppReturnVarName[5];

		for (int i = 0; i < 5; i++)
		{
			temppReturnVarName[i] = new StoreVarNameInfo;
		}
		temppSubCode = new char*;
		*temppSubCode = target;

		//�������д�����Ϊ����ȡ���ж༶���ƽṹ�ı���׼���ģ�������δ��ʹ�ã�ֻ��д���⹩֮��ʹ�� 22.9.28   �Ѿ�ʹ��  22.10.4
		tempInt = 0;
		ProcessVar((void**)temppSubCode, &tempInt, temppReturnVarName, &tempReturnVarNameNum);
		for (int i = 0; i < tempReturnVarNameNum; i++)                //update at 22.10.4
		{
			if (CheckVarExist((temppReturnVarName[i])->VarMainName, pCodeExeBlock->pFunc, &temppVar) == 1)                 //if (CheckVarExist(target, pCodeExeBlock->pFunc, &temppVar) == 1)
			{
				//���ӶԱ������͵��жϣ��ж����Ƿ�Ϊ�û��Զ���ı������ͣ�������ҳ��û��Զ���ı������Ͷ������ڵĴ�����         22.9.30
				AddUserDefVarTypeInfoInCodeExePathBlock(temppVar, pCodeExeBlock);

				/*GetVarChangeByOtherVar(temppVar, pFunc, ArrayLenth, pVarArray, CodeLineNoArray, CodeLineNo);
				GetVarDefByOtherVarAndInfo(temppVar, pFunc, ArrayLenth, pVarArray, CodeLineNoArray);*/
				GetVarChangeVarAndFunctionCallPathDefInfo(temppVar, ArrayLenth, pVarArray, CodeLineNo, pReturnVar, pReturnFunc, pCodeExeBlock, bIsPar);
				/*GetVarSpreadPath(temppVar, CodeLineNo, pFunc->StopGlobalLineNo, FunctionCallNum, VarChangeNum, RealFunctionCallNum, RealVarChangeNum, CodeLineNoArray, pReturnVar, pReturnFunc);*/

				//������Զ��ҵ��Ĵ����кŸ��ݳ����ִ��ʱ��˳��������Ҳ�����ȷ���������

			}
			else if (CheckMacroExist((temppReturnVarName[i])->VarMainName, pCodeExeBlock->pFunc, &temppMacro) == 1)         //else if (CheckMacroExist(target, pCodeExeBlock->pFunc, &temppMacro) == 1)
			{
				//����鵽�ñ���Ϊ�궨��ʱ�����궨��Ĵ����к����ӵ�pCodeBLock�еĴ����кż�¼��
				pCodeExeBlock->Path[(pCodeExeBlock->PathLength)++] = temppMacro->DefCodeLineGlobalNo;
			}
			else
			{
#ifdef _DEBUG
				std::cout << "Get Forward API One Par Fail Var:" << target << std::endl;
#endif
				return 0;
			}
		}

		delete temppSubCode;
		for (int i = 0; i < 5; i++)
		{
			delete temppReturnVarName[i];
		}

		return 1;
	}

	int GetBackAPIOnePar(char* target, PInterMediateParInfo pPar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeExeBlock, bool bIsPar)
	{
		PVariable temppVar;
		PMacro temppMacro;
		char** temppSubCode;
		int tempInt;
		int tempReturnVarNameNum;
		int tempReturnMemoryAllocCodeLineArray[5] = { 0 };
		int tempReturnMemoryAllocCodeLineArrayLength = 0;
		PStoreVarNameInfo temppReturnVarName[5];

		for (int i = 0; i < 5; i++)
		{
			temppReturnVarName[i] = new StoreVarNameInfo;
		}
		temppSubCode = new char*;
		*temppSubCode = target;

		//�������д�����Ϊ����ȡ���ж༶���ƽṹ�ı���׼���ģ�������δ��ʹ�ã�ֻ��д���⹩֮��ʹ�� 22.9.28          �Ѿ�ʹ�� 22.10.4
		tempInt = 0;
		ProcessVar((void**)temppSubCode, &tempInt, temppReturnVarName, &tempReturnVarNameNum);
		for (int i = 0; i < tempReturnVarNameNum; i++)
		{
			if (CheckVarExist((temppReturnVarName[i])->VarMainName, pCodeExeBlock->pFunc, &temppVar) == 1)         //if (CheckVarExist(target, pCodeExeBlock->pFunc, &temppVar) == 1)
			{
				//���ӶԱ������͵��жϣ��ж����Ƿ�Ϊ�û��Զ���ı������ͣ�������ҳ��û��Զ���ı������Ͷ������ڵĴ�����         22.9.30
				AddUserDefVarTypeInfoInCodeExePathBlock(temppVar, pCodeExeBlock);

				//����û������ǰ��Ƭһ���Ա������ݵ���������ƣ������Ҫ�����ټ��ϣ������￪ʼ��ÿ���������������ͽ�����ϸ�ķ���
				GetVarChangeByOtherVar(temppVar, pVarArray, CodeLineNo, pCodeExeBlock);
				CheckVarAndDefVarOtherVarIsFunctionPar(pCodeExeBlock->pFunc, pVarArray[pCodeExeBlock->BlockRealVarDefByOtherVarNum - 1], pVarArray, pCodeExeBlock, bIsPar);
				GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(temppVar, pVarArray, pCodeExeBlock);
				CheckVarAndDefVarOtherVarIsFunctionPar(pCodeExeBlock->pFunc, pVarArray[pCodeExeBlock->BlockRealVarDefByOtherVarNum - 1], pVarArray, pCodeExeBlock, bIsPar);
				//������Զ��ҵ��Ĵ����кŸ��ݳ����ִ��ʱ��˳��������Ҳ�����ȷ���������
				
				//update at 23.3.7
				if (pPar->ParType == 1 || pPar->ParType == 0)
				{
					GetVarMemoryAllocInfo(temppVar, tempReturnMemoryAllocCodeLineArray, &tempReturnMemoryAllocCodeLineArrayLength);
					for(int z = 0; z < tempReturnMemoryAllocCodeLineArrayLength;z++)
					{
						(pCodeExeBlock->Path)[(pCodeExeBlock->PathLength)++] = tempReturnMemoryAllocCodeLineArray[z];
					}
				}
			}
			else if (CheckMacroExist((temppReturnVarName[i])->VarMainName, pCodeExeBlock->pFunc, &temppMacro) == 1)                         //else if (CheckMacroExist(target, pCodeExeBlock->pFunc, &temppMacro) == 1)
			{
				//����鵽�ñ���Ϊ�궨��ʱ�����궨��Ĵ����к����ӵ�pCodeBLock�еĴ����кż�¼��
				pCodeExeBlock->Path[(pCodeExeBlock->PathLength)++] = temppMacro->DefCodeLineGlobalNo;
			}
			else
			{
				std::cout << "Get Forward API One Par Fail" << std::endl;
				return 0;
			}
		}

		delete temppSubCode;
		for (int i = 0; i < 5; i++)
		{
			delete temppReturnVarName[i];
		}

		return 1;
	}

	int CheckFunctionInOneTypeInterMediate(char* target, int Type, PInterMediateFunctionInfo* pReturn)
	{
		int tempIndex;
		PInterMediate temppInterMediate;
		PInterMediateFunctionInfo temppFunctionInfo;

		temppInterMediate = pInterMediateArray->Array[Type];
		for (int i = 0; i < temppInterMediate->CodeElementsNum; i++)
		{
			temppFunctionInfo = &((temppInterMediate->CodeElements)[i]);
			if (strcmp(temppFunctionInfo->Name, target) == 0)
			{
				*pReturn = temppFunctionInfo;
				return 1;
			}
		}

		return 0;
	}

	///////////////////////////////////////////////////

	//��鴫��Ĳ������Ƿ��к������ã��������Ĳ�����ָ��ÿ�д����ָ��
	int CheckCodeLineHaveFunctionCallAndMarkInParAndMarkInFunctionInfo(void** Code, PSourceFunction pFunc)
	{
		int tempIndex = 0;
		int tempFunctionCallIndex[5];
		int tempFunctionCallNum = 0;
		char** tempParName;
		int tempParNum = 0;
		int tempIndexStart = 0;
		int tempIndexStop = 0;
		char tempFunctionName[100];

		tempParName = new char* [15];
		for (int i = 0; i < 15; i++)
		{
			tempParName[i] = new char[100];
			memset(tempParName[i], 0x0, 100);
		}

		tempFunctionCallNum = CheckLineFunctionCall(Code, tempFunctionCallIndex);
		if (tempFunctionCallNum == 0)
		{
			return 0;
		}
		for (int i = 0; i < tempFunctionCallNum; i++)
		{
			tempParNum = 0;
			GetNameFromLastNamePos(Code, tempFunctionCallIndex[i], tempFunctionName);
			tempFunctionCallIndex[i]++;
			if (GetBracketContent(Code, &(tempFunctionCallIndex[i]), &tempIndexStart, &tempIndexStop) == -1)
			{
				//std::cout << "CodeLineHaveFunctionCallAndMarkInPar fail no Par \n";
			}
			else
			{
				GetFunctionCallParName(Code, &tempIndexStart, &tempIndexStop, tempParName, &tempParNum);
				CheckParNameIsDefParAndAddInfo(pFunc, tempParName, &tempParNum, tempFunctionName);
			}
			CheckFuncNameIsDefFuncAndAddInfo(pFunc, tempFunctionName, tempParName, &tempParNum);
		}

		for (int i = 0; i < 15; i++)
		{
			if (strlen(tempParName[i]) != 0)
			{
				delete[] tempParName[i];;
			}
		}
		delete [] tempParName;

		return 1;
	}

	//��ȡ���������еĲ����������������ʲô�����Ĳ��������磺ǿ������ת���򲻻Ὣ��ǿ������ת������Ϣ���������ú������صı�����������Ƕ༶�������ƵĻ���Ȼ�᷵�ض༶�������ƣ���֮��ĶԱ���������ʱ��Ҫע�⽫�༶�������Ʒֽ⣬�������Ϊ����ʽ��ʽ���Ὣ��������ʽ���أ����������ԭ���ǰ��� ',' �ָ�����ģ�
	int GetFunctionCallParName(void** Code, int* indexStart, int* indexStop, char** ParName, int* ParNum)
	{
		int tempIndex = 0;
		int tempParIndex = 0;
		char tempPar[100];
		int tempLBracketNum, tempRBracketNum;
		bool tempbInBracket = false;
		bool tempbInName = false;
		tempLBracketNum = tempRBracketNum = 0;

		tempIndex = *indexStart;
		while (tempIndex <= *indexStop)
		{
			if ((*(char**)Code)[tempIndex] == ' ')
			{
				tempIndex++;
				continue;
			}
			if ((*(char**)Code)[tempIndex] == ',')
			{
				tempPar[tempParIndex] = 0x0;
				tempbInName = false;
				strcpy(ParName[(*ParNum)++], tempPar);
				tempParIndex = 0;
				tempIndex++;
				continue;
			}
			if ((*(char**)Code)[tempIndex] == '(' && !tempbInName)
			{
				tempLBracketNum++;
				if (!tempbInBracket)
				{
					tempbInBracket = true;
				}
			}
			if ((*(char**)Code)[tempIndex] == ')' && !tempbInName)
			{
				tempRBracketNum++;
			}
			if (tempbInBracket && tempLBracketNum == tempRBracketNum)
			{
				tempLBracketNum = 0;
				tempRBracketNum = 0;
				tempbInBracket = false;

				tempIndex++;
				continue;
			}
			if (tempbInBracket)
			{
				tempIndex++;
				continue;
			}
			tempPar[tempParIndex++] = (*(char**)Code)[tempIndex];
			tempbInName = true;
			tempIndex++;
		}
		tempPar[tempParIndex] = 0x0;
		strcpy(ParName[(*ParNum)++], tempPar);

		return 1;
	}

	//��������������������õĲ������û�����ı�����������صĺ���������Ϣ
	int CheckParNameIsDefParAndAddInfo(PSourceFunction pFunc, char** ParName, int* ParNum, char* FunctionName)
	{
		int tempIndex;
		PVariable temppVar;
		PSourceFunction temppFunc = NULL;
		PStoreFunctionDefInfo temppStoreFunctionDefInfo;
		PStoreFunctionDefInfo temppStoreFunctionDefInfo1;
		bool tempbHaveParNoDef = false;
		bool tempbFuncDef = false;
		int tempReturnNameNum = 0;
		int tempReturnArrayNum = 0;
		int tempReturnNum;
		int tempArrayIndex[10];
		char** temppName;
		char** temppArray;
		char** tempppVar;
		tempppVar = new char*;

		temppName = new char* [10];
		temppArray = new char* [10];
		for (int i = 0; i < 10; i++)
		{
			temppName[i] = new char[100];
			temppArray[i] = new char[100];
		}

		if (CheckFuncExist(FunctionName, &temppFunc))
		{
			tempbFuncDef = true;
		}

		for (int i = 0; i < *ParNum; i++)
		{
			tempIndex = 0;
			tempReturnNameNum = 0;
			tempReturnArrayNum = 0;
			*tempppVar = ParName[i];
			tempReturnNum = GetSubCodeName((void**)tempppVar, &tempIndex, temppName, &tempReturnNameNum, temppArray, &tempReturnArrayNum, tempArrayIndex);
			for (int z = 0; z < tempReturnNameNum; z++)
			{
				if (CheckVarExist(temppName[z], pFunc, &temppVar))
				{
					if (!(temppVar->bIsFunctionCallPar))
					{
						temppVar->bIsFunctionCallPar = true;
						temppStoreFunctionDefInfo = new StoreFunctionDefInfo;
						if (temppVar->IsFunctionCallParNum == 0)
						{
							temppVar->pFunctionCallPar = temppStoreFunctionDefInfo;
						}
					}
					else
					{
						temppStoreFunctionDefInfo1 = temppVar->pFunctionCallPar;
						for (int z = 1; z < temppVar->IsFunctionCallParNum; z++)
						{
							temppStoreFunctionDefInfo1 = temppStoreFunctionDefInfo1->pNext;
						}
						temppStoreFunctionDefInfo = new StoreFunctionDefInfo;
						temppStoreFunctionDefInfo1->pNext = temppStoreFunctionDefInfo;
					}
					temppVar->IsFunctionCallParNum++;
					strcpy(temppStoreFunctionDefInfo->Name, FunctionName);
					temppStoreFunctionDefInfo->FunctionCallGlobalLineNo = AnalysisCodeLineNo;
					temppStoreFunctionDefInfo->bUserDefFunction = tempbFuncDef;
					temppStoreFunctionDefInfo->pParent = temppVar;
					temppStoreFunctionDefInfo->pFuncDef = temppFunc;
					temppStoreFunctionDefInfo->ParNo = i;
					temppStoreFunctionDefInfo->pNext = NULL;
				}
				else
				{
					tempbHaveParNoDef = true;
				}
			}
		}

		for (int i = 0; i < 10; i++)
		{
			if (strlen(temppName[i]) != 0)
			{
				delete[] temppName[i];
			}
			if (strlen(temppArray[i]) != 0)
			{
				delete[] temppArray[i];
			}
		}
		delete[] temppName;
		delete[] temppArray;

		return 1;
	}

	int GetNameFromLastNamePos(void** Code, int index, char* pReturn)
	{
		int tempIndex = 0;

		while (true)
		{
			if (CheckNamableCharacter(&((*(char**)Code)[index - tempIndex])))
			{
				pReturn[tempIndex] = (*(char**)Code)[index - tempIndex];
				tempIndex++;
			}
			else
			{
				break;
			}
		}
		pReturn[tempIndex] = 0x0;
		ReverseString(pReturn);

		return tempIndex;
	}

	//��ת�ַ���
	int ReverseString(char* pStr)
	{
		int tempStrLength = 0;
		char tempChar;

		tempStrLength = strlen(pStr);
		for (int i = 0; i < tempStrLength / 2; i++)
		{	
			tempChar = pStr[i];
			pStr[i] = pStr[tempStrLength - 1 - i];
			pStr[tempStrLength - 1 - i] = tempChar;
		}

		return 1;
	}

	//////////////////////////////////////////////////////

	int GetFunctionStructAndParStruct(char* pFunctionName, int* ParNum, int* ParNo, PSourceFunction pFuncReturn, PVariable* pParReturn)
	{
		if (CheckFuncExist(pFunctionName, &pFuncReturn) == 0)
		{
			return 0;
		}
		for (int i = 0; i < *ParNum; i++)
		{
			GetFunctionParStruct(pFuncReturn, ParNo[i], pParReturn[i]);
		}

		return 1;
	}

	int GetFunctionParStruct(PSourceFunction pFunc, int ParNo, PVariable pVarReturn)
	{
		int tempIndex;

		if (!(pFunc->bHavePar))
		{
			return 0;
		}

		//����͸��ݶ�Դ�ļ��Ľ���������ֱ�ӷ���Parָ���ˣ��������Դ�ļ�������������ʱ����������Ϊ�����µ��ʼ�ļ����ֲ�������֮����ı��������
		pVarReturn = (pFunc->Variable)[ParNo];

		return 1;
	}

	//��ȡFunctionCall�еĲ�������·��������FunctionCallNum��VarChangeNum�ǿ���ÿ����������·������ȣ����⺯��������Ϊʲôд���ˣ���Ȼûʲô�ã������Ȳ�ɾ�����в���pCodeBlock��Ϊ�����ں����е���GetVarSpreadPath���������õĲ�����
	int GetFunctionCallParSpreadPath(char* pFunctionName, int* ParNum, int* ParNo, int FunctionCallNum, int VarChangeNum, int* RealFunctionCallNum, int* RealVarChangeNum, int* CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PCodeExePathBlock pCodeBlock)
	{
		int tempIndex;
		PSourceFunction temppFunction;
		PVariable temppVar[10];

		GetFunctionStructAndParStruct(pFunctionName, ParNum, ParNo, temppFunction, temppVar);
		for (int i = 0; i < *ParNum; i++)
		{
			GetVarSpreadPath(temppVar[i], temppFunction->StartGlobalLineNo, temppFunction->StopGlobalLineNo, pReturnVar, pReturnFunc, pCodeBlock);
		}

		return 1;
	}

	//��ȡVar�Ĵ���·��������ֵ���ݼ��������õĴ���
	int GetVarSpreadPath(PVariable pVar, int indexStart, int indexStop, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PCodeExePathBlock pCodeBlock)
	{
		int tempIndex;
		int tempRealVarChangeNum = 0;
		int tempRealFunctionCallNum = 0;
		int tempRealVarChangeNum1 = 0;
		int tempRealFunctionCallNum1 = 0;
		PStoreFunctionDefInfo temppStoreFunctionDefInfo;
		PStoreVarDefInfo temppStoreVarDefInfo;

		if (pVar->bChangeOtherVar)
		{
			temppStoreVarDefInfo = pVar->pChangeOtherVar;
		}
		
		if (pVar->bIsFunctionCallPar)
		{
			temppStoreFunctionDefInfo = pVar->pFunctionCallPar;
		}

		while (true)
		{
			if (tempRealVarChangeNum1 == pCodeBlock->VarChangeNum)
			{
				break;
			}
			if (pVar->ChangeOtherVarNum == tempRealVarChangeNum)
			{
				break;
			}
			if (temppStoreVarDefInfo->ChangGlobalLineNo < indexStart)
			{
				tempRealVarChangeNum++;
				temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
				continue;
			}
			else if (temppStoreVarDefInfo->ChangGlobalLineNo > indexStop)
			{
				break;
			}
			else
			{
				if (tempRealVarChangeNum1 < pCodeBlock->VarChangeNum)
				{
					/*pCodeBlock->Path[(pCodeBlock->BlockRealVarChangeNum) + (pCodeBlock->BlockRealFunctionCallNum)] = temppStoreVarDefInfo->ChangGlobalLineNo;*/
					pCodeBlock->Path[pCodeBlock->PathLength] = temppStoreVarDefInfo->ChangGlobalLineNo;
					/*CodeLineNo[(*RealVarChangeNum) + (*RealFunctionCallNum)] = temppStoreVarDefInfo->ChangGlobalLineNo;*/
					/*pReturnVar[(pCodeBlock->BlockRealVarChangeNum)++] = temppStoreVarDefInfo;*/
					pReturnVar[(pCodeBlock->BlockRealVarChangeNum)] = temppStoreVarDefInfo;
					(pCodeBlock->BlockRealVarChangeNum)++;
					(pCodeBlock->PathLength)++;
					tempRealVarChangeNum++;
					tempRealVarChangeNum1++;
				}
				else
				{
					break;
				}
			}
			temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
		}
		while (true)
		{
			if (tempRealFunctionCallNum1 == pCodeBlock->FunctionCallNum)
			{
				break;
			}
			if (pVar->IsFunctionCallParNum == tempRealFunctionCallNum)
			{
				break;
			}
			if (temppStoreFunctionDefInfo->FunctionCallGlobalLineNo <= indexStart)
			{
				tempRealFunctionCallNum++;
				temppStoreFunctionDefInfo = temppStoreFunctionDefInfo->pNext;
				continue;
			}
			else if (temppStoreFunctionDefInfo->FunctionCallGlobalLineNo > indexStop)
			{
				break;
			}
			else
			{
				if (tempRealFunctionCallNum1 < pCodeBlock->FunctionCallNum)
				{
					/*pCodeBlock->Path[(pCodeBlock->BlockRealVarChangeNum) + (pCodeBlock->BlockRealFunctionCallNum)] = temppStoreFunctionDefInfo->FunctionCallGlobalLineNo;*/
					pCodeBlock->Path[pCodeBlock->PathLength] = temppStoreFunctionDefInfo->FunctionCallGlobalLineNo;
					/*CodeLineNo[(*RealVarChangeNum) + (*RealFunctionCallNum)] = temppStoreFunctionDefInfo->FunctionCallGlobalLineNo;*/
					/*pReturnFunc[(pCodeBlock->BlockRealFunctionCallNum)++] = temppStoreFunctionDefInfo;*/
					pReturnFunc[(pCodeBlock->BlockRealFunctionCallNum)] = temppStoreFunctionDefInfo;
					(pCodeBlock->BlockRealFunctionCallNum)++;
					(pCodeBlock->PathLength)++;
					tempRealFunctionCallNum++;
					tempRealFunctionCallNum1++;
				}
				else
				{
					break;
				}
			}
			temppStoreFunctionDefInfo = temppStoreFunctionDefInfo->pNext;
		}

		return 1;
	}

	/////////////////////////////////////////////////////////

	int ProcessPath(PCodeExePathBlock pCodePath)
	{
		int tempIndex;

		return 1;
	}

	int ProcessOneFuncPath(PCodeExePathBlock pCodePath)
	{
		int tempIndex;

		return 1;
	}

	int InitCodeExePathBlock(PStoreSensitiveAPIInfo pSSAPIInfo, PSourceFunction pFunc, PCodeExePathBlock* pReturnCodeBlock, int PathTraceDeepth, int VarDefByOtherVarNum, int VarChangeNum, int FunctionCallNum, int MacroChangeNum, int VarDefByOtherMacroNum, int ParNo, bool IsPar)
	{
		int tempIndex;
		PCodeExePathBlock temppCodeExePathBlock;

		temppCodeExePathBlock = new CodeExePathBlock;
		temppCodeExePathBlock->PathLength = 0;
		temppCodeExePathBlock->BlockRealFunctionCallNum = 0;
		temppCodeExePathBlock->BlockRealVarChangeNum = 0;
		temppCodeExePathBlock->BlockRealVarDefByOtherVarNum = 0;
		temppCodeExePathBlock->BlockRealMacroChangeNum = 0;
		temppCodeExePathBlock->BlockRealVarDefByOtherMacroNum = 0;
		temppCodeExePathBlock->FunctionCallNum = FunctionCallNum;
		temppCodeExePathBlock->VarChangeNum = VarChangeNum;
		temppCodeExePathBlock->VarDefByOtherVarNum = VarDefByOtherVarNum;
		temppCodeExePathBlock->MacroChangeNum = MacroChangeNum;
		temppCodeExePathBlock->VarDefByOtherMacroNum = VarDefByOtherMacroNum;
		temppCodeExePathBlock->PathTraceDeepth = PathTraceDeepth;
		temppCodeExePathBlock->pParent = pSSAPIInfo;
		temppCodeExePathBlock->pFunc = pFunc;
		temppCodeExePathBlock->bIsPar = IsPar;
		if (IsPar)
		{
			temppCodeExePathBlock->ParNo = ParNo;
			temppCodeExePathBlock->ReturnVarNo = -1;
			
			if (pSSAPIInfo->CodePathBlockNum[ParNo] == 0)
			{
				temppCodeExePathBlock->pForward = temppCodeExePathBlock;
				temppCodeExePathBlock->pNext = temppCodeExePathBlock;
				pSSAPIInfo->pCodePathBlock[ParNo] = temppCodeExePathBlock;
				pSSAPIInfo->CodePathBlockNum[ParNo]++;
				*pReturnCodeBlock = temppCodeExePathBlock;
				return 1;
			}

			temppCodeExePathBlock->pForward = ((pSSAPIInfo->pCodePathBlock)[ParNo])->pForward;
			temppCodeExePathBlock->pNext = (pSSAPIInfo->pCodePathBlock)[ParNo];
			(((pSSAPIInfo->pCodePathBlock)[ParNo])->pForward)->pNext = temppCodeExePathBlock;
			((pSSAPIInfo->pCodePathBlock)[ParNo])->pForward = temppCodeExePathBlock;
			pSSAPIInfo->CodePathBlockNum[ParNo]++;
		}
		else
		{
			temppCodeExePathBlock->ReturnVarNo = ParNo;
			temppCodeExePathBlock->ParNo = -1;
			
			if (pSSAPIInfo->ReturnVarCodePathBlockNum[ParNo] == 0)
			{
				temppCodeExePathBlock->pForward = temppCodeExePathBlock;
				temppCodeExePathBlock->pNext = temppCodeExePathBlock;
				pSSAPIInfo->pReturnVarCodePathBlock[ParNo] = temppCodeExePathBlock;
				pSSAPIInfo->ReturnVarCodePathBlockNum[ParNo]++;
				*pReturnCodeBlock = temppCodeExePathBlock;
				return 1;
			}

			temppCodeExePathBlock->pForward = ((pSSAPIInfo->pReturnVarCodePathBlock)[ParNo])->pForward;
			temppCodeExePathBlock->pNext = (pSSAPIInfo->pReturnVarCodePathBlock)[ParNo];
			(((pSSAPIInfo->pReturnVarCodePathBlock)[ParNo])->pForward)->pNext = temppCodeExePathBlock;
			((pSSAPIInfo->pReturnVarCodePathBlock)[ParNo])->pForward = temppCodeExePathBlock;
			pSSAPIInfo->ReturnVarCodePathBlockNum[ParNo]++;
		}

		*pReturnCodeBlock = temppCodeExePathBlock;

		return 1;
	}

	/////////////////////////////////////////////////////////

	//ChainType == 1 ΪCallFunction Chain ;      ChainType == -1 ΪCalledFunction Chain
	int AddFunctionInfoAtLastFuntionInfoChain(PSourceFunction pFunc, PFunctionInfo pFuncInfo, int ChainType)
	{
		int tempIndex;
		PFunctionInfo temppFunctionInfo;

		if (ChainType == 1)                          //CallFunction Chain
		{
			if (pFunc->CallFunctionNum == 0)
			{
				pFunc->CallFunction = pFuncInfo;
				pFunc->CallFunctionNum++;
				return 1;
			}
			else
			{
				temppFunctionInfo = pFunc->CallFunction;
				for (int i = 1; i < pFunc->CallFunctionNum; i++)
				{
					temppFunctionInfo = temppFunctionInfo->pNext;
				}
			}
			pFunc->CallFunctionNum++;
		}
		else if (ChainType == -1)                    //CalledFunction Chain
		{
			if (pFunc->CalledFunctionNum == 0)
			{
				pFunc->CalledFunction = pFuncInfo;
				pFunc->CalledFunctionNum++;
				return 1;
			}
			else
			{
				temppFunctionInfo = pFunc->CalledFunction;
				for (int i = 1; i < pFunc->CalledFunctionNum; i++)
				{
					temppFunctionInfo = temppFunctionInfo->pNext;
				}
			}
			pFunc->CalledFunctionNum++;
		}
		else
		{
			std::cout << "AddFunctionInfoAtLastFuntionInfoChain fail" << std::endl;
			return 0;
		}
		temppFunctionInfo->pNext = pFuncInfo;

		return 1;
	}

	int CheckFuncNameIsDefFuncAndAddInfo(PSourceFunction pFunc, char* FunctionName, char** ParName, int* ParNum)
	{
		int tempIndex;
		PVariable temppVar[10];
		PMacro temppMacro[10];
		PSourceFunction temppFunc = NULL;
		PFunctionInfo temppFunctionInfo;
		PParInfo temppParInfo;
		PParInfo temppParInfo1;
		bool tempbFuncDef = false;
		temppFunctionInfo = new FunctionInfo;
		char** temppSubCode;
		int tempInt;
		int tempReturnVarNameNum;
		PStoreVarNameInfo temppReturnVarName[10];

		for (int i = 0; i < 10; i++)
		{
			temppReturnVarName[i] = new StoreVarNameInfo;
			(temppReturnVarName[i])->MinorNameNum = 0;
		}
		temppSubCode = new char*;

		if (CheckFuncExist(FunctionName, &temppFunc))
		{
			tempbFuncDef = true;
		}

		for (int i = 0; i < *ParNum; i++)
		{
			temppParInfo = new ParInfo;
			temppParInfo->bDefPar = false;                             //update at 22.10.4
			temppParInfo->bDefMacro = false;
			temppParInfo->pVar = NULL;
			temppParInfo->pMacro = NULL;
			strcpy(temppParInfo->Name, ParName[i]);
			temppParInfo->pParent = temppFunctionInfo;

			//�������д�����Ϊ����ȡ���ж༶���ƽṹ�ı���׼���ģ�������δ��ʹ�ã�ֻ��д���⹩֮��ʹ�� 22.9.28              �Ѿ�ʹ�� 22.10.4
			*temppSubCode = ParName[i];
			tempInt = 0;
			ProcessVar((void**)temppSubCode, &tempInt, temppReturnVarName, &tempReturnVarNameNum);
			//����д��������,����������Ĳ�������ʽ���ж���Ѷ���ı�����궨��,��ô������ֻ��ȡ���һ�������ͺ궨�� 22.10.4
			for (int z = 0; z < tempReturnVarNameNum; z++)
			{
				if (CheckVarExist((temppReturnVarName[z])->VarMainName, pFunc, &(temppVar[i])))              //if (CheckVarExist(ParName[i], pFunc, &(temppVar[i])))   22.9.28
				{
					temppParInfo->bDefPar = true;
					temppParInfo->pVar = temppVar[i];
				} //��Ϊ�궨�岻�漰�༶���Ƶ�������Ծ�û��������ı��������ƴ��ݽ�CheckMacroExist������
				else if (CheckMacroExist((temppReturnVarName[z])->VarMainName, pFunc, &(temppMacro[i])) == 1)                         //else if (CheckMacroExist(ParName[i], pFunc, &(temppMacro[i])) == 1)
				{
					temppParInfo->bDefMacro = true;
					temppParInfo->pMacro = temppMacro[i];
				}
				else
				{
					/*temppParInfo->bDefPar = false;
					temppParInfo->bDefMacro = false;
					temppParInfo->pVar = NULL;
					temppParInfo->pMacro = NULL;*/
				}
			}

			if (i == 0)
			{
				temppFunctionInfo->pPar = temppParInfo;
				temppParInfo1 = temppParInfo;
				continue;
			}
			
			temppParInfo1->pNext = temppParInfo;
			temppParInfo1 = temppParInfo1->pNext;
		}

		temppFunctionInfo->pFunc = temppFunc;
		if (tempbFuncDef)
		{
			temppFunctionInfo->FunctionNo = temppFunc->FunctionNo;
		}
		else
		{
			temppFunctionInfo->FunctionNo = -1;
		}
		temppFunctionInfo->GlobalLineNo = AnalysisCodeLineNo;
		temppFunctionInfo->LocalLineNo = AnalysisCodeLineNo - pFunc->StartGlobalLineNo;
		temppFunctionInfo->bIsUserDefFunc = tempbFuncDef;
		strcpy(temppFunctionInfo->Name, FunctionName);
		temppFunctionInfo->pNext = NULL;
		temppFunctionInfo->ParNum = *ParNum;
		
		AddFunctionInfoAtLastFuntionInfoChain(pFunc, temppFunctionInfo, -1);

		if (tempbFuncDef)
		{
			FuntionInfoAddCalledFunc(temppFunc, pFunc, temppFunctionInfo->pPar, *ParNum);
		}

		delete temppSubCode;
		for (int i = 0; i < 5; i++)
		{
			delete temppReturnVarName[i];
		}

		return 1;
	}

	int FuntionInfoAddCalledFunc(PSourceFunction pFunc, PSourceFunction pCallFunc, PParInfo pPar, int ParNum)
	{
		int tempIndex;

		PFunctionInfo temppFunctionInfo;
		temppFunctionInfo = new FunctionInfo;

		temppFunctionInfo->pFunc = pCallFunc;
		temppFunctionInfo->FunctionNo = pCallFunc->FunctionNo;
		temppFunctionInfo->GlobalLineNo = AnalysisCodeLineNo;
		temppFunctionInfo->LocalLineNo = AnalysisCodeLineNo - pCallFunc->StartGlobalLineNo;
		temppFunctionInfo->bIsUserDefFunc = true;
		strcpy(temppFunctionInfo->Name, pCallFunc->FunctionName);
		temppFunctionInfo->pNext = NULL;
		temppFunctionInfo->pPar = pPar;
		temppFunctionInfo->ParNum = ParNum;

		AddFunctionInfoAtLastFuntionInfoChain(pFunc, temppFunctionInfo, 1);

		return 1;
	}

	//������鴫�����ı����Ƿ��Ǻ����Ĳ�����������򷵻ز����ţ������򷵻�-1
	int CheckVarIsFunctionPar(PSourceFunction pFunc, PVariable pTargetVar)
	{
		int tempIndex;
		PVariable temppVar;

		if (!pFunc->bHavePar)
		{
			return -1;
		}

		for (int i = 0; i < pFunc->ParNum; i++)
		{
			if (pTargetVar == pFunc->Variable[i])
			{
				return i;
			}
		}

		return -1;
	}

	int CheckVarAndDefVarOtherVarIsFunctionPar(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, bool bIsPar)
	{
		int tempIndex;
		PStoreVarDefInfo temppStoreVarDefInfo;
		PVariable temppVar;
		int tempParVarNum;
		int tempParVarNo[10];
		int tempParNo = -1;

		if (pVar->bDefByOthersVar)
		{
			temppStoreVarDefInfo = pVar->pDefOthersVar;
			for (int i = 0; i < pVar->DefByOthersVarNum; i++)
			{
				temppVar = temppStoreVarDefInfo->pVarDef;
				tempParNo = CheckVarIsFunctionPar(pFunc, temppVar);
				if (tempParNo != -1)
				{
					//����ҵ�����Ϊ���ú����Ĳ������еĲ���
					tempParVarNo[tempParVarNum++] = tempParNo;
				}
				temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
			}
		}
		tempParNo = CheckVarIsFunctionPar(pFunc, pVar);
		if (tempParNo != -1)
		{
			//����ҵ�����Ϊ���ú����Ĳ������еĲ���
			tempParVarNo[tempParVarNum++] = tempParNo;
		}
		GetFunctionCallForwardParPath(pFunc, pVarArray, tempParVarNo, tempParVarNum, pCodeBlock, bIsPar);

		return 1;
	}

	int GetOneVarChangePathInFunc(PParInfo pPar, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeBlock, bool bIsPar)
	{
		int tempIndex;

		if (pPar->bDefPar)
		{
			GetVarChangeByOtherVar(pPar->pVar, pVarArray, CodeLineNo, pCodeBlock);
			CheckVarAndDefVarOtherVarIsFunctionPar(pCodeBlock->pFunc, pVarArray[pCodeBlock->PathLength - 1], pVarArray, pCodeBlock, bIsPar);
			GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(pPar->pVar, pVarArray, pCodeBlock);
			CheckVarAndDefVarOtherVarIsFunctionPar(pCodeBlock->pFunc, pVarArray[pCodeBlock->PathLength - 1], pVarArray, pCodeBlock, bIsPar);
		}
		else if (pPar->bDefMacro)
		{
			//���ӹ�����������Ǻ궨��Ļ������궨��Ķ���Ĵ����к����ӵ�pCodeBlock��
			pCodeBlock->Path[(pCodeBlock->PathLength)++] = (pPar->pMacro)->DefCodeLineGlobalNo;
		}
		else
		{
			(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = CodeLineNo;
		}

		return 1;
	}

	//����ҵ���������Ǻ����Ĳ���ʱ���������ǰѰ�ұ����Ĵ���·��
	int GetFunctionCallForwardParPath(PSourceFunction pFunc, PVariable* pVarArray, int* ParNo, int ParNum, PCodeExePathBlock pCodeBlock, bool bIsPar)
	{
		int tempIndex;
		PFunctionInfo temppFunctionInfo;
		PCodeExePathBlock temppCodeBlock;
		PParInfo temppParInfo;
		PVariable temppVar[50];

		temppFunctionInfo = pFunc->CallFunction;
		for (int i = 0; i < pFunc->CallFunctionNum; i++)
		{
			/*InitCodeExePathBlock(pCodeBlock->pParent, temppFunctionInfo->pFunc, temppCodeBlock, pCodeBlock->PathTraceDeepth - 1, pCodeBlock->VarDefByOtherVarNum, pCodeBlock->VarChangeNum, pCodeBlock->FunctionCallNum, pCodeBlock->ParNo, bIsPar);*/
			for (int z = 0; z < ParNum; z++)
			{
				temppParInfo = temppFunctionInfo->pPar;
				for (int x = 0; x < ParNo[z]; x++)
				{
					temppParInfo = temppParInfo->pNext;
				}
				InitCodeExePathBlock(pCodeBlock->pParent, temppFunctionInfo->pFunc, &temppCodeBlock, pCodeBlock->PathTraceDeepth - 1, pCodeBlock->VarDefByOtherVarNum, pCodeBlock->VarChangeNum, pCodeBlock->FunctionCallNum, pCodeBlock->MacroChangeNum, pCodeBlock->VarDefByOtherMacroNum, pCodeBlock->ParNo, bIsPar);
				GetOneVarChangePathInFunc(temppParInfo, temppVar, temppFunctionInfo->GlobalLineNo, temppCodeBlock, bIsPar);
			}
			temppFunctionInfo = temppFunctionInfo->pNext;       //�޲�bug 22.9.27
		}

		return 1;
	}

	int CheckAllCodeLineToGenerateCodeSlice(int PathTraceDeepth, int VarChangeNum, int FunctionCallNum, int VarDefByOtherVarNum, int MacroChangeNum, int VarDefByOtherMacroNum, int AlgorithmType)
	{
		int tempIndex;
		PStoreSensitiveAPIInfo temppStoreSSAPIInfo;
		PStoreArrayUseInfo temppStoreArrayUseInfo;
		PSourceFunction temppSourceFunc;

		temppStoreSSAPIInfo = new StoreSensitiveAPIInfo;
		temppStoreArrayUseInfo = new StoreArrayUseInfo;

		//Base API Call Generate Code Slice Block
		for (int i = 0; i < pSourceCodeFile->FunctionNum; i++)
		{
			temppSourceFunc = pSourceCodeFile->Function[i];
			for (int z = 0; z < temppSourceFunc->CodeLineNum; z++)
			{
				temppStoreSSAPIInfo->PathTraceDeepth = PathTraceDeepth;
				temppStoreSSAPIInfo->VarChangeNum = VarChangeNum;
				temppStoreSSAPIInfo->FunctionCallNum = FunctionCallNum;
				temppStoreSSAPIInfo->VarDefByOtherVarNum = VarDefByOtherVarNum;
				temppStoreSSAPIInfo->MacroChangeNum = MacroChangeNum;
				temppStoreSSAPIInfo->VarDefByOtherMacroNum = VarDefByOtherMacroNum;
				temppStoreSSAPIInfo->FunctionCallGlobalLineNo = ((temppSourceFunc->CodeLine)[z])->GlobalLineNo;
				temppStoreSSAPIInfo->RealFunctionCallNum = 0;
				temppStoreSSAPIInfo->RealVarChangeNum = 0;
				temppStoreSSAPIInfo->RealVarDefByOtherVarNum = 0;
				temppStoreSSAPIInfo->RealMacroChangeNum = 0;
				temppStoreSSAPIInfo->RealVarDefByOtherMacroNum = 0;
				temppStoreSSAPIInfo->ParNum = 0;
				temppStoreSSAPIInfo->ReturnVarNum = 0;
				temppStoreSSAPIInfo->pFunc = temppSourceFunc;
				temppStoreSSAPIInfo->pSourceLine = (temppSourceFunc->CodeLine)[z];
				for (int x = 0; x < 5; x++)
				{
					temppStoreSSAPIInfo->CodePathBlockNum[x] = 0;
					temppStoreSSAPIInfo->ReturnVarCodePathBlockNum[x] = 0;
				}
				CheckCodeLineHaveImportAPI(temppStoreSSAPIInfo, AlgorithmType);
				CheckLoopBranchHaveArrayAssignment(temppStoreSSAPIInfo);
			}
		}

		//Base Array Use Info Generate Code Slice Block
		/*for (int i = 0; i < pSourceCodeFile->VariableNum; i++)
		{

		}
		for (int i = 0; i < pSourceCodeFile->FunctionNum; i++)
		{
			
		}*/

		return 1;
	}

	int BaseCodeExePathGenerateCodeSlice(PStoreSensitiveAPIInfo pStoreSSAPIInfo)
	{
		/*int tempIndex;
		int** tempIndexArray;
		int tempArrayLength;
		int tempIndexArrayLength[20];*/
		int tempIndexArrayNew[200];
		int tempIndexArrayLengthnew = 0;
		PCodeExePathBlock temppCodeBlock;
		PSourceLine tempImportAPICodeLine;
		PSourceLine tempImportAPICodeLineInSyntaxBlock[30];
		int tempReturnSyntaxBlockCodeLineNum = 0;

		/*tempIndexArray = new int* [20];
		for (int i = 0; i < 20; i++)
		{
			tempIndexArray[i] = new int[30];
		}*/

		//std::cout << "Code Slice Start:" << std::endl;

		/*switch (CheckStrHaveGoodOrBad((pStoreSSAPIInfo->pFunc)->FunctionName))
		{
		case 1:
		{
			std::cout << "1\n";
			std::cout << "---------------------------------------------------------------\n";
			break;
		}
		case -1:
		{
			std::cout << "0\n";
			std::cout << "---------------------------------------------------------------\n";
			break;
		}
		default:
			break;
		}

		std::cout << pStoreSSAPIInfo->pSourceLine->GlobalLineNo << " | ";
		*/
		tempIndexArrayNew[tempIndexArrayLengthnew++] = pStoreSSAPIInfo->pSourceLine->GlobalLineNo;

		//������������Ŀ��������������﷨��֧�����ȡ�Ĵ���
		tempImportAPICodeLine = pStoreSSAPIInfo->pSourceLine;
		GetCodeLineInSyntaxBlockInfo(tempImportAPICodeLine, tempImportAPICodeLineInSyntaxBlock, &tempReturnSyntaxBlockCodeLineNum);
		ProcessCodeLineInSyntaxBlockInfo(tempImportAPICodeLineInSyntaxBlock, &tempReturnSyntaxBlockCodeLineNum);
		for (int i = 0; i < tempReturnSyntaxBlockCodeLineNum; i++)
		{
			tempIndexArrayNew[tempIndexArrayLengthnew++] = (tempImportAPICodeLineInSyntaxBlock[i])->GlobalLineNo;
		}
		//������Ŀ��������������﷨��֧�����ȡ�Ĵ���                    22.9.29

		if (pStoreSSAPIInfo->ParNum != 0)
		{
			for (int i = 0; i < 5; i++)
			{
				if (pStoreSSAPIInfo->CodePathBlockNum[i] != 0)
				{
					temppCodeBlock = pStoreSSAPIInfo->pCodePathBlock[i];
					for (int z = 0; z < pStoreSSAPIInfo->CodePathBlockNum[i]; z++)
					{
						for (int x = 0; x < temppCodeBlock->PathLength; x++)
						{
							tempIndexArrayNew[tempIndexArrayLengthnew++] = (temppCodeBlock->Path)[x];
							//std::cout << (temppCodeBlock->Path)[x] << "   ";
						}
						temppCodeBlock = temppCodeBlock->pNext;
						//std::cout << " | ";
					}
					//std::cout << std::endl;

					AdjustCodeLineNoOrder(tempIndexArrayNew, &tempIndexArrayLengthnew);
//#ifdef _DEBUG
//					display(tempIndexArrayNew, tempIndexArrayLengthnew, 5);
//					display(tempIndexArrayNew, tempIndexArrayLengthnew, 6);
//#endif // DEBUG
//					//display(tempIndexArrayNew, tempIndexArrayLengthnew, 7);
				}
			}
			//GetCodeLineArrayInCodeBlockInfo(tempIndexArrayNew, &tempIndexArrayLengthnew);            //update at 22.10.4
			//display(tempIndexArrayNew, tempIndexArrayLengthnew, 5);
			//display(tempIndexArrayNew, tempIndexArrayLengthnew, 6);
			//display(tempIndexArrayNew, tempIndexArrayLengthnew, 8);
			//display(tempIndexArrayNew, tempIndexArrayLengthnew, 10);
			//display(tempIndexArrayNew, tempIndexArrayLengthnew, 7);
		}
		if (pStoreSSAPIInfo->ReturnVarNum != 0)
		{
			for (int i = 0; i < 5; i++)
			{
				if (pStoreSSAPIInfo->ReturnVarCodePathBlockNum[i] != 0)
				{
					temppCodeBlock = pStoreSSAPIInfo->pReturnVarCodePathBlock[i];
					for (int z = 0; z < pStoreSSAPIInfo->ReturnVarCodePathBlockNum[i]; z++)
					{
						for (int x = 0; x < temppCodeBlock->PathLength; x++)
						{
							tempIndexArrayNew[tempIndexArrayLengthnew++] = (temppCodeBlock->Path)[x];
							//std::cout << (temppCodeBlock->Path)[x] << "   ";
						}
						temppCodeBlock = temppCodeBlock->pNext;
						//std::cout << " | ";
					}
					//std::cout << std::endl;

					AdjustCodeLineNoOrder(tempIndexArrayNew, &tempIndexArrayLengthnew);
//#ifdef _DEBUG
//					display(tempIndexArrayNew, tempIndexArrayLengthnew, 5);
//					display(tempIndexArrayNew, tempIndexArrayLengthnew, 6);
//#endif // DEBUG
//					//display(tempIndexArrayNew, tempIndexArrayLengthnew, 7);
				}
			}
			//GetCodeLineArrayInCodeBlockInfo(tempIndexArrayNew, &tempIndexArrayLengthnew);            //update at 22.10.4
			//display(tempIndexArrayNew, tempIndexArrayLengthnew, 5);
			//display(tempIndexArrayNew, tempIndexArrayLengthnew, 6);
			//display(tempIndexArrayNew, tempIndexArrayLengthnew, 8);
			//display(tempIndexArrayNew, tempIndexArrayLengthnew, 10);
			////display(tempIndexArrayNew, tempIndexArrayLengthnew, 7);
		}
		else
		{
			//std::cout << "BaseCodeExePathGenerateCodeSlice fail" << std::endl;
		}

		GetCodeLineArrayInCodeBlockInfo(tempIndexArrayNew, &tempIndexArrayLengthnew);            //update at 22.10.4
		//display(tempIndexArrayNew, tempIndexArrayLengthnew, 5);
		display(tempIndexArrayNew, tempIndexArrayLengthnew, 6);
		/*display(tempIndexArrayNew, tempIndexArrayLengthnew, 8);
		display(tempIndexArrayNew, tempIndexArrayLengthnew, 10);*/
		//display(tempIndexArrayNew, tempIndexArrayLengthnew, 7);

		/*for (int i = 0; i < 20; i++)
		{
			delete [] tempIndexArray[i];
		}
		delete [] tempIndexArray;*/

		return 1;
	}

	int RemoveStringFrontBlank(char* target)
	{
		int tempIndex = 0;
		int tempStrLength = strlen(target);

		while (true)
		{
			if (target[tempIndex] != ' ')
			{
				break;
			}
			tempIndex++;
		}
		for (int i = tempIndex; i < tempStrLength; i++)
		{
			target[i - tempIndex] = target[i];
		}
		target[tempStrLength - tempIndex] = 0x0;

		return 1;
	}

	int StrToInt(char* target)
	{
		int tempStrLength = 0;
		int tempResult = 0;
		int tempInt = 0;
		int tempInt1 = 10;

		tempStrLength = strlen(target);
		if (target[0] == '-')
		{
			for (int i = 1; i < tempStrLength; i++)
			{
				tempInt = target[i] - 48;
				tempInt1 = 10;
				for (int z = 2; z < tempStrLength - i; z++)
				{
					tempInt1 *= 10;
				}
				if (i != tempStrLength - 1)
				{
					tempResult = tempResult + tempInt * tempInt1;
				}
				else
				{
					tempResult += tempInt;
				}
			}
			tempResult = 0 - tempResult;
		}
		else
		{
			for (int i = 0; i < tempStrLength; i++)
			{
				tempInt = target[i] - 48;
				tempInt1 = 10;
				for (int z = 2; z < tempStrLength - i; z++)
				{
					tempInt1 *= 10;
				}
				if (i != tempStrLength - 1)
				{
					tempResult = tempResult + tempInt * tempInt1;
				}
				else
				{
					tempResult += tempInt;
				}
			}
		}

		return tempResult;
	}

	//��ȡ���д����б��溯������ֵ�ı���
	int GetFunctionCallReturnVarInOneCodeLine(void** Code, PSourceFunction pFunc, int* ReturnVarNum, PVariable* pReturnVar)
	{
		int tempIndex = 0;
		int temp = 0;
		int tempReturnIndex = 0;
		char tempChar = '=';
		char** tempName;
		int tempNameNum = 0;
		char** tempArray;
		int tempArrayNum = 0;
		int* tempArrayIndex;
		int tempReturnNameNum = 0;
		SyntaxKey syntaxKey1;
		SyntaxKey syntaxKey2;
		ProfixType tempProfixType;
		ReturnType tempReturnType;
		PUserDefStruct temppUserDefStruct;

		tempArrayIndex = new int[10];
		tempName = new char* [15];
		for (int i = 0; i < 15; i++)
		{
			tempName[i] = new char[80];
		}
		tempArray = new char* [10];
		for (int i = 0; i < 10; i++)
		{
			tempArray[i] = new char[80];
		}

		tempIndex += CheckSyntaxKey(Code, &tempIndex, &syntaxKey1, &syntaxKey2);
		MoveCodeIndexUntillNoBlank(Code, &tempIndex);
		temp = CheckProfixType(Code, &tempIndex, &tempProfixType);
		if (tempProfixType != ProfixType::ProfixType_unknownType)
		{
			tempIndex += temp;
			MoveCodeIndexUntillNoBlank(Code, &tempIndex);
		}

		temp = CheckReturnType(Code, &tempIndex, &tempReturnType, &temppUserDefStruct);         //�������Ǵ�����Ƭ�������Բ���Է��ص�temppUserDefStruct���д�����Ҳû�жԷ��غ󷵻ر������Ͷ�Ӧ�ı����������������Ϣ������
		if (tempReturnType != ReturnType::ReturnType_unknownType)
		{
			tempIndex += temp;
			MoveCodeIndexUntillNoBlank(Code, &tempIndex);
		}
		tempReturnIndex = GetStrFirstCharIndex(&((*(char**)Code)[tempIndex]), &tempChar);
		if (tempReturnIndex == -1)
		{
			std::cout << "GetFunctionCallReturnVarInOneCodeLine fail no '='" << std::endl;
			return 0;
		}
		tempReturnNameNum = GetSubCodeName(Code, &tempIndex, tempName, &tempNameNum, tempArray, &tempArrayNum, tempArrayIndex);
		//tempReturnNameNum = GetName(Code, &tempIndex, tempIndex, tempIndex + tempReturnIndex, tempName, &tempNameNum, tempArray, &tempArrayNum, tempArrayIndex);
		for (int i = 0; i < tempReturnNameNum; i++)
		{
			if (CheckVarExist(tempName[i], pFunc, &(pReturnVar[*ReturnVarNum])))
			{
				(*ReturnVarNum)++;
			}
		}

		for (int i = 0; i < 15; i++)
		{
			if (strlen(tempName[i]) != 0)
			{
				delete[] tempName[i];
			}
		}
		delete [] tempName;
		for (int i = 0; i < 10; i++)
		{
			if (strlen(tempArray[i]) != 0)
			{
				delete [] tempArray[i];
			}
		}
		delete [] tempArray;
		delete [] tempArrayIndex;

		return 1;
	}

	int GetStrFirstCharIndex(char* str, char* target)
	{
		int tempIndex = 0;
		int tempLength = 0;

		tempLength = strlen(str);
		for (tempIndex = 0; tempIndex < tempLength; tempIndex++)
		{
			if (str[tempIndex] == *target)
			{
				break;
			}
		}
		if (tempIndex == tempLength - 1)
		{
			if (str[tempIndex] != *target)
			{
				tempIndex = -1;
			}
		}

		return tempIndex;
	}

	/////////////////////////////////////////////////////////

	//���������д�����ܱȽϷ�ʱ�䣬��Ҫ�����ٶȵĻ����Խ��������Ĵ����нṹ��ȡ
	int GetCodeLineStruct(int GlobalCodeLineNo, PSourceLine* pSourceLineReturn, PSourceFunction* pFunctionReturn)
	{
		int tempIndex;
		PSourceFunction temppFunc;

		for (int i = 0; i < pSourceCodeFile->FunctionNum; i++)
		{
			temppFunc = pSourceCodeFile->Function[i];
			if (GlobalCodeLineNo >= temppFunc->StartGlobalLineNo && GlobalCodeLineNo <= temppFunc->StopGlobalLineNo)
			{
				*pSourceLineReturn = temppFunc->CodeLine[GlobalCodeLineNo - temppFunc->StartGlobalLineNo];
				*pFunctionReturn = temppFunc;
				return 1;
			}
		}
		for (int i = 0; i < pSourceCodeFile->SourceCodeLineNum; i++)
		{
			if (GlobalCodeLineNo == ((pSourceCodeFile->SourceCodeLine)[i])->GlobalLineNo)
			{
				*pSourceLineReturn = (pSourceCodeFile->SourceCodeLine)[i];
				*pFunctionReturn = NULL;
				return 1;
			}
		}

		return 0;
	}

	int GetForwardAPICodeSlice(int* CodeLineNoArray, int* ArrayLength)
	{
		int tempIndex;



		return 1;
	}

	int GetBackAPICodeSlice(int* CodeLineNoArray, int* ArrayLength)
	{
		int tempIndex;

		return 1;
	}

	int AdjustCodeLineNoOrder(int* CodeLineNoArray, int* ArrayLength)
	{
		int tempIndex = 0;
		int tempStartIndex = 0;
		int tempStopIndex = 0;
		int tempCodeLineNo = 0;
		int tempIntArray[200];
		int tempIntArrayLength = 0;
		int tempLength = 0;
		int tempBlockStartIndex = 0;
		int tempBlockStopIndex = 0;
		PSourceLine* tempSourceLine;
		PSourceFunction* tempFunction;
		tempSourceLine = new PSourceLine;
		tempFunction = new PSourceFunction;

		tempCodeLineNo = CodeLineNoArray[tempIndex++];
		while (tempIndex <= *ArrayLength)
		{
			if (tempCodeLineNo >= tempStartIndex && tempCodeLineNo <= tempStopIndex)
			{
				tempIntArray[tempIntArrayLength++] = tempCodeLineNo;
				tempCodeLineNo = CodeLineNoArray[tempIndex++];
			}
			else
			{
				GetCodeLineStruct(tempCodeLineNo, tempSourceLine, tempFunction);
				if (*tempFunction != NULL)
				{
					tempStartIndex = (*tempFunction)->StartGlobalLineNo;
					tempStopIndex = (*tempFunction)->StopGlobalLineNo;
				}
				else
				{
					tempStartIndex = (*tempSourceLine)->GlobalLineNo;
					tempStopIndex = (*tempSourceLine)->GlobalLineNo;
				}
				tempBlockStopIndex = tempIndex - 2;
				if (tempIntArrayLength != 0)
				{
					AdjustIntOrderSTL(tempIntArray, &tempIntArrayLength);
					tempLength = tempIntArrayLength;
					RemoveRepeateIntInIntArray(tempIntArray, &tempIntArrayLength);
					for (int i = 0; i < tempIntArrayLength; i++)
					{
						CodeLineNoArray[tempBlockStartIndex + i] = tempIntArray[i];
					}
					if (tempIntArrayLength != tempLength)
					{
						RemoveIntArrayMemberFromStartToStop(CodeLineNoArray, ArrayLength, tempBlockStartIndex + tempIntArrayLength, tempBlockStopIndex);
						tempIndex = tempBlockStartIndex + tempIntArrayLength + 1;    //fix bug 22.10.4
					}
				}
				//if (tempIntArrayLength == 0)
				//{
				//	//����Ŀǰ��Ϊ�����������еĵ�һ��Ԫ�����õ�
				//	tempBlockStartIndex = tempIndex - 1;
				//}
				//else
				//{
				//	tempBlockStartIndex = tempIndex - 1;
				//}
				tempBlockStartIndex = tempIndex - 1;
				tempIntArrayLength = 0;
			}
		}
		tempBlockStopIndex = tempIndex - 2;
		if (tempIntArrayLength != 0)
		{
			AdjustIntOrderSTL(tempIntArray, &tempIntArrayLength);
			tempLength = tempIntArrayLength;
			RemoveRepeateIntInIntArray(tempIntArray, &tempIntArrayLength);
			for (int i = 0; i < tempIntArrayLength; i++)
			{
				CodeLineNoArray[tempBlockStartIndex + i] = tempIntArray[i];
			}
			if (tempIntArrayLength != tempLength)
			{
				RemoveIntArrayMemberFromStartToStop(CodeLineNoArray, ArrayLength, tempBlockStartIndex + tempIntArrayLength, tempBlockStopIndex);
			}
		}

		AdjustIntOrderSTL(CodeLineNoArray, ArrayLength);

		delete tempFunction;
		delete tempSourceLine;

		return 1;
	}

	//��Ϊ����һ������������С���������ԾͲ�ʹ�ÿ��ŵ�ʱ�临�Ӷȵ͵��㷨�ˣ������������ԸĽ�
	int AdjustIntOrderSTL(int* IntArray, int* ArrayLength)
	{
		int tempIndex = -1;
		int tempIndex1 = -1;

		for (int i = 0; i < *ArrayLength; i++)
		{
			tempIndex = i;
			for (int z = i + 1; z < *ArrayLength; z++)
			{
				if (IntArray[tempIndex] > IntArray[z])
				{
					tempIndex = z;
				}
			}
			tempIndex1 = IntArray[tempIndex];
			IntArray[tempIndex] = IntArray[i];
			IntArray[i] = tempIndex1;
		}

		return 1;
	}

	//����㷨��ʵ���Ǹ���IntArray�Ѿ�����˳���С�ź�˳�������µ��øú���ʵ�ֽ�IntArray���ظ�������������� AdjustIntOrderSTL ����ʹ��
	int RemoveRepeateIntInIntArray(int* IntArray, int* ArrayLength)
	{
		int tempIndex;

		for (int i = *ArrayLength - 2; i >= 0; i--)
		{
			if (IntArray[i] == IntArray[i + 1])
			{
				for (int z = i + 1; z < *ArrayLength; z++)
				{
					IntArray[z - 1] = IntArray[z];
				}
				(* ArrayLength)--;
			}
		}

		return 1;
	}

	//�Ƴ��������Ǵ�Start��Stop��Start��Stop���������������0Ϊ��ʼ
	int RemoveIntArrayMemberFromStartToStop(int* IntArray, int* ArrayLength, int StartIndex, int StopIndex)
	{
		int tempIndex = 0;

		for (int i = StopIndex + 1; i < *ArrayLength; i++)
		{
			IntArray[StartIndex + tempIndex] = IntArray[i];
			tempIndex++;
		}
		*ArrayLength = *ArrayLength - StopIndex + StartIndex - 1;

		return 1;
	}

	///////////////////////////////////////////////////////////

	int CheckTypedefType(void** Code, int* index, TypedefType* pReturn)
	{
		int tempIndex = 0;
		char temp[100];

		memset(temp, 0x0, 100);

		*pReturn = TypedefType::TypedefType_unknownType;
		tempIndex = DivisionCodeByBlank(Code, index, temp);

		if (tempIndex == 0)
		{
			std::cout << "Check Typedef Type fail" << std::endl;
		}
		if (strcmp(temp, "struct") == 0)
		{
			*pReturn = TypedefType::StructType;
		}
		if (strcmp(temp, "union") == 0)
		{
			*pReturn = TypedefType::UnionType;
		}

		return tempIndex;
	}

	int AddTypeDefStruct(void** Code, int* index)
	{
		int tempIndex = 0;
		char tempSubCode[150];
		char* temppSubCode;
		int temp = 0;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempReturnLength = 0;
		int tempArrayNum;
		int tempNameNum;
		bool bInBrace = false;
		char tempCode[20];
		char** Name;
		char* tempArray[20];
		int* tempArrayIndex;
		int NameNum = 0;
		int tempContantNo = 0;
		int tempInt;
		ProfixType tempProfixType;
		ReturnType tempReturnType;
		PUserDefStruct temppUserDefStruct;
		temppSubCode = tempSubCode;

		tempArrayIndex = new int[20];
		for (int i = 0; i < 20; i++)
		{
			tempArray[i] = new char[50];
		}
		Name = new char* [10];
		for (int i = 0; i < 10; i++)
		{
			Name[i] = new char[80];
		}
		memset(tempSubCode, 0x0, 150);

		tempReturnLength = DivisionCodeByLineFeed(Code, index, tempSubCode);
		temp = 0;
		tempIndex = DivisionCodeByBlank((void**)(&temppSubCode), &temp, tempCode);
		temp += tempIndex;
		MoveCodeIndexUntillNoBlank((void**)(&temppSubCode), &temp);
		tempIndex = DivisionCodeByBlank((void**)(&temppSubCode), &temp, tempCode);
		temp += tempIndex;
		MoveCodeIndexUntillNoBlank((void**)(&temppSubCode), &temp);
		strcpy(((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Name, &(tempSubCode[temp]));
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->ContentNum = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->AnotherNameNum = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->PointerNameNum = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->WriteContantNo = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->ReadContantNo = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->bUserDefStruct = true;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->bUserDefUnion = false;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->DefStartGlobalLineNo = AnalysisCodeLineNo;
		
		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::StructDefType;
		strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, tempSubCode);
		pSourceCodeFile->SourceCodeLineNum++;
		pSourceCodeFile->WriteSourceCodeLineNo++;

		AnalysisCodeLineNo++;
		*index = *index + tempReturnLength + 2;
		tempReturnLength = DivisionCodeByLineFeed(Code, index, tempSubCode);
		if (tempSubCode[0] == '{')                         //�����д��û�п���ͨ���ԣ��̶�����Ϊtypedef struct xxx\r\n{\r\n xxx ����ʽ����
		{
			((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
			((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
			((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::StructDefType;
			strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, tempSubCode);
			pSourceCodeFile->SourceCodeLineNum++;
			pSourceCodeFile->WriteSourceCodeLineNo++;

			tempLBraceNum++;
			AnalysisCodeLineNo++;
			*index = *index + tempReturnLength + 2;
			while (tempLBraceNum != tempRBraceNum)
			{
				tempInt = 0;
				MoveCodeIndexUntillNoBlank(Code, index);
				tempReturnLength = DivisionCodeByLineFeed(Code, index, tempSubCode);
				if (tempSubCode[0] == '{')                 //����û������ô��ͨ���Ե������˽�����xxx\r\n{\r\nxxx\r\n} xxx\r\n����ʽ��
				{
					tempLBraceNum++;
				}
				else if (tempSubCode[0] == '}')
				{
					tempRBraceNum++;
					tempIndex = 1;
					GetUserDefStructAnotherName((void**)(&temppSubCode), &tempIndex, ((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo]));
				}
				else
				{
					tempIndex = 0;
					temp = CheckProfixType((void**)(&temppSubCode), &tempIndex, &tempProfixType);
					if (tempProfixType != ProfixType::ProfixType_unknownType)
					{
						tempIndex += temp;
						MoveCodeIndexUntillNoBlank((void**)(&temppSubCode), &tempIndex);
					}

					temp = CheckReturnType((void**)(&temppSubCode), &tempIndex, &tempReturnType, &temppUserDefStruct);
					if (tempReturnType != ReturnType::ReturnType_unknownType)
					{
						tempIndex += temp;
						MoveCodeIndexUntillNoBlank((void**)(&temppSubCode), &tempIndex);
					}
					tempArrayNum = 0;
					NameNum = 0;
					tempArrayNum = 0;
					tempNameNum = GetSubCodeName((void**)(&temppSubCode), &tempIndex, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
					for (int i = 0; i < tempNameNum; i++)
					{
						tempContantNo = ((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->WriteContantNo;
						((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).DefCodeLineGlobalNo = AnalysisCodeLineNo;
						((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).ReturnType = tempReturnType;
						strcpy(((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).Name, Name[i]);
						((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).UserDefStructNo = pSourceCodeFile->WriteUserDefStructNo;
						((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).ProfixType = tempProfixType;
						if (tempArrayNum > 0)
						{
							if ((i + tempInt) == tempArrayIndex[tempInt])
							{
								((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).bArray = true;
								((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).bPointerType = true;
								temp = 0;
								((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).PointerPointMemSize = CalculateIntExpression((void**)(&(tempArray[tempInt])), &temp, NULL) * GetReturnTypeSize(tempReturnType);           //��������Ƕ��û��Զ���ı������Ͷ���Ľ��������漰��������ĸ������У����Բ����ں����ṹָ�루�п���֮���Զ�����ĳ�������е��û��Զ���������ͽ��н�������ʱ���ٽ��о���ķ�����
								strcpy(((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).Array, tempArray[tempInt]);
								tempInt++;
								tempArrayNum--;
							}
						}
						if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
						{
							((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).bUserDefStruct = true;
							((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).pUserDefStruct = temppUserDefStruct;
						}
						else
						{
							((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).bUserDefStruct = false;
							((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).pUserDefStruct = NULL;
						}
						//��һ�еĺ�������Ӧ������Ϊ���鶨��ʱ���������������ʱ���õģ�����������ж�tempArrayNum���Ƿ������鶨���йأ�����й�Ӧ�ý���һ�д����ƶ���if��֧��
						//��һ�еĺ��������ڼ���û�����Ľṹ������ʱע�͵��ˣ����������˵�ɣ�һ������û�����Ľṹ����Ҫ��������ģ������С�����ܻ��漰�궨��
						//CheckVarDefByOtherVarStatus(&(tempArray[tempInt]), (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);
						((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->ContentNum++;
						((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->WriteContantNo++;
					}
				}
				((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
				((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
				((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::StructDefType;
				strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, tempSubCode);
				pSourceCodeFile->SourceCodeLineNum++;
				pSourceCodeFile->WriteSourceCodeLineNo++;

				AnalysisCodeLineNo++;
				*index = *index + tempReturnLength + 2;
			}
			((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->DefStopGlobalLineNo = AnalysisCodeLineNo - 1;
			pSourceCodeFile->WriteUserDefStructNo++;
			pSourceCodeFile->UserDefStructNum++;
		}
		else
		{
			std::cout << "Add Typedef Struct error" << std::endl;
			return 0;
		}

		for (int i = 0; i < 10; i++)
		{
			if (strlen(Name[i]) != 0)
			{
				delete[]Name[i];
			}
		}
		delete[]Name;
		for (int i = 0; i < 20; i++)
		{
			if (strlen(tempArray[i]) != 0)
			{
				delete[]tempArray[i];
			}
		}
		delete [] tempArrayIndex;

		return 1;
	}

	int GetUserDefStructAnotherName(void** Code, int* index, PUserDefStruct pUserDefStruct)
	{
		int tempIndex;
		bool bPointer = false;
		char tempName[100];
		int tempNameIndex = 0;

		tempIndex = *index;
		while ((*(char**)Code)[tempIndex] != 0x0)
		{
			MoveCodeIndexUntillNoBlank(Code, &tempIndex);
			if ((*(char**)Code)[tempIndex] == '*')
			{
				bPointer = true;
				tempIndex++;
				continue;
			}
			if ((*(char**)Code)[tempIndex] == ',' || (*(char**)Code)[tempIndex] == ';') //|| (*(char**)Code)[tempIndex] != ';'
			{
				tempName[tempNameIndex] = 0x0;
				if (bPointer)
				{
					strcpy((pUserDefStruct->PointerName)[pUserDefStruct->PointerNameNum], tempName);
					pUserDefStruct->PointerNameNum++;
				}
				else
				{
					strcpy((pUserDefStruct->AnotherName)[pUserDefStruct->AnotherNameNum], tempName);
					pUserDefStruct->AnotherNameNum++;
				}
				tempNameIndex = 0;
				bPointer = false;
				tempIndex++;
				continue;
			}
			if (CheckNamableCharacter(&(*(char**)Code)[tempIndex]))
			{
				tempName[tempNameIndex++] = (*(char**)Code)[tempIndex++];
			}
		}

		return 1;
	}

	//�����������Ƿ��С�{����}�������С�{������-1�����С�}������1,�����������򷵻�0
	int CheckCodeLineHaveBrace(void** Code, int* index, int* LBraceNum, int* RBraceNum)
	{
		int tempLength = strlen(*(char**)Code);
		int BraceType = -2;
		
		*LBraceNum = 0;
		*RBraceNum = 0;

		*LBraceNum = CheckByte(Code, index, tempLength, '{');
		if (*LBraceNum != 0)
		{
			BraceType = -1;
		}
		*RBraceNum = CheckByte(Code, index, tempLength, '}');
		if (*RBraceNum != 0)
		{
			if (BraceType == -1)
			{
				BraceType = 0;
			}
			else
			{
				BraceType = 1;
			}
		}

		return BraceType;
	}

	//���������������������Ϣ���ӵ�������洢�ṹ�У�����Ϊָ�����ͼ�����ָ��ָ����ڴ�����Ĵ�С�����������ֻ�ܴ����򵥵ı���ʽ���㣬�����ܴ����ϸ��ӵı���ʽ���㣬���ӵı���ʽ���������Ҫʹ�ñ���ʽ�﷨�������н����������Ҷ�ʵ�������Ĺ۲췢�ֻ����ϲ�����ƽϸ��ӵı���ʽ
	int AddPointerTypeVarInfo(void** Code, int* index, PVariable pVar, PSourceFunction pFunc)
	{
		pVar->PointerPointMemSize = CalculateIntExpression(Code, index, pFunc) * GetReturnTypeSize(pVar->returnType);
		pVar->bPointerType = true;

		return 1;
	}

	OperatorType CheckOperatorType(char* target)
	{
		if(strcmp(target, "==") == 0)
		{
			return EqualOperator;
		}
		if (strcmp(target, ">") == 0)
		{
			return GreaterOperator;
		}
		if (strcmp(target, ">=") == 0)
		{
			return GreaterAndEqualOperator;
		}
		if (strcmp(target, "<") == 0)
		{
			return LessOperator;
		}
		if (strcmp(target, "<=") == 0)
		{
			return LessAndEqualOperator;
		}
		if (strcmp(target, "-") == 0)
		{
			return SubOperator;
		}
		if (strcmp(target, "+") == 0)
		{
			return AddOperator;
		}
		if (strcmp(target, "*") == 0)
		{
			return MulOperator;
		}
		if (strcmp(target, "/") == 0)
		{
			return DivOperator;
		}
		if (strcmp(target, "%") == 0)
		{
			return ComplementationOperator;
		}
		if (strcmp(target, "++") == 0)
		{
			return DoubleAddOperator;
		}
		if (strcmp(target, "--") == 0)
		{
			return DoubleSubOperator;
		}
		if (strcmp(target, "=") == 0)
		{
			return AssignmentOperator;
		}
		if (strcmp(target, "|") == 0)
		{
			return OrOperator;
		}
		if (strcmp(target, "&") == 0)
		{
			return AndOperator;
		}
		if (strcmp(target, "||") == 0)
		{
			return DoubleOrOperator;
		}
		if (strcmp(target, "&&") == 0)
		{
			return DoubleAndOperator;
		}

		return OperatorType_UnknownType;
	}

	//����Ŀ�����͵ĵ�����С,��������������û��Զ���ı����Ļ�/����ʶ��ı������͵Ļ��᷵��-1
	int GetReturnTypeSize(ReturnType target)
	{
		int tempInt = 0;

		switch (target)
		{
		case ReturnType_unknownType:
		{
			std::cout << "GetReturnTypeSize error " << std::endl;
			break;
		}
		case charType:
		{
			tempInt = 1;
			return tempInt;
		}
		case pcharType:
		case pintType:
		case pfloatType:
		case pdoubleType:
		case pvoidType:
		case pshortType:
		case longType:
		case plongType:
		case size_tType:
		case FILEType:
		case HCRYPTPROVType:
		case HCRYPTKEYType:
		case HCRYPTHASHType:
		case DWORDType:
		case UserDefStructPointerType:
		case pwchar_tType:
		{
			tempInt = 4;
			break;
		}
		case intType:
		case floatType:
		{
			tempInt = 4;
			return tempInt;
		}
		case doubleType:
		{
			tempInt = 8;
			return tempInt;
		}
		case voidType:
		{
			tempInt = 0;
			return tempInt;
		}
		case shortType:
		case wchar_tType:
		{
			tempInt = 2;
			return tempInt;
		}
		case UserDefStructType:
		case UserDefStructAnotherNameType:
		case UserDefStructContentType:
		default:
		{
			tempInt = -1;
			return tempInt;
		}
		}
#ifdef _WIN64 // _WIN64
		return tempInt * 2;
#else // _WIN32
		return tempInt;
#endif
	}

	//����Ŀ�����ʽ��ֵ��Int���ͱ���ʽ��,��������Ľ��ͨ������ֵ����,���б���ʽ�����������Ѿ�����ı������ߺ궨�壨��ʵ�������Ӧ���ٷֽ�һ�£����궨�弰����ı�����ֵȥ������Ȼ�󴫵�һ��ר�Ž��б���ʽ����ĺ����н���ר�ŵĴ�����,�����������������Щ����
	int CalculateIntExpression(void** Code, int* index, PSourceFunction pFunc)
	{
		int tempIndex = 0;
		int tempCodeLength = 0;
		int tempOperatorLength = 0;
		int tempInt = 0;
		int tempNum = 0;
		char tempSubCode[50];
		char tempOperator[5];
		OperatorType OperType = OperatorType_UnknownType;
		PVariable temppVar;
		PMacro temppMacro;

		//tempCodeLength = strlen(&((*(char**)Code)[*index]));                   //fix bug at 22.10.1
		while ((*(char**)Code)[*index + tempIndex] != 0x0)
		{
			if ((*(char**)Code)[*index + tempIndex] != ' ')
			{
				if (CheckNamableCharacter(&((*(char**)Code)[*index + tempIndex])) == 1)
				{
					if (tempOperatorLength != 0)
					{
						tempOperator[tempOperatorLength] = 0x0;
						OperType = CheckOperatorType(tempOperator);
						switch (OperType)
						{
						case DoubleAddOperator:        // ++
						case DoubleSubOperator:        // --
						{
							//std::cout << "CalculateExpression error!   " << AnalysisCodeLineNo << std::endl;
							return 0;
						}
						default:
							break;
						}
						tempOperatorLength = 0;
					}
					tempSubCode[tempCodeLength++] = (*(char**)Code)[*index + tempIndex];
				}
				else
				{
					if (tempCodeLength != 0)
					{
						tempSubCode[tempCodeLength] = 0x0;
						tempCodeLength = 0;

						//��ѯ�Ƿ����Ѿ�����ı��������Ǻ궨�壬�����Ϸ�tempSubCode����������������Ƿ�Ϊ�������ַ�Ȼ�����ɵģ��������ﲻ�ü���ProcessVar()���д���
						if (CheckVarExist(tempSubCode, pFunc, &temppVar))
						{
							if (temppVar->returnType == intType)
							{
								//�����п��ܳ������������Ƿ��ڷ�����ʱ��ʱ�̱���ű�����ֵ
								tempInt = StrToInt(temppVar->Value);
							}
							else if (temppVar->returnType == pintType)
							{
								//�����п��ܳ�������Ϊ����������ô��ָ��������д�������
								tempInt = StrToInt(temppVar->Value);
							}
							else
							{
								//std::cout << "CalculateExpression error!   " << AnalysisCodeLineNo << std::endl;
								return 0;
							}
						}
						else
						{
							if (CheckMacroExist(tempSubCode, pFunc, &temppMacro))
							{
								tempInt = StrToInt(temppMacro->Value);
							}
							else
							{
								//std::cout << "CalculateExpression error!   " << AnalysisCodeLineNo << std::endl;
								return 0;
							}
						}

						switch (OperType)
						{
						case OperatorType_UnknownType:     //��û���κβ�������������ʱ��
						{
							tempNum = tempInt;
							break;
						}
						case AddOperator:        // +
						{
							tempNum += tempInt;
							break;
						}
						case SubOperator:        // -
						{
							tempNum -= tempInt;
							break;
						}
						case DivOperator:        // /
						{
							tempNum /= tempInt;
							break;
						}
						case MulOperator:       // *
						{
							tempNum *= tempInt;
							break;
						}
						case ComplementationOperator:        // %
						{
							tempNum %= tempInt;
							break;
						}
						default:
							break;
						}
					}

					tempOperator[tempOperatorLength++] = (*(char**)Code)[*index + tempIndex];
				}
			}

			tempIndex++;
		}

		if (tempCodeLength != 0)
		{
			tempSubCode[tempCodeLength] = 0x0;
			tempCodeLength = 0;

			//��ѯ�Ƿ����Ѿ�����ı��������Ǻ궨�壬�����Ϸ�tempSubCode����������������Ƿ�Ϊ�������ַ�Ȼ�����ɵģ��������ﲻ�ü���ProcessVar()���д���
			if (CheckVarExist(tempSubCode, pFunc, &temppVar))
			{
				if (temppVar->returnType == intType)
				{
					//�����п��ܳ������������Ƿ��ڷ�����ʱ��ʱ�̱���ű�����ֵ
					tempInt = StrToInt(temppVar->Value);
				}
				else if (temppVar->returnType == pintType)
				{
					//�����п��ܳ�������Ϊ����������ô��ָ��������д�������
					tempInt = StrToInt(temppVar->Value);
				}
				else
				{
					//std::cout << "CalculateExpression error!   " << AnalysisCodeLineNo << std::endl;
					return 0;
				}
			}
			else
			{
				if (CheckMacroExist(tempSubCode, pFunc, &temppMacro))
				{
					//���������⣬����궨����һ������ʽ����ô��ôֱ�ӻ�ȡ����Intֵ�������������Ŀǰ����ָ������������С�Ĺ�ϵ
					//Ŀǰ���bug�Ȳ��޸�
					tempInt = StrToInt(temppMacro->Value);
				}
				else
				{
					//std::cout << "CalculateExpression error!   " << AnalysisCodeLineNo << std::endl;
					return 0;
				}
			}

			switch (OperType)
			{
			case OperatorType_UnknownType:     //��û���κβ�������������ʱ��
			{
				tempNum = tempInt;
				break;
			}
			case AddOperator:        // +
			{
				tempNum += tempInt;
				break;
			}
			case SubOperator:        // -
			{
				tempNum -= tempInt;
				break;
			}
			case DivOperator:        // /
			{
				tempNum /= tempInt;
				break;
			}
			case MulOperator:       // *
			{
				tempNum *= tempInt;
				break;
			}
			case ComplementationOperator:        // %
			{
				tempNum %= tempInt;
				break;
			}
			default:
				break;
			}
		}

		if (tempOperatorLength != 0)
		{
			tempOperator[tempOperatorLength] = 0x0;
			OperType = CheckOperatorType(tempOperator);
			switch (OperType)
			{
			case DoubleAddOperator:        // ++
			{
				tempNum++;
				break;
			}
			case DoubleSubOperator:        // --
			{
				tempNum--;
				break;
			}
			default:
				break;
			}
			tempOperatorLength = 0;
		}

		return tempNum;
	}

	//�������Ĵ洢�ṹ������SytaxKey��ص���Ϣ
	int AddVarStructSyntaxKeyInfo(PVariable pVar, PSourceLine pSourceLine)
	{
		int tempIndex;
		PStoreSyntaxKeyInfo temppStoreSyntaxKeyInfo;
		PStoreSyntaxKeyInfo temppStoreSyntaxKeyInfo1;

		temppStoreSyntaxKeyInfo = new StoreSyntaxKeyInfo;

		pVar->bInSyntaxBlock = true;
		if (pVar->SyntaxCodeLineNum == 0)
		{
			pVar->SyntaxCodeLineNoArray = temppStoreSyntaxKeyInfo;
		}
		else
		{
			temppStoreSyntaxKeyInfo1 = pVar->SyntaxCodeLineNoArray;
			for (int i = 1; i < pVar->SyntaxCodeLineNum; i++)
			{
				temppStoreSyntaxKeyInfo1 = temppStoreSyntaxKeyInfo1->pNext;
			}
			temppStoreSyntaxKeyInfo1->pNext = temppStoreSyntaxKeyInfo;
		}
		pVar->SyntaxCodeLineNum++;

		temppStoreSyntaxKeyInfo->GlobalCodeLineNo = AnalysisCodeLineNo;
		temppStoreSyntaxKeyInfo->pParent = pVar;
		temppStoreSyntaxKeyInfo->pSourceLine = pSourceLine;
		temppStoreSyntaxKeyInfo->SyntaxKeyType = (pSourceLine->PSyntaxCode)->SyntaxKeyType;

		return 1;
	}

	//���� IN ���͵Ĳ���������ȡ�䶨�������Ϣ����������漰���������ò�������Ϣ��������ݹ����ǰѰ�����յĶ��壩�����ҵ��ı�ñ���ֵ������һ�μ�¼���ɱ����ı䡢�����ɺ�������ֵ�ı䣩���ٽ��ñ����ڵ�ǰ�����к�ǰ����Ϊ�����������û�����ĺ���������Ϣȫ��ȡ����
	int GetBackAPIInTypeOnePar(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, bool bIsPar, int CodeLineNo)
	{
		int tempReturnCodeLineNum = 0;
		PSourceLine temppReturnCodeLine[20];
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;
		SyntaxKey SyntaxKeyArray[8] = { SyntaxKey::ifType, SyntaxKey::switchType, SyntaxKey::caseType, SyntaxKey::defaultType, SyntaxKey::forType, SyntaxKey::whileType, SyntaxKey::elseType, SyntaxKey::switchType };
		int tempReturnCodeLineArray[20] = { 0 };
		int tempReturnCodeLineArrayLength = 0;

		GetVarValueSpreadChainFinalNode(pVar, CodeLineNo, temppReturnCodeLine, &tempReturnCodeLineNum);
		
		//updata at 23.3.13 for CEW194
		if (tempReturnCodeLineNum)
		{
			HandleReturnCodeLineArrayForCWE194(temppReturnCodeLine, &tempReturnCodeLineNum);
		}
		////////

		for (int i = 0; i < tempReturnCodeLineNum; i++)
		{
			pCodeBlock->Path[(pCodeBlock->PathLength)++] = (temppReturnCodeLine[i])->GlobalLineNo;

			//update at 23.3.8 ���������ҲӦ��Ϊ����ĺ궨��ı����ֵ�ͺ������øı����ֵ������������
			/*GetCodeLineStruct((temppReturnCodeLine[i])->GlobalLineNo, &temppCodeLine, &temppFunc);
			if (CheckCodeLineMasterTypeIsTargetSyntaxType(temppCodeLine->PUnSyntaxCode->MasterLineNo, SyntaxKeyArray, 5))
			{
				pCodeBlock->Path[(pCodeBlock->PathLength)++] = temppCodeLine->PUnSyntaxCode->MasterLineNo;
			}*/
			GetCodeLineCodeBlockInfoIsTargetSyntaxType((temppReturnCodeLine[i])->GlobalLineNo, SyntaxKeyArray, 8, tempReturnCodeLineArray, &tempReturnCodeLineArrayLength);
			for (int z = 0; z < tempReturnCodeLineArrayLength; z++)
			{
				(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = tempReturnCodeLineArray[z];
			}
		}

		//updata at 23.1.7
		GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(pVar, pVarArray, pCodeBlock);
		GetPVarPointMemoryInfo(pVar, pCodeBlock);
		
		return 1;
	}

	//��ȡ���API OUT ���͵Ĳ�����Ƭ��Ϣ������pFunc������δ��ʹ�ã�����ע��һ��д���Ƿ������⣬����OUT���Ͳ�������ֻȥ�䶨�������Ϣ������ñ����Ķ����漰������ú�����ݹ�����Ѱ���ҵ������յĶ��壩��
	int GetBackAPIOUTTypeOnePar(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, bool bIsPar, int CodeLineNo)
	{
		PStoreVarDefInfo temppStoreVarDefInfo;
		int tempReturnMemoryAllocCodeLineArray[5] = { 0 };
		int tempReturnMemoryAllocCodeLineArrayLength = 0;
		bool tempBool = false;
		SyntaxKey SyntaxKeyArray[8] = { SyntaxKey::ifType, SyntaxKey::switchType, SyntaxKey::caseType, SyntaxKey::defaultType, SyntaxKey::forType, SyntaxKey::whileType, SyntaxKey::elseType, SyntaxKey::switchType };
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;
		int tempReturnCodeLineArray[5] = { 0 };
		int tempReturnCodeLineArrayLength = 0;

		GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(pVar, pVarArray, pCodeBlock);
		//�����µķ������ý�Ѱ�ұ������ں����ڵ���Ƭ��Ϣ�������п纯����Ƭ�����ԾͲ����ÿ纯����Ƭ�����ˣ����к�����
		//CheckVarAndDefVarOtherVarIsFunctionPar(pCodeBlock->pFunc, pVarArray[pCodeBlock->BlockRealVarDefByOtherVarNum - 1], pVarArray, pCodeBlock, bIsPar);

		//update at 2022.12.31
		if (CheckReturnTypeIsPointerType(pVar))
		{
			if (pVar->bChangVar)
			{
				temppStoreVarDefInfo = pVar->pChangVar;
				if (temppStoreVarDefInfo->pVarDef != NULL)
				{
					if (CheckReturnTypeIsPointerType(temppStoreVarDefInfo->pVarDef))
					{
						tempBool = true;
						(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
						
						//update at 23.3.8
						/*GetCodeLineStruct(temppStoreVarDefInfo->ChangGlobalLineNo, &temppCodeLine, &temppFunc);
						if(CheckCodeLineMasterTypeIsTargetSyntaxType(temppCodeLine->PUnSyntaxCode->MasterLineNo, SyntaxKeyArray, 8))
						{
							(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppCodeLine->PUnSyntaxCode->MasterLineNo;
						}*/
						GetCodeLineCodeBlockInfoIsTargetSyntaxType(temppStoreVarDefInfo->ChangGlobalLineNo, SyntaxKeyArray, 8, tempReturnCodeLineArray, &tempReturnCodeLineArrayLength);
						for (int i = 0; i < tempReturnCodeLineArrayLength; i++)
						{
							(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = tempReturnCodeLineArray[i];
						}

						GetBackAPIOUTTypeOnePar(pFunc, temppStoreVarDefInfo->pVarDef, pVarArray, pCodeBlock, false, CodeLineNo);
					}
				}
				for (int i = 1; i < pVar->ChangeVarNum; i++)
				{
					if (!tempBool)
					{
						temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
						if (temppStoreVarDefInfo->pVarDef != NULL)
						{
							if (CheckReturnTypeIsPointerType(temppStoreVarDefInfo->pVarDef))
							{
								tempBool = true;
								(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
								
								//update at 23.3.8
								/*GetCodeLineStruct(temppStoreVarDefInfo->ChangGlobalLineNo, &temppCodeLine, &temppFunc);
								if (CheckCodeLineMasterTypeIsTargetSyntaxType(temppCodeLine->PUnSyntaxCode->MasterLineNo, SyntaxKeyArray, 8))
								{
									(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppCodeLine->PUnSyntaxCode->MasterLineNo;
								}*/
								GetCodeLineCodeBlockInfoIsTargetSyntaxType(temppStoreVarDefInfo->ChangGlobalLineNo, SyntaxKeyArray, 8, tempReturnCodeLineArray, &tempReturnCodeLineArrayLength);
								for (int z = 0; z < tempReturnCodeLineArrayLength; z++)
								{
									(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = tempReturnCodeLineArray[z];
								}

								GetBackAPIOUTTypeOnePar(pFunc, temppStoreVarDefInfo->pVarDef, pVarArray, pCodeBlock, false, CodeLineNo);
							}
						}
					}
				}
			}

			//update at 23.3.7
			GetVarMemoryAllocInfo(pVar, tempReturnMemoryAllocCodeLineArray, &tempReturnMemoryAllocCodeLineArrayLength);
			for (int z = 0; z < tempReturnMemoryAllocCodeLineArrayLength; z++)
			{
				(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = tempReturnMemoryAllocCodeLineArray[z];
			}
		}

		//updata at 23.3.9 Ϊ��ʵ�ֶ�buffer_overread�Ĵ���Ƭ����ȡ����д���µĹ���
		ExtractVarAsPrintFuncParInfo(pVar, pCodeBlock, CodeLineNo);
		ExtractVarAsFprintfFuncParInfo(pVar, pCodeBlock, CodeLineNo);

		//update at 23.3.13 for CWE134
		HandleCodeSliceForCWE134(pVar, CodeLineNo, pCodeBlock);
		////////////////

		return 1;
	}

	int GetBackAPIINAndOUTTypeOnePar(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, bool bIsPar, int CodeLineNo)
	{
		int tempIndex;

		GetBackAPIInTypeOnePar(pFunc, pVar, pVarArray, pCodeBlock, bIsPar, CodeLineNo);
		GetBackAPIOUTTypeOnePar(pFunc, pVar, pVarArray, pCodeBlock, bIsPar, CodeLineNo);

		return 1;
	}

	//�������������ȡ����ֵ������ı�ĵط�����ֵ�ĸı��Ǳ���һ����������һ�������ĵ��õķ���ֵ���Ǻ궨��ı�ģ�������һ���������������û�����ĺ����䷵��ֵ�ı��˱�����ֵ�Ļ�Ҳ�᷵�أ��ڽ������Ķ��û�����ĺ�������ֵ�ı����ֵ�����Ӧ�ý��н�һ���ķ�����������һ����������û�����ĺ����ķ���ֵ���ɵ�Ե����ʲô������������̫���ӣ���û��������ȡ�ú������÷���ֵ�ı����ֵ�ĵط����û�����ĺ����������⴦�����������ظú�����Ϊ�������õ����з��û�����ĺ���������Ϣ�����Ǻ����еĺ���������Ϣ��Ƭ��ȡ���������˹����н�һ���Ĵ�����,��ʵҲӦ�ö԰Ѹñ�����Ϊ�������û�����ĺ������еݹ��ȥ����������Ŀ�ľ��Ƿ������û�����ĺ�������û�е��ö���������в����Ŀ⺯����free/delete��,��������ǵĺ���˼�룩
	int GetVarChangeByOtherVarOrFunctionCallNew(PVariable pTargetVar, int* ReturnVarNum, PStoreVarDefInfo* pReturnVar, int* ReturnFunctionNum, PStoreFunctionDefInfo* pReturnFuncion, PStoreFunctionDefInfo* pReturnFunctionArray, int* ReturnFunctionArrayLength, int* ReturnMacroNum, PStoreMacroDefInfo* pReturnMacro, int CodeLineNo)
	{
		int tempIndex;
		PStoreFunctionDefInfo temppStoreFunctionInfo;
		PStoreFunctionDefInfo temppStoreFunctionInfo1;
		PStoreVarDefInfo temppStoreVarDefInfo;
		PStoreVarDefInfo temppStoreVarDefInfo1;
		PStoreMacroDefInfo temppStoreMacroDefInfo;
		PStoreMacroDefInfo temppStoreMacroDefInfo1;

		*ReturnVarNum = 0;
		*ReturnFunctionNum = 0;
		*ReturnFunctionArrayLength = 0;
		*ReturnMacroNum = 0;
		if (pTargetVar->bChangVar)
		{
			if (pTargetVar->ChangeVarNum > 0)
			{
				temppStoreVarDefInfo = pTargetVar->pChangVar;
				if (temppStoreVarDefInfo->ChangGlobalLineNo > CodeLineNo)
				{
					pReturnVar[0] = NULL;
				}
				else
				{
					for (int i = 1; i < pTargetVar->ChangeVarNum; i++)
					{
						if ((temppStoreVarDefInfo->pNext)->ChangGlobalLineNo > CodeLineNo)
						{
							break;
						}
						temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
					}
					pReturnVar[(*ReturnVarNum)++] = temppStoreVarDefInfo;
					if (GetStoreVarDefInfoChainFrontNode(temppStoreVarDefInfo, pTargetVar->pChangVar, &temppStoreVarDefInfo1) != 0)
					{
						while (true)
						{
							if (temppStoreVarDefInfo1->ChangGlobalLineNo == temppStoreVarDefInfo->ChangGlobalLineNo)
							{
								temppStoreVarDefInfo = temppStoreVarDefInfo1;
								pReturnVar[(*ReturnVarNum)++] = temppStoreVarDefInfo;
								if (GetStoreVarDefInfoChainFrontNode(temppStoreVarDefInfo, pTargetVar->pChangVar, &temppStoreVarDefInfo1) == 0)
								{
									break;
								}
							}
							else
							{
								break;
							}
						}
					}
				}
			}
		}
		if (pTargetVar->bFunctionCallReturn)
		{
			temppStoreFunctionInfo = pTargetVar->pFunctionCallReturn;
			if (temppStoreFunctionInfo->FunctionCallGlobalLineNo > CodeLineNo)
			{
				pReturnFuncion[0] = NULL;
			}
			else
			{
				for (int i = 1; i < pTargetVar->FunctionCallReturnNum; i++)
				{
					if ((temppStoreFunctionInfo->pNext)->FunctionCallGlobalLineNo > CodeLineNo)
					{
						break;
					}
					temppStoreFunctionInfo = temppStoreFunctionInfo->pNext;
				}
				pReturnFuncion[(*ReturnFunctionNum)++] = temppStoreFunctionInfo;
				if (GetStoreFunctionDefInfoChainFrontNode(temppStoreFunctionInfo, pTargetVar->pFunctionCallReturn, &temppStoreFunctionInfo1) != 0)
				{
					while (true)
					{
						if (temppStoreFunctionInfo1->FunctionCallGlobalLineNo == temppStoreFunctionInfo->FunctionCallGlobalLineNo)
						{
							temppStoreFunctionInfo = temppStoreFunctionInfo1;
							pReturnFuncion[(*ReturnFunctionNum)++] = temppStoreFunctionInfo;
							if (GetStoreFunctionDefInfoChainFrontNode(temppStoreFunctionInfo, pTargetVar->pFunctionCallReturn, &temppStoreFunctionInfo1) == 0)
							{
								break;
							}
						}
						else
						{
							break;
						}
					}
				}
			}
		}
		if (pTargetVar->bChangeByOthersMacro)
		{
			temppStoreMacroDefInfo = pTargetVar->pChangeOtherMacro;
			if (temppStoreMacroDefInfo->ChangeGlobalLineNo > CodeLineNo)
			{
				pReturnMacro[0] = NULL;
			}
			else
			{
				for (int i = 1; i < pTargetVar->ChangeByOthersMacroNum; i++)
				{
					if ((temppStoreMacroDefInfo->pNext)->ChangeGlobalLineNo > CodeLineNo)
					{
						break;
					}
					temppStoreMacroDefInfo = temppStoreMacroDefInfo->pNext;
				}
				pReturnMacro[(*ReturnMacroNum)++] = temppStoreMacroDefInfo;
				if (GetStoreMacroDefInfoChainFrontNode(temppStoreMacroDefInfo, pTargetVar->pChangeOtherMacro, &temppStoreMacroDefInfo1) != 0)
				{
					while (true)
					{
						if (temppStoreMacroDefInfo1->ChangeGlobalLineNo == temppStoreMacroDefInfo->ChangeGlobalLineNo)
						{
							temppStoreMacroDefInfo = temppStoreMacroDefInfo1;
							pReturnMacro[(*ReturnMacroNum)++] = temppStoreMacroDefInfo;
							if (GetStoreMacroDefInfoChainFrontNode(temppStoreMacroDefInfo, pTargetVar->pChangeOtherMacro, &temppStoreMacroDefInfo1) == 0)
							{
								break;
							}
						}
						else
						{
							break;
						}
					}
				}
			}
		}

		if (pTargetVar->bIsFunctionCallPar)
		{
			temppStoreFunctionInfo = pTargetVar->pFunctionCallPar;
			while (temppStoreFunctionInfo->FunctionCallGlobalLineNo <= CodeLineNo)
			{
				pReturnFunctionArray[(*ReturnFunctionArrayLength)++] = temppStoreFunctionInfo;
				temppStoreFunctionInfo = temppStoreFunctionInfo->pNext;
				if (temppStoreFunctionInfo == NULL)
				{
					break;
				}
			}
		}

		return 1;
	}

	int GetStoreFunctionDefInfoChainFrontNode(PStoreFunctionDefInfo Target, PStoreFunctionDefInfo Start, PStoreFunctionDefInfo* Return)
	{
		int tempIndex = 1;
		PStoreFunctionDefInfo tempp;
		tempp = Start;

		if (Target == tempp)
		{
			return 0;
		}

		while (true)
		{
			if (tempp->pNext == Target)
			{
				*Return = tempp;
				break;
			}
			tempIndex++;
			tempp = tempp->pNext;
		}

		return tempIndex;
	}

	int GetStoreVarDefInfoChainFrontNode(PStoreVarDefInfo Target, PStoreVarDefInfo Start, PStoreVarDefInfo* Return)
	{
		int tempIndex = 1;
		PStoreVarDefInfo tempp;
		tempp = Start;

		if (Target == tempp)
		{
			return 0;
		}

		while (true)
		{
			if (tempp->pNext == Target)
			{
				*Return = tempp;
				break;
			}
			tempIndex++;
			tempp = tempp->pNext;
		}

		return tempIndex;
	}

	//��ȡ�������ڵ�ĳ���䴦�ڵ��﷨��֧�ṹ�ڵ���Ϣ���о���ôд��������ģ���Ӧ����ȥ�ñ��������ֵķ�֧���Ĵ�������Ϣ������Ӧ����ȡ�ô��������ڵķ�֧��䣨��ʹ�ñ���û�г����ڴˣ�����Ϣ��������������ͱ������������Ժ���ܻ��õ�
	int GetVarInSyntaxBlockInfo(PVariable pTarget, int CodeLineNo, PStoreSyntaxKeyInfo* pReturn, int* ReturnCodeLineNum)
	{
		int i;
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;
		PStoreSyntaxKeyInfo temppSyntaxCodeLine;
		PStoreSyntaxKeyInfo temppSyntaxCodeLine1;

		*ReturnCodeLineNum = 0;
		if (pTarget->bInSyntaxBlock)
		{
			temppSyntaxCodeLine = pTarget->SyntaxCodeLineNoArray;
			if (temppSyntaxCodeLine->GlobalCodeLineNo > CodeLineNo)
			{
				pReturn[0] = NULL;
			}
			else
			{
				for (i = 1; i < pTarget->SyntaxCodeLineNum; i++)
				{
					if ((temppSyntaxCodeLine->pNext)->GlobalCodeLineNo > CodeLineNo)
					{
						break;
					}
					temppSyntaxCodeLine = temppSyntaxCodeLine->pNext;
				}
				for (int z = 0; z < i; z++)
				{
					GetCodeLineStruct(temppSyntaxCodeLine->GlobalCodeLineNo, &temppCodeLine, &temppFunc);
					if (CodeLineNo >= (temppCodeLine->PSyntaxCode)->FirstContentLineNo && CodeLineNo <= (temppCodeLine->PSyntaxCode)->FinalContentLineNo)
					{
						pReturn[(*ReturnCodeLineNum)++] = temppSyntaxCodeLine;
					}
					if (GetStoreSyntaxKeyInfoChainFrontNode(temppSyntaxCodeLine, pTarget->SyntaxCodeLineNoArray, &temppSyntaxCodeLine1) == 0)
					{
						break;
					}
					temppSyntaxCodeLine = temppSyntaxCodeLine1;
				}
			}
		}
		else
		{
			pReturn[0] = NULL;
		}

		return 1;
	}

	int GetStoreSyntaxKeyInfoChainFrontNode(PStoreSyntaxKeyInfo Target, PStoreSyntaxKeyInfo Start, PStoreSyntaxKeyInfo* pReturn)
	{
		int tempIndex = 1;
		PStoreSyntaxKeyInfo tempp;
		tempp = Start;

		if (Target == tempp)
		{
			return 0;
		}

		while (true)
		{
			if (tempp->pNext == Target)
			{
				*pReturn = tempp;
				break;
			}
			tempIndex++;
			tempp = tempp->pNext;
		}

		return tempIndex;
	}

	int GetCodeLineInSyntaxBlockInfo(PSourceLine pTarget, PSourceLine* pReturn, int* ReturnCodeLineNum)
	{
		PSourceLine temppCodeLine;
		PSourceLine temppCodeLine1;
		PSourceFunction temppFunc;

		*ReturnCodeLineNum = 0;
		temppCodeLine = pTarget;
		while ((temppCodeLine->PUnSyntaxCode)->MasterType != 2)
		{
			GetCodeLineStruct((temppCodeLine->PUnSyntaxCode)->MasterLineNo, &temppCodeLine, &temppFunc);
			if ((temppCodeLine->PSyntaxCode)->SyntaxKeyType != SyntaxKey::SyntaxKey_unknownType)
			{
				pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
			}
			GetCodeLineStruct((temppCodeLine->PSyntaxCode)->FirstContentLineNo, &temppCodeLine1, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine1;
			GetCodeLineStruct((temppCodeLine->PSyntaxCode)->FinalContentLineNo, &temppCodeLine1, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine1;
		}

		return 1;
	}

	//���������ֵ��δ�ܵ�����������ֱ�Ӹı���ߺ�������ֱֵ�Ӹı���ô�������ҵ��������յ㣨�ñ�����ֵ�����Ǵ��뵽�����У�Ȼ���ں������ڲ������˸ı䣬��������ͱȽ��Ѵ����ˣ���ԭ���ĶԱ���ֵ���ݹ�����ȡ�ĺ����Ὣ�����Ķ���Ҳ��ȡ����
	int GetVarValueSpreadChainFinalNode(PVariable pTarget, int CodeLineNo, PSourceLine* pReturn, int* ReturnCodeLineNum)
	{
		int tempCodeLineNo;
		int bReturnVar = 0;                            // == 0 :��ʾ���߶��ı��˱�����ֵ; == -1 ��������������ֵ�ı��˱�����ֵ; == -2 �������궨��ı��˱�����ֵ; == -3 ��������ֵ���궨��ı��˱�����ֵ; == 1 ֻ�б����ı��˱�����ֵ; == 2 ֻ�к�������ֵ�ı��˱�����ֵ; == 3 ֻ�к궨��ı��˱�����ֵ;
		int tempReturnVarNum;
		int tempReturnFunctionCallNum;
		int tempReturnFunctionArrayNum;
		int tempReturnMacroNum;
		int tempInt = 0;
		int tempInt2 = -1;
		bool bVarNoDef = false;
		PStoreFunctionDefInfo temppFunctionCall[5];
		PStoreFunctionDefInfo temppFunctionArray[20];
		PStoreVarDefInfo temppReturnVar[5];
		PStoreMacroDefInfo temppReturnMacro[5];
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;

		GetVarChangeByOtherVarOrFunctionCallNew(pTarget, &tempReturnVarNum, temppReturnVar, &tempReturnFunctionCallNum, temppFunctionCall, temppFunctionArray, &tempReturnFunctionArrayNum, &tempReturnMacroNum, temppReturnMacro, CodeLineNo);
		if (tempReturnVarNum > 0)
		{
			if (tempReturnFunctionCallNum > 0)
			{
				if (tempReturnMacroNum > 0)
				{
					//�������ı����ֵ�ĵط����бȽ�
					if ((temppReturnVar[0])->ChangGlobalLineNo > (temppFunctionCall[0])->FunctionCallGlobalLineNo)
					{
						if ((temppReturnVar[0])->ChangGlobalLineNo > (temppReturnMacro[0])->ChangeGlobalLineNo)
						{
							bReturnVar = 1;
							tempCodeLineNo = (temppReturnVar[0])->ChangGlobalLineNo;
						}
						else
						{
							if ((temppReturnVar[0])->ChangGlobalLineNo == (temppReturnMacro[0])->ChangeGlobalLineNo)
							{
								bReturnVar = -2;
							}
							else
							{
								bReturnVar = 3;
							}
							tempCodeLineNo = (temppReturnMacro[0])->ChangeGlobalLineNo;
						}
					}
					else
					{
						if ((temppReturnVar[0])->ChangGlobalLineNo == (temppFunctionCall[0])->FunctionCallGlobalLineNo)
						{
							if ((temppFunctionCall[0])->FunctionCallGlobalLineNo > (temppReturnMacro[0])->ChangeGlobalLineNo)
							{
								bReturnVar = -1;
								tempCodeLineNo = (temppFunctionCall[0])->FunctionCallGlobalLineNo;
							}
							else
							{
								if ((temppFunctionCall[0])->FunctionCallGlobalLineNo == (temppReturnMacro[0])->ChangeGlobalLineNo)
								{
									bReturnVar = 0;
								}
								else
								{
									bReturnVar = 3;
								}
								tempCodeLineNo = (temppReturnMacro[0])->ChangeGlobalLineNo;
							}
						}
						else
						{
							if ((temppFunctionCall[0])->FunctionCallGlobalLineNo > (temppReturnMacro[0])->ChangeGlobalLineNo)
							{
								bReturnVar = 2;
								tempCodeLineNo = (temppFunctionCall[0])->FunctionCallGlobalLineNo;
							}
							else
							{
								if ((temppFunctionCall[0])->FunctionCallGlobalLineNo == (temppReturnMacro[0])->ChangeGlobalLineNo)
								{
									bReturnVar = -3;
								}
								else
								{
									bReturnVar = 3;
								}
								tempCodeLineNo = (temppReturnMacro[0])->ChangeGlobalLineNo;
							}
						}
					}
				}
				else
				{
					//�ӱ�������������ֵ�ı����ֵ�ĵط����бȽ�
					if ((temppReturnVar[0])->ChangGlobalLineNo > (temppFunctionCall[0])->FunctionCallGlobalLineNo)
					{
						bReturnVar = 1;
						tempCodeLineNo = (temppReturnVar[0])->ChangGlobalLineNo;
					}
					else
					{
						if ((temppReturnVar[0])->ChangGlobalLineNo == (temppFunctionCall[0])->FunctionCallGlobalLineNo)
						{
							bReturnVar = -1;
						}
						else
						{
							bReturnVar = 2;
						}
						tempCodeLineNo = (temppFunctionCall[0])->FunctionCallGlobalLineNo;
					}
				}
			}
			else
			{
				//�ӱ������궨��ı����ֵ�ĵط����бȽ�
				if (tempReturnMacroNum > 0)
				{
					if ((temppReturnVar[0])->ChangGlobalLineNo > (temppReturnMacro[0])->ChangeGlobalLineNo)
					{
						bReturnVar = 1;
						tempCodeLineNo = (temppReturnVar[0])->ChangGlobalLineNo;
					}
					else
					{
						if ((temppReturnVar[0])->ChangGlobalLineNo == (temppReturnMacro[0])->ChangeGlobalLineNo)
						{
							bReturnVar = -2;
						}
						else
						{
							bReturnVar = 3;
						}
						tempCodeLineNo = (temppReturnMacro[0])->ChangeGlobalLineNo;
					}
				}
				else
				{
					bReturnVar = 1;
					tempCodeLineNo = (temppReturnVar[0])->ChangGlobalLineNo;
				}
			}
		}
		else
		{
			if (tempReturnFunctionCallNum > 0)
			{
				if (tempReturnMacroNum > 0)
				{
					if ((temppFunctionCall[0])->FunctionCallGlobalLineNo > (temppReturnMacro[0])->ChangeGlobalLineNo)
					{
						bReturnVar = 2;
						tempCodeLineNo = (temppFunctionCall[0])->FunctionCallGlobalLineNo;
					}
					else
					{
						if ((temppFunctionCall[0])->FunctionCallGlobalLineNo == (temppReturnMacro[0])->ChangeGlobalLineNo)
						{
							bReturnVar = -3;
						}
						else
						{
							bReturnVar = 3;
						}
						tempCodeLineNo = (temppReturnMacro[0])->ChangeGlobalLineNo;
					}
				}
				else
				{
					bReturnVar = 2;
					tempCodeLineNo = (temppFunctionCall[0])->FunctionCallGlobalLineNo;
				}
			}
			else
			{
				if (tempReturnMacroNum > 0)
				{
					bReturnVar = 3;
					tempCodeLineNo = (temppReturnMacro[0])->ChangeGlobalLineNo;
				}
				else
				{
					return 0;
				}
			}
		}

		switch (bReturnVar)
		{
		case -3:
		{
			//����Ͳ����û�����ĺ����������⴦����
			GetCodeLineStruct(tempCodeLineNo, &temppCodeLine, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;

			//fix up at 23.3.15
			for (int i = 0; i < tempReturnMacroNum; i++)
			{
				if ((temppReturnMacro[i])->ChangeGlobalLineNo <= CodeLineNo)
				{
					if ((temppReturnMacro[i])->ChangeGlobalLineNo > tempInt)
					{
						tempInt2 = i;
					}
				}
			}
			GetCodeLineStruct(tempInt2, &temppCodeLine, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
			break;
		}
		case -2:
		{
			GetCodeLineStruct(tempCodeLineNo, &temppCodeLine, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
			for (int i = 0; i < tempReturnVarNum; i++)
			{
				if ((temppReturnVar[i])->pVarDef != NULL)
				{
					GetVarValueSpreadChainFinalNode((temppReturnVar[i])->pVarDef, (temppReturnVar[i])->ChangGlobalLineNo, pReturn, ReturnCodeLineNum);
				}
			}

			//fix up at 23.3.15
			for (int i = 0; i < tempReturnMacroNum; i++)
			{
				if ((temppReturnMacro[i])->ChangeGlobalLineNo <= CodeLineNo)
				{
					if ((temppReturnMacro[i])->ChangeGlobalLineNo > tempInt)
					{
						tempInt2 = i;
					}
				}
			}
			GetCodeLineStruct(tempInt2, &temppCodeLine, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
			break;
		}
		case -1:
		{
			GetCodeLineStruct(tempCodeLineNo, &temppCodeLine, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
			for (int i = 0; i < tempReturnVarNum; i++)
			{
				if ((temppReturnVar[i])->pVarDef != NULL)
				{
					GetVarValueSpreadChainFinalNode((temppReturnVar[i])->pVarDef, (temppReturnVar[i])->ChangGlobalLineNo, pReturn, ReturnCodeLineNum);
				}
			}

			break;
		}
		case 0:
		{
			//����Ͳ����û�����ĺ����������⴦����
			GetCodeLineStruct(tempCodeLineNo, &temppCodeLine, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
			for (int i = 0; i < tempReturnVarNum; i++)
			{
				if ((temppReturnVar[i])->pVarDef != NULL)
				{
					GetVarValueSpreadChainFinalNode((temppReturnVar[i])->pVarDef, (temppReturnVar[i])->ChangGlobalLineNo, pReturn, ReturnCodeLineNum);
				}
			}

			//fix up at 23.3.15
			for (int i = 0; i < tempReturnMacroNum; i++)
			{
				if ((temppReturnMacro[i])->ChangeGlobalLineNo <= CodeLineNo)
				{
					if ((temppReturnMacro[i])->ChangeGlobalLineNo > tempInt)
					{
						tempInt2 = i;
					}
				}
			}
			GetCodeLineStruct(tempInt2, &temppCodeLine, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
			break;
		}
		case 1:
		{
			for (int i = 0; i < tempReturnVarNum; i++)
			{
				if ((temppReturnVar[i])->pVarDef == NULL)
				{
					bVarNoDef = true;
				}
			}
			if (bVarNoDef)
			{
				GetCodeLineStruct(tempCodeLineNo, &temppCodeLine, &temppFunc);
				pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
			}
			for (int i = 0; i < tempReturnVarNum; i++)
			{
				if ((temppReturnVar[i])->pVarDef != NULL)
				{
					GetVarValueSpreadChainFinalNode((temppReturnVar[i])->pVarDef, (temppReturnVar[i])->ChangGlobalLineNo, pReturn, ReturnCodeLineNum);
				}
			}
			break;
		}
		case 2:
		case 3:
		{
			//����Ͳ����û�����ĺ����������⴦����
			GetCodeLineStruct(tempCodeLineNo, &temppCodeLine, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;

			//updata at 23.1.6
			for (int i = 0; i < tempReturnMacroNum; i++)
			{
				if ((temppReturnMacro[i])->ChangeGlobalLineNo <= CodeLineNo)
				{
					if ((temppReturnMacro[i])->ChangeGlobalLineNo > tempInt)
					{
						tempInt2 = i;
					}
				}
			}
			GetCodeLineStruct(tempInt2, &temppCodeLine, &temppFunc);
			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;

			break;
		}
		default:
			break;
		}
		//if (bReturnVar == -1)
		//{
		//	//����Ͳ����û�����ĺ����������⴦����
		//	GetCodeLineStruct(tempCodeLineNo, &temppCodeLine, &temppFunc);
		//	pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
		//}
		//else
		//{
		//	if (bReturnVar == 0)
		//	{
		//		//����Ͳ����û�����ĺ����������⴦����
		//		GetCodeLineStruct(tempCodeLineNo, &temppCodeLine, &temppFunc);
		//		pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
		//	}
		//	for (int i = 0; i < tempReturnVarNum; i++)
		//	{
		//		if ((temppReturnVar[i])->pVarDef == NULL)
		//		{
		//			bVarNoDef = true;
		//		}
		//	}
		//	if (bVarNoDef)
		//	{
		//		if (bReturnVar != 0)
		//		{
		//			GetCodeLineStruct(tempCodeLineNo, &temppCodeLine, &temppFunc);
		//			pReturn[(*ReturnCodeLineNum)++] = temppCodeLine;
		//		}
		//	}
		//	for (int i = 0; i < tempReturnVarNum; i++)
		//	{
		//		if ((temppReturnVar[i])->pVarDef != NULL)
		//		{
		//			GetVarValueSpreadChainFinalNode((temppReturnVar[i])->pVarDef, (temppReturnVar[i])->ChangGlobalLineNo, pReturn, ReturnCodeLineNum);
		//		}
		//	}
		//}

		return 1;
	}

	int GetBackAPIOneParNew(char* target, PInterMediateParInfo pPar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeExeBlock, bool bIsPar)
	{
		PVariable temppVar;
		PMacro temppMacro;
		char** temppSubCode;
		int tempInt;
		int tempReturnVarNameNum;
		PStoreVarNameInfo temppReturnVarName[5];

		for (int i = 0; i < 5; i++)
		{
			temppReturnVarName[i] = new StoreVarNameInfo;
		}
		temppSubCode = new char*;
		*temppSubCode = target;

		//�������д�����Ϊ����ȡ���ж༶���ƽṹ�ı���׼���ģ�������δ��ʹ�ã�ֻ��д���⹩֮��ʹ�� 22.9.28                          �Ѿ�ʹ�� 22.10.4
		tempInt = 0;
		ProcessVar((void**)temppSubCode, &tempInt, temppReturnVarName, &tempReturnVarNameNum);
		for (int i = 0; i < tempReturnVarNameNum; i++)
		{
			if (CheckVarExist((temppReturnVarName[i])->VarMainName, pCodeExeBlock->pFunc, &temppVar) == 1)                             //if (CheckVarExist(target, pCodeExeBlock->pFunc, &temppVar) == 1)
			{
				//���ӶԱ������͵��жϣ��ж����Ƿ�Ϊ�û��Զ���ı������ͣ�������ҳ��û��Զ���ı������Ͷ������ڵĴ�����         22.9.30
				AddUserDefVarTypeInfoInCodeExePathBlock(temppVar, pCodeExeBlock);

				switch (pPar->ParType)
				{
				case -1:
				{
					GetBackAPIInTypeOnePar(pCodeExeBlock->pFunc, temppVar, pVarArray, pCodeExeBlock, bIsPar, CodeLineNo);
					break;
				}
				case 0:
				{
					GetBackAPIINAndOUTTypeOnePar(pCodeExeBlock->pFunc, temppVar, pVarArray, pCodeExeBlock, bIsPar, CodeLineNo);
					break;
				}
				case 1:
				{
					GetBackAPIOUTTypeOnePar(pCodeExeBlock->pFunc, temppVar, pVarArray, pCodeExeBlock, bIsPar, CodeLineNo);
					break;
				}
				default:
				{
					break;
				}
				}
			}
			else if (CheckMacroExist((temppReturnVarName[i])->VarMainName, pCodeExeBlock->pFunc, &temppMacro) == 1)                     //else if (CheckMacroExist(target, pCodeExeBlock->pFunc, &temppMacro) == 1)
			{
				//�����µĴ�����������Ϊ�궨�����������궨��Ķ����кż�¼��pCodeBlock�е�Path�ֶ���
				pCodeExeBlock->Path[(pCodeExeBlock->PathLength)++] = temppMacro->DefCodeLineGlobalNo;
			}
			else
			{
#ifdef _DEBUG
				std::cout << "Get Back API One Par New Fail " << target << std::endl;
#endif
				return 0;
			}
		}

		delete temppSubCode;
		for (int i = 0; i < 5; i++)
		{
			delete temppReturnVarName[i];
		}

		return 1;
	}
	
	int GetBackAPINew(char* target, int* ParNum, char** pPar, PInterMediateFunctionInfo pFuncInfo, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreSensitiveAPIInfo pSSAPIInfo)
	{
		PCodeExePathBlock temppCodeBlock;

		for (int i = 0; i < pFuncInfo->FunctionParNum; i++)
		{
			//����������Ӹ���ϸ�ĸ��ݱ��������ͽ���һϵ�еĲ�����Ŀǰ�ʹֲڵĲ�����,�˴���ֱ�Ӷ���һ�е�Init��������дtrue�ˣ���Ϊ�������Ƭ��Ŀǰ����Ѱ�Һ�������ֵӰ��ı��������Ծ�ֻѰ�Һ�������������
			InitCodeExePathBlock(pSSAPIInfo, pSSAPIInfo->pFunc, &temppCodeBlock, pSSAPIInfo->PathTraceDeepth, pSSAPIInfo->VarDefByOtherVarNum, pSSAPIInfo->VarChangeNum, pSSAPIInfo->FunctionCallNum, pSSAPIInfo->MacroChangeNum, pSSAPIInfo->VarDefByOtherMacroNum, i, true);
			GetBackAPIOneParNew(pPar[i], &(pFuncInfo->pPar[i]), ArrayLenth, pVarArray, CodeLineNo, (pSSAPIInfo->pCodePathBlock)[i], true);
		}

		return 1;
	}

	///////////////////////////////////////////////////////////////////////

	int RemoveStringEndBlank(char* target)
	{
		int tempCodeLength;

		tempCodeLength = strlen(target);
		while (target[tempCodeLength - 1] == ' ')
		{
			tempCodeLength--;
		}
		target[tempCodeLength] = 0x0;

		return tempCodeLength;
	}

	//�Ը�ֵ�����и�ʽ������
	int ProcessExpression(char* target)
	{
		int tempSubCodeLength;
		bool bPro = false;
		char** temppSubCode;
		int tempReturnSubCodeLength;
		ReturnType tempReturnType;
		PUserDefStruct temppUserDefStruct;

		temppSubCode = new char*;
		*temppSubCode = target;

		//�����Ϊ�˴����������= (char *)ALLOCA(50*sizeof(char));��char *�м��пո���ȥ��
		RemoveStringFrontBlank(target);
		tempSubCodeLength = strlen(target);
		for (int i = 0; i < tempSubCodeLength; i++)
		{
			if (target[i] == '(')
			{
				if (CheckNamableCharacter(&(target[i + 1])) == 1)
				{
					i++;
					tempReturnSubCodeLength = CheckReturnType((void**)temppSubCode, &i, &tempReturnType, &temppUserDefStruct);
					if (tempReturnType != ReturnType::ReturnType_unknownType)
					{
						i += tempReturnSubCodeLength;
						while (target[i] != ')')
						{
							if (target[i] == ' ')
							{
								RemoveStringFrontBlank(&(target[i]));
							}
							i++;
						}
					}
				}
			}
		}

		return 1;
	}

	int GetStoreMacroDefInfoChainFrontNode(PStoreMacroDefInfo Target, PStoreMacroDefInfo Start, PStoreMacroDefInfo* Return)
	{
		int tempIndex = 1;
		PStoreMacroDefInfo tempp;
		tempp = Start;

		if (Target == tempp)
		{
			return 0;
		}

		while (true)
		{
			if (tempp->pNext == Target)
			{
				*Return = tempp;
				break;
			}
			tempIndex++;
			tempp = tempp->pNext;
		}

		return tempIndex;
	}

	int GetVarChangeByOtherMacro(PVariable target, PMacro* pMacroArray, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeBlock)
	{
		int tempIndex;
		PStoreMacroDefInfo temppMacroDefInfo;

		if (target->bChangeByOthersMacro)
		{
			temppMacroDefInfo = target->pChangeOtherMacro;

			if (temppMacroDefInfo->ChangeGlobalLineNo > CodeLineNo)
			{
				//�о���Ӧ���������������Ķ�����صĴ�������ȡ����Ƭ�У��������Ӧ����ר����ȡ�����������صĴ����к������еģ��е㹦�������
				GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(target, pVarArray, pCodeBlock);
				return 1;
			}

			for (int i = 0; i < target->ChangeByOthersMacroNum; i++)
			{
				if (temppMacroDefInfo->pNext == NULL)
				{

				}
				else
				{
					if ((temppMacroDefInfo->pNext)->ChangeGlobalLineNo > CodeLineNo)
					{
						break;
					}
					temppMacroDefInfo = temppMacroDefInfo->pNext;
				}
			}
			pMacroArray[(pCodeBlock->BlockRealMacroChangeNum)++] = temppMacroDefInfo->pMacroDef;
			(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppMacroDefInfo->ChangeGlobalLineNo;

			//�¼��д��벻���ܸı����ֵ�ĺ궨�������г��֣��������ڸı����ֵ�ı��������г��֣��������Ҹı����ֵ�ı�������������ʹ��
			/*if (temppStoreVarDefInfo->pVarDef == NULL)
			{
				return 1;
			}

			GetVarChangeByOtherVar(temppStoreVarDefInfo->pVarDef, pVarArray, temppStoreVarDefInfo->ChangGlobalLineNo, pCodeBlock);*/
		}
		else
		{
			//�о���Ӧ���������������Ķ�����صĴ�������ȡ����Ƭ�У��������Ӧ����ר����ȡ�����������صĴ����к������еģ��е㹦�������
			GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(target, pVarArray, pCodeBlock);
		}

		return 1;
	}

	//�������������ַ����б������ķֽ⣬Ŀǰֻ�ܴ��� . (��������)�� -> (ָ����������)��Ŀǰ�����������֧�ֶ༶ָ�������ж��������Ƶı�����Ŀǰֻ֧����������,���Խ�����ʽ�����������͵ı�����ʾ��&XXX�����ַֽ����ʵ�ı�����(���������ǿ������ַ��ȼ����Ƿ��Ƕ༶�����õ��ķ��ţ������������ֽ�Ϊ���������),��������Ὣ�ǿ������ַ�������
	int ProcessVar(void** Code, int* index, PStoreVarNameInfo* ReturnNameArray, int* ReturnNameArrayLength)
	{
		int tempIndex = 0;
		int CodeLength;
		char SubCode[100];
		int SubCodeLength = 0;
		int NameType = 0;

		*ReturnNameArrayLength = 0;
		CodeLength = strlen(*(char**)Code);
		//����Ŀǰ��֧�ֶ������֣�xxx.xxx / xxx->xxx���������CodeֻΪ����������ʽ,���������㷨�����ն������ֽ������
		strcpy((ReturnNameArray[*ReturnNameArrayLength])->buffer, *(char**)Code);
		for (int i = 0; i < CodeLength; i++)
		{
			if (CheckNamableCharacter((&(*(char**)Code)[*index + i])) == 1)
			{
				SubCode[SubCodeLength++] = (*(char**)Code)[*index + i];
			}
			else
			{
				if ((*(char**)Code)[*index + i] == '.')
				{
					SubCode[SubCodeLength] = 0x0;
					SubCodeLength = 0;
					(ReturnNameArray[(*ReturnNameArrayLength)])->VarType = 1;
					strcpy((ReturnNameArray[*ReturnNameArrayLength])->VarMainName, SubCode);
					(ReturnNameArray[*ReturnNameArrayLength])->MinorNameNum = 0;
					NameType = 1;
				}
				else if ((*(char**)Code)[*index + i] == '-' && (*(char**)Code)[*index + i + 1] == '>')
				{
					SubCode[SubCodeLength] = 0x0;
					SubCodeLength = 0;
					(ReturnNameArray[(*ReturnNameArrayLength)])->VarType = 2;
					strcpy((ReturnNameArray[*ReturnNameArrayLength])->VarMainName, SubCode);
					(ReturnNameArray[*ReturnNameArrayLength])->MinorNameNum = 0;
					NameType = 1;
					i++;
				}
				else
				{
					if (SubCodeLength > 0)
					{
						if (NameType == 0)
						{
							SubCode[SubCodeLength] = 0x0;                                              //update at 22.10.4
							SubCodeLength = 0;
							(ReturnNameArray[(*ReturnNameArrayLength)])->VarType = 0;
							strcpy((ReturnNameArray[*ReturnNameArrayLength])->VarMainName, SubCode);
							(ReturnNameArray[*ReturnNameArrayLength])->MinorNameNum = 0;
							(*ReturnNameArrayLength)++;
							//����Ƿ�'.'��"->"��ʽ�ַ�Ŀǰ�������������ԾͲ�������ֱ�Ӹ��ƻ�ȥ
							//SubCode[SubCodeLength++] = (*(char**)Code)[*index + i];
						}
						else if (NameType == 1)
						{
							SubCode[SubCodeLength] = 0x0;
							SubCodeLength = 0;
							strcpy((ReturnNameArray[*ReturnNameArrayLength])->VarMinorName[((ReturnNameArray[*ReturnNameArrayLength])->MinorNameNum)++], SubCode);
							((ReturnNameArray[*ReturnNameArrayLength])->MinorNameNum)++;
							(*ReturnNameArrayLength)++;
						}
						else
						{
							std::cout << "ProcessVar fail" << std::endl;
						}
					}
				}
			}
		}
		if (SubCodeLength > 0)
		{
			if (NameType == 0)
			{
				SubCode[SubCodeLength] = 0x0;
				(ReturnNameArray[(*ReturnNameArrayLength)])->VarType = 0;
				strcpy((ReturnNameArray[*ReturnNameArrayLength])->VarMainName, SubCode);
				(ReturnNameArray[*ReturnNameArrayLength])->MinorNameNum = 0;
				(*ReturnNameArrayLength)++;
			}
			else if (NameType == 1)
			{
				SubCode[SubCodeLength] = 0x0;
				strcpy((ReturnNameArray[*ReturnNameArrayLength])->VarMinorName[((ReturnNameArray[*ReturnNameArrayLength])->MinorNameNum)++], SubCode);
				(ReturnNameArray[*ReturnNameArrayLength])->MinorNameNum++;
				(*ReturnNameArrayLength)++;
			}
			else
			{
				std::cout << "ProcessVar fail" << std::endl;
			}
		}
		return 1;
	}

	
	//
	int RemoveUnSyntaxKeyCodeLineInSyntaxBlockInfo(PSourceLine* TargetSourceLineArray, int* SourceLineArrayLength)
	{
		int tempIndex;

		for (int i = 0; i < *SourceLineArrayLength; i++)
		{
			if (((TargetSourceLineArray[i])->PSyntaxCode)->SyntaxKeyType == SyntaxKey::SyntaxKey_unknownType)
			{
				for (int z = i; z < *SourceLineArrayLength - 1; z++)
				{
					TargetSourceLineArray[z] = TargetSourceLineArray[z + 1];
				}
				(*SourceLineArrayLength)--;
				i--;
			}
		}

		return 1;
	}

	int EncounterSyntaxKsyAddSyntaxChainInfo(PSourceLine TargetCodeLine, PSourceFunction pFunc)
	{
		PSourceLine temppSourceLine;
		PSourceLine temppSourceLine1;
		PSourceFunction temppSourceFunc;

		if ((TargetCodeLine->PSyntaxCode)->SyntaxKeyType != ifType && (TargetCodeLine->PSyntaxCode)->SyntaxKeyType != forType && (TargetCodeLine->PSyntaxCode)->SyntaxKeyType != switchType && (TargetCodeLine->PSyntaxCode)->SyntaxKeyType != doType)
		{
			//��Ҫ��Ϊ�˷ֱ��жϲ�ͬ��֧������֮ǰ�ķ�֧��ȡ����Ӧ�ò�ͬ����else��֧����case��֧��
			if ((TargetCodeLine->PSyntaxCode)->SyntaxKeyType == caseType || (TargetCodeLine->PSyntaxCode)->SyntaxKeyType == defaultType)                  //add at 22.10.1
			{
				temppSourceLine = (pFunc->CodeLine)[AnalysisCodeLineNo - 1 - pFunc->StartGlobalLineNo];
				//GetCodeLineStruct(AnalysisCodeLineNo - 2, &temppSourceLine, &temppSourceFunc);
			}
			else
			{
				temppSourceLine = (pFunc->CodeLine)[AnalysisCodeLineNo - 2 - pFunc->StartGlobalLineNo];
				//GetCodeLineStruct(AnalysisCodeLineNo - 2, &temppSourceLine, &temppSourceFunc);
			}

			if ((temppSourceLine->PUnSyntaxCode)->MasterType == 1)
			{
				temppSourceLine1 = (pFunc->CodeLine)[(temppSourceLine->PUnSyntaxCode)->MasterLineNo - pFunc->StartGlobalLineNo];

				if ((TargetCodeLine->PSyntaxCode)->SyntaxKeyType == whileType && (temppSourceLine1->PSyntaxCode)->SyntaxKeyType != doType)                   //add at 22.10.1
				{
					//��������� while �﷨��֧����do while����ֱ�ӷ���
					((TargetCodeLine->PSyntaxCode)->SyntaxChainCodeLineArray)[((TargetCodeLine->PSyntaxCode)->SyntaxChainLength)++] = AnalysisCodeLineNo;
					return 1;
				}

				//GetCodeLineStruct((temppSourceLine->PUnSyntaxCode)->MasterLineNo, &temppSourceLine1, &temppSourceFunc);
				for (int i = 0; i < (temppSourceLine1->PSyntaxCode)->SyntaxChainLength; i++)
				{
					((TargetCodeLine->PSyntaxCode)->SyntaxChainCodeLineArray)[i] = ((temppSourceLine1->PSyntaxCode)->SyntaxChainCodeLineArray)[i];
					((TargetCodeLine->PSyntaxCode)->SyntaxChainLength)++;
				}
				AddNewSyntaxKeyCodeLineInSyntaxKeyChainEveryNode((temppSourceLine1->PSyntaxCode)->SyntaxChainCodeLineArray, (temppSourceLine1->PSyntaxCode)->SyntaxChainLength, AnalysisCodeLineNo, pFunc);
			}
		}
		
		((TargetCodeLine->PSyntaxCode)->SyntaxChainCodeLineArray)[((TargetCodeLine->PSyntaxCode)->SyntaxChainLength)++] = AnalysisCodeLineNo;

		return 1;
	}

	int AddNewSyntaxKeyCodeLineInSyntaxKeyChainEveryNode(int* SyntaxKeyChainArray, int SyntaxKeyChainArrayLength, int AddCodeLineNo, PSourceFunction pFunc)
	{
		PSourceLine temppSourceLine;
		PSourceFunction temppSourceFunc;

		for (int i = 0; i < SyntaxKeyChainArrayLength; i++)
		{
			temppSourceLine = (pFunc->CodeLine)[SyntaxKeyChainArray[i] - pFunc->StartGlobalLineNo];
			//GetCodeLineStruct(SyntaxKeyChainArray[i], &temppSourceLine, &temppSourceFunc);
			((temppSourceLine->PSyntaxCode)->SyntaxChainCodeLineArray)[((temppSourceLine->PSyntaxCode)->SyntaxChainLength)++] = AddCodeLineNo;
		}

		return 1;
	}

	int ProcessCodeLineInSyntaxBlockInfo(PSourceLine* TargetSourceLineArray, int* SourceLineArrayLength)
	{
		int tempIndex;

		//RemoveUnSyntaxKeyCodeLineInSyntaxBlockInfo(TargetSourceLineArray, SourceLineArrayLength);                 update at 22.10.4    ��Ϊ���Ǵ�����Ƭ��˼���м����˱�ʾ�﷨(if/for/while...)�����ṹ��'{'��'}',���Բ���Ҫ���з��﷨�ṹ��������
		GetWholeSyntaxChain(TargetSourceLineArray, SourceLineArrayLength);
		GetSyntaxKeyConditionContentVarOrMacroDefInfo(TargetSourceLineArray, SourceLineArrayLength);

		return 1;
	}

	//��ȡ SyntaxChain �������������Ҹ��ݴ����кŵĴ�С��������
	int GetWholeSyntaxChain(PSourceLine* TargetSourceLineArray, int* SourceLineArrayLength)
	{
		int tempSyntaxChainLength = 0;
		int tempSyntaxChain[20];
		PSourceLine temppSourceLine;
		PSourceFunction temppSourceFunc;

		for (int i = 0; i < (*SourceLineArrayLength); i++)
		{
			if (((TargetSourceLineArray[i])->PSyntaxCode)->SyntaxKeyType != SyntaxKey::SyntaxKey_unknownType)                                 // update at 22.10.4
			{
				for (int z = 0; z < ((TargetSourceLineArray[i])->PSyntaxCode)->SyntaxChainLength; z++)
				{
					tempSyntaxChain[tempSyntaxChainLength++] = (((TargetSourceLineArray[i])->PSyntaxCode)->SyntaxChainCodeLineArray)[z];
				}
			}
			else
			{
				tempSyntaxChain[tempSyntaxChainLength++] = (TargetSourceLineArray[i])->GlobalLineNo;
			}
		}
		AdjustIntOrderSTL(tempSyntaxChain, &tempSyntaxChainLength);
		RemoveRepeateIntInIntArray(tempSyntaxChain, &tempSyntaxChainLength);
		for (int i = 0; i < tempSyntaxChainLength; i++)
		{
			GetCodeLineStruct(tempSyntaxChain[i], &temppSourceLine, &temppSourceFunc);
			TargetSourceLineArray[i] = temppSourceLine;
		}
		(*SourceLineArrayLength) = tempSyntaxChainLength;

		return 1;
	}

	int AddUserDefVarTypeInfoInCodeExePathBlock(PVariable pVar, PCodeExePathBlock pCodeExeBlock)
	{
		int tempIndex;

		if (pVar->returnType == ReturnType::UserDefStructType || pVar->returnType == ReturnType::UserDefStructAnotherNameType || pVar->returnType == ReturnType::UserDefStructPointerType)
		{
			for (int i = (pVar->pUserDefStruct)->DefStartGlobalLineNo; i <= (pVar->pUserDefStruct)->DefStopGlobalLineNo; i++)
			{
				(pCodeExeBlock->Path)[(pCodeExeBlock->PathLength)++] = i;
			}
		}

		return 1;
	}

	int GetInCodeVarOrMacroDefCodeLineStruct(void** Code, int* index, PSourceFunction pFunc, PSourceLine* pReturnSourceLineArray, int* ReturnSourceLineArrayLength)
	{
		int tempReturnNameNum;
		int tempNameNum = 0;
		int tempArrayNum = 0;
		int tempArrayIndex[10];
		char** tempppName;
		char** tempppArray;
		PSourceFunction temppSourceFunc;
		PSourceLine temppSourceLine;
		PVariable temppVar;
		PMacro temppMacro;

		tempppName = new char* [5];
		tempppArray = new char* [5];
		for (int i = 0; i < 5; i++)
		{
			tempppName[i] = new char[50];
			tempppArray[i] = new char[50];
		}

		tempReturnNameNum = GetSubCodeName(Code, index, tempppName, &tempNameNum, tempppArray, &tempArrayNum, tempArrayIndex);
		for (int i = 0; i < tempReturnNameNum; i++)
		{
			if (CheckVarExist(tempppName[i], pFunc, &temppVar) == 1)
			{
				GetCodeLineStruct(temppVar->DefCodeLineGlobalNo, &temppSourceLine, &temppSourceFunc);
				pReturnSourceLineArray[(*ReturnSourceLineArrayLength)++] = temppSourceLine;
			}
			if (CheckMacroExist(tempppName[i], pFunc, &temppMacro) == 1)
			{
				GetCodeLineStruct(temppMacro->DefCodeLineGlobalNo, &temppSourceLine, &temppSourceFunc);
				pReturnSourceLineArray[(*ReturnSourceLineArrayLength)++] = temppSourceLine;
			}
		}

		for (int i = 0; i < 5; i++)
		{
			if (strlen(tempppName[i]) != 0)
			{
				delete [] tempppName[i];
			}
			if (strlen(tempppArray[i]) != 0)
			{
				delete [] tempppArray[i];
			}
		}
		delete [] tempppName;
		delete [] tempppArray;

		return 1;
	}

	int GetSyntaxKeyConditionContentVarOrMacroDefInfo(PSourceLine* pSourceLineArray, int* SourceLineArrayLength)
	{
		int tempIndex = 0;
		char** tempppSubCode;
		int tempSourceLineArrayLength = *SourceLineArrayLength;

		tempppSubCode = new char*;

		for (int i = 0; i < tempSourceLineArrayLength; i++)
		{
			if (((pSourceLineArray[i])->PSyntaxCode)->SyntaxKeyType != SyntaxKey::SyntaxKey_unknownType)                              //update at 22.10.4
			{
				tempIndex = 0;
				if (((pSourceLineArray[i])->PSyntaxCode)->bCondition)
				{
					*tempppSubCode = ((pSourceLineArray[i])->PSyntaxCode)->Condition;
					GetInCodeVarOrMacroDefCodeLineStruct((void**)tempppSubCode, &tempIndex, (pSourceCodeFile->Function)[(pSourceLineArray[i])->FunctionNo], pSourceLineArray, SourceLineArrayLength);
				}
			}
		}

		return 1;
	}

	//����������֧��ʮ�ڼ����ת��
	int IntToStrNew(long target, char* StrReturn)
	{
		long tempInt;
		long tempInt1 = target;
		long Multiple = 1000000000;
		long tempIndex = 0;

		if (target >= 10000000000)
		{
			StrReturn[0] = 0x0;
			return 0;
		}
		for (int i = 0; i < 9; i++)
		{
			tempInt = tempInt1 / Multiple;
			tempInt1 = tempInt1 % Multiple;
			Multiple /= 10;
			if (tempInt == 0)
			{
				if (tempIndex != 0)
				{
					StrReturn[tempIndex++] = tempInt + 48;
				}
			}
			else
			{
				StrReturn[tempIndex++] = tempInt + 48;
			}
		}
		StrReturn[tempIndex++] = tempInt1 + 48;
		StrReturn[tempIndex] = 0x0;

		return 1;
	}

	int AddTypedefUnion(void** Code, int* index)
	{
		int tempIndex = 0;
		char tempSubCode[150];
		char* temppSubCode;
		char tempCode[20];
		int tempReturnLength = 0;
		int temp = 0;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempInt = 0;
		int tempArrayNum = 0;
		int NameNum = 0;
		int tempNameNum = 0;
		int tempContantNo = 0;
		char** Name;
		char* tempArray[20];
		int* tempArrayIndex;
		ProfixType tempProfixType;
		ReturnType tempReturnType;
		PUserDefStruct temppUserDefStruct;

		tempArrayIndex = new int[20];
		for (int i = 0; i < 20; i++)
		{
			tempArray[i] = new char[50];
		}
		Name = new char* [10];
		for (int i = 0; i < 10; i++)
		{
			Name[i] = new char[80];
		}

		temppSubCode = tempSubCode;
		memset(tempSubCode, 0x0, 150);
		tempReturnLength = DivisionCodeByLineFeed(Code, index, tempSubCode);

		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->ContentNum = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->AnotherNameNum = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->PointerNameNum = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->WriteContantNo = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->ReadContantNo = 0;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->bUserDefStruct = false;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->bUserDefUnion = true;
		((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->DefStartGlobalLineNo = AnalysisCodeLineNo;

		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::UnionDefType;
		strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, tempSubCode);
		pSourceCodeFile->SourceCodeLineNum++;
		pSourceCodeFile->WriteSourceCodeLineNo++;

		AnalysisCodeLineNo++;
		*index = *index + tempReturnLength + 2;
		tempReturnLength = DivisionCodeByLineFeed(Code, index, tempSubCode);
		if (tempSubCode[0] == '{')                                           //�����д��û�п���ͨ���ԣ��̶�����Ϊtypedef union\r\n{\r\n xxx ����ʽ����
		{
			((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
			((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
			((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::UnionDefType;
			strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, tempSubCode);
			pSourceCodeFile->SourceCodeLineNum++;
			pSourceCodeFile->WriteSourceCodeLineNo++;

			tempLBraceNum++;
			AnalysisCodeLineNo++;
			*index = *index + tempReturnLength + 2;
			while (tempLBraceNum != tempRBraceNum)
			{
				tempInt = 0;
				MoveCodeIndexUntillNoBlank(Code, index);
				tempReturnLength = DivisionCodeByLineFeed(Code, index, tempSubCode);
				if (tempSubCode[0] == '{')                 //����û������ô��ͨ���Ե������˽�����xxx\r\n{\r\nxxx\r\n} xxx\r\n����ʽ��
				{
					tempLBraceNum++;
				}
				else if (tempSubCode[0] == '}')
				{
					tempRBraceNum++;
					tempIndex = 1;
					GetUserDefUnionName((void**)(&temppSubCode), &tempIndex, ((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo]));
				}
				else
				{
					tempIndex = 0;
					temp = CheckProfixType((void**)(&temppSubCode), &tempIndex, &tempProfixType);
					if (tempProfixType != ProfixType::ProfixType_unknownType)
					{
						tempIndex += temp;
						MoveCodeIndexUntillNoBlank((void**)(&temppSubCode), &tempIndex);
					}

					temp = CheckReturnType((void**)(&temppSubCode), &tempIndex, &tempReturnType, &temppUserDefStruct);
					if (tempReturnType != ReturnType::ReturnType_unknownType)
					{
						tempIndex += temp;
						MoveCodeIndexUntillNoBlank((void**)(&temppSubCode), &tempIndex);
					}
					tempArrayNum = 0;
					NameNum = 0;
					tempArrayNum = 0;
					tempNameNum = GetSubCodeName((void**)(&temppSubCode), &tempIndex, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
					for (int i = 0; i < tempNameNum; i++)
					{
						tempContantNo = ((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->WriteContantNo;
						((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).DefCodeLineGlobalNo = AnalysisCodeLineNo;
						((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).ReturnType = tempReturnType;
						strcpy(((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).Name, Name[i]);
						((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).UserDefStructNo = pSourceCodeFile->WriteUserDefStructNo;
						((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).ProfixType = tempProfixType;
						if (tempArrayNum > 0)
						{
							if ((i + tempInt) == tempArrayIndex[tempInt])
							{
								((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).bArray = true;
								((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).bPointerType = true;
								temp = 0;
								((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).PointerPointMemSize = CalculateIntExpression((void**)(&(tempArray[tempInt])), &temp, NULL) * GetReturnTypeSize(tempReturnType);           //��������Ƕ��û��Զ���ı������Ͷ���Ľ��������漰��������ĸ������У����Բ����ں����ṹָ�루�п���֮���Զ�����ĳ�������е��û��Զ���������ͽ��н�������ʱ���ٽ��о���ķ�����
								strcpy(((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).Array, tempArray[tempInt]);
								tempInt++;
								tempArrayNum--;
							}
						}
						if (tempReturnType == ReturnType::UserDefStructType || tempReturnType == ReturnType::UserDefStructAnotherNameType || tempReturnType == ReturnType::UserDefStructPointerType)
						{
							((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).bUserDefStruct = true;
							((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).pUserDefStruct = temppUserDefStruct;
						}
						else
						{
							((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).bUserDefStruct = false;
							((((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->Content)[tempContantNo]).pUserDefStruct = NULL;
						}
						//��һ�еĺ�������Ӧ������Ϊ���鶨��ʱ���������������ʱ���õģ�����������ж�tempArrayNum���Ƿ������鶨���йأ�����й�Ӧ�ý���һ�д����ƶ���if��֧��
						//��һ�еĺ��������ڼ���û�����Ľṹ������ʱע�͵��ˣ����������˵�ɣ�һ������û�����Ľṹ����Ҫ��������ģ������С�����ܻ��漰�궨��
						//CheckVarDefByOtherVarStatus(&(tempArray[tempInt]), (pFunction->Variable)[pFunction->WriteVariableNo], pFunction);
						((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->ContentNum++;
						((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->WriteContantNo++;
					}
				}
				((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
				((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
				((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::UnionDefType;
				strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, tempSubCode);
				pSourceCodeFile->SourceCodeLineNum++;
				pSourceCodeFile->WriteSourceCodeLineNo++;

				AnalysisCodeLineNo++;
				*index = *index + tempReturnLength + 2;
			}
			((pSourceCodeFile->UserDefStruct)[pSourceCodeFile->WriteUserDefStructNo])->DefStopGlobalLineNo = AnalysisCodeLineNo - 1;
			pSourceCodeFile->WriteUserDefStructNo++;
			pSourceCodeFile->UserDefStructNum++;
		}
		else
		{
			std::cout << "AddTypedefUnion error" << std::endl;
			return 0;
		}

		for (int i = 0; i < 10; i++)
		{
			if (strlen(Name[i]) != 0)
			{
				delete [] Name[i];
			}
		}
		delete [] Name;
		for (int i = 0; i < 20; i++)
		{
			if (strlen(tempArray[i]) != 0)
			{
				delete[]tempArray[i];
			}
		}
		delete [] tempArrayIndex;

		return 1;
	}

	int GetUserDefUnionName(void** Code, int* index, PUserDefStruct pUserDefStruct)
	{
		int tempIndex = 0;
		char tempName[100];
		int tempNameIndex = 0;

		///////////////////////////////////////////////////////////////
		//Ŀǰ�ú���ֻ��ʵ�̶ֹ���ʽ��typedef union���͵Ķ��壬���ʺ�������ʽ��typedef union���Ͷ��壨�ؼ���Ҳ���˽�typedef union�Ķ���Ҫ�󣩣�
		// �����������ָ�ʽ������bug��ô�ٽ�����ϸ�ľ����������ʱ���ٽ���bug�޸�
		//Ŀǰ֧�ֵ�typedef union���͵Ķ����ʽΪ�� typedef union\r\n {\r\n xxx ...\r\n} UnionName;\r\n����ʽ
		//////////////////////////////////////////////////////////////

		tempIndex = *index;
		while ((*(char**)Code)[tempIndex] != 0x0)
		{
			MoveCodeIndexUntillNoBlank(Code, &tempIndex);
			if ((*(char**)Code)[tempIndex] == ';')
			{
				tempName[tempNameIndex] = 0x0;
				strcpy(pUserDefStruct->Name, tempName);
				tempNameIndex = 0;
				tempIndex++;
				continue;
			}
			if (CheckNamableCharacter(&(*(char**)Code)[tempIndex]))
			{
				tempName[tempNameIndex++] = (*(char**)Code)[tempIndex++];
			}
		}

		return 1;
	}

	int CheckSourceFileType(const char* FilePath, LanguageType* pReturnLanguageType)
	{
		int tempIndex = 0;
		char tempSubCode[30];

		memset(tempSubCode, 0x0, 30);
		while (FilePath[tempIndex] != '.')
			tempIndex++;
		tempIndex++;
		strcpy(tempSubCode, &(FilePath[tempIndex]));

		//����û�ж��ļ���׺�Ĵ�Сд����ͳһ����֮��Ĳ��������Ǽ��ȫСд��ȫ��д�������������ֲ���Сд���߲��ִ�д���ļ���׺�������ˣ�
		if (strcmp(tempSubCode, "c") == 0 || strcmp(tempSubCode, "C") == 0)
		{
			*pReturnLanguageType = LanguageType::CLanguageType;
		}
		if (strcmp(tempSubCode, "cpp") == 0 || strcmp(tempSubCode, "CPP") == 0)
		{
			*pReturnLanguageType = LanguageType::CPlusPlusLanguageType;
		}

		return 1;
	}

	int InitSourceFileLanguageCharacterInfo(PSourceCodeFile pSourceCodeFile, LanguageType SourceFileLanguageType)
	{
		int tempIndex;

		(pSourceCodeFile->pStoreLanguageCharacterInfo)->FileLanguageType = SourceFileLanguageType;

		switch (SourceFileLanguageType)
		{
		case LanguageType_UnknownType:
		{
			std::cout << "Source File Language Type error" << std::endl;
			break;
		}
		case CLanguageType:
		{
			(pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater = NULL;
			break;
		}
		case CPlusPlusLanguageType:
		{
			(pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater = new StoreCPlusPlusLanguageCharacter;
			InitStoreCPlusPlusLanguageCharacter((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater);
			break;
		}
		default:
			break;
		}

		return 1;
	}

	int InitVariable(PVariable pVar)
	{
		int tempIndex = 0;

		pVar->returnType = ReturnType::ReturnType_unknownType;
		pVar->profixType = ProfixType::ProfixType_unknownType;
		pVar->bGlobal = false;
		pVar->bDefByOthersMacro = false;
		pVar->bChangeByOthersMacro = false;
		pVar->bDefByOthersVar = false;
		pVar->bChangVar = false;
		pVar->bChangeOtherVar = false;
		pVar->bIsFunctionCallPar = false;
		pVar->bFunctionCallReturn = false;
		pVar->bUserDefStruct = false;
		pVar->bUserDefStructContent = false;
		pVar->bInSyntaxBlock = false;
		pVar->bPointerType = false;
		pVar->PointerPointMemSize = 0;
		pVar->DefCodeLineGlobalNo = -1;
		pVar->DefByOthersVarNum = 0;
		pVar->ChangeVarNum = 0;
		pVar->ChangeOtherVarNum = 0;
		pVar->IsFunctionCallParNum = 0;
		pVar->FunctionCallReturnNum = 0;
		pVar->ContentNum = 0;
		pVar->DefByOthersMacroNum = 0;
		pVar->ChangeByOthersMacroNum = 0;
		pVar->pChangeOtherVar = NULL;
		pVar->pDefOthersVar = NULL;
		pVar->pChangVar = NULL;
		pVar->pFunctionCallPar = NULL;
		pVar->pFunctionCallReturn = NULL;
		pVar->pDefOthersMacro = NULL;
		pVar->pChangeOtherMacro = NULL;
		pVar->bArrayIndex = false;
		pVar->AsArrayIndexNum = 0;
		pVar->pStoreAsArrayIndexInfo = NULL;

		pVar->pParent = NULL;

		for (int i = 0; i < 10; i++)
		{
			(pVar->pContent)[i] = NULL;
		}

		pVar->pUserDefStruct = NULL;
		pVar->CodeLineNum = 0;
		pVar->SyntaxCodeLineNum = 0;
		pVar->SyntaxCodeLineNoArray = NULL;
		pVar->bArray = false;
		pVar->Array = new char[100];
		pVar->bParameter = false;
		pVar->ParNo = -1;
		pVar->bFunctionCall = false;
		pVar->FunctionNo = -1;
		pVar->CodeLineNo = -1;
		pVar->VariableNo = -1;

		return 1;
	}

	int InitSourceCodeLine(PSourceLine pSourceLine)
	{
		int tempIndex = 0;

		pSourceLine->CodeType = CodeLineType::CodeLineType_unknownType;
		pSourceLine->PSyntaxCode = new SyntaxCodeLine;
		InitSyntaxCodeLine(pSourceLine->PSyntaxCode);
		pSourceLine->PUnSyntaxCode = new UnSyntaxSourceLine;
		InitUnSyntaxSourceLine(pSourceLine->PUnSyntaxCode);
		pSourceLine->PMiddleCode = new MiddleSourcceLine;
		
		for (int i = 0; i < 20; i++)
		{
			(pSourceLine->Variable)[i] = new Variable;
			InitVariable((pSourceLine->Variable)[i]);
		}

		pSourceLine->WriteBufferNo = 0;
		pSourceLine->ReadBufferNo = 0;
		pSourceLine->VariableNum = 0;
		pSourceLine->WriteVariableNo = 0;
		pSourceLine->ReadVariableNo = 0;
		pSourceLine->SubCodeNum = 0;
		pSourceLine->Syntax = -1;
		pSourceLine->FunctionNo = -1;
		pSourceLine->CodeLineNo = -1;
		pSourceLine->GlobalLineNo = -1;
		pSourceLine->LocalLineNo = -1;

		return 1;
	}

	int InitSourceFunction(PSourceFunction pSourceFunction)
	{
		int tempIndex = 0;

		pSourceFunction->returnType = ReturnType::ReturnType_unknownType;
		pSourceFunction->CodeLineNum = 0;
		for (int i = 0; i < 200; i++)
		{
			(pSourceFunction->CodeLine)[i] = new SourceLine;
			InitSourceCodeLine((pSourceFunction->CodeLine)[i]);
		}
		pSourceFunction->pReturnUserDefStruct = NULL;
		pSourceFunction->VariableNum = 0;
		for (int i = 0; i < 20; i++)
		{
			(pSourceFunction->Variable)[i] = new Variable;
			InitVariable((pSourceFunction->Variable)[i]);
		}
		pSourceFunction->bHavePar = false;
		pSourceFunction->bReturnUserDefStruct = false;
		pSourceFunction->ParNum = -1;
		pSourceFunction->FunctionNo = -1;
		pSourceFunction->WriteCodeLineNo = 0;
		pSourceFunction->ReadCodeLineNo = 0;
		pSourceFunction->WriteVariableNo = 0;
		pSourceFunction->ReadVariableNo = 0;
		pSourceFunction->StartGlobalLineNo = -1;
		pSourceFunction->StopGlobalLineNo = -1;
		pSourceFunction->StartIndex = -1;
		pSourceFunction->StopIndex = -1;
		pSourceFunction->CallFunction = NULL;
		pSourceFunction->CalledFunction = NULL;
		pSourceFunction->CallFunctionNum = 0;
		pSourceFunction->CalledFunctionNum = 0;
		pSourceFunction->pCodeBlock = NULL;
		pSourceFunction->bDeclare = false;
		pSourceFunction->bDefinition = false;
		pSourceFunction->DeclareGlobalLineNo = -1;

		return 1;
	}

	int InitStoreNameSpaceInfo(PStoreNameSpaceInfo pStoreNameSpaceInfo)
	{
		int tempIndex = 0;

		pStoreNameSpaceInfo->NameSpaceNo = -1;
		pStoreNameSpaceInfo->StartGlobalLineNo = -1;
		pStoreNameSpaceInfo->StopGlobalLineNo = -1;
		pStoreNameSpaceInfo->VariableNum = 0;
		pStoreNameSpaceInfo->WriteVariableNo = 0;
		pStoreNameSpaceInfo->ReadVariableNo = 0;
		pStoreNameSpaceInfo->SourceCodeLineNum = 0;
		pStoreNameSpaceInfo->WriteSourceCodeLineNo = 0;
		pStoreNameSpaceInfo->ReadSourceCodeLineNo = 0;
		pStoreNameSpaceInfo->SourceFunctionNum = 0;
		pStoreNameSpaceInfo->WriteSourceFunctionNo = 0;
		pStoreNameSpaceInfo->ReadSourceFunctionNo = 0;
		for (int z = 0; z < 20; z++)
		{
			(pStoreNameSpaceInfo->Variable)[z] = new Variable;
			(pStoreNameSpaceInfo->SourceCodeLine)[z] = new SourceLine;
			InitVariable((pStoreNameSpaceInfo->Variable)[z]);
			InitSourceCodeLine((pStoreNameSpaceInfo->SourceCodeLine)[z]);
		}
		for (int z = 0; z < 10; z++)
		{
			(pStoreNameSpaceInfo->SourceFunction)[z] = new SourceFunction;
			InitSourceFunction((pStoreNameSpaceInfo->SourceFunction)[z]);
		}

		return 1;
	}

	int InitStoreCPlusPlusLanguageCharacter(PStoreCPlusPlusLanguageCharacter pStoreCPlusPlusLanguageCharacter)
	{
		int tempIndex = 0;

		pStoreCPlusPlusLanguageCharacter->bHaveNameSpace = false;
		pStoreCPlusPlusLanguageCharacter->bUseNameSpace = false;
		pStoreCPlusPlusLanguageCharacter->NameSpaceNum = 0;
		pStoreCPlusPlusLanguageCharacter->WriteNameSpaceNo = 0;
		pStoreCPlusPlusLanguageCharacter->ReadNameSpaceNo = 0;
		pStoreCPlusPlusLanguageCharacter->UseNameSpaceInfoNum = 0;
		pStoreCPlusPlusLanguageCharacter->pStoreUseNameSpaceInfo = NULL;
		for (int i = 0; i < 5; i++)
		{
			(pStoreCPlusPlusLanguageCharacter->pStoreNameSpaceInfo)[i] = new StoreNameSpaceInfo;
			InitStoreNameSpaceInfo((pStoreCPlusPlusLanguageCharacter->pStoreNameSpaceInfo)[i]);
		}

		return 1;
	}

	int InitUnSyntaxSourceLine(PUnSyntaxSourceLine pUnSyntaxSourceLine)
	{
		int tempIndex = 0;

		pUnSyntaxSourceLine->MasterType = -1;
		pUnSyntaxSourceLine->MasterLineNo = -1;

		return 1;
	}

	int InitSyntaxCodeLine(PSyntaxCodeLine pSyntaxCodeLine)
	{
		int tempIndex = 0;

		pSyntaxCodeLine->SyntaxKeyType = SyntaxKey::SyntaxKey_unknownType;
		pSyntaxCodeLine->bbrace = false;
		pSyntaxCodeLine->FirstContentLineNo = -1;
		pSyntaxCodeLine->FinalContentLineNo = -1;
		pSyntaxCodeLine->SyntaxChainLength = 0;
		pSyntaxCodeLine->bCondition = false;
		pSyntaxCodeLine->BraceContentFeedLineNum = 0;

		return 1;
	}

	int InitStoreUseNameSpaceInfo(PStoreUseNameSpaceInfo pStoreUseNameSpaceInfo)
	{
		int tempIndex = 0;
		
		pStoreUseNameSpaceInfo->UseNameSpaceCodeLineNo = -1;
		pStoreUseNameSpaceInfo->bUserDefNameSpace = false;
		pStoreUseNameSpaceInfo->pNameSpaceDefInfo = NULL;
		pStoreUseNameSpaceInfo->pNext = NULL;

		return 1;
	}

	int AddNodeInStoreUseNameSpaceInfoChain(PStoreCPlusPlusLanguageCharacter pStoreCPlusPlusLanguageCharacter, PStoreUseNameSpaceInfo target)
	{
		int tempIndex = 0;
		PStoreUseNameSpaceInfo temppStoreUseNameSpaceInfo;

		if (!pStoreCPlusPlusLanguageCharacter->bUseNameSpace)
		{
			pStoreCPlusPlusLanguageCharacter->bUseNameSpace = true;
			pStoreCPlusPlusLanguageCharacter->pStoreUseNameSpaceInfo = target;
			pStoreCPlusPlusLanguageCharacter->UseNameSpaceInfoNum++;
		}
		else
		{
			temppStoreUseNameSpaceInfo = pStoreCPlusPlusLanguageCharacter->pStoreUseNameSpaceInfo;
			for (int i = 1; i < pStoreCPlusPlusLanguageCharacter->UseNameSpaceInfoNum; i++)
			{
				temppStoreUseNameSpaceInfo = temppStoreUseNameSpaceInfo->pNext;
			}
			temppStoreUseNameSpaceInfo->pNext = target;
			pStoreCPlusPlusLanguageCharacter->UseNameSpaceInfoNum++;
		}

		return 1;
	}

	int AddNameSpaceDefInfo(void** Code, int* index)
	{
		int tempIndex = 0;
		char tempSubCode[150];
		char* temppSubCode;
		char tempCode[50];
		int tempReturnLength = 0;
		int temp = 0;
		int tempWriteNameSpaceNo = 0;

		((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->bHaveNameSpace = true;
		temppSubCode = tempSubCode;
		memset(tempSubCode, 0x0, 150);
		tempReturnLength = DivisionCodeByLineFeed(Code, index, tempSubCode);
		temp = 0;
		tempIndex = DivisionCodeByBlank((void**)(&temppSubCode), &temp, tempCode);
		temp += tempIndex;
		MoveCodeIndexUntillNoBlank((void**)(&temppSubCode), &temp);

		tempWriteNameSpaceNo = ((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->WriteNameSpaceNo;
		strcpy(((((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->pStoreNameSpaceInfo)[tempWriteNameSpaceNo])->Name, &(temppSubCode[temp]));
		((((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->pStoreNameSpaceInfo)[tempWriteNameSpaceNo])->NameSpaceNo = tempWriteNameSpaceNo;
		((((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->pStoreNameSpaceInfo)[tempWriteNameSpaceNo])->StartGlobalLineNo = AnalysisCodeLineNo;

		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::namespaceDefType;
		strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, tempSubCode);
		pSourceCodeFile->SourceCodeLineNum++;
		pSourceCodeFile->WriteSourceCodeLineNo++;

		AnalysisCodeLineNo++;
		*index = *index + tempReturnLength + 2;

		tempReturnLength = DivisionCodeByLineFeed(Code, index, tempSubCode);
		if (tempSubCode[0] == '{')                         //�����д��û�п���ͨ���ԣ��̶�����Ϊtypedef struct xxx\r\n{\r\n xxx ����ʽ����
		{
			((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
			((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
			((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::namespaceDefType;
			strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, tempSubCode);
			pSourceCodeFile->SourceCodeLineNum++;
			pSourceCodeFile->WriteSourceCodeLineNo++;

			AnalysisCodeLineNo++;
			*index = *index + tempReturnLength + 2;

			////////////////////////////////////////////////
			//����namespae�еĴ���Ӧ�ý�����������������ڴ��д���󣬵���Ϊ�˼򵥾���ֱ�ӷ���
			//namespace�еĺ������廹����Ϊ��ȫ�ֶ���ĺ���������using namespaceҲֻ���м�
			//���������Ծ�����ôд�ˣ�֮������Ҫ��˵�ɣ����޸İ�
			////////////////////////////////////////////////


		}
		else
		{
			std::cout << "Add NameSpace Def error" << std::endl;
			return 0;
		}

		return 1;
	}

	int AddUseNameSpaceInfo(void** Code, int* index)
	{
		int tempIndex = 0;
		char tempSubCode[150];
		char tempCode[50];
		char* temppSubCode;
		int tempReturnLength = 0;
		int tempSubCodeLength = 0;
		int temp = 0;
		PStoreUseNameSpaceInfo temppStoreUseNameSpaceInfo;
		PStoreNameSpaceInfo temppStoreNameSpaceInfo;

		temppStoreUseNameSpaceInfo = new StoreUseNameSpaceInfo;

		temppSubCode = tempSubCode;
		tempReturnLength = DivisionCodeByLineFeed(Code, index, tempSubCode);
		RemoveStringEndBlank(tempSubCode);
		temp = 0;
		tempIndex = DivisionCodeByBlank((void**)(&temppSubCode), &temp, tempCode);
		temp += tempIndex;
		MoveCodeIndexUntillNoBlank((void**)(&temppSubCode), &temp);
		tempIndex = DivisionCodeByBlank((void**)(&temppSubCode), &temp, tempCode);
		temp += tempIndex;
		MoveCodeIndexUntillNoBlank((void**)(&temppSubCode), &temp);
		
		//��Ϊusing namespace xxx;�����������ʽ����ΪҪ��ȡ��namespace�����֣�������Ҫ���漸�д��뽫����;ɾ�������Ի������漸�д���
		tempSubCodeLength = strlen(tempSubCode);
		tempSubCode[tempSubCodeLength - 1] = 0x0;

		temppStoreUseNameSpaceInfo->UseNameSpaceCodeLineNo = AnalysisCodeLineNo;
		strcpy(temppStoreUseNameSpaceInfo->NameSpaceName, &(temppSubCode[temp]));
		if (CheckNameSpaceExist(temppStoreUseNameSpaceInfo->NameSpaceName, &temppStoreNameSpaceInfo) != 0)
		{
			temppStoreUseNameSpaceInfo->bUserDefNameSpace = true;
			temppStoreUseNameSpaceInfo->pNameSpaceDefInfo = temppStoreNameSpaceInfo;
		}
		else
		{
			temppStoreUseNameSpaceInfo->bUserDefNameSpace = false;
			temppStoreUseNameSpaceInfo->pNameSpaceDefInfo = NULL;
		}
		AddNodeInStoreUseNameSpaceInfoChain((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater, temppStoreUseNameSpaceInfo);

		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeLineNo = AnalysisCodeLineNo;
		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->GlobalLineNo = AnalysisCodeLineNo;
		((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->CodeType = CodeLineType::usingnamespaceKeywordType;
		strcpy(((pSourceCodeFile->SourceCodeLine)[pSourceCodeFile->WriteSourceCodeLineNo])->buffer, tempSubCode);
		pSourceCodeFile->SourceCodeLineNum++;
		pSourceCodeFile->WriteSourceCodeLineNo++;

		AnalysisCodeLineNo++;
		*index = *index + tempReturnLength + 2;

		return 1;
	}

	int CheckNameSpaceExist(char* target, PStoreNameSpaceInfo* pReturnStoreNameSpaceInfo)
	{
		int tempIndex = 0;
		int tempNameSpaceNum = ((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->NameSpaceNum;
		
		*pReturnStoreNameSpaceInfo = NULL;
		for (int i = 0; i < tempNameSpaceNum; i++)
		{
			if (strcmp(((((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->pStoreNameSpaceInfo)[i])->Name, target) == 0)
			{
				*pReturnStoreNameSpaceInfo = (((pSourceCodeFile->pStoreLanguageCharacterInfo)->pStoreCPlusPlusLanguageCharater)->pStoreNameSpaceInfo)[i];
				return 1;
			}
		}

		return 0;
	}

	//�˺�������Ŀ������������Ĵ���鿪ʼ�ͽ�β,ֻ����������Ĵ�������ʼ�ͽ�β,������봦�ڶ༶�����ṹ��,������������һ���������ʼ�ͽ�β,�˺���û�н�ReturnCodeLineNoArrayLength��0,�����ڵ��ô˺���ʱҪע��ReturnCodeLineNoArrayLength�����ĳ�ʼֵ
	int GetOneCodeLineInCodeBlockInfo(int TargetCodeLineNo, int* ReturnCodeLineNoArray, int* ReturnCodeLineNoArrayLength)
	{
		PSourceLine temppSourceLine;
		PSourceFunction temppSourceFunction;

		//update at 23.3.14 ���ܴ�������
		/*GetCodeLineStruct(TargetCodeLineNo, &temppSourceLine, &temppSourceFunction);
		if (temppSourceLine->PUnSyntaxCode->MasterType != 2 && temppSourceLine->PUnSyntaxCode->MasterType != -1)
		{*/
			GetCodeLineStruct(TargetCodeLineNo, &temppSourceLine, &temppSourceFunction);
			GetCodeLineStruct((temppSourceLine->PUnSyntaxCode)->MasterLineNo, &temppSourceLine, &temppSourceFunction);
			ReturnCodeLineNoArray[(*ReturnCodeLineNoArrayLength)++] = (temppSourceLine->PSyntaxCode)->FirstContentLineNo;
			ReturnCodeLineNoArray[(*ReturnCodeLineNoArrayLength)++] = (temppSourceLine->PSyntaxCode)->FinalContentLineNo;
		/*}*/

		return 1;
	}

	int GetCodeLineArrayInCodeBlockInfo(int* TargetCodeLineNoArray, int* TargetCodeLineNoArrayLength)
	{
		int tempArrayLength = 0;
		int tempArray[150];

		for (int i = 0; i < *TargetCodeLineNoArrayLength; i++)
		{
			GetOneCodeLineInCodeBlockInfo(TargetCodeLineNoArray[i], tempArray, &tempArrayLength);
		}
		//����û��ֱ�ӽ���ȡ�����Ĵ����ṹ�����д����кż��뵽����Ĵ����к��������ٽ�������������ظ���Ĳ���,�����Ƚ���ȡ���������д����ṹ�Ĵ����к��Ƚ���������ظ�������,�ټ��뵽����Ĵ����к��������ٽ��������������ԭ����,�Ҹо����ֱ�Ӽ��뵽���������ܴ������(��Ȼ����Ҳ�ܴ�(��ʾ�����ṹ�Ĵ����кŽ����кܶ�),��������ʱ�����ܴ�Ŀ���),���Էֲ�����,�������һ��,֮�������˵
		AdjustIntOrderSTL(tempArray, &tempArrayLength);
		RemoveRepeateIntInIntArray(tempArray, &tempArrayLength);
		for (int i = 0; i < tempArrayLength; i++)
		{
			TargetCodeLineNoArray[i + *TargetCodeLineNoArrayLength] = tempArray[i];
		}
		(*TargetCodeLineNoArrayLength) += tempArrayLength;
		AdjustIntOrderSTL(TargetCodeLineNoArray, TargetCodeLineNoArrayLength);
		RemoveRepeateIntInIntArray(TargetCodeLineNoArray, TargetCodeLineNoArrayLength);

		return 1;
	}

	int CheckStrHaveGoodOrBad(char* Target)
	{
		int tempStrLength = 0;
		char** tempppStr;
		char good[5] = "good";
		char bad[5] = "bad";
		
		tempppStr = new char*;
		*tempppStr = Target;

		tempStrLength = strlen(Target);
		if (CheckAscii((void**)tempppStr, tempStrLength, good) > 0)
		{
			return 1;
		}
		else if (CheckAscii((void**)tempppStr, tempStrLength, bad) > 0)
		{
			return -1;
		}
		else
		{
#ifdef _DEBUG
			std::cout << "CheckStrHaveGoodOrBad Fail\n";
#endif
		}

		return 0;
	}

	//�µķ�������ģ�黯�ֽ�������,����ͨ���ú����ж�Ӧ�ý�����һ��ģ����н���,Ȼ�������Ӧ�ĺ������д������
	int TranslateCodeSlice(void** Code, int* index, void** OutPut, int* OutPutindex)
	{
		int tempIndex = 0;
		char tempSubCode[400];
		char** tempppSubCode;
		int tempReturnLength = 0;
		CodeBlockType tempCodeBlockType;
		/*int tempMacroNum = 0;
		char** tempppMacroArray;
		int tempVarNum = 0;
		char** tempppVarArray;
		int tempUserDefTypeNum = 0;
		char** tempppUserDefTypeArray;*/
		InterMediateNew tempInterMediate(Code, index, OutPut, OutPutindex);

		//tempppMacroArray = new char* [20];
		//tempppVarArray = new char* [20];
		//tempppUserDefTypeArray = new char* [20];
		//for (int i = 0; i < 20; i++)
		//{
		//	tempppMacroArray[i] = new char[50];
		//	tempppVarArray[i] = new char[100];
		//	tempppUserDefTypeArray[i] = new char[80];
		//}

		tempppSubCode = new char*;
		*tempppSubCode = tempSubCode;
		memset(tempSubCode, 0x0, 400);

		while ((*(char**)(tempInterMediate.InputBuffer))[*(tempInterMediate.InputBufferIndex)] != 0x0)
		{
			/*tempReturnLength = DivisionCodeByLineFeed(Code, index, (void*)tempSubCode);*/
			tempReturnLength = DivisionCodeByLineFeed(tempInterMediate.InputBuffer, tempInterMediate.InputBufferIndex, (void*)tempSubCode);
			tempIndex = 0;
			CheckCodeBlockType((void**)tempppSubCode, &tempIndex, &tempCodeBlockType);
			switch (tempCodeBlockType)
			{
			case CodeBlockType_unknown:
			{
				std::cout << "Translate Code Slice New Fail: Can not Get Code Block Type" << tempSubCode << "\n";
				throw 1;
				break;
			}
			case MacroDefType:
			{
				ProcessCodeSliceMacroDef(&tempInterMediate);
				break;
			}
			case StructDef:
			{
				ProcessCodeSliceStructDef(&tempInterMediate);
				break;
			}
			case TypedefStructDef:
			{
				ProcessCodeSliceTypedefStructDef(&tempInterMediate);
				break;
			}
			case UnionDef:
			{
				ProcessCodeSliceUnionDef(&tempInterMediate);
				break;
			}
			case TypedefUnionDef:
			{
				ProcessCodeSliceTypedefUnionDef(&tempInterMediate);
				break;
			}
			case VarDefType:
			{
				ProcessCodeSliceVarDefType(&tempInterMediate);
				break;
			}
			case VarDeclareType:
			{
				ProcessCodeSliceVarDeclareType(&tempInterMediate);
				break;
			}
			case VarAssignmentType:
			{
				ProcessCodeSliceVarAssignmentType(&tempInterMediate);
				break;
			}
			case CodeBlockTypeOnlyFunctionCall:
			{
				ProcessCodeSliceCodeBlockTypeOnlyFunctionCallType(&tempInterMediate);
				break;
			}
			case SyntaxKeyCodeLine:
			{
				ProcessCodeSliceSyntaxKeyCodeLineType(&tempInterMediate);
				break;
			}
			case CodeBlockTypeLBraceType:
			{
				ProcessCodeSliceCodeBlockTypeLBraceType(&tempInterMediate);
				break;
			}
			case CodeBlockTypeRBraceType:
			{
				ProcessCodeSliceCodeBlockTypeRBraceType(&tempInterMediate);
				break;
			}
			case CodeBlockTypeFunctionDeclare:
			{
				ProcessCodeSliceCodeBlockTypeFunctionDeclare(&tempInterMediate);
				break;
			}
			default:
			{
				std::cout << "Translate Code Slice New Fail: Can not Get Code Block Type" << tempSubCode << "\n";
				throw 1;
				break;
			}
			}

			/**index = *index + tempReturnLength + 2;*/
		}

		/*for (int i = 0; i < 10; i++)
		{
			if (strlen(tempppMacroArray[i]) != 0)
			{
				delete [] tempppMacroArray[i];
			}
			if (strlen(tempppVarArray[i]) != 0)
			{
				delete[] tempppVarArray[i];
			}
			if (strlen(tempppUserDefTypeArray[i]) != 0)
			{
				delete[] tempppUserDefTypeArray[i];
			}
		}
		delete [] tempppMacroArray;
		delete[] tempppVarArray;
		delete[] tempppUserDefTypeArray;*/

		return 1;
	}

	int CheckCodeBlockType(void** Code, int* index, CodeBlockType* pReturn)
	{
		int tempIndex = 0;
		int tempInt = 0;
		char tempSubCode[200];
		int tempAssigningOperatorNum = 0;
		int tempSubCodeLength = 0;
		int tempOperatorArrayIndex[5] = { 0 };
		ProfixType tempProfixType;
		TypedefType tempTypedefReturn;
		ReturnType tempReturnType;
		PUserDefStruct temppUserDefStruct;
		SyntaxKey tempSyntaxKey;
		SyntaxKey tempSyntaxKey1;

		memset(tempSubCode, 0x0, 200);
		*pReturn = CodeBlockType::CodeBlockType_unknown;

		tempIndex = *index;
		tempInt = DivisionCodeByBlank(Code, &tempIndex, tempSubCode);
		
		if (tempSubCode[0] == '{')
		{
			*pReturn = CodeBlockType::CodeBlockTypeLBraceType;
			return 1;
		}
		if (tempSubCode[0] == '}')
		{
			*pReturn = CodeBlockType::CodeBlockTypeRBraceType;
			return 1;
		}
		if (strcmp(tempSubCode, "#define") == 0)
		{
			*pReturn = CodeBlockType::MacroDefType;
			return 1;
		}
		CheckSyntaxKey(Code, &tempIndex, &tempSyntaxKey, &tempSyntaxKey1);
		if (tempSyntaxKey != SyntaxKey::SyntaxKey_unknownType)
		{
			*pReturn = CodeBlockType::SyntaxKeyCodeLine;
			return 1;
		}

		tempSubCodeLength = strlen(*(char**)Code);
		if ((*(char**)Code)[tempSubCodeLength - 1] == ')')
		{
			*pReturn = CodeBlockType::CodeBlockTypeFunctionDeclare;
			return 1;
		}

		CheckProfixType(Code, &tempIndex, &tempProfixType);
		tempIndex += tempInt;
		switch (tempProfixType)
		{
		case ProfixType_unknownType:
		{
			tempIndex -= tempInt;
			break;
		}
		case typedefType:
		{
			MoveCodeIndexUntillNoBlank(Code, &tempIndex);
			CheckTypedefType(Code, &tempIndex, &tempTypedefReturn);
			switch (tempTypedefReturn)
			{
			case TypedefType_unknownType:
			{
				*pReturn = CodeBlockType::CodeBlockType_unknown;
				return 1;
			}
			case StructType:
			{
				*pReturn = CodeBlockType::TypedefStructDef;
				return 1;
			}
			case UnionType:
			{
				*pReturn = CodeBlockType::TypedefUnionDef;
				return 1;
			}
			default:
				break;
			}
			break;
		}
		case structType:
		{
			MoveCodeIndexUntillNoBlank(Code, &tempIndex);
			CheckReturnType(Code, &tempIndex, &tempReturnType, &temppUserDefStruct);
			
			//fix bug at 23.4.5
			tempAssigningOperatorNum = CheckLincCodeAssigningOperator(Code, tempOperatorArrayIndex);
			if (tempReturnType != ReturnType::ReturnType_unknownType)
			{
				if (tempAssigningOperatorNum > 0)
				{
					*pReturn = CodeBlockType::VarDefType;
				}
				else
				{
					if ((*(char**)Code)[tempSubCodeLength - 2] == ')')
					{
						*pReturn = CodeBlockType::CodeBlockTypeFunctionDeclare;
					}
					else
					{
						*pReturn = CodeBlockType::VarDeclareType;
					}
				}
			}
			else
			{
				*pReturn = CodeBlockType::StructDef;
			}
			return 1;
		}
		case unionType:
		{
			*pReturn = CodeBlockType::UnionDef;
			return 1;
		}
		case staticconstType:
		{
			MoveCodeIndexUntillNoBlank(Code, &tempIndex);
			tempInt = DivisionCodeByBlank(Code, &tempIndex, tempSubCode);
			tempIndex += tempInt;
		}
		case staticType:
		case externType:
		{
			//fix bug at 23.4.5
			tempAssigningOperatorNum = CheckLincCodeAssigningOperator(Code, tempOperatorArrayIndex);

			if (tempAssigningOperatorNum > 0)
			{
				*pReturn = CodeBlockType::VarDefType;
			}
			else
			{
				if ((*(char**)Code)[tempSubCodeLength - 2] == ')')
				{
					*pReturn = CodeBlockType::CodeBlockTypeFunctionDeclare;
				}
				else
				{
					*pReturn = CodeBlockType::VarDeclareType;
				}
			}
			return 1;
		}
		default:
			break;
		}
		MoveCodeIndexUntillNoBlank(Code, &tempIndex);
		CheckReturnType(Code, &tempIndex, &tempReturnType, &temppUserDefStruct);

		//fix bug at 23.4.5
		tempAssigningOperatorNum = CheckLincCodeAssigningOperator(Code, tempOperatorArrayIndex);
		if (tempReturnType != ReturnType::ReturnType_unknownType)
		{
			if (tempAssigningOperatorNum > 0)
			{
				*pReturn = CodeBlockType::VarDefType;
			}
			else
			{
				if ((*(char**)Code)[tempSubCodeLength - 2] == ')')
				{
					*pReturn = CodeBlockType::CodeBlockTypeFunctionDeclare;
				}
				else
				{
					*pReturn = CodeBlockType::VarDeclareType;
				}
			}
		}
		else
		{
			if (tempAssigningOperatorNum > 0)
			{
				*pReturn = CodeBlockType::VarAssignmentType;
			}
			else
			{
				*pReturn = CodeBlockType::CodeBlockTypeOnlyFunctionCall;
			}
		}

		return 1;
	}

	int InitStoreArrayIndexInfo(PStoreArrayIndexInfo pStoreArrayIndexInfo)
	{
		pStoreArrayIndexInfo->GlobalCodeLineNo = -1;
		pStoreArrayIndexInfo->pArray = NULL;
		pStoreArrayIndexInfo->pNext = NULL;
		pStoreArrayIndexInfo->pParent = NULL;
		pStoreArrayIndexInfo->pSourceLine = NULL;

		return 1;
	}

	int ProcessCodeSliceMacroDef(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		int tempInt = 0;
		int tempReturnLength = 0;
		char tempSubCode[150];
		char tempSubCode1[100];
		char tempMacroNo[10];
		char** tempppSubCode;
		PStoreInterMediateMacroDefInfo temppMacro;
		PStoreInterMediateCodeBlockInfo temppCodeBlock;
		
		tempppSubCode = new char*;
		*tempppSubCode = tempSubCode;
		temppMacro = new StoreInterMediateMacroDefInfo;
		InitStoreInterMediateMacroDefInfo(temppMacro);
		memset(tempSubCode, 0x0, 150);
		memset(tempSubCode1, 0x0, 100);
		memset(tempMacroNo, 0x0, 10);

		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, (void*)tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		tempInt += tempReturnLength;
		MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, (void*)tempSubCode1);
		tempInt += tempReturnLength;
		MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
		strcpy(temppMacro->MacroName, tempSubCode1);
		strcpy(temppMacro->InterMediateName, "Macro_");
		IntToStrNew(pInterMediateNew->StoreInterMediateMacroDefInfoNum, tempMacroNo);
		strcat(temppMacro->InterMediateName, tempMacroNo);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppMacro->InterMediateName);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		/*tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, (void*)tempSubCode1);
		tempInt += tempReturnLength;*/
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), &(tempSubCode[tempInt]));

		pInterMediateNew->GetStoreInterMediateCodeBlockInfoLastUnMatchedElement(&temppCodeBlock);
		if (temppCodeBlock != NULL)
		{
			temppMacro->pCodeBlock = temppCodeBlock;
		}
		temppMacro->InterMediateCodeLineNo = pInterMediateNew->WriteInterMediateCodeLineNo;

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		pInterMediateNew->AddStoreInterMediateMacroDefInfo(temppMacro);
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		delete tempppSubCode;

		return 1;
	}

	//��������û�����Ľṹ������ʱ,�䰴�չ̶��ĸ�ʽ���н���,����Ƿǹ̶���ʽ�Ļ������
	int ProcessCodeSliceStructDef(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		char tempSubCode[150];
		char tempSubCode1[100];
		char tempSubCode2[100];
		char tempSubCode3[2];
		char** tempppSubCode;
		char** tempppSubCode1;
		int tempSubCode2Index = 0;
		int tempSubCode1Index = 0;
		bool bName = false;
		bool bArray = false;
		int tempInt = 0;
		int tempReturnLength = 0;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempReturnLBraceNum = 0;
		int tempReturnRBraceNum = 0;
		char tempStructNo[10];
		void** tempppPointer;
		PStoreInterMediateUserDefTypeInfo temppUserDefType;
		PStoreInterMediateUserDefTypeContenTypeInfo temppUserDefTypeContent;
		ProfixType tempReturnProfixType;
		ReturnType tempReturnReturnType;
		PUserDefStruct tempReturnUserDefStruct;
		PStoreInterMediateUserDefTypeInfo temppUserDefTypeInfo;

		tempppPointer = new void*;
		temppUserDefType = new StoreInterMediateUserDefTypeInfo;
		InitStoreInterMediateUserDefTypeInfo(temppUserDefType);
		tempppSubCode1 = new char*;
		*tempppSubCode1 = tempSubCode1;
		tempppSubCode = new char*;
		*tempppSubCode = tempSubCode;
		memset(tempSubCode, 0x0, 150);
		memset(tempSubCode1, 0x0, 100);
		memset(tempStructNo, 0x0, 10);
		memset(tempSubCode2, 0x0, 100);

		temppUserDefType->UserDefTypeType = 1;
		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;
		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		tempInt += tempReturnLength;
		MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
		strcpy(temppUserDefType->DefTypeMainName, &(tempSubCode[tempInt]));
		strcpy(temppUserDefType->InterMediateName, "UserDefType_");
		IntToStrNew(pInterMediateNew->StoreInterMediateUserDefTypeInfoNum, tempStructNo);
		strcat(temppUserDefType->InterMediateName, tempStructNo);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefType->InterMediateName);

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		//�ⲿ����ƵĲ���ͨ��,ֻ֧�̶ֹ���ʽ��д��
		if (strcmp(tempSubCode, "{") == 0)
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

			pInterMediateNew->InterMediateCodeLineNum++;
			pInterMediateNew->WriteInterMediateCodeLineNo++;
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
			tempLBraceNum++;
		}
		else
		{
			//fix bug at 23.4.5
			tempIndex = tempIndex - tempReturnLength - 2;
			std::cout << "Process Code Slice Struct Def Fail\n";
		}
		while (tempLBraceNum != tempRBraceNum)
		{
			tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
			tempIndex = tempIndex + tempReturnLength + 2;
			tempInt = 0;
			tempReturnLBraceNum = 0;
			tempReturnRBraceNum = 0;
			tempSubCode2Index = 0;
			tempSubCode1Index = 0;
			bName = false;
			switch (CheckCodeLineHaveBrace((void**)tempppSubCode, &tempInt, &tempReturnLBraceNum, &tempReturnRBraceNum))
			{
			case 0:
			{
				tempLBraceNum += tempReturnLBraceNum;
				tempRBraceNum += tempReturnRBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
				break;
			}
			case 1:
			{
				tempRBraceNum += tempReturnRBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
				break;
			}
			case -1:
			{
				tempLBraceNum += tempReturnLBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
				break;
			}
			case -2:
			{
				temppUserDefTypeContent = new StoreInterMediateUserDefTypeContenTypeInfo;
				InitStoreInterMediateUserDefTypeContenTypeInfo(temppUserDefTypeContent);

				CheckProfixType((void**)tempppSubCode, &tempInt, &tempReturnProfixType);
				if (tempReturnProfixType != ProfixType::ProfixType_unknownType)
				{
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
					tempInt += tempReturnLength;
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);

					//������Ȱ��չ̶���ʽ������,��ʵ�õķ���������CheckProfixType�����������ĳ��Ƚ����ַ���һ�θ���,ֱ������Profix����,����������Ӳ��������ķ�ʽ����
					if (tempReturnProfixType == ProfixType::staticconstType)
					{
						tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
						tempInt += tempReturnLength;
						MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					}
				}
				CheckReturnType((void**)tempppSubCode, &tempInt, &tempReturnReturnType, &tempReturnUserDefStruct);
				if (tempReturnReturnType != ReturnType::ReturnType_unknownType)
				{
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					tempInt += tempReturnLength;
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					if (tempReturnUserDefStruct != NULL)
					{
						pInterMediateNew->FindStoreInterMediateUserDefTypeInfo(tempSubCode1, &temppUserDefTypeInfo);
						if (temppUserDefTypeInfo != NULL)
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeInfo->InterMediateName);
						}
						else
						{
							std::cout << "ProcessCodeSliceStructDef Error\n";
							throw 1;
							return 0;
						}
					}
					else
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					}
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				}
				else
				{
					std::cout << "ProcessCodeSliceStructDef Error\n";
					throw 1;
					return 0;
				}
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				//tempInt += tempReturnLength;
				/*tempSubCode1[tempReturnLength - 1] = 0x0;*/
				while (tempSubCode[tempInt] != 0x0)
				{
					if (CheckNamableCharacter(&(tempSubCode[tempInt])))
					{
						tempSubCode2[tempSubCode2Index++] = tempSubCode[tempInt];
					}
					else
					{
						if (tempSubCode2Index > 0)
						{
							tempSubCode2[tempSubCode2Index] = 0x0;
							tempSubCode2Index = 0;
							if (!bName)
							{
								bName = true;
								strcpy(temppUserDefTypeContent->Name, tempSubCode2);
								strcpy(temppUserDefTypeContent->InterMediateName, "UserDefTypeContent_");
								IntToStrNew(temppUserDefType->ContentNum, tempStructNo);
								strcat(temppUserDefTypeContent->InterMediateName, tempStructNo);
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeContent->InterMediateName);

								if (tempSubCode[tempInt] == '[')
								{
									temppUserDefTypeContent->bArray = true;
									bArray = true;
								}
							}
							else
							{
								if (bArray)
								{
									switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode2, tempppPointer))
									{
									case 0:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
										break;
									}
									case 1:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 2:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 3:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 4:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 5:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 6:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
										delete[] * tempppPointer;
										break;
									}
									default:
									{
										std::cout << "ProcessCodeSliceStructDef Fail\n";
										break;
									}
									}
									strcat(temppUserDefTypeContent->Array, tempSubCode2);
								}
								else
								{
									/*if (tempSubCode1[tempSubCode1Index] == '[')
									{
										temppUserDefTypeContent->bArray = true;
									}*/
									//else
									//{
									std::cout << "ProcessCodeSliceStructDef Fail\n";
									//}
								}
							}
						}

						if (bArray)
						{
							tempSubCode3[0] = tempSubCode[tempInt];
							tempSubCode3[1] = 0x0;
							strcat(temppUserDefTypeContent->Array, tempSubCode3);
						}

						if (tempSubCode[tempInt] == ']')
						{
							bArray = false;
						}

						tempSubCode3[0] = tempSubCode[tempInt];
						tempSubCode3[1] = 0x0;
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
					}

					tempInt++;
				}

				/*tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				tempInt += tempReturnLength;
				MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				tempInt += tempReturnLength;
				if (tempSubCode1[0] == '*')
				{
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					tempInt += tempReturnLength;
				}
				tempSubCode1[tempReturnLength - 1] = 0x0;
				strcpy(temppUserDefTypeContent->Name, tempSubCode1);
				strcpy(temppUserDefTypeContent->InterMediateName, "UserDefTypeContent_");
				IntToStrNew(temppUserDefType->ContentNum, tempStructNo);
				strcat(temppUserDefTypeContent->InterMediateName, tempStructNo);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeContent->InterMediateName);*/

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");

				AddStoreInterMediateUserDefTypeContentInfo(temppUserDefType, temppUserDefTypeContent);

				break;
			}
			default:
				break;
			}

		}

		pInterMediateNew->AddStoreInterMediateUserDefTypeInfo(temppUserDefType);
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		delete tempppSubCode1;
		delete tempppSubCode;
		delete tempppPointer;

		return 1;
	}

	int LIKED()
	{
		char temp[5];
		display(temp, 5, -1);
		return 1;
	}

	int InitStoreInterMediateVarDefInfo(PStoreInterMediateVarDefInfo p)
	{
		memset(p->InterMediateName, 0x0, 80);
		memset(p->VarName, 0x0, 100);
		p->pNext = NULL;
		p->InterMediateCodeLineNo = -1;
		p->pCodeBlock = NULL;
		p->bArray = false;
		memset(p->Array, 0x0, 100);

		return 1;
	}

	int InitStoreInterMediateMacroDefInfo(PStoreInterMediateMacroDefInfo p)
	{
		memset(p->MacroName, 0x0, 100);
		memset(p->InterMediateName, 0x0, 80);
		p->pNext = NULL;
		p->InterMediateCodeLineNo = -1;
		p->pCodeBlock = NULL;

		return 1;
	}

	int InitStoreInterMediateUserDefFunctionInfo(PStoreInterMediateUserDefFunctionInfo p)
	{
		memset(p->UserDefFunctionName, 0x0, 100);
		memset(p->InterMediateName, 0x0, 80);
		p->pNext = NULL;

		return 1;
	}

	int InitStoreInterMediateUserDefTypeContenTypeInfo(PStoreInterMediateUserDefTypeContenTypeInfo p)
	{
		memset(p->Name, 0x0, 100);
		memset(p->InterMediateName, 0x0, 80);
		p->pNext = NULL;
		p->bArray = false;
		memset(p->Array, 0x0, 100);

		return 1;
	}

	int InitStoreInterMediateUserDefTypeInfo(PStoreInterMediateUserDefTypeInfo p)
	{
		p->UserDefTypeType = 0;
		p->AnotherNameNum = 0;
		p->PointerNameNum = 0;
		p->ContentNum = 0;
		memset(p->DefTypeMainName, 0x0, 100);
		memset(p->InterMediateName, 0x0, 80);
		for (int i = 0; i < 2; i++)
		{
			memset((p->AnotherName)[i], 0x0, 100);
			memset((p->PointerName)[i], 0x0, 100);
		}
		p->pContent = NULL;
		p->pNext = NULL;

		return 1;
	}

	int InitStoreInterMediateBraceInfo(PStoreInterMediateBraceInfo p)
	{
		p->BraceType = 0;
		p->bMatched = false;
		p->InterMediateCodeLineNo = -1;
		p->pMatched = NULL;
		p->pParent = NULL;
		p->pForward = NULL;
		p->pNext = NULL;

		return 1;
	}

	int InitStoreInterMediateCodeBlockInfo(PStoreInterMediateCodeBlockInfo p)
	{
		p->bMatched = false;
		p->StartInterMediateCodeLineNo = -1;
		p->StopInterMediateCodeLineNo = -1;
		p->InterMediateCodeLineNum = 0;
		p->pLBrace = NULL;
		p->pRBrace = NULL;
		p->pForWard = NULL;
		p->pNext = NULL;

		return 1;
	}

	int AddStoreInterMediateUserDefTypeContentInfo(PStoreInterMediateUserDefTypeInfo pParent, PStoreInterMediateUserDefTypeContenTypeInfo p)
	{
		PStoreInterMediateUserDefTypeContenTypeInfo temppUserDefTypeContent;

		if (pParent->ContentNum == 0)
		{
			pParent->pContent = p;
		}
		else
		{
			temppUserDefTypeContent = pParent->pContent;
			for (int i = 1; i < pParent->ContentNum; i++)
			{
				temppUserDefTypeContent = temppUserDefTypeContent->pNext;
			}
			temppUserDefTypeContent->pNext = p;
		}
		pParent->ContentNum++;

		return 1;
	}

	int ProcessCodeSliceUnionDef(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		char tempSubCode[150];
		char tempSubCode1[100];
		char tempSubCode2[100];
		char tempSubCode3[2];
		char** tempppSubCode;
		char** tempppSubCode1;
		int tempSubCode2Index = 0;
		int tempSubCode1Index = 0;
		bool bName = false;
		bool bArray = false;
		int tempInt = 0;
		int tempReturnLength = 0;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempReturnLBraceNum = 0;
		int tempReturnRBraceNum = 0;
		char tempStructNo[10];
		void** tempppPointer;
		PStoreInterMediateUserDefTypeInfo temppUserDefType;
		PStoreInterMediateUserDefTypeContenTypeInfo temppUserDefTypeContent;
		ProfixType tempReturnProfixType;
		ReturnType tempReturnReturnType;
		PUserDefStruct tempReturnUserDefStruct;
		PStoreInterMediateUserDefTypeInfo temppUserDefTypeInfo;

		tempppPointer = new void*;
		temppUserDefType = new StoreInterMediateUserDefTypeInfo;
		InitStoreInterMediateUserDefTypeInfo(temppUserDefType);
		tempppSubCode1 = new char*;
		*tempppSubCode1 = tempSubCode1;
		tempppSubCode = new char*;
		*tempppSubCode = tempSubCode;
		memset(tempSubCode, 0x0, 150);
		memset(tempSubCode1, 0x0, 100);
		memset(tempStructNo, 0x0, 10);
		memset(tempSubCode2, 0x0, 100);

		temppUserDefType->UserDefTypeType = 2;
		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;
		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		tempInt += tempReturnLength;
		MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
		strcpy(temppUserDefType->DefTypeMainName, &(tempSubCode[tempInt]));
		strcpy(temppUserDefType->InterMediateName, "UserDefType_");
		IntToStrNew(pInterMediateNew->StoreInterMediateUserDefTypeInfoNum, tempStructNo);
		strcat(temppUserDefType->InterMediateName, tempStructNo);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefType->InterMediateName);

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		//�ⲿ����ƵĲ���ͨ��,ֻ֧�̶ֹ���ʽ��д��
		if (strcmp(tempSubCode, "{") == 0)
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

			pInterMediateNew->InterMediateCodeLineNum++;
			pInterMediateNew->WriteInterMediateCodeLineNo++;
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
			tempLBraceNum++;
		}
		else
		{
			std::cout << "Process Code Slice Struct Def Fail\n";
		}
		while (tempLBraceNum != tempRBraceNum)
		{
			tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
			tempIndex = tempIndex + tempReturnLength + 2;
			tempInt = 0;
			tempReturnLBraceNum = 0;
			tempReturnRBraceNum = 0;
			tempSubCode2Index = 0;
			tempSubCode1Index = 0;
			bName = false;
			switch (CheckCodeLineHaveBrace((void**)tempppSubCode, &tempInt, &tempReturnLBraceNum, &tempReturnRBraceNum))
			{
			case 0:
			{
				tempLBraceNum += tempReturnLBraceNum;
				tempRBraceNum += tempReturnRBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
				break;
			}
			case 1:
			{
				tempRBraceNum += tempReturnRBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
				break;
			}
			case -1:
			{
				tempLBraceNum += tempReturnLBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
				break;
			}
			case -2:
			{
				temppUserDefTypeContent = new StoreInterMediateUserDefTypeContenTypeInfo;
				InitStoreInterMediateUserDefTypeContenTypeInfo(temppUserDefTypeContent);

				CheckProfixType((void**)tempppSubCode, &tempInt, &tempReturnProfixType);
				if (tempReturnProfixType != ProfixType::ProfixType_unknownType)
				{
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
					tempInt += tempReturnLength;
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);

					//������Ȱ��չ̶���ʽ������,��ʵ�õķ���������CheckProfixType�����������ĳ��Ƚ����ַ���һ�θ���,ֱ������Profix����,����������Ӳ��������ķ�ʽ����
					if (tempReturnProfixType == ProfixType::staticconstType)
					{
						tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
						tempInt += tempReturnLength;
						MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					}
				}
				CheckReturnType((void**)tempppSubCode, &tempInt, &tempReturnReturnType, &tempReturnUserDefStruct);
				if (tempReturnReturnType != ReturnType::ReturnType_unknownType)
				{
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					tempInt += tempReturnLength;
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					if (tempReturnUserDefStruct != NULL)
					{
						pInterMediateNew->FindStoreInterMediateUserDefTypeInfo(tempSubCode1, &temppUserDefTypeInfo);
						if (temppUserDefTypeInfo != NULL)
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeInfo->InterMediateName);
						}
						else
						{
							std::cout << "ProcessCodeSliceUnionDef Error\n";
							throw 1;
							return 0;
						}
					}
					else
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					}
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				}
				else
				{
					std::cout << "ProcessCodeSliceUnionDef Error\n";
					throw 1;
					return 0;
				}
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				//tempInt += tempReturnLength;
				/*tempSubCode1[tempReturnLength - 1] = 0x0;*/
				while (tempSubCode[tempInt] != 0x0)
				{
					if (CheckNamableCharacter(&(tempSubCode[tempInt])))
					{
						tempSubCode2[tempSubCode2Index++] = tempSubCode[tempInt];
					}
					else
					{
						if (tempSubCode2Index > 0)
						{
							tempSubCode2[tempSubCode2Index] = 0x0;
							tempSubCode2Index = 0;
							if (!bName)
							{
								bName = true;
								strcpy(temppUserDefTypeContent->Name, tempSubCode2);
								strcpy(temppUserDefTypeContent->InterMediateName, "UserDefTypeContent_");
								IntToStrNew(temppUserDefType->ContentNum, tempStructNo);
								strcat(temppUserDefTypeContent->InterMediateName, tempStructNo);
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeContent->InterMediateName);

								if (tempSubCode[tempInt] == '[')
								{
									temppUserDefTypeContent->bArray = true;
									bArray = true;
								}
							}
							else
							{
								if (bArray)
								{
									switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode2, tempppPointer))
									{
									case 0:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
										break;
									}
									case 1:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 2:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 3:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 4:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 5:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 6:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
										delete[] * tempppPointer;
										break;
									}
									default:
									{
										std::cout << "ProcessCodeSliceUnionDef Fail\n";
										break;
									}
									}
									strcat(temppUserDefTypeContent->Array, tempSubCode2);
								}
								else
								{
									/*if (tempSubCode1[tempSubCode1Index] == '[')
									{
										temppUserDefTypeContent->bArray = true;
									}
									else
									{*/
									std::cout << "ProcessCodeSliceUnionDef Fail\n";
									//}
								}
							}
						}

						if (bArray)
						{
							tempSubCode3[0] = tempSubCode[tempInt];
							tempSubCode3[1] = 0x0;
							strcat(temppUserDefTypeContent->Array, tempSubCode3);
						}

						if (tempSubCode[tempInt] == ']')
						{
							bArray = false;
						}

						tempSubCode3[0] = tempSubCode[tempInt];
						tempSubCode3[1] = 0x0;
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
					}

					tempInt++;
				}

				/*tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				tempInt += tempReturnLength;
				MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				tempInt += tempReturnLength;
				if (tempSubCode1[0] == '*')
				{
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					tempInt += tempReturnLength;
				}
				tempSubCode1[tempReturnLength - 1] = 0x0;
				strcpy(temppUserDefTypeContent->Name, tempSubCode1);
				strcpy(temppUserDefTypeContent->InterMediateName, "UserDefTypeContent_");
				IntToStrNew(temppUserDefType->ContentNum, tempStructNo);
				strcat(temppUserDefTypeContent->InterMediateName, tempStructNo);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeContent->InterMediateName);*/

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");

				AddStoreInterMediateUserDefTypeContentInfo(temppUserDefType, temppUserDefTypeContent);

				break;
			}
			default:
				break;
			}

		}

		pInterMediateNew->AddStoreInterMediateUserDefTypeInfo(temppUserDefType);
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		delete tempppSubCode;
		delete tempppSubCode1;
		delete tempppPointer;

		return 1;
	}

	//Ŀǰֻ֧�̶ֹ���ʽ��typedef struct �Ķ���,���Բ�֧�ֶ����struct�к��������û��Զ��������(ָ����������ָ��Ҳ����)
	int ProcessCodeSliceTypedefStructDef(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		char tempSubCode[150];
		char tempSubCode1[100];
		char tempSubCode2[100];
		char tempSubCode3[2];
		char** tempppSubCode;
		char** tempppSubCode1;
		int tempSubCode2Index = 0;
		int tempSubCode1Index = 0;
		bool bName = false;
		bool bArray = false;
		int tempInt = 0;
		int tempReturnLength = 0;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempReturnLBraceNum = 0;
		int tempReturnRBraceNum = 0;
		char tempStructNo[10];
		void** tempppPointer;
		PStoreInterMediateUserDefTypeInfo temppUserDefType;
		PStoreInterMediateUserDefTypeContenTypeInfo temppUserDefTypeContent;
		ProfixType tempReturnProfixType;
		ReturnType tempReturnReturnType;
		PUserDefStruct tempReturnUserDefStruct;
		PStoreInterMediateUserDefTypeInfo temppUserDefTypeInfo;

		tempppPointer = new void*;
		temppUserDefType = new StoreInterMediateUserDefTypeInfo;
		InitStoreInterMediateUserDefTypeInfo(temppUserDefType);
		tempppSubCode1 = new char*;
		*tempppSubCode1 = tempSubCode1;
		tempppSubCode = new char*;
		*tempppSubCode = tempSubCode;
		memset(tempSubCode, 0x0, 150);
		memset(tempSubCode1, 0x0, 100);
		memset(tempStructNo, 0x0, 10);
		memset(tempSubCode2, 0x0, 100);

		temppUserDefType->UserDefTypeType = 3;
		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		tempInt += tempReturnLength;
		MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);

		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		tempInt += tempReturnLength;
		MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);

		strcpy(temppUserDefType->DefTypeMainName, &(tempSubCode[tempInt]));
		strcpy(temppUserDefType->InterMediateName, "UserDefType_");
		IntToStrNew(pInterMediateNew->StoreInterMediateUserDefTypeInfoNum, tempStructNo);
		strcat(temppUserDefType->InterMediateName, tempStructNo);
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefType->InterMediateName);

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		//�ⲿ����ƵĲ���ͨ��,ֻ֧�̶ֹ���ʽ��д��
		if (strcmp(tempSubCode, "{") == 0)
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

			pInterMediateNew->InterMediateCodeLineNum++;
			pInterMediateNew->WriteInterMediateCodeLineNo++;
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
			tempLBraceNum++;
		}
		else
		{
			std::cout << "Process Code Slice Struct Def Fail\n";
		}
		while (tempLBraceNum != tempRBraceNum)
		{
			tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
			tempIndex = tempIndex + tempReturnLength + 2;
			tempInt = 0;
			tempReturnLBraceNum = 0;
			tempReturnRBraceNum = 0;
			tempSubCode2Index = 0;
			tempSubCode1Index = 0;
			bName = false;
			switch (CheckCodeLineHaveBrace((void**)tempppSubCode, &tempInt, &tempReturnLBraceNum, &tempReturnRBraceNum))
			{
			case 0:
			{
				tempLBraceNum += tempReturnLBraceNum;
				tempRBraceNum += tempReturnRBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
				break;
			}
			case 1:
			{
				tempRBraceNum += tempReturnRBraceNum;

				tempInt = 1;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "} ");

				MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				tempSubCode1[tempReturnLength - 1] = 0x0;
				strcpy(temppUserDefType->AnotherName[(temppUserDefType->AnotherNameNum)++], tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefType->InterMediateName);
				tempInt += tempReturnLength;

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), ";\r\n");
				break;
			}
			case -1:
			{
				tempLBraceNum += tempReturnLBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
				break;
			}
			case -2:
			{
				temppUserDefTypeContent = new StoreInterMediateUserDefTypeContenTypeInfo;
				InitStoreInterMediateUserDefTypeContenTypeInfo(temppUserDefTypeContent);

				CheckProfixType((void**)tempppSubCode, &tempInt, &tempReturnProfixType);
				if (tempReturnProfixType != ProfixType::ProfixType_unknownType)
				{
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
					tempInt += tempReturnLength;
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);

					//������Ȱ��չ̶���ʽ������,��ʵ�õķ���������CheckProfixType�����������ĳ��Ƚ����ַ���һ�θ���,ֱ������Profix����,����������Ӳ��������ķ�ʽ����
					if (tempReturnProfixType == ProfixType::staticconstType)
					{
						tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
						tempInt += tempReturnLength;
						MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					}
				}
				CheckReturnType((void**)tempppSubCode, &tempInt, &tempReturnReturnType, &tempReturnUserDefStruct);
				if (tempReturnReturnType != ReturnType::ReturnType_unknownType)
				{
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					tempInt += tempReturnLength;
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					if (tempReturnUserDefStruct != NULL)
					{
						pInterMediateNew->FindStoreInterMediateUserDefTypeInfo(tempSubCode1, &temppUserDefTypeInfo);
						if (temppUserDefTypeInfo != NULL)
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeInfo->InterMediateName);
						}
						else
						{
							std::cout << "ProcessCodeSliceTypedefStructDef Error\n";
							throw 1;
							return 0;
						}
					}
					else
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					}
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				}
				else
				{
					std::cout << "ProcessCodeSliceTypedefStructDef Error\n";
					throw 1;
					return 0;
				}
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				//tempInt += tempReturnLength;
				/*tempSubCode1[tempReturnLength - 1] = 0x0;*/
				while (tempSubCode[tempInt] != 0x0)
				{
					if (CheckNamableCharacter(&(tempSubCode[tempInt])))
					{
						tempSubCode2[tempSubCode2Index++] = tempSubCode[tempInt];
					}
					else
					{
						if (tempSubCode2Index > 0)
						{
							tempSubCode2[tempSubCode2Index] = 0x0;
							tempSubCode2Index = 0;
							if (!bName)
							{
								bName = true;
								strcpy(temppUserDefTypeContent->Name, tempSubCode2);
								strcpy(temppUserDefTypeContent->InterMediateName, "UserDefTypeContent_");
								IntToStrNew(temppUserDefType->ContentNum, tempStructNo);
								strcat(temppUserDefTypeContent->InterMediateName, tempStructNo);
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeContent->InterMediateName);

								if (tempSubCode[tempInt] == '[')
								{
									temppUserDefTypeContent->bArray = true;
									bArray = true;
								}
							}
							else
							{
								if (bArray)
								{
									switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode2, tempppPointer))
									{
									case 0:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
										break;
									}
									case 1:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 2:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 3:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 4:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 5:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 6:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
										delete[] * tempppPointer;
										break;
									}
									default:
									{
										std::cout << "ProcessCodeSliceTypedefStructDef Fail\n";
										break;
									}
									}
									strcat(temppUserDefTypeContent->Array, tempSubCode2);
								}
								else
								{
									/*if (tempSubCode1[tempSubCode1Index] == '[')
									{
										temppUserDefTypeContent->bArray = true;
									}
									else
									{*/
									std::cout << "ProcessCodeSliceTypedefStructDef Fail\n";
									//}
								}
							}
						}

						if (bArray)
						{
							tempSubCode3[0] = tempSubCode[tempInt];
							tempSubCode3[1] = 0x0;
							strcat(temppUserDefTypeContent->Array, tempSubCode3);
						}

						if (tempSubCode[tempInt] == ']')
						{
							bArray = false;
						}

						tempSubCode3[0] = tempSubCode[tempInt];
						tempSubCode3[1] = 0x0;
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
					}

					tempInt++;
				}

				/*tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				tempInt += tempReturnLength;
				MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				tempInt += tempReturnLength;
				if (tempSubCode1[0] == '*')
				{
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					tempInt += tempReturnLength;
				}
				tempSubCode1[tempReturnLength - 1] = 0x0;
				strcpy(temppUserDefTypeContent->Name, tempSubCode1);
				strcpy(temppUserDefTypeContent->InterMediateName, "UserDefTypeContent_");
				IntToStrNew(temppUserDefType->ContentNum, tempStructNo);
				strcat(temppUserDefTypeContent->InterMediateName, tempStructNo);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeContent->InterMediateName);*/

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");

				AddStoreInterMediateUserDefTypeContentInfo(temppUserDefType, temppUserDefTypeContent);

				break;
			}
			default:
				break;
			}

		}

		pInterMediateNew->AddStoreInterMediateUserDefTypeInfo(temppUserDefType);
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		delete tempppSubCode1;
		delete tempppSubCode;
		delete tempppPointer;

		return 1;
	}

	//Ŀǰֻ֧�̶ֹ���ʽ��typedef union �Ķ���,���Բ�֧�ֶ����union�к��������û��Զ��������(ָ����������ָ��Ҳ����)
	int ProcessCodeSliceTypedefUnionDef(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		char tempSubCode[150];
		char tempSubCode1[100];
		char tempSubCode2[100];
		char tempSubCode3[2];
		char** tempppSubCode;
		char** tempppSubCode1;
		int tempSubCode2Index = 0;
		int tempSubCode1Index = 0;
		int tempInt = 0;
		int tempReturnLength = 0;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempReturnLBraceNum = 0;
		int tempReturnRBraceNum = 0;
		char tempStructNo[10];
		bool bName = false;
		bool bArray = false;
		void** tempppPointer;
		PStoreInterMediateUserDefTypeInfo temppUserDefType;
		PStoreInterMediateUserDefTypeContenTypeInfo temppUserDefTypeContent;
		ProfixType tempReturnProfixType;
		ReturnType tempReturnReturnType;
		PUserDefStruct tempReturnUserDefStruct;
		PStoreInterMediateUserDefTypeInfo temppUserDefTypeInfo;

		tempppPointer = new void*;
		temppUserDefType = new StoreInterMediateUserDefTypeInfo;
		InitStoreInterMediateUserDefTypeInfo(temppUserDefType);
		tempppSubCode1 = new char*;
		*tempppSubCode1 = tempSubCode1;
		tempppSubCode = new char*;
		*tempppSubCode = tempSubCode;
		memset(tempSubCode, 0x0, 150);
		memset(tempSubCode1, 0x0, 100);
		memset(tempStructNo, 0x0, 10);
		memset(tempSubCode2, 0x0, 100);

		temppUserDefType->UserDefTypeType = 4;
		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		strcpy(temppUserDefType->InterMediateName, "UserDefType_");
		IntToStrNew(pInterMediateNew->StoreInterMediateUserDefTypeInfoNum, tempStructNo);
		strcat(temppUserDefType->InterMediateName, tempStructNo);

		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		//�ⲿ����ƵĲ���ͨ��,ֻ֧�̶ֹ���ʽ��д��
		if (strcmp(tempSubCode, "{") == 0)
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

			pInterMediateNew->InterMediateCodeLineNum++;
			pInterMediateNew->WriteInterMediateCodeLineNo++;
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
			tempLBraceNum++;
		}
		else
		{
			std::cout << "Process Code Slice Struct Def Fail\n";
		}
		while (tempLBraceNum != tempRBraceNum)
		{
			tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
			tempIndex = tempIndex + tempReturnLength + 2;
			tempInt = 0;
			tempReturnLBraceNum = 0;
			tempReturnRBraceNum = 0;
			tempSubCode2Index = 0;
			tempSubCode1Index = 0;
			bName = false;
			switch (CheckCodeLineHaveBrace((void**)tempppSubCode, &tempInt, &tempReturnLBraceNum, &tempReturnRBraceNum))
			{
			case 0:
			{
				tempLBraceNum += tempReturnLBraceNum;
				tempRBraceNum += tempReturnRBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), ";\r\n");
				break;
			}
			case 1:
			{
				tempRBraceNum += tempReturnRBraceNum;

				tempInt = 1;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "} ");

				MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				tempSubCode1[tempReturnLength - 1] = 0x0;
				strcpy(temppUserDefType->AnotherName[(temppUserDefType->AnotherNameNum)++], tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefType->InterMediateName);
				tempInt += tempReturnLength;

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), ";\r\n");
				break;

				//tempRBraceNum += tempReturnRBraceNum;
				//strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);
				//strcat((*(char**)(pInterMediateNew->OutputBuffer)), ";\r\n");
				//break;
			}
			case -1:
			{
				tempLBraceNum += tempReturnLBraceNum;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), ";\r\n");
				break;
			}
			case -2:
			{
				temppUserDefTypeContent = new StoreInterMediateUserDefTypeContenTypeInfo;
				InitStoreInterMediateUserDefTypeContenTypeInfo(temppUserDefTypeContent);

				CheckProfixType((void**)tempppSubCode, &tempInt, &tempReturnProfixType);
				if (tempReturnProfixType != ProfixType::ProfixType_unknownType)
				{
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
					tempInt += tempReturnLength;
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);

					//������Ȱ��չ̶���ʽ������,��ʵ�õķ���������CheckProfixType�����������ĳ��Ƚ����ַ���һ�θ���,ֱ������Profix����,����������Ӳ��������ķ�ʽ����
					if (tempReturnProfixType == ProfixType::staticconstType)
					{
						tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
						tempInt += tempReturnLength;
						MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					}
				}
				CheckReturnType((void**)tempppSubCode, &tempInt, &tempReturnReturnType, &tempReturnUserDefStruct);
				if (tempReturnReturnType != ReturnType::ReturnType_unknownType)
				{
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					tempInt += tempReturnLength;
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					if (tempReturnUserDefStruct != NULL)
					{
						pInterMediateNew->FindStoreInterMediateUserDefTypeInfo(tempSubCode1, &temppUserDefTypeInfo);
						if (temppUserDefTypeInfo != NULL)
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeInfo->InterMediateName);
						}
						else
						{
							std::cout << "ProcessCodeSliceTypedefUnionDef Error\n";
							throw 1;
							return 0;
						}
					}
					else
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					}
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				}
				else
				{
					std::cout << "ProcessCodeSliceTypedefUnionDef Error\n";
					throw 1;
					return 0;
				}
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				//tempInt += tempReturnLength;
				/*tempSubCode1[tempReturnLength - 1] = 0x0;*/
				while (tempSubCode[tempInt] != 0x0)
				{
					if (CheckNamableCharacter(&(tempSubCode[tempInt])))
					{
						tempSubCode2[tempSubCode2Index++] = tempSubCode[tempInt];
					}
					else
					{
						if (tempSubCode2Index > 0)
						{
							tempSubCode2[tempSubCode2Index] = 0x0;
							tempSubCode2Index = 0;
							if (!bName)
							{
								bName = true;
								strcpy(temppUserDefTypeContent->Name, tempSubCode2);
								strcpy(temppUserDefTypeContent->InterMediateName, "UserDefTypeContent_");
								IntToStrNew(temppUserDefType->ContentNum, tempStructNo);
								strcat(temppUserDefTypeContent->InterMediateName, tempStructNo);
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeContent->InterMediateName);

								if (tempSubCode[tempInt] == '[')
								{
									temppUserDefTypeContent->bArray = true;
									bArray = true;
								}
							}
							else
							{
								if (bArray)
								{
									switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode2, tempppPointer))
									{
									case 0:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
										break;
									}
									case 1:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 2:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 3:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 4:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 5:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
										break;
									}
									case 6:
									{
										strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
										delete[] * tempppPointer;
										break;
									}
									default:
									{
										std::cout << "ProcessCodeSliceTypedefUnionDef Fail\n";
										break;
									}
									}
									strcat(temppUserDefTypeContent->Array, tempSubCode2);
								}
								else
								{
									/*if (tempSubCode1[tempSubCode1Index] == '[')
									{
										temppUserDefTypeContent->bArray = true;
									}
									else
									{*/
									std::cout << "ProcessCodeSliceTypedefUnionDef Fail\n";
									//}
								}
							}
						}

						if (bArray)
						{
							tempSubCode3[0] = tempSubCode[tempInt];
							tempSubCode3[1] = 0x0;
							strcat(temppUserDefTypeContent->Array, tempSubCode3);
						}

						if (tempSubCode[tempInt] == ']')
						{
							bArray = false;
						}

						tempSubCode3[0] = tempSubCode[tempInt];
						tempSubCode3[1] = 0x0;
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
					}

					tempInt++;
				}

				/*tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				tempInt += tempReturnLength;
				MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				tempInt += tempReturnLength;
				if (tempSubCode1[0] == '*')
				{
					MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
					tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
					tempInt += tempReturnLength;
				}
				tempSubCode1[tempReturnLength - 1] = 0x0;
				strcpy(temppUserDefTypeContent->Name, tempSubCode1);
				strcpy(temppUserDefTypeContent->InterMediateName, "UserDefTypeContent_");
				IntToStrNew(temppUserDefType->ContentNum, tempStructNo);
				strcat(temppUserDefTypeContent->InterMediateName, tempStructNo);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeContent->InterMediateName);*/

				pInterMediateNew->InterMediateCodeLineNum++;
				pInterMediateNew->WriteInterMediateCodeLineNo++;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");

				AddStoreInterMediateUserDefTypeContentInfo(temppUserDefType, temppUserDefTypeContent);

				break;
			}
			default:
				break;
			}

		}

		pInterMediateNew->AddStoreInterMediateUserDefTypeInfo(temppUserDefType);
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		delete tempppSubCode1;
		delete tempppSubCode;
		delete tempppPointer;

		return 1;
	}

	int ProcessCodeSliceCodeBlockTypeLBraceType(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		int tempReturnLength = 0;
		char tempSubCode[150];
		PStoreInterMediateBraceInfo temppBraceInfo;
		PStoreInterMediateCodeBlockInfo temppCodeBlockInfo;

		memset(tempSubCode, 0x0, 150);

		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		if (strcmp(tempSubCode, "{") == 0)
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

			temppBraceInfo = new StoreInterMediateBraceInfo;
			temppCodeBlockInfo = new StoreInterMediateCodeBlockInfo;

			InitStoreInterMediateBraceInfo(temppBraceInfo);
			InitStoreInterMediateCodeBlockInfo(temppCodeBlockInfo);

			temppBraceInfo->BraceType = -1;
			temppBraceInfo->bMatched = false;
			temppBraceInfo->InterMediateCodeLineNo = pInterMediateNew->WriteInterMediateCodeLineNo;
			temppBraceInfo->pParent = temppCodeBlockInfo;
			pInterMediateNew->AddStoreInterMediateBraceInfo(temppBraceInfo, -1);

			temppCodeBlockInfo->bMatched = false;
			temppCodeBlockInfo->StartInterMediateCodeLineNo = pInterMediateNew->WriteInterMediateCodeLineNo;
			temppCodeBlockInfo->pLBrace = temppBraceInfo;
			pInterMediateNew->AddStoreInterMediateCodeBlockInfo(temppCodeBlockInfo);
		}
		else
		{
			std::cout << "ProcessCodeSliceCodeBlockTypeLBraceType Fail\n";
		}

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		return 1;
	}

	int ProcessCodeSliceCodeBlockTypeRBraceType(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		int tempReturnLength = 0;
		char tempSubCode[150];
		PStoreInterMediateBraceInfo temppBraceInfo;
		PStoreInterMediateCodeBlockInfo temppCodeBlockInfo;

		memset(tempSubCode, 0x0, 150);

		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		if (strcmp(tempSubCode, "}") == 0)
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode);

			temppBraceInfo = new StoreInterMediateBraceInfo;

			InitStoreInterMediateBraceInfo(temppBraceInfo);

			if (!pInterMediateNew->GetStoreInterMediateCodeBlockInfoLastUnMatchedElement(&temppCodeBlockInfo))
			{
				std::cout << "ProcessCodeSliceCodeBlockTypeRBraceType Fail\n";
				throw 1;
				return 0;
			}

			temppBraceInfo->BraceType = 1;
			temppBraceInfo->bMatched = true;
			temppBraceInfo->InterMediateCodeLineNo = pInterMediateNew->WriteInterMediateCodeLineNo;
			temppBraceInfo->pParent = temppCodeBlockInfo;
			temppBraceInfo->pMatched = temppCodeBlockInfo->pLBrace;
			pInterMediateNew->AddStoreInterMediateBraceInfo(temppBraceInfo, 1);

			(temppCodeBlockInfo->pLBrace)->bMatched = true;
			(temppCodeBlockInfo->pLBrace)->pMatched = temppBraceInfo;
			temppCodeBlockInfo->bMatched = true;
			temppCodeBlockInfo->StopInterMediateCodeLineNo = pInterMediateNew->WriteInterMediateCodeLineNo;
			temppCodeBlockInfo->InterMediateCodeLineNum = temppCodeBlockInfo->StopInterMediateCodeLineNo - temppCodeBlockInfo->StartInterMediateCodeLineNo + 1;
			temppCodeBlockInfo->pRBrace = temppBraceInfo;
		}
		else
		{
			std::cout << "ProcessCodeSliceCodeBlockTypeRBraceType Fail\n";
		}

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		return 1;
	}

	int ProcessCodeSliceVarDeclareType(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		int tempReturnLength = 0;
		int tempInt = 0;
		char tempStructNo[5];
		char tempSubCode[150];
		char tempSubCode1[100];
		char tempSubCode2[100];
		char tempSubCode3[2];
		int tempSubCode2Index = 0;
		int tempSubCode1Index = 0;
		bool bName = false;
		bool bArray = false;
		char** tempppSubCode;
		char** tempppSubCode1;
		void** tempppPointer;
		ProfixType tempReturnProfixType;
		ReturnType tempReturnReturnType;
		PUserDefStruct tempReturnUserDefStruct;
		PStoreInterMediateUserDefTypeInfo temppUserDefTypeInfo;
		PStoreInterMediateVarDefInfo temppVar;
		PStoreInterMediateCodeBlockInfo temppCodeBlock;

		tempppPointer = new void*;
		temppVar = new StoreInterMediateVarDefInfo;
		InitStoreInterMediateVarDefInfo(temppVar);
		tempppSubCode = new char*;
		tempppSubCode1 = new char*;
		*tempppSubCode = tempSubCode;
		*tempppSubCode1 = tempSubCode1;
		memset(tempSubCode, 0x0, 150);
		memset(tempSubCode1, 0x0, 100);
		memset(tempSubCode2, 0x0, 100);
		memset(tempStructNo, 0x0, 5);

		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		CheckProfixType((void**)tempppSubCode, &tempInt, &tempReturnProfixType);
		if (tempReturnProfixType != ProfixType::ProfixType_unknownType)
		{
			tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
			tempInt += tempReturnLength;
			MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);

			//������Ȱ��չ̶���ʽ������,��ʵ�õķ���������CheckProfixType�����������ĳ��Ƚ����ַ���һ�θ���,ֱ������Profix����,����������Ӳ��������ķ�ʽ����
			if (tempReturnProfixType == ProfixType::staticconstType)
			{
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				tempInt += tempReturnLength;
				MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
			}
		}
		CheckReturnType((void**)tempppSubCode, &tempInt, &tempReturnReturnType, &tempReturnUserDefStruct);
		if (tempReturnReturnType != ReturnType::ReturnType_unknownType)
		{
			tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
			tempInt += tempReturnLength;
			MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
			if (tempReturnUserDefStruct != NULL)
			{
				pInterMediateNew->FindStoreInterMediateUserDefTypeInfo(tempSubCode1, &temppUserDefTypeInfo);
				if (temppUserDefTypeInfo != NULL)
				{
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeInfo->InterMediateName);
				}
				else
				{
					std::cout << "ProcessCodeSliceVarDeclareType Error\n";
					throw 1;
					return 0;
				}
			}
			else
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
			}
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		}
		else
		{
			std::cout << "ProcessCodeSliceVarDeclareType Error\n";
			throw 1;
			return 0;
		}

		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
		//tempInt += tempReturnLength;
		/*tempSubCode1[tempReturnLength - 1] = 0x0;*/
		while (tempSubCode[tempInt] != 0x0)
		{
			if (CheckNamableCharacter(&(tempSubCode[tempInt])))
			{
				tempSubCode2[tempSubCode2Index++] = tempSubCode[tempInt];
			}
			else
			{
				if (tempSubCode2Index > 0)
				{
					tempSubCode2[tempSubCode2Index] = 0x0;
					tempSubCode2Index = 0;
					if (!bName)
					{
						bName = true;
						strcpy(temppVar->VarName, tempSubCode2);
						strcpy(temppVar->InterMediateName, "Var_");
						IntToStrNew(pInterMediateNew->StoreInterMediateVarDefInfoNum, tempStructNo);
						strcat(temppVar->InterMediateName, tempStructNo);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppVar->InterMediateName);

						//update at 23.3.9
						pInterMediateNew->GetStoreInterMediateCodeBlockInfoLastUnMatchedElement(&temppCodeBlock);
						if (temppCodeBlock != NULL)
						{
							temppVar->pCodeBlock = temppCodeBlock;
						}
						temppVar->InterMediateCodeLineNo = pInterMediateNew->WriteInterMediateCodeLineNo;

						pInterMediateNew->AddStoreInterMediateVarDefInfo(temppVar);
						//////////////////

						if (tempSubCode[tempInt] == '[')
						{
							temppVar->bArray = true;
							bArray = true;
						}
					}
					else
					{
						if (bArray)
						{
							switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode2, tempppPointer))
							{
							case 0:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
								break;
							}
							case 1:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 2:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 3:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 4:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 5:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 6:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
								delete[] * tempppPointer;
								break;
							}
							default:
							{
#ifdef _DEBUG
								std::cout << "ProcessCodeSliceVarDeclareType Fail\n";
#endif
								break;
							}
							}
							strcat(temppVar->Array, tempSubCode2);
						}
						else
						{
#ifdef _DEBUG
							std::cout << "ProcessCodeSliceVarDeclareType Fail\n";
#endif
						}
							}
						}

				if (bArray)
				{
					tempSubCode3[0] = tempSubCode[tempInt];
					tempSubCode3[1] = 0x0;
					strcat(temppVar->Array, tempSubCode3);
				}

				if (tempSubCode[tempInt] == ']')
				{
					bArray = false;
					bName = false;
				}

				if (tempSubCode[tempInt] == ',')
				{
					temppVar = new StoreInterMediateVarDefInfo;
					InitStoreInterMediateVarDefInfo(temppVar);

					//fix bug at 23.4.3
					bName = false;
				}

				tempSubCode3[0] = tempSubCode[tempInt];
				tempSubCode3[1] = 0x0;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
					}

			tempInt++;
				}
		/*strcpy(temppVar->VarName, tempSubCode1);
		strcpy(temppVar->InterMediateName, "Var_");
		IntToStrNew(pInterMediateNew->StoreInterMediateVarDefInfoNum, tempStructNo);
		strcat(temppVar->InterMediateName, tempStructNo);*/
		/*strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppVar->InterMediateName);*/

		/*pInterMediateNew->GetStoreInterMediateCodeBlockInfoLastUnMatchedElement(&temppCodeBlock);
		if (temppCodeBlock != NULL)
		{
			temppVar->pCodeBlock = temppCodeBlock;
		}
		temppVar->InterMediateCodeLineNo = pInterMediateNew->WriteInterMediateCodeLineNo;

		pInterMediateNew->AddStoreInterMediateVarDefInfo(temppVar);*/

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");

		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		return 1;
			}

	int ProcessCodeSliceVarAssignmentType(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		int tempReturnLength = 0;
		int tempInt = 0;
		int tempSubCodeIndex = 0;
		int tempSubCode1Index = 0;
		char tempStructNo[5];
		char tempSubCode[400];
		char tempSubCode1[100];
		char tempSubCode3[100];
		char tempSubCode2[2];
		char** tempppSubCode;
		char** tempppSubCode1;
		void** tempppPointer;
		PStoreInterMediateVarDefInfo temppVar;

		tempppPointer = new void*;
		tempppSubCode = new char*;
		tempppSubCode1 = new char*;
		*tempppSubCode = tempSubCode;
		*tempppSubCode1 = tempSubCode1;
		memset(tempSubCode, 0x0, 400);
		memset(tempSubCode1, 0x0, 100);
		memset(tempStructNo, 0x0, 5);
		memset(tempSubCode3, 0x0, 100);

		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		//fix bug at 23.3.13
		/*tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
		tempInt += tempReturnLength;*/

		while (tempSubCode[tempInt] != '=')
		{
			//update at 23.4.4 to handle x++;
			if ((tempSubCode[tempInt] == '+' && tempSubCode[tempInt + 1] == '+') || (tempSubCode[tempInt] == '-' && tempSubCode[tempInt + 1] == '-'))
			{
				break;
			}

			if (CheckNamableCharacter((&(tempSubCode[tempInt]))) == 1)
			{
				tempSubCode3[tempSubCode1Index++] = tempSubCode[tempInt];
			}
			else
			{
				if (tempSubCode1Index != 0)
				{
					tempSubCode3[tempSubCode1Index] = 0x0;
					tempSubCode1Index = 0;

					switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode3, tempppPointer))
					{
					case 0:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
						break;
					}
					case 1:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 2:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 3:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 4:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 5:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 6:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
						delete[] * tempppPointer;
						break;
					}
					default:
					{
						std::cout << "ProcessCodeSliceVarAssignmentType Fail\n";
						break;
					}
					}
				}

				tempSubCode2[0] = tempSubCode[tempInt];
				tempSubCode2[1] = 0x0;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
			}

			tempInt++;
		}
		tempSubCode3[tempSubCode1Index] = 0x0;
		tempSubCode1Index = 0;

		switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode3, tempppPointer))
		{
		case 0:
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
			break;
		}
		case 1:
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
			break;
		}
		case 2:
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
			break;
		}
		case 3:
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
			break;
		}
		case 4:
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
			break;
		}
		case 5:
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
			break;
		}
		case 6:
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
			delete[] * tempppPointer;
			break;
		}
		default:
		{
			std::cout << "ProcessCodeSliceVarAssignmentType Fail\n";
			break;
		}
		}
		//strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");

		/*pInterMediateNew->FindStoreInterMediateVarDefInfo(tempSubCode1, &temppVar);
		if (temppVar != NULL)
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppVar->InterMediateName);
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		}
		else
		{
			std::cout << "ProcessCodeSliceVarAssignmentType Fail\n";
			return 0;
		}*/

		//update at 23.4.4 to handle x++;
		if ((tempSubCode[tempInt] == '+' && tempSubCode[tempInt + 1] == '+') || (tempSubCode[tempInt] == '-' && tempSubCode[tempInt + 1] == '-'))
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), &(tempSubCode[tempInt]));
		}
		else
		{
			MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
			tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
			tempInt += tempReturnLength;

			if (strcmp(tempSubCode1, "=") == 0)
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
			}
			else
			{
				std::cout << "ProcessCodeSliceVarAssignmentType Fail\n";
				throw 1;
				return 0;
			}

			MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
			while (tempSubCode[tempInt] != 0x0)
			{
				if (CheckNamableCharacter(&(tempSubCode[tempInt])))
				{
					tempSubCode1[tempSubCodeIndex++] = tempSubCode[tempInt];
				}
				else
				{
					if (tempSubCodeIndex != 0)
					{
						tempSubCode1[tempSubCodeIndex] = 0x0;
						switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode1, tempppPointer))
						{
						case 0:
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
							break;
						}
						case 1:
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
							break;
						}
						case 2:
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
							break;
						}
						case 3:
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
							break;
						}
						case 4:
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
							break;
						}
						case 5:
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
							break;
						}
						case 6:
						{
							strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
							delete[] * tempppPointer;
							break;
						}
						default:
						{
							std::cout << "ProcessCodeSliceVarAssignmentType Fail\n";
							break;
						}
						}
					}
					tempSubCodeIndex = 0;
					tempSubCode2[0] = tempSubCode[tempInt];
					tempSubCode2[1] = 0x0;
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
				}

				tempInt++;
			}
		}

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		return 1;
	}

	int ProcessCodeSliceVarDefType(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		int tempReturnLength = 0;
		int tempInt = 0;
		int tempSubCodeIndex = 0;
		char tempStructNo[5];
		char tempSubCode[150];
		char tempSubCode1[100];
		char tempSubCode2[2];
		char tempSubCode3[100];
		int tempSubCode3Index = 0;
		int tempSubCode1Index = 0;
		bool bName = false;
		bool bArray = false;
		char** tempppSubCode;
		char** tempppSubCode1;
		void** tempppPointer;
		ProfixType tempReturnProfixType;
		ReturnType tempReturnReturnType;
		PUserDefStruct tempReturnUserDefStruct;
		PStoreInterMediateUserDefTypeInfo temppUserDefTypeInfo;
		PStoreInterMediateVarDefInfo temppVar;
		PStoreInterMediateCodeBlockInfo temppCodeBlock;

		temppVar = new StoreInterMediateVarDefInfo;
		InitStoreInterMediateVarDefInfo(temppVar);
		tempppPointer = new void*;
		tempppSubCode = new char*;
		tempppSubCode1 = new char*;
		*tempppSubCode = tempSubCode;
		*tempppSubCode1 = tempSubCode1;
		memset(tempSubCode, 0x0, 150);
		memset(tempSubCode1, 0x0, 100);
		memset(tempStructNo, 0x0, 5);
		memset(tempSubCode3, 0x0, 100);

		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		CheckProfixType((void**)tempppSubCode, &tempInt, &tempReturnProfixType);
		if (tempReturnProfixType != ProfixType::ProfixType_unknownType)
		{
			tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
			tempInt += tempReturnLength;
			MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);

			//������Ȱ��չ̶���ʽ������,��ʵ�õķ���������CheckProfixType�����������ĳ��Ƚ����ַ���һ�θ���,ֱ������Profix����,����������Ӳ��������ķ�ʽ����
			if (tempReturnProfixType == ProfixType::staticconstType)
			{
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				tempInt += tempReturnLength;
				MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
			}
		}
		CheckReturnType((void**)tempppSubCode, &tempInt, &tempReturnReturnType, &tempReturnUserDefStruct);
		if (tempReturnReturnType != ReturnType::ReturnType_unknownType)
		{
			tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
			tempInt += tempReturnLength;
			MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
			if (tempReturnUserDefStruct != NULL)
			{
				pInterMediateNew->FindStoreInterMediateUserDefTypeInfo(tempSubCode1, &temppUserDefTypeInfo);
				if (temppUserDefTypeInfo != NULL)
				{
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeInfo->InterMediateName);
				}
				else
				{
					std::cout << "ProcessCodeSliceVarDefType Error\n";
					throw 1;
					return 0;
				}
			}
			else
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
			}
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		}
		else
		{
			std::cout << "ProcessCodeSliceVarDefType Error\n";
			throw 1;
			return 0;
		}
		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
		//tempInt += tempReturnLength;

		while (tempSubCode[tempInt] != '=')
		{
			if (CheckNamableCharacter(&(tempSubCode[tempInt])))
			{
				tempSubCode3[tempSubCode3Index++] = tempSubCode[tempInt];
			}
			else
			{
				if (tempSubCode3Index > 0)
				{
					tempSubCode3[tempSubCode3Index] = 0x0;
					tempSubCode3Index = 0;
					if (!bName)
					{
						bName = true;
						strcpy(temppVar->VarName, tempSubCode3);
						strcpy(temppVar->InterMediateName, "Var_");
						IntToStrNew(pInterMediateNew->StoreInterMediateVarDefInfoNum, tempStructNo);
						strcat(temppVar->InterMediateName, tempStructNo);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppVar->InterMediateName);

						if (tempSubCode[tempInt] == '[')
						{
							temppVar->bArray = true;
							bArray = true;
						}
					}
					else
					{
						if (bArray)
						{
							switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode3, tempppPointer))
							{
							case 0:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
								break;
							}
							case 1:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 2:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 3:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 4:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 5:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
								break;
							}
							case 6:
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
								delete[] * tempppPointer;
								break;
							}
							default:
							{
								std::cout << "ProcessCodeSliceVarDefType Fail\n";
								break;
							}
							}
							strcat(temppVar->Array, tempSubCode3);
						}
						else
						{
							/*if (tempSubCode1[tempSubCode1Index] == '[')
							{
								temppVar->bArray = true;
							}
							else
							{*/
							std::cout << "ProcessCodeSliceVarDefType Fail\n";
							//}
						}
					}
				}

				if (bArray)
				{
					tempSubCode2[0] = tempSubCode[tempInt];
					tempSubCode2[1] = 0x0;
					strcat(temppVar->Array, tempSubCode2);
				}

				if (tempSubCode[tempInt] == ']')
				{
					bArray = false;
				}

				tempSubCode2[0] = tempSubCode[tempInt];
				tempSubCode2[1] = 0x0;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
			}

			tempInt++;
		}
		/*strcpy(temppVar->VarName, tempSubCode1);
		strcpy(temppVar->InterMediateName, "Var_");
		IntToStrNew(pInterMediateNew->StoreInterMediateVarDefInfoNum, tempStructNo);
		strcat(temppVar->InterMediateName, tempStructNo);*/
		/*strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppVar->InterMediateName);*/

		if (tempSubCode3Index > 0)
		{
			tempSubCode3[tempSubCode3Index] = 0x0;
			tempSubCode3Index = 0;
			if (!bName)
			{
				bName = true;
				strcpy(temppVar->VarName, tempSubCode3);
				strcpy(temppVar->InterMediateName, "Var_");
				IntToStrNew(pInterMediateNew->StoreInterMediateVarDefInfoNum, tempStructNo);
				strcat(temppVar->InterMediateName, tempStructNo);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppVar->InterMediateName);

				if (tempSubCode1[tempSubCode1Index] == '[')
				{
					temppVar->bArray = true;
				}
			}
			else
			{
				if (temppVar->bArray)
				{
					switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode3, tempppPointer))
					{
					case 0:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
						break;
					}
					case 1:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 2:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 3:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 4:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 5:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 6:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
						delete[] * tempppPointer;
						break;
					}
					default:
					{
						std::cout << "ProcessCodeSliceVarDefType Fail\n";
						break;
					}
					}
					strcat(temppVar->Array, tempSubCode3);
				}
				else
				{
					/*if (tempSubCode1[tempSubCode1Index] == '[')
					{
						temppVar->bArray = true;
					}
					else
					{*/
					std::cout << "ProcessCodeSliceVarDefType Fail\n";
					//}
				}
			}
		}

		//strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");

		pInterMediateNew->GetStoreInterMediateCodeBlockInfoLastUnMatchedElement(&temppCodeBlock);
		if (temppCodeBlock != NULL)
		{
			temppVar->pCodeBlock = temppCodeBlock;
		}
		temppVar->InterMediateCodeLineNo = pInterMediateNew->WriteInterMediateCodeLineNo;

		pInterMediateNew->AddStoreInterMediateVarDefInfo(temppVar);

		MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
		tempInt += tempReturnLength;

		if (strcmp(tempSubCode1, "=") == 0)
		{
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		}
		else
		{
			std::cout << "ProcessCodeSliceVarDefType Fail\n";
			throw 1;
			return 0;
		}

		MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
		while (tempSubCode[tempInt] != 0x0)
		{
			if (CheckNamableCharacter(&(tempSubCode[tempInt])))
			{
				tempSubCode1[tempSubCodeIndex++] = tempSubCode[tempInt];
			}
			else
			{
				if (tempSubCodeIndex != 0)
				{
					tempSubCode1[tempSubCodeIndex] = 0x0;
					switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode1, tempppPointer))
					{
					case 0:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
						break;
					}
					case 1:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 2:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 3:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 4:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 5:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 6:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
						delete[] * tempppPointer;
						break;
					}
					default:
					{
						std::cout << "ProcessCodeSliceVarDefType Fail\n";
						break;
					}
					}
				}
				tempSubCodeIndex = 0;
				tempSubCode2[0] = tempSubCode[tempInt];
				tempSubCode2[1] = 0x0;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
			}

			tempInt++;
		}

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		return 1;
	}

	int ProcessCodeSliceCodeBlockTypeOnlyFunctionCallType(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		int tempReturnLength = 0;
		int tempInt = 0;
		int tempSubCodeIndex = 0;
		char tempSubCode[400];
		char tempSubCode1[300];
		char tempSubCode2[2];
		char tempStructNo[5];
		char** tempppSubCode;
		char** tempppSubCode1;
		void** tempppPointer;
		PStoreInterMediateUserDefFunctionInfo temppFunction;

		tempppPointer = new void*;
		tempppSubCode = new char*;
		tempppSubCode1 = new char*;
		*tempppSubCode = tempSubCode;
		*tempppSubCode1 = tempSubCode1;
		memset(tempSubCode, 0x0, 400);
		memset(tempSubCode1, 0x0, 300);
		memset(tempStructNo, 0x0, 5);

		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		while (tempSubCode[tempInt] != 0x0)
		{
			if (CheckNamableCharacter(&(tempSubCode[tempInt])))
			{
				tempSubCode1[tempSubCodeIndex++] = tempSubCode[tempInt];
			}
			else
			{
				/*if (CheckNamableCharacter(&(tempSubCode[tempInt - 1])) && tempSubCode[tempInt] == '(')
				{
					tempSubCode1[tempSubCodeIndex] = 0x0;
					if (pInterMediateNew->FindStoreInterMediateUserDefFunctionInfo(tempSubCode1, (PStoreInterMediateUserDefFunctionInfo*)tempppPointer))
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
					}
					else
					{
						temppFunction = new StoreInterMediateUserDefFunctionInfo;
						InitStoreInterMediateUserDefFunctionInfo(temppFunction);

						strcpy(temppFunction->UserDefFunctionName, tempSubCode1);
						strcpy(temppFunction->InterMediateName, "Function_");
						IntToStrNew(pInterMediateNew->StoreInterMediateUserDefFunctionInfoNum, tempStructNo);
						strcat(temppFunction->InterMediateName, tempStructNo);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppFunction->InterMediateName);

						pInterMediateNew->AddStoreInterMediateUserDefFunctionInfo(temppFunction);
					}
				}
				else
				{*/
				if (tempSubCodeIndex != 0)
				{
					tempSubCode1[tempSubCodeIndex] = 0x0;
					switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode1, tempppPointer))
					{
					case 0:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
						break;
					}
					case 1:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 2:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 3:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 4:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 5:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 6:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
						delete[] * tempppPointer;
						break;
					}
					default:
					{
						std::cout << "ProcessCodeSliceCodeBlockTypeOnlyFunctionCallType Fail\n";
						break;
					}
					}
				}
				/*}*/

				tempSubCodeIndex = 0;
				tempSubCode2[0] = tempSubCode[tempInt];
				tempSubCode2[1] = 0x0;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
			}

			tempInt++;
		}

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		return 1;
	}

	int ProcessCodeSliceSyntaxKeyCodeLineType(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		int tempReturnLength = 0;
		int tempInt = 0;
		int tempSubCodeIndex = 0;
		char tempSubCode[400];
		char tempSubCode1[100];
		char tempSubCode2[2];
		char** tempppSubCode;
		char** tempppSubCode1;
		void** tempppPointer;

		tempppPointer = new void*;
		tempppSubCode = new char*;
		tempppSubCode1 = new char*;
		*tempppSubCode = tempSubCode;
		*tempppSubCode1 = tempSubCode1;
		memset(tempSubCode, 0x0, 400);
		memset(tempSubCode1, 0x0, 100);

		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		while (tempSubCode[tempInt] != 0x0)
		{
			if (CheckNamableCharacter(&(tempSubCode[tempInt])))
			{
				tempSubCode1[tempSubCodeIndex++] = tempSubCode[tempInt];
			}
			else
			{
				if (tempSubCodeIndex != 0)
				{
					tempSubCode1[tempSubCodeIndex] = 0x0;
					switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode1, tempppPointer))
					{
					case 0:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
						break;
					}
					case 1:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 2:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 3:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 4:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 5:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
						break;
					}
					case 6:
					{
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
						delete[] * tempppPointer;
						break;
					}
					default:
					{
						std::cout << "ProcessCodeSliceSyntaxKeyCodeLineType Fail\n";
						break;
					}
					}
				}
				tempSubCodeIndex = 0;
				tempSubCode2[0] = tempSubCode[tempInt];
				tempSubCode2[1] = 0x0;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
			}

			tempInt++;
		}

		if (tempSubCodeIndex != 0)
		{
			tempSubCode1[tempSubCodeIndex] = 0x0;
			switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode1, tempppPointer))
			{
			case 0:
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
				break;
			}
			case 1:
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
				break;
			}
			case 2:
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
				break;
			}
			case 3:
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
				break;
			}
			case 4:
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
				break;
			}
			case 5:
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
				break;
			}
			case 6:
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
				delete[] * tempppPointer;
				break;
			}
			default:
			{
				std::cout << "ProcessCodeSliceSyntaxKeyCodeLineType Fail\n";
				break;
			}
			}
		}

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		return 1;
	}

	int ProcessCodeSliceCodeBlockTypeFunctionDeclare(InterMediateNew* pInterMediateNew)
	{
		int tempIndex = 0;
		int tempReturnLength = 0;
		int tempInt = 0;
		char tempStructNo[5];
		char tempSubCode[300];
		char tempSubCode1[100];
		char tempSubCode2[100];
		char tempSubCode3[2];
		int tempSubCode2Index = 0;
		int tempSubCode1Index = 0;
		bool bName = false;
		bool bPar = false;
		bool bArray = false;
		char** tempppSubCode;
		char** tempppSubCode1;
		void** tempppPointer;
		ProfixType tempReturnProfixType;
		ReturnType tempReturnReturnType;
		PUserDefStruct tempReturnUserDefStruct;
		PStoreInterMediateUserDefTypeInfo temppUserDefTypeInfo;
		PStoreInterMediateUserDefFunctionInfo temppFunction;
		PStoreInterMediateVarDefInfo temppVar;
		PStoreInterMediateCodeBlockInfo temppCodeBlock;

		temppFunction = new StoreInterMediateUserDefFunctionInfo;
		InitStoreInterMediateUserDefFunctionInfo(temppFunction);
		tempppPointer = new void*;
		tempppSubCode = new char*;
		*tempppSubCode = tempSubCode;
		tempppSubCode1 = new char*;
		*tempppSubCode1 = tempSubCode1;
		memset(tempSubCode, 0x0, 300);
		memset(tempSubCode1, 0x0, 100);
		memset(tempSubCode2, 0x0, 100);
		memset(tempStructNo, 0x0, 5);

		tempIndex = *(pInterMediateNew->InputBufferIndex);
		tempReturnLength = DivisionCodeByLineFeed(pInterMediateNew->InputBuffer, &tempIndex, tempSubCode);
		tempIndex = tempIndex + tempReturnLength + 2;

		CheckProfixType((void**)tempppSubCode, &tempInt, &tempReturnProfixType);
		if (tempReturnProfixType != ProfixType::ProfixType_unknownType)
		{
			tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
			tempInt += tempReturnLength;
			MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);

			//������Ȱ��չ̶���ʽ������,��ʵ�õķ���������CheckProfixType�����������ĳ��Ƚ����ַ���һ�θ���,ֱ������Profix����,����������Ӳ��������ķ�ʽ����
			if (tempReturnProfixType == ProfixType::staticconstType)
			{
				tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
				tempInt += tempReturnLength;
				MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
			}
		}

		CheckReturnType((void**)tempppSubCode, &tempInt, &tempReturnReturnType, &tempReturnUserDefStruct);
		if (tempReturnReturnType != ReturnType::ReturnType_unknownType)
		{
			tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
			tempInt += tempReturnLength;
			MoveCodeIndexUntillNoBlank((void**)tempppSubCode, &tempInt);
			if (tempReturnUserDefStruct != NULL)
			{
				pInterMediateNew->FindStoreInterMediateUserDefTypeInfo(tempSubCode1, &temppUserDefTypeInfo);
				if (temppUserDefTypeInfo != NULL)
				{
					strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeInfo->InterMediateName);
				}
				else
				{
					std::cout << "ProcessCodeSliceCodeBlockTypeFunctionDeclare Error\n";
					throw 1;
					return 0;
				}
			}
			else
			{
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode1);
			}
			strcat((*(char**)(pInterMediateNew->OutputBuffer)), " ");
		}
		else
		{
			std::cout << "ProcessCodeSliceCodeBlockTypeFunctionDeclare Error\n";
			throw 1;
			return 0;
		}

		tempReturnLength = DivisionCodeByBlank((void**)tempppSubCode, &tempInt, tempSubCode1);
		//tempInt += tempReturnLength;
		/*tempSubCode1[tempReturnLength - 1] = 0x0;*/
		while (tempSubCode[tempInt] != 0x0)
		{
			if (CheckNamableCharacter(&(tempSubCode[tempInt])))
			{
				tempSubCode2[tempSubCode2Index++] = tempSubCode[tempInt];
			}
			else
			{
				if (tempSubCode2Index > 0)
				{
					tempSubCode2[tempSubCode2Index] = 0x0;
					tempSubCode2Index = 0;
					if (!bName)
					{
						bName = true;
						strcpy(temppFunction->UserDefFunctionName, tempSubCode2);
						strcpy(temppFunction->InterMediateName, "Function_");
						IntToStrNew(pInterMediateNew->StoreInterMediateUserDefFunctionInfoNum, tempStructNo);
						strcat(temppFunction->InterMediateName, tempStructNo);
						strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppFunction->InterMediateName);
					}
					else
					{
						if (bPar)
						{
							if (pInterMediateNew->FindStoreInterMediateUserDefTypeInfo(tempSubCode2, &temppUserDefTypeInfo) == 1)
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppUserDefTypeInfo->InterMediateName);
							}
							else
							{
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
							}
							bPar = false;
							temppVar = new StoreInterMediateVarDefInfo;
							InitStoreInterMediateVarDefInfo(temppVar);
						}
						else
						{
							if (bArray)
							{
								strcat(temppVar->Array, tempSubCode2);

								switch (pInterMediateNew->FindStoreInterMediateElement(tempSubCode2, tempppPointer))
								{
								case 0:
								{
									strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode2);
									break;
								}
								case 1:
								{
									strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeInfo*)tempppPointer)->InterMediateName);
									break;
								}
								case 2:
								{
									strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefFunctionInfo*)tempppPointer)->InterMediateName);
									break;
								}
								case 3:
								{
									strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateMacroDefInfo*)tempppPointer)->InterMediateName);
									break;
								}
								case 4:
								{
									strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateVarDefInfo*)tempppPointer)->InterMediateName);
									break;
								}
								case 5:
								{
									strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(PStoreInterMediateUserDefTypeContenTypeInfo*)tempppPointer)->InterMediateName);
									break;
								}
								case 6:
								{
									strcat((*(char**)(pInterMediateNew->OutputBuffer)), (*(char**)tempppPointer));
									delete[] * tempppPointer;
									break;
								}
								default:
								{
									std::cout << "ProcessCodeSliceCodeBlockTypeFunctionDeclare Fail\n";
									break;
								}
								}
							}
							else
							{
								strcpy(temppVar->VarName, tempSubCode2);
								strcpy(temppVar->InterMediateName, "Var_");
								IntToStrNew(pInterMediateNew->StoreInterMediateVarDefInfoNum, tempStructNo);
								strcat(temppVar->InterMediateName, tempStructNo);
								strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppVar->InterMediateName);

								if (tempSubCode[tempInt] == '[')
								{
									bArray = true;
									temppVar->bArray = true;
								}

								pInterMediateNew->GetStoreInterMediateCodeBlockInfoLastUnMatchedElement(&temppCodeBlock);
								if (temppCodeBlock != NULL)
								{
									temppVar->pCodeBlock = temppCodeBlock;
								}
								temppVar->InterMediateCodeLineNo = pInterMediateNew->WriteInterMediateCodeLineNo;

								pInterMediateNew->AddStoreInterMediateVarDefInfo(temppVar);

								//updata at 23.4.3
								bPar = true;
							}
						}
					}
				}

				if (bArray)
				{
					tempSubCode3[0] = tempSubCode[tempInt];
					tempSubCode3[1] = 0x0;
					strcat(temppVar->Array, tempSubCode3);
				}

				if (tempSubCode[tempInt] == '(' || tempSubCode[tempInt] == ',')
				{
					bPar = true;
				}

				if (tempSubCode[tempInt] == ']')
				{
					bArray = false;
				}

				tempSubCode3[0] = tempSubCode[tempInt];
				tempSubCode3[1] = 0x0;
				strcat((*(char**)(pInterMediateNew->OutputBuffer)), tempSubCode3);
			}

			tempInt++;
		}
		/*strcpy(temppVar->VarName, tempSubCode1);
		strcpy(temppVar->InterMediateName, "Var_");
		IntToStrNew(pInterMediateNew->StoreInterMediateVarDefInfoNum, tempStructNo);
		strcat(temppVar->InterMediateName, tempStructNo);*/
		/*strcat((*(char**)(pInterMediateNew->OutputBuffer)), temppVar->InterMediateName);*/

		pInterMediateNew->AddStoreInterMediateUserDefFunctionInfo(temppFunction);

		pInterMediateNew->InterMediateCodeLineNum++;
		pInterMediateNew->WriteInterMediateCodeLineNo++;
		strcat((*(char**)(pInterMediateNew->OutputBuffer)), "\r\n");
		*(pInterMediateNew->InputBufferIndex) = tempIndex;

		delete tempppSubCode1;
		delete tempppSubCode;

		return 1;
	}

	int CheckFuntionInInterMediateAndReturnToken(char* target, PInterMediateFunctionInfo* pReturn, char** pReturnToken)
	{
		char tempNumber[5];

		for (int i = 0; i < pInterMediateArray->ArrayNum; i++)
		{
			for (int z = 0; z < pInterMediateArray->Array[i]->CodeElementsNum; z++)
			{
				if (!strcmp(target, ((pInterMediateArray->Array)[i]->CodeElements)[z].Name))
				{
					*pReturnToken = new char[20];

					strcpy(*pReturnToken, pInterMediateArray->Array[i]->Token);
					IntToStrNew(z, tempNumber);
					strcat(*pReturnToken, "_");
					strcat(*pReturnToken, tempNumber);
					return i;
				}
			}
		}

		return -1;
	}

	int LOVE()
	{
		char temp[5];
		display(temp, 9, 9);

		return 1;
	}

	int InitStoreAsArrayIndexInfo(PStoreAsArrayIndexInfo p)
	{
		p->AsArrayIndexGlobalCodeLineNo = -1;
		p->pVar = NULL;
		p->pParent = NULL;
		p->pNext = NULL;

		return 1;
	}

	int AddStoreAsArrayIndexInfo(PVariable pVar, PStoreAsArrayIndexInfo p)
	{
		PStoreAsArrayIndexInfo temppStoreAsArrayIndexInfo;

		if (!pVar->bArrayIndex)
		{
			pVar->bArrayIndex = true;
			pVar->pStoreAsArrayIndexInfo = p;
			pVar->AsArrayIndexNum++;
		}
		else
		{
			temppStoreAsArrayIndexInfo = pVar->pStoreAsArrayIndexInfo;

			for (int i = 1; i < pVar->AsArrayIndexNum; i++)
			{
				temppStoreAsArrayIndexInfo = temppStoreAsArrayIndexInfo->pNext;
			}

			temppStoreAsArrayIndexInfo->pNext = p;
		}

		return 1;
	}

	int CheckArrayIndexIsVarAndAddInfo(char* Code, int* index, PVariable pVar, PSourceFunction pFunc)
	{
		int tempIndex = 0;
		char tempSubCode[100];
		char UnNamealbeChar;
		int tempSubCodeIndex = 0;
		PVariable temppVar;
		PStoreAsArrayIndexInfo temppStoreAsArrayIndexInfo;

		memset(tempSubCode, 0x0, 100);

		tempIndex = *index;
		while (GetNameableSubCodeInCode(Code, &tempIndex, tempSubCode, &UnNamealbeChar))
		{
			if (CheckVarExist(tempSubCode, pFunc, &temppVar))
			{
				temppStoreAsArrayIndexInfo = new StoreAsArrayIndexInfo;

				InitStoreAsArrayIndexInfo(temppStoreAsArrayIndexInfo);
				temppStoreAsArrayIndexInfo->AsArrayIndexGlobalCodeLineNo = AnalysisCodeLineNo;
				temppStoreAsArrayIndexInfo->pParent = temppVar;
				temppStoreAsArrayIndexInfo->pVar = pVar;

				AddStoreAsArrayIndexInfo(temppVar, temppStoreAsArrayIndexInfo);
			}
		}
		if (strlen(tempSubCode) != 0)
		{
			if (CheckVarExist(tempSubCode, pFunc, &temppVar))
			{
				temppStoreAsArrayIndexInfo = new StoreAsArrayIndexInfo;

				InitStoreAsArrayIndexInfo(temppStoreAsArrayIndexInfo);
				temppStoreAsArrayIndexInfo->AsArrayIndexGlobalCodeLineNo = AnalysisCodeLineNo;
				temppStoreAsArrayIndexInfo->pParent = temppVar;
				temppStoreAsArrayIndexInfo->pVar = pVar;

				AddStoreAsArrayIndexInfo(temppVar, temppStoreAsArrayIndexInfo);
			}
		}

		return 1;
	}

	int GetNameableSubCodeInCode(char* TargetCode, int* index, char* NameableSubCode, char* UnNameableChar)
	{
		int tempIndex = 0;
		int tempSubCodeIndex = 0;

		while (TargetCode[(*index) + tempIndex] != 0x0)
		{
			if (CheckNamableCharacter(&(TargetCode[(*index) + tempIndex])))
			{
				NameableSubCode[tempSubCodeIndex++] = TargetCode[(*index) + tempIndex];
				tempIndex++;
			}
			else
			{
				*UnNameableChar = TargetCode[(*index) + tempIndex];
				NameableSubCode[tempSubCodeIndex] = 0x0;
				tempIndex++;
				*index += tempIndex;
				return 1;
			}
		}
		NameableSubCode[tempSubCodeIndex] = 0x0;
		*index += tempIndex;

		return 0;
	}

	//�ú�������ʱ����,��Ϊ�����ʹ�����������APIʹ�õ�����ڴ�������׶�û�м�¼,���Կ���ֱ��ͨ���ڴ�������׶β����ļ�¼��Ϣֱ�ӽ��д�����Ƭ
	int CheckCodeLineHaveArrayUse(PStoreSensitiveAPIInfo pStoreSSAPIInfo, int AlgorithmType)
	{
		int tempIndex = 0;
		int tempCodeLineHaveArrayUseNum = 0;
		int tempArrayNameIndex[5];
		int tempArrayIndexNameIndex[5];

		tempCodeLineHaveArrayUseNum = CheckCodeLineArrayUse((pStoreSSAPIInfo->pSourceLine)->buffer, tempArrayNameIndex, tempArrayIndexNameIndex);
		for (int i = 0; i < tempCodeLineHaveArrayUseNum; i++)
		{
			
		}

		return 1;
	}

	//�ú���Ĭ����ȡ����ʹ�õ���������,���������������ʹ����������ô������ȡ����������ʹ�õ��������,������ȡ������������
	int CheckCodeLineArrayUse(char* Code, int* ArrayNameIndex, int* ArrayIndexNameIndex)
	{
		int tempIndex = 0;
		int tempNotNameableCharIndex = 0;
		int tempArrayUseNum = 0;
		bool bArray = false;

		while (Code[tempIndex] != 0x0)
		{
			if (Code[tempIndex] == '[' && !bArray)
			{
				tempNotNameableCharIndex = tempIndex - 1;
				while (CheckNamableCharacter(&(Code[tempNotNameableCharIndex])))
				{
					tempNotNameableCharIndex--;
				}
				if (Code[tempNotNameableCharIndex] == ' ')
				{
					while (Code[tempNotNameableCharIndex] == ' ')
					{
						tempNotNameableCharIndex--;
					}
					if (CheckNamableCharacter(&(Code[tempNotNameableCharIndex])))
					{
						tempIndex++;
						continue;
					}
				}

				bArray = true;
				ArrayNameIndex[tempArrayUseNum] = tempIndex - 1;
			}
			
			if (Code[tempIndex] == ']' && bArray)
			{
				bArray = false;
				ArrayIndexNameIndex[tempArrayUseNum++] = tempIndex - 1;
			}
			
			tempIndex++;
		}

		return tempArrayUseNum;
	}

	int GetVarAsArrayIndexUseInfo(PVariable pVar, PCodeExePathBlock pCodeExePathBlock, int CodeLineNo)
	{
		int tempIndex = 0;
		PStoreAsArrayIndexInfo temppStoreAsArrayIndexInfo;
		PSourceLine temppSourceLine;
		PSourceFunction temppSourceFunction;
		PSourceLine tempArrayUseCodeLineInSyntaxBlock[15];
		PVariable tempppVarArray[5];
		int tempArrayUseCodeLineInSyntaxBlockNum = 0;

		if (pVar->bArrayIndex)
		{
			for (int i = 0; i < pVar->AsArrayIndexNum; i++)
			{
				temppStoreAsArrayIndexInfo = pVar->pStoreAsArrayIndexInfo;
				if (temppStoreAsArrayIndexInfo->AsArrayIndexGlobalCodeLineNo >= CodeLineNo)
				{
					(pCodeExePathBlock->Path)[(pCodeExePathBlock->PathLength)++] = temppStoreAsArrayIndexInfo->AsArrayIndexGlobalCodeLineNo;
					GetCodeLineStruct(temppStoreAsArrayIndexInfo->AsArrayIndexGlobalCodeLineNo, &temppSourceLine, &temppSourceFunction);
					GetCodeLineInSyntaxBlockInfo(temppSourceLine, tempArrayUseCodeLineInSyntaxBlock, &tempArrayUseCodeLineInSyntaxBlockNum);
					for (int z = 0; z < tempArrayUseCodeLineInSyntaxBlockNum; z++)
					{
						(pCodeExePathBlock->Path)[(pCodeExePathBlock->PathLength)++] = (tempArrayUseCodeLineInSyntaxBlock[z])->GlobalLineNo;
					}
					GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(temppStoreAsArrayIndexInfo->pVar, tempppVarArray, pCodeExePathBlock);
				}
				temppStoreAsArrayIndexInfo = temppStoreAsArrayIndexInfo->pNext;
			}
		}

		return 1;
	}

	int InitStoreVecTableInfo(PStoreVecTableInfo pStoreVecTable)
	{
		int tempIndex = 0;

		pStoreVecTable->VecNum = 0;
		pStoreVecTable->VecTableFristNode = NULL;

		return 1;
	}

	int InitStoreVecInfo(PStoreVecInfo pStoreVec)
	{
		int tempIndex = 0;

		(pStoreVec->String)[0] = 0x0;
		(pStoreVec->VecValueStr)[0] = 0x0;
		pStoreVec->VecNo = -1;
		pStoreVec->VecValue = 0.0;
		pStoreVec->VecIntValue = 0;
		pStoreVec->pForward = NULL;
		pStoreVec->pNext = NULL;

		return 1;
	}

	int AddStoreVecInfoToChain(PStoreVecTableInfo pVecTable, PStoreVecInfo pVec)
	{
		int tempIndex = 0;
		PStoreVecInfo temppStoreVec;
		
		if (pVecTable->VecNum == 0)
		{
			pVecTable->VecTableFristNode = pVec;
			pVec->pNext = pVec;
			pVec->pForward = pVec;
		}
		else
		{
			temppStoreVec = (pVecTable->VecTableFristNode)->pForward;
			temppStoreVec->pNext = pVec;
			pVec->pForward = temppStoreVec;
			pVec->pNext = pVecTable->VecTableFristNode;
			(pVecTable->VecTableFristNode)->pForward = pVec;
		}
		(pVecTable->VecNum)++;
		
		return 1;
	}

	int ReadVecTable(const char* VecTableFilePath, const char* VecValueTableFilePath)
	{
		int tempIndex = 0;
		int tempIndex2 = 0;
		char** tempppBuffer;
		char** tempppBuffer2;
		void* temppBuffer;
		char temppStr[100];
		int tempStrIndex = 0;
		double tempDouble = 0.0;
		int tempInt = 0;
		PStoreVecInfo temppStoreVec;
		
		tempppBuffer = new char*;
		tempppBuffer2 = new char*;
		temppBuffer = malloc(50000);
		*tempppBuffer = (char*)temppBuffer;
		memset(temppBuffer, 0x0, 50000);
		temppBuffer = malloc(50000);
		*tempppBuffer2 = (char*)temppBuffer;
		memset(temppBuffer, 0x0, 50000);

		file::readOneFile(VecTableFilePath, (void**)tempppBuffer);
		file::readOneFile(VecValueTableFilePath, (void**)tempppBuffer2);

		while ((*tempppBuffer)[tempIndex] != 0x0)
		{
			if ((*tempppBuffer)[tempIndex] == '\r' && (*tempppBuffer)[tempIndex] == '\r' && (*tempppBuffer)[tempIndex + 1] == '\n')
			{
				temppStoreVec = new StoreVecInfo;
				InitStoreVecInfo(temppStoreVec);

				tempIndex += 2;
				temppStr[tempStrIndex] = 0x0;
				tempStrIndex = 0;

				strcpy(temppStoreVec->String, temppStr);
				temppStoreVec->VecNo = pStoreVecTable->VecNum;
				
				while ((*tempppBuffer2)[tempIndex2] != ' ' && (*tempppBuffer2)[tempIndex2] != 0x0)
				{
					temppStr[tempStrIndex++] = (*tempppBuffer2)[tempIndex2];
					tempIndex2++;
				}
				tempIndex2++;
				temppStr[tempStrIndex] = 0x0;
				tempStrIndex = 0;
				strcpy(temppStoreVec->VecValueStr, temppStr);
				tempDouble = 0.0;
				tempInt = 0;
				//StrToDouble(temppStr, &tempDouble);
				//temppStoreVec->VecValue = tempDouble;
				tempInt = StrToInt(temppStr);
				temppStoreVec->VecIntValue = tempInt;
				AddStoreVecInfoToChain(pStoreVecTable, temppStoreVec);

				continue;
			}
			else
			{
				temppStr[tempStrIndex++] = (*tempppBuffer)[tempIndex];
			}

			tempIndex++;
		}

		return 1;
	}

	int StrToDouble(const char* Str, double* pReturn)
	{
		int tempIndex = 0;
		int tempIndex2 = 0;
		int tempInt = 0;
		char tempStr[100];
		double tempDouble = 0.10;
		double tempDouble2 = 0.0;

		while (Str[tempIndex] != '.')
		{
			tempStr[tempIndex2++] = Str[tempIndex];
			tempIndex++;
		}
		tempIndex++;
		tempStr[tempIndex2] = 0x0;
		tempIndex2 = 0;
		tempInt = StrToInt(tempStr);
		(* pReturn) += tempInt;
		
		while (Str[tempIndex] != 0x0)
		{
			tempStr[tempIndex2++] = Str[tempIndex];
			tempIndex++;
		}
		tempStr[tempIndex2] = 0x0;
		for (int i = 0; i < tempIndex2; i++)
		{
			tempDouble2 = tempDouble2 + tempDouble * (tempStr[i] - 48);
			tempDouble *= 0.1;
		}
		if (Str[0] == '-')
		{
			tempDouble2 = 0 - tempDouble2;
		}
		*pReturn += tempDouble2;

		return 1;
	}

	//Ŀǰֻʵ��С����ǰ��3λ����ȡ
	int DoubleToStr(double target, char* pReturn)
	{
		int tempInt = 0;
		int tempInt1 = target;
		int tempInt2 = 0;
		int tempIndex = 0;
		double tempDouble = 0.1;
		double tempDouble1 = target - tempInt1;
		double tempDouble2 = 0.0;

		tempInt = 100;
		if (target >= 1000)
		{
			pReturn[0] = 0x0;
			return 0;
		}
		for (int i = 0; i < 3; i++)
		{
			tempInt2 = tempInt1 / tempInt;
			tempInt1 = tempInt1 % tempInt;
			tempInt /= 10;
			if (tempInt2 == 0)
			{
				if (tempIndex != 0)
				{
					pReturn[tempIndex++] = tempInt2 + 48;
				}
			}
			else
			{
				pReturn[tempIndex++] = tempInt2 + 48;
			}
		}
		pReturn[tempIndex++] = tempInt1 + 48;
		pReturn[tempIndex++] = '.';
		for (int i = 0; i < 3; i++)
		{
			tempInt2 = tempDouble1 / tempDouble;
			tempDouble1 = tempDouble1 - tempDouble * tempInt2;
			tempDouble /= 10;
			
			pReturn[tempIndex++] = tempInt2 + 48;
		}
		pReturn[tempIndex++] = (int)tempDouble1 + 48;
		pReturn[tempIndex++] = 0x0;

		return 1;
	}

	int TranslateIntermediateToVec(void** Code, int* index, void** OutPut, int* OutPutindex)
	{
		int tempIndex = 0;
		int tempInt = 0;
		int tempIndex1 = 0;
		int tempReturn = 0;
		char tempSubCode[400];
		char tempSubCode1[100];
		char tempSubCode3[20];
		double tempDouble = 0.0;

		while ((*(char**)Code)[*index + tempIndex] != 0x0)
		{
			tempInt = *index + tempIndex;
			tempReturn = DivisionCodeByLineFeed(Code, &tempInt, tempSubCode);

			for (int i = 0; i < tempReturn; i++)
			{
				if (CheckNamableCharacter(&(tempSubCode[i])))
				{
					tempSubCode1[tempIndex1++] = tempSubCode[i];
				}
				else
				{
					tempSubCode1[tempIndex1] = 0x0;

					if (tempIndex1 != 0)
					{
						FindVecTableElement(tempSubCode1, tempSubCode3, &tempDouble, &tempInt);
						strcat((*(char**)OutPut), tempSubCode3);
						strcat((*(char**)OutPut), " ");
						tempIndex1 = 0;
					}

					tempSubCode1[0] = tempSubCode[i];
					tempSubCode1[1] = 0x0;
					FindVecTableElement(tempSubCode1, tempSubCode3, &tempDouble, &tempInt);
					strcat((*(char**)OutPut), tempSubCode3);
					strcat((*(char**)OutPut), " ");
				}
			}

			if (tempIndex1 != 0)
			{
				tempSubCode1[tempIndex1] = 0x0;
				FindVecTableElement(tempSubCode1, tempSubCode3, &tempDouble, &tempInt);
				strcat((*(char**)OutPut), tempSubCode3);
				strcat((*(char**)OutPut), " ");
				tempIndex1 = 0;
			}

			(*(char**)OutPut)[strlen(*(char**)OutPut) - 1] = 0x0;
			strcat((*(char**)OutPut), "\r\n");
			tempIndex = tempIndex + tempReturn + 2;
		}

		return 1;
	}

	int FindVecTableElement(const char* pInputStr, char* pOutputStr, double* pOutputValue, int* pOutputIntValue)
	{
		int tempIndex = 0;
		PStoreVecInfo temppStoreVec;

		temppStoreVec = pStoreVecTable->VecTableFristNode;
		for (int i = 0; i < pStoreVecTable->VecNum; i++)
		{
			if (strcmp(temppStoreVec->String, pInputStr) == 0)
			{
				strcpy(pOutputStr, temppStoreVec->VecValueStr);
				*pOutputValue = temppStoreVec->VecValue;
				*pOutputIntValue = temppStoreVec->VecIntValue;
				return 1;
			}
			else
			{
				temppStoreVec = temppStoreVec->pNext;
			}
		}

		return 0;
	}

	int InitDataDependenceStruct(PDataDependence p)
	{
		p->GlobalCodeLineNo = -1;
		p->pCodeLine = NULL;
		p->bDependenceFunctionCallCodeLine = false;
		p->pNext = NULL;

		return 0;
	}

	int InitControlDependenceStruct(PControlDependence p)
	{
		p->GlobalCodeLineNo = -1;
		p->pCodeLine = NULL;
		p->bDependenceFunctionCallCodeLine = false;
		p->pNext = NULL;

		return 0;
	}

	int AddDataDependenceStruct(PSourceLine pCodeLine, PDataDependence pData)
	{
		PDataDependence tempp;

		if (pCodeLine->bDataDependence)
		{
			tempp = pCodeLine->pDataDependence;
			for (int i = 1; i < pCodeLine->DataDependenceNum; i++)
			{
				tempp = tempp->pNext;
			}
			tempp->pNext = pData;
		}
		else
		{
			pCodeLine->bDataDependence = true;
			pCodeLine->pDataDependence = pData;
		}
		pCodeLine->DataDependenceNum++;

		return 0;
	}

	int AddControlDependenceStruct(PSourceLine pCodeLine, PControlDependence pControl)
	{
		PControlDependence tempp;

		if (pCodeLine->bControlDependence)
		{
			tempp = pCodeLine->pControlDependence;
			for (int i = 1; i < pCodeLine->ControlDependenceNum; i++)
			{
				tempp = tempp->pNext;
			}
			tempp->pNext = pControl;
		}
		else
		{
			pCodeLine->bControlDependence = true;
			pCodeLine->pControlDependence = pControl;
		}
		pCodeLine->ControlDependenceNum++;

		return 0;
	}

	int CheckDataDependence(void** Code, PSourceLine pCodeLine, PSourceFunction pFunc)
	{
		int tempIndex = 0;
		int tempSubCodeIndex = 0;
		int tempIndexArray[1];
		char tempStr[100];
		PVariable temppVar;
		PSourceLine temppCodeLine;
		PDataDependence temppDataDependence;
		PSourceFunction temppFunc;

		while ((*(char**)Code)[tempIndex] != 0x0)
		{
			if (CheckNamableCharacter(&(*(char**)Code)[tempIndex]))
			{
				tempStr[tempSubCodeIndex++] = (*(char**)Code)[tempIndex];
			}
			else
			{
				if (tempSubCodeIndex != 0)
				{
					tempStr[tempSubCodeIndex] = 0x0;
					tempSubCodeIndex = 0;
					MoveCodeIndexUntillNoBlank(Code, &tempIndex);

					if ((*(char**)Code)[tempIndex] == '=' && (*(char**)Code)[tempIndex + 1] != '=')
					{
						if (CheckVarExist(tempStr, pFunc, &temppVar))
						{
							temppVar->ChangeNewGlobalCodeLineNo = AnalysisCodeLineNo;
						}
					}
					else
					{
						if (CheckVarExist(tempStr, pFunc, &temppVar))
						{
							temppDataDependence = new DataDependence;
							InitDataDependenceStruct(temppDataDependence);

							//����ñ����б���ֵ��ô�������Ƶ����ڵĴ����кŽ��м�¼�����û�У�ͨ���Ǳ�������������Ϊ������������ô��¼�����������ڴ����к�
							if (temppVar->ChangeNewGlobalCodeLineNo != -1)
							{
								temppDataDependence->GlobalCodeLineNo = temppVar->ChangeNewGlobalCodeLineNo;
								temppDataDependence->bDependenceFunctionCallCodeLine = false;
							}
							else
							{
								temppDataDependence->GlobalCodeLineNo = temppVar->DefCodeLineGlobalNo;
								temppDataDependence->bDependenceFunctionCallCodeLine = true;
							}
							CheckCodeLineExist(temppDataDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
							temppDataDependence->pCodeLine = temppCodeLine;
							AddDataDependenceStruct(pCodeLine, temppDataDependence);
						}

						if (CheckAssigningOperator(Code, tempIndex, tempIndex + 2, tempIndexArray) == 1)
						{
							if (CheckVarExist(tempStr, pFunc, &temppVar))
							{
								temppVar->ChangeNewGlobalCodeLineNo = AnalysisCodeLineNo;
							}
						}

						//���ﻹӦ�����ӶԸ��ַ������Ƿ�Ϊ���������жϣ�����Ǻ������õĻ������Ӧ�����Ƿ���ں������ú�ֵ�ᱻ�޸ģ��ᱻ�޸�����Ҫ�Զ�Ӧ����������ֵ���޸ĵı�ǣ�Ŀǰû������
						//�����������ַ����Ƿ�Ϊ���������жϣ���������Ӧ��Ǽ�¼
						if (CheckFuncExist(tempStr, &temppFunc))
						{
							pCodeLine->bHaveUserDefFunctionCall = true;
							pCodeLine->HaveUserDefFunctionCallCodeLineNoArray[(pCodeLine->HaveUserDefFunctionCallNum)++] = temppFunc->StartGlobalLineNo;
						}
					}

					continue;
				}		
			}

			tempIndex++;
		}

		return 1;
	}

	int CheckCodeLineExist(int CodeLineGlobalLineNo, PSourceFunction pFunc, PSourceLine* pCodeLine)
	{
		int tempIndex = 0;
		PSourceLine temppCodeLine;

		for (int i = 0; i < pSourceCodeFile->SourceCodeLineNum; i++)
		{
			temppCodeLine = (pSourceCodeFile->SourceCodeLine)[i];
			if (temppCodeLine->GlobalLineNo == CodeLineGlobalLineNo)
			{
				*pCodeLine = temppCodeLine;
				return 1;
			}
		}

		if (pFunc != NULL)
		{
			for (int i = 0; i < pFunc->CodeLineNum; i++)
			{
				temppCodeLine = (pFunc->CodeLine)[i];
				if (temppCodeLine->GlobalLineNo == CodeLineGlobalLineNo)
				{
					*pCodeLine = temppCodeLine;
					return 1;
				}
			}
		}

		return 0;
	}

	int CheckControlDependence(void** Code, PSourceLine pCodeLine, PSourceFunction pFunc, int** ControlDependenceArray, int* ControlDependenceNum, int* ControlDependenceArrayLBraceArray, int** ControlDependenceType)
	{
		int tempIndex = 0;
		int tempInt = 0;
		SyntaxKey syntaxKey1;
		SyntaxKey syntaxKey2;
		PControlDependence temppControlDependence;
		PControlDependence temppControlDependence2;
		PSourceLine temppCodeLine;

		temppControlDependence = new ControlDependence;
		InitControlDependenceStruct(temppControlDependence);

		AddControlDependenceStruct(pCodeLine, temppControlDependence);

		if ((*(char**)Code)[0] == '{')
		{
			(ControlDependenceArrayLBraceArray[*ControlDependenceNum])++;
			return 0;
		}
		if ((*(char**)Code)[0] == '}')
		{
			(ControlDependenceArrayLBraceArray[*ControlDependenceNum])--;

			if (ControlDependenceArrayLBraceArray[*ControlDependenceNum] == 0)
			{
				//���do...while()�ṹ������������
				if ((ControlDependenceType[*ControlDependenceNum])[0] == 6)
				{
					/*temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
					CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
					temppControlDependence->pCodeLine = temppCodeLine;
					if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = true;
					}
					else
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = false;
					}*/

					tempInt = (ControlDependenceArray[*ControlDependenceNum])[1];
					(ControlDependenceArray[*ControlDependenceNum])[0] = AnalysisCodeLineNo + 1;
					ControlDependenceArrayLBraceArray[*ControlDependenceNum] = 0;
					(ControlDependenceType[*ControlDependenceNum])[0] = 5;
					for (int i = tempInt + 2; i < AnalysisCodeLineNo; i++)
					{
						CheckCodeLineExist(i, pFunc, &temppCodeLine);

						temppControlDependence = new ControlDependence;
						InitControlDependenceStruct(temppControlDependence);
						AddControlDependenceStruct(temppCodeLine, temppControlDependence);

						temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
						CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
						temppControlDependence->pCodeLine = temppCodeLine;
						if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
						{
							temppControlDependence->bDependenceFunctionCallCodeLine = true;
						}
						else
						{
							temppControlDependence->bDependenceFunctionCallCodeLine = false;
						}
					}
				}

				(*ControlDependenceNum)--;
			}
			return 0;
		}

		CheckSyntaxKey(Code, &tempIndex, &syntaxKey1, &syntaxKey2);
		if (syntaxKey1 != SyntaxKey::SyntaxKey_unknownType)
		{
			switch (syntaxKey1)
			{
			case SyntaxKey::ifType:
			{
				temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
				CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
				temppControlDependence->pCodeLine = temppCodeLine;
				if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = true;
				}
				else
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = false;
				}

				(*ControlDependenceNum)++;
				(ControlDependenceArray[*ControlDependenceNum])[0] = AnalysisCodeLineNo;
				ControlDependenceArrayLBraceArray[*ControlDependenceNum] = 0;
				(ControlDependenceType[*ControlDependenceNum])[0] = 1;

				break;
			}
			case SyntaxKey::elseType:
			{
				(*ControlDependenceNum)++;

				break;
			}
			case SyntaxKey::elseifType:
			{
				(*ControlDependenceNum)++;

				temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
				CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
				temppControlDependence->pCodeLine = temppCodeLine;
				if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = true;
				}
				else
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = false;
				}

				(ControlDependenceArray[*ControlDependenceNum])[0] = AnalysisCodeLineNo;
				ControlDependenceArrayLBraceArray[*ControlDependenceNum] = 0;
				(ControlDependenceType[*ControlDependenceNum])[0] = 3;

				break;
			}
			case SyntaxKey::forType:
			{
				temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
				CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
				temppControlDependence->pCodeLine = temppCodeLine;
				if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = true;
				}
				else
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = false;
				}

				temppControlDependence = new ControlDependence;
				InitControlDependenceStruct(temppControlDependence);

				AddControlDependenceStruct(pCodeLine, temppControlDependence);

				(*ControlDependenceNum)++;
				(ControlDependenceArray[*ControlDependenceNum])[0] = AnalysisCodeLineNo;
				ControlDependenceArrayLBraceArray[*ControlDependenceNum] = 0;
				(ControlDependenceType[*ControlDependenceNum])[0] = 4;

				temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
				CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
				temppControlDependence->pCodeLine = temppCodeLine;
				if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = true;
				}
				else
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = false;
				}

				break;
			}
			case SyntaxKey::whileType:
			{
				CheckCodeLineExist(AnalysisCodeLineNo - 2, pFunc, &temppCodeLine);
				temppControlDependence2 = temppCodeLine->pControlDependence;
				for (int i = 1; i < temppCodeLine->ControlDependenceNum; i++)
				{
					temppControlDependence2 = temppControlDependence2->pNext;
				}
				if (!temppControlDependence2 || temppControlDependence2->GlobalCodeLineNo != AnalysisCodeLineNo)
				{
					temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
					CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
					temppControlDependence->pCodeLine = temppCodeLine;
					if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = true;
					}
					else
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = false;
					}

					temppControlDependence = new ControlDependence;
					InitControlDependenceStruct(temppControlDependence);

					AddControlDependenceStruct(pCodeLine, temppControlDependence);

					(*ControlDependenceNum)++;
					(ControlDependenceArray[*ControlDependenceNum])[0] = AnalysisCodeLineNo;
					ControlDependenceArrayLBraceArray[*ControlDependenceNum] = 0;
					(ControlDependenceType[*ControlDependenceNum])[0] = 5;

					temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
					CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
					temppControlDependence->pCodeLine = temppCodeLine;
					if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = true;
					}
					else
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = false;
					}
				}
				else
				{
					CheckCodeLineExist(AnalysisCodeLineNo - 2, pFunc, &temppCodeLine);
					temppControlDependence2 = temppCodeLine->pControlDependence;
					temppControlDependence->bDependenceFunctionCallCodeLine = temppControlDependence2->bDependenceFunctionCallCodeLine;
					temppControlDependence->GlobalCodeLineNo = temppControlDependence2->GlobalCodeLineNo;
					temppControlDependence->pCodeLine = temppControlDependence2->pCodeLine;
					tempInt = temppCodeLine->ControlDependenceNum;
					/*CheckCodeLineExist(AnalysisCodeLineNo, pFunc, &temppCodeLine);*/
					for (int i = 1; i < tempInt; i++)
					{
						temppControlDependence = new ControlDependence;
						InitControlDependenceStruct(temppControlDependence);
						AddControlDependenceStruct(pCodeLine, temppControlDependence);
						
						temppControlDependence2 = temppControlDependence2->pNext;
						temppControlDependence->bDependenceFunctionCallCodeLine = temppControlDependence2->bDependenceFunctionCallCodeLine;
						temppControlDependence->GlobalCodeLineNo = temppControlDependence2->GlobalCodeLineNo;
						temppControlDependence->pCodeLine = temppControlDependence2->pCodeLine;
					}
				}
				
				break;
			}
			case SyntaxKey::doType:
			{
				(*ControlDependenceNum)++;
				(ControlDependenceArray[*ControlDependenceNum])[0] = (ControlDependenceArray[*ControlDependenceNum - 1])[0];
				(ControlDependenceArray[*ControlDependenceNum])[1] = AnalysisCodeLineNo;
				ControlDependenceArrayLBraceArray[*ControlDependenceNum] = 0;
				(ControlDependenceType[*ControlDependenceNum])[0] = 6;

				break;
			}
			case SyntaxKey::switchType:
			{
				temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
				CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
				temppControlDependence->pCodeLine = temppCodeLine;
				if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = true;
				}
				else
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = false;
				}

				(*ControlDependenceNum)++;
				(ControlDependenceArray[*ControlDependenceNum])[0] = (ControlDependenceArray[*ControlDependenceNum - 1])[0];
				ControlDependenceArrayLBraceArray[*ControlDependenceNum] = 0;
				(ControlDependenceType[*ControlDependenceNum])[0] = 7;

				break;
			}
			case SyntaxKey::caseType:
			{
				if ((ControlDependenceType[*ControlDependenceNum])[0] == 7)
				{
					temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
					CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
					temppControlDependence->pCodeLine = temppCodeLine;
					if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = true;
					}
					else
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = false;
					}

					(*ControlDependenceNum)++;
				}
				else
				{
					(*ControlDependenceNum)++;
					temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
					CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
					temppControlDependence->pCodeLine = temppCodeLine;
					if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = true;
					}
					else
					{
						temppControlDependence->bDependenceFunctionCallCodeLine = false;
					}
				}
				
				
				(ControlDependenceArray[*ControlDependenceNum])[0] = AnalysisCodeLineNo;
				ControlDependenceArrayLBraceArray[*ControlDependenceNum] = 0;
				(ControlDependenceType[*ControlDependenceNum])[0] = 8;

				break;
			}
			case SyntaxKey::defaultType:
			{
				//��defalut�Ȳ�����
				break;
			}
			default:
			{
				//updata at 23.1.8
				temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
				CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
				temppControlDependence->pCodeLine = temppCodeLine;
				if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = true;
				}
				else
				{
					temppControlDependence->bDependenceFunctionCallCodeLine = false;
				}
				break;
			}
			}
		}
		else
		{
			temppControlDependence->GlobalCodeLineNo = (ControlDependenceArray[*ControlDependenceNum])[0];
			CheckCodeLineExist(temppControlDependence->GlobalCodeLineNo, pFunc, &temppCodeLine);
			temppControlDependence->pCodeLine = temppCodeLine;
			if ((ControlDependenceType[*ControlDependenceNum])[0] == 0)
			{
				temppControlDependence->bDependenceFunctionCallCodeLine = true;
			}
			else
			{
				temppControlDependence->bDependenceFunctionCallCodeLine = false;
			}
		}

		return 1;
	}

	int GetCodeSliceDataDependence(int* CodeSliceArray, int CodeSliceArrayLength, int** ReturnDataDependence)
	{
		PSourceFunction tempFunc;
		PSourceLine tempCodeLine;
		PSourceLine tempCodeLine1;
		PDataDependence temppDataDependence;
		int tempInt = 0;
		char tempBuffer[10] = { 0 };
		char tempBuffer1[3] = " ";
		char tempBuffer2[3] = "\n";
		int64_t tempNSTime1 = 0;
		int64_t tempNSTime2 = 0;
		/*long tempTime1 = 0;
		long tempTime2 = 0;
		double tempSecond1 = 0.0;
		double tempSecond2 = 0.0;
		double tempmSecond1 = 0.0;
		double tempmSecond2 = 0.0;
		double tempMin1 = 0.0;
		double tempMin2 = 0.0;*/
	
		//GetTimeOnWindowsPlatform(&tempSecond1, &tempmSecond1, &tempMin1);
		//GetTimeOnWindowsPlatformNew(&tempTime1);
		//tempNSTime1 = GetSysTimeMicros();
		for (int i = 0; i < CodeSliceArrayLength; i++)
		{
			if (GetCodeLineStruct(CodeSliceArray[i], &tempCodeLine, &tempFunc))
			{
				for (int z = 0; z < CodeSliceArrayLength; z++)
				{
					(ReturnDataDependence[i])[z] = 0;
				}
				if (tempCodeLine->bDataDependence)
				{
					temppDataDependence = tempCodeLine->pDataDependence;
					for (int x = 0; x < CodeSliceArrayLength; x++)
					{
						if (temppDataDependence->GlobalCodeLineNo == CodeSliceArray[x])
						{
							(ReturnDataDependence[i])[x] = 1;
						}
						
						if (GetCodeLineStruct(CodeSliceArray[x], &tempCodeLine1, &tempFunc))
						{
							if (tempCodeLine1->bHaveUserDefFunctionCall)
							{
								for (int a = 0; a < tempCodeLine1->HaveUserDefFunctionCallNum; a++)
								{
									if ((tempCodeLine1->HaveUserDefFunctionCallCodeLineNoArray)[a] == temppDataDependence->GlobalCodeLineNo)
									{
										(ReturnDataDependence[i])[x] = 1;
									}
								}
							}
						}
						else
						{
#ifdef _DEBUG
							std::cout << "Get Code Slice Data Dependence Error\n";
#endif
							return 0;
						}
					}
					temppDataDependence = temppDataDependence->pNext;
					for (int z = 1; z < tempCodeLine->DataDependenceNum; z++)
					{
						for (int x = 0; x < CodeSliceArrayLength; x++)
						{
							if (temppDataDependence->GlobalCodeLineNo == CodeSliceArray[x])
							{
								(ReturnDataDependence[i])[x] = 1;
							}
							
							if (GetCodeLineStruct(CodeSliceArray[x], &tempCodeLine1, &tempFunc))
							{
								if (tempCodeLine1->bHaveUserDefFunctionCall)
								{
									for (int a = 0; a < tempCodeLine1->HaveUserDefFunctionCallNum; a++)
									{
										if ((tempCodeLine1->HaveUserDefFunctionCallCodeLineNoArray)[a] == temppDataDependence->GlobalCodeLineNo)
										{
											(ReturnDataDependence[i])[x] = 1;
										}
									}
								}
							}
							else
							{
#ifdef _DEBUG
								std::cout << "Get Code Slice Data Dependence Error\n";
#endif
								return 0;
							}
						}
						temppDataDependence = temppDataDependence->pNext;
					}
				}
			}
			else
			{
#ifdef _DEBUG
				std::cout << "Get Code Slice Data Dependence Error\n";
#endif
				return 0;
			}
		}
		/*tempNSTime2 = GetSysTimeMicros();
		IntToStr(tempNSTime2 - tempNSTime1, tempBuffer);
		file::OutPutToFile(OutputFilePath16, tempBuffer);
		file::OutPutToFile(OutputFilePath16, tempBuffer2);
		GetTimeOnWindowsPlatformNew(&tempTime2);
		IntToStr(tempTime2 - tempTime1, tempBuffer);
		file::OutPutToFile(OutputFilePath16, tempBuffer);
		file::OutPutToFile(OutputFilePath16, tempBuffer2);
		GetTimeOnWindowsPlatform(&tempSecond2, &tempmSecond2, &tempMin2);
		DoubleToStr(tempSecond2 - tempSecond1, tempBuffer);
		file::OutPutToFile(OutputFilePath16, tempBuffer);
		file::OutPutToFile(OutputFilePath16, tempBuffer1);
		DoubleToStr(tempmSecond2 - tempmSecond1, tempBuffer);
		file::OutPutToFile(OutputFilePath16, tempBuffer);
		file::OutPutToFile(OutputFilePath16, tempBuffer2);*/
		
		return 1;
	}

	int GetCodeSliceControlDependence(int* CodeSliceArray, int CodeSliceArrayLength, int** ReturnControlDependence)
	{
		PSourceFunction tempFunc;
		PSourceLine tempCodeLine;
		PSourceLine tempCodeLine1;
		PControlDependence temppControlDependence;
		int tempInt = 0;
		long tempTime1 = 0;
		long tempTime2 = 0;
		char tempBuffer[10] = { 0 };
		char tempBuffer1[3] = " ";
		char tempBuffer2[3] = "\n";
		/*double tempSecond1 = 0.0;
		double tempSecond2 = 0.0;
		double tempmSecond1 = 0.0;
		double tempmSecond2 = 0.0;
		double tempMin1 = 0.0;
		double tempMin2 = 0.0;*/

		//GetTimeOnWindowsPlatform(&tempSecond1, &tempmSecond1, &tempMin1);
		//GetTimeOnWindowsPlatformNew(&tempTime1);
		for (int i = 0; i < CodeSliceArrayLength; i++)
		{
			if (GetCodeLineStruct(CodeSliceArray[i], &tempCodeLine, &tempFunc))
			{
				for (int z = 0; z < CodeSliceArrayLength; z++)
				{
					(ReturnControlDependence[i])[z] = 0;
				}
				if (tempCodeLine->bControlDependence)
				{
					temppControlDependence = tempCodeLine->pControlDependence;
					for (int x = 0; x < CodeSliceArrayLength; x++)
					{
						if (temppControlDependence->GlobalCodeLineNo == CodeSliceArray[x])
						{
							(ReturnControlDependence[i])[x] = 1;
						}
						
						if (GetCodeLineStruct(CodeSliceArray[x], &tempCodeLine1, &tempFunc))
						{
							if (tempCodeLine1->bHaveUserDefFunctionCall)
							{
								for (int a = 0; a < tempCodeLine1->HaveUserDefFunctionCallNum; a++)
								{
									if ((tempCodeLine1->HaveUserDefFunctionCallCodeLineNoArray)[a] == temppControlDependence->GlobalCodeLineNo)
									{
										(ReturnControlDependence[i])[x] = 1;
									}
								}
							}
						}
						else
						{
#ifdef _DEBUG
							std::cout << "Get Code Slice Control Dependence Error\n";
#endif
							return 0;
						}
					}
					temppControlDependence = temppControlDependence->pNext;
					for (int z = 1; z < tempCodeLine->ControlDependenceNum; z++)
					{
						for (int x = 0; x < CodeSliceArrayLength; x++)
						{
							if (temppControlDependence->GlobalCodeLineNo == CodeSliceArray[x])
							{
								(ReturnControlDependence[i])[x] = 1;
							}

							if (GetCodeLineStruct(CodeSliceArray[x], &tempCodeLine1, &tempFunc))
							{
								if (tempCodeLine1->bHaveUserDefFunctionCall)
								{
									for (int a = 0; a < tempCodeLine1->HaveUserDefFunctionCallNum; a++)
									{
										if ((tempCodeLine1->HaveUserDefFunctionCallCodeLineNoArray)[a] == temppControlDependence->GlobalCodeLineNo)
										{
											(ReturnControlDependence[i])[x] = 1;
										}
									}
								}
							}
							else
							{
#ifdef _DEBUG
								std::cout << "Get Code Slice Control Dependence Error\n";
#endif
								return 0;
							}
						}
						temppControlDependence = temppControlDependence->pNext;
					}
				}
			}
			else
			{
#ifdef _DEBUG
				std::cout << "Get Code Slice Control Dependence Error\n";
#endif
				return 0;
			}
		}
		/*GetTimeOnWindowsPlatformNew(&tempTime2);
		IntToStr(tempTime2 - tempTime1, tempBuffer);
		file::OutPutToFile(OutputFilePath17, tempBuffer);
		file::OutPutToFile(OutputFilePath17, tempBuffer2);
		GetTimeOnWindowsPlatform(&tempSecond2, &tempmSecond2, &tempMin2);
		DoubleToStr(tempSecond2 - tempSecond1, tempBuffer);
		file::OutPutToFile(OutputFilePath17, tempBuffer);
		file::OutPutToFile(OutputFilePath17, tempBuffer1);
		DoubleToStr(tempmSecond2 - tempmSecond1, tempBuffer);
		file::OutPutToFile(OutputFilePath17, tempBuffer);
		file::OutPutToFile(OutputFilePath17, tempBuffer2);*/

		return 1;
	}

	//��ʱû�ã���Ϊԭ����Ҫ�Ĺ�����CheckDataDependence������ʵ����
	int CheckCodeLineHaveUserDefFunctionCall(void** Code, PSourceLine pCodeLine, PSourceFunction pFunc)
	{

		return 1;
	}

	int TransformIntMatrix2Str(int** Matrix, int RealWidth, int RealHeight, int Width, int Height, char* Pad, char** ReturnBuffer)
	{
		int tempIndex = 0;
		char tempBuffer[10];

		if (RealWidth > Width || RealHeight > Height)
		{
			std::cout << "Transform Int Matrix To Str Error\n";
			return 0;
		}

		for (int i = 0; i < RealHeight; i++)
		{
			for (int z = 0; z < RealWidth; z++)
			{
				IntToStrNew((Matrix[i])[z], tempBuffer);
				strcat(*ReturnBuffer, tempBuffer);
				strcat(*ReturnBuffer, " ");
			}
			for (int z = RealWidth; z < Width; z++)
			{
				strcat(*ReturnBuffer, Pad);
				strcat(*ReturnBuffer, " ");
			}
			strcat(*ReturnBuffer, "\r\n");
		}
		for (int i = RealHeight; i < Height; i++)
		{
			for (int z = 0; z < Width; z++)
			{
				strcat(*ReturnBuffer, Pad);
				strcat(*ReturnBuffer, " ");
			}
			strcat(*ReturnBuffer, "\r\n");
		}

		return 1;
	}

	int GenerateBMP(char* FileName, uint32_t Width, uint32_t Height, int** CodeMatrix, int** DataDependenceMatrix, int** ControlDependenceMatrix)
	{
		FILE* fp;
		uint32_t i;
		LITTLE l_width, l_height, l_bfSize, l_biSizeImage;
		int tempIndex = 0;
		char tempBuffer[10000];
		char tempStr[10];
		uint8_t tempChar;
		uint8_t tempChar2;
		uint8_t tempChar3;

		memset(tempBuffer, 0x0, 10000);

		uint32_t width_r = (Width * 24 / 8 + 3) / 4 * 4;
		uint32_t bfSize = width_r * Height + 54 + 2;
		uint32_t biSizeImage = width_r * Height;

		l_width.value = Width;
		l_height.value = Height;
		l_bfSize.value = bfSize;
		l_biSizeImage.value = biSizeImage;

		/* BMP file format: www.cnblogs.com/wainiwann/p/7086844.html */
		uint8_t BMPHeader[54] = {
			/* bmp file header: 14 byte */
			0x42, 0x4d,
			// bmp pixel size: width * height * 3 + 54
			l_bfSize.bytes[0], l_bfSize.bytes[1], l_bfSize.bytes[2], l_bfSize.bytes[3],
			0, 0 , 0, 0,
			54, 0 , 0, 0,    /* 14+40=54 */

			/* bmp map info: 40 byte */
			40, 0, 0, 0,
			//width
			l_width.bytes[0], l_width.bytes[1], l_width.bytes[2], l_width.bytes[3],
			//height
			l_height.bytes[0], l_height.bytes[1], l_height.bytes[2], l_height.bytes[3],
			1, 0,
			24, 00,             /* 24 bit: R[8]/G[8]/B[8] */

			0, 0, 0, 0,     //biCompression:0
			//        0, 0, 0, 0,     //biSizeImage2
						l_biSizeImage.bytes[0], l_biSizeImage.bytes[1], l_biSizeImage.bytes[2], l_biSizeImage.bytes[3],
						0, 0, 0, 0,     //biXPelsPerMeter: 60 0F 00 00
						0, 0, 0, 0,     //biYPelsPerMeter
						0, 0, 0, 0,     //biClrUsed
						0, 0, 0, 0      //biClrImportant
		};

		/* write in binary format */
		fp = fopen(FileName, "wb+");
		if (fp == NULL)
		{
			printf("%s: file create failed!\n", FileName);
			return -1;
		}

		//printf("%s: file create success!\n", FileName);

		fwrite(BMPHeader, sizeof(BMPHeader), 1, fp);

		for (i = 0; i < Height; i++) {
			for (int z = 0; z < Width; z++)
			{
				tempChar = (CodeMatrix[i])[z];
				tempChar2 = (DataDependenceMatrix[i])[z];
				tempChar3 = (ControlDependenceMatrix[i])[z];
				fprintf(fp, "%c%c%c", tempChar, tempChar2, tempChar3); /* BGR */
			}
			//4 byte align
			for (int z = 0; z < width_r - Width * 3; z++)
			{
				fprintf(fp, "%c", 0);
			}
		}

		fprintf(fp, "%c%c", 0, 0); //PhotoStop two byte "0"

		if (fclose(fp))
		{
			printf("file close failed!\n");
			return -1;
		}
		fp = NULL;

		/*printf("width: %d\n", width);
		printf("height: %d\n", height);
		printf("R:%d, G:%d, B:%d or #%06x\n", r, g, b, color);*/

		return 0;
	}

	int MatrixStr2Int(char** Matrix, int** ReturnMatrix, int Width, int Height)
	{
		int tempIndex = 0;
		char tempBuffer[10];
		int tempBufferIndex = 0;
		int tempInt = 0;
		int tempWidth = 0;
		int tempHeight = 0;
		
		while ((*Matrix)[tempIndex] != 0x0)
		{
			if ((*Matrix)[tempIndex] >= '0' && (*Matrix)[tempIndex] <= '9')
			{
				tempBuffer[tempBufferIndex++] = (*Matrix)[tempIndex];
			}
			else
			{
				if ((*Matrix)[tempIndex] == ' ' || (*Matrix)[tempIndex] == '\r' || (*Matrix)[tempIndex] == '\n')
				{
					if (tempBufferIndex != 0)
					{
						tempBuffer[tempBufferIndex] = 0x0;
						tempBufferIndex = 0;
						tempInt = StrToInt(tempBuffer);

						(ReturnMatrix[tempHeight])[tempWidth] = tempInt;
						if ((*Matrix)[tempIndex] == ' ')
						{
							tempWidth++;
							if (tempWidth >= Width)
							{
								std::cout << "MatrixStr2Int Error, Exceed Range\n";
								return 0;
							}
						}
						else
						{
							tempWidth = 0;
							tempHeight++;
							if (tempHeight >= Height)
							{
								std::cout << "MatrixStr2Int Error, Exceed Range\n";
								return 0;
							}
						}
					}
				}
				else
				{
					std::cout << "MatrixStr2Int Error, Please Add Function\n";
					return 0;
				}
			}
			tempIndex++;
		}

		return 1;
	}

	int GetBMP(char** CodeMatrix, int** DataDependenceMatrix, int** ControlDependenceMatrix, bool bSafe, const char* StroeFilePath, char* FileName, char* FunctionName, int width, int height, int mod)
	{
		int** tempBuffer;
		char tempPicFilePath[250];

		tempBuffer = new int* [150];
		for (int i = 0; i < 150; i++)
		{
			tempBuffer[i] = new int[150];
		}
		memset(tempPicFilePath, 0x0, 250);

		//����������Ϊ0�����Բ����ٶԴ���������ʾ�ľ���������0��
		for (int i = 0; i < 150; i++)
		{
			for (int z = 0; z < 150; z++)
			{
				(tempBuffer[i])[z] = 0;
			}
		}

		if (mod == 0)
		{

			//update at 23.1.11
			for (int i = 0; i < 50; i++)
			{
				for (int z = 0; z < 50; z++)
				{
					if ((DataDependenceMatrix[i])[z] == 1)
					{
						(DataDependenceMatrix[i])[z] = 255;
					}
					if ((ControlDependenceMatrix[i])[z] == 1)
					{
						(ControlDependenceMatrix[i])[z] = 255;
					}
				}
			}

			if (bSafe)
			{
				sprintf(tempPicFilePath, "%s%s__%s_%d_1.bmp", StroeFilePath, FileName, FunctionName, OutputPicNum);
			}
			else
			{
				sprintf(tempPicFilePath, "%s%s__%s_%d_0.bmp", StroeFilePath, FileName, FunctionName, OutputPicNum);
			}

			MatrixStr2Int(CodeMatrix, tempBuffer, width, height);

			//update at 23.4.24 Ϊ�˱任ͼƬ��ɫ
			//ReverseIntValue(tempBuffer, 50);
			//ReverseIntValue(DataDependenceMatrix, 50);
			//ReverseIntValue(ControlDependenceMatrix, 50);

			GenerateBMP(tempPicFilePath, width, height, tempBuffer, DataDependenceMatrix, ControlDependenceMatrix);
			OutputPicNum++;
		}
		else if (mod == 1)
		{

			//update at 23.1.11
			for (int i = 0; i < 150; i++)
			{
				for (int z = 0; z < 150; z++)
				{
					if ((DataDependenceMatrix[i])[z] == 1)
					{
						(DataDependenceMatrix[i])[z] = 255;
					}
					if ((ControlDependenceMatrix[i])[z] == 1)
					{
						(ControlDependenceMatrix[i])[z] = 255;
					}
				}
			}

			if (bSafe)
			{
				sprintf(tempPicFilePath, "%s%s__%s_%d_1.bmp", StroeFilePath, FileName, FunctionName, OutputPicNum2);
			}
			else
			{
				sprintf(tempPicFilePath, "%s%s__%s_%d_0.bmp", StroeFilePath, FileName, FunctionName, OutputPicNum2);
			}

			MatrixStr2Int(CodeMatrix, tempBuffer, width, height);
			GenerateBMP(tempPicFilePath, width, height, tempBuffer, DataDependenceMatrix, ControlDependenceMatrix);
			OutputPicNum2++;
		}
		else
		{
			std::cout << "GetBMP Error\n";
		}

		for (int i = 0; i < 150; i++)
		{
			delete [] tempBuffer[i];
		}
		delete[] tempBuffer;

		return 1;
	}

	int ReadOutputPicNumConfigFile(const char* FilePath, const char* FilePath2)
	{
		char tempBuffer[20];
		char** tempppBuffer;

		tempppBuffer = new char*;
		*tempppBuffer = tempBuffer;
		
		memset(tempBuffer, 0x0, 20);

		file::readOneFile(FilePath, (void**)tempppBuffer);
		
		OutputPicNum = StrToInt(tempBuffer);

		memset(tempBuffer, 0x0, 20);

		file::readOneFile(FilePath2, (void**)tempppBuffer);

		OutputPicNum2 = StrToInt(tempBuffer);

		return 1;
	}

	int WriteOutputPicNumConfigFile(const char* FilePath, const char* FilePath2)
	{
		char tempBuffer[20];
		FILE* fp;

		memset(tempBuffer, 0x0, 20);
		
		IntToStrNew(OutputPicNum, tempBuffer);

		fp = fopen(FilePath, "wb");
		if (fp == NULL)
		{
			printf("%s: file create failed!\n", FilePath);
			return -1;
		}
		fprintf(fp, "%d", OutputPicNum);
		if (fclose(fp))
		{
			printf("file close failed!\n");
			return -1;
		}
		fp = NULL;

		memset(tempBuffer, 0x0, 20);

		IntToStrNew(OutputPicNum2, tempBuffer);

		fp = fopen(FilePath2, "wb");
		if (fp == NULL)
		{
			printf("%s: file create failed!\n", FilePath);
			return -1;
		}
		fprintf(fp, "%d", OutputPicNum2);
		if (fclose(fp))
		{
			printf("file close failed!\n");
			return -1;
		}
		fp = NULL;

		return 1;
	}

	int OutputAllSourceFileIntermediate()
	{
		int tempIndex = 0;
		int CodeLineArray[200];
		char tempBuffer[5000];
		char tempBuffer2[5000];
		char** tempppBuffer;
		char** tempppBuffer2;
		int tempBufferIndex = 0;
		int tempBuffer2Index = 0;
		PSourceLine temppCodeLine;
		PSourceFunction temppFuncion;

		tempppBuffer = new char*;
		tempppBuffer2 = new char*;

		*tempppBuffer = tempBuffer;
		*tempppBuffer2 = tempBuffer2;

		memset(tempBuffer, 0x0, 5000);
		memset(tempBuffer2, 0x0, 5000);

		for (int i = 0; i < pSourceCodeFile->MacroNum; i++)
		{
			CodeLineArray[tempIndex++] = ((pSourceCodeFile->Macro)[i])->DefCodeLineGlobalNo;
		}

		for (int i = 0; i < pSourceCodeFile->VariableNum; i++)
		{
			CodeLineArray[tempIndex++] = ((pSourceCodeFile->Variable)[i])->DefCodeLineGlobalNo;
		}

		for (int i = 0; i < pSourceCodeFile->UserDefStructNum; i++)
		{
			for (int z = ((pSourceCodeFile->UserDefStruct)[i])->DefStartGlobalLineNo; z <= ((pSourceCodeFile->UserDefStruct)[i])->DefStopGlobalLineNo; z++)
			{
				CodeLineArray[tempIndex++] = z;
			}
		}

		for (int i = 0; i < pSourceCodeFile->FunctionNum; i++)
		{
			for (int z = ((pSourceCodeFile->Function)[i])->StartGlobalLineNo + 1; z <= ((pSourceCodeFile->Function)[i])->StopGlobalLineNo; z++)
			{
				CodeLineArray[tempIndex++] = z;
			}
		}

		for (int i = 0; i < tempIndex; i++)
		{
			GetCodeLineStruct(CodeLineArray[i], &temppCodeLine, &temppFuncion);
			strcat(tempBuffer, temppCodeLine->buffer);
			strcat(tempBuffer, "\r\n");
		}

		if (strlen(tempBuffer) != 0)
		{
			TranslateCodeSlice((void**)tempppBuffer, &tempBufferIndex, (void**)tempppBuffer2, &tempBuffer2Index);
		}

		strcat(tempBuffer2, "\r\n");

		/*if (!file::OutPutToFile(OutputFilePath10, tempBuffer2))
			std::cout << "Wirte File Fail" << std::endl;*/

		return 1;
	}

	int OutputFullFunctionIntermediate(int* CodeLineArray, int CodeLineArrayLength, bool bSafe)
	{
		int tempIndex = 0;
		int tempCodeLineArray[200];
		char tempBuffer[5000];
		char tempBuffer2[5000];
		char tempBuffer3[5000];
		char** tempppBuffer;
		char** tempppBuffer2;
		char** tempppBuffer3;
		int tempBufferIndex = 0;
		int tempBuffer2Index = 0;
		int tempBuffer3Index = 0;
		int** tempBufferDataDependence;
		int** tempBufferControlDependence;
		int PicSize = 0;
		bool bInArray = false;
		PSourceLine temppCodeLine;
		PSourceFunction temppFuncion;

		PicSize = 150;

		tempppBuffer = new char*;
		tempppBuffer2 = new char*;
		tempppBuffer3 = new char*;

		*tempppBuffer = tempBuffer;
		*tempppBuffer2 = tempBuffer2;
		*tempppBuffer3 = tempBuffer3;

		memset(tempBuffer, 0x0, 5000);
		memset(tempBuffer2, 0x0, 5000);
		memset(tempBuffer3, 0x0, 5000);

		//Ŀǰ������150*150�ľ��󣬺��ڱ�׼�����������ٸ���
		tempBufferDataDependence = new int* [PicSize];
		tempBufferControlDependence = new int* [PicSize];
		for (int i = 0; i < PicSize; i++)
		{
			tempBufferDataDependence[i] = new int[PicSize];
			tempBufferControlDependence[i] = new int[PicSize];
		}

		for (int i = 0; i < PicSize; i++)
		{
			for (int z = 0; z < PicSize; z++)
			{
				(tempBufferDataDependence[i])[z] = 0;
				(tempBufferControlDependence[i])[z] = 0;
			}
		}

		for (int i = 0; i < pSourceCodeFile->SourceCodeLineNum; i++)
		{
			tempCodeLineArray[tempIndex++] = ((pSourceCodeFile->SourceCodeLine)[i])->GlobalLineNo;
		}

		for (int i = 0; i < CodeLineArrayLength; i++)
		{
			bInArray = false;
			for (int z = 0; z < tempIndex; z++)
			{
				if (tempCodeLineArray[z] == CodeLineArray[i])
				{
					bInArray = true;
				}
			}
			if (!bInArray)
			{
				GetCodeLineStruct(CodeLineArray[i], &temppCodeLine, &temppFuncion);
				if (temppFuncion != NULL)
				{
					for (int z = temppFuncion->StartGlobalLineNo + 1; z <= temppFuncion->StopGlobalLineNo; z++)
					{
						tempCodeLineArray[tempIndex++] = z;
					}
				}
				else
				{
					tempCodeLineArray[tempIndex++] = CodeLineArray[i];
				}
			}
		}

		for (int i = 0; i < tempIndex; i++)
		{
			GetCodeLineStruct(tempCodeLineArray[i], &temppCodeLine, &temppFuncion);
			strcat(tempBuffer, temppCodeLine->buffer);
			strcat(tempBuffer, "\r\n");
		}

		//update at 23.6.13 �������д�����Ϊ�˽���ȡ����Ǳ��©������Ƭ�α����ڵ������ļ��У����ڼ��VulCNN���Ǳ��©������Ƭ��
		OutputFuncCodeSliceToFile(CodeLineArray, CodeLineArrayLength, bSafe);
		
		//update at 23.3.25 �������д�����Ϊ�˽�������ȡ��������һ���������ļ����б�������ƥ��VulCNN�����ݼ�Ҫ��
		OutputFuncToFile(temppFuncion->FunctionNo, bSafe);

		GetCodeSliceDataDependence(tempCodeLineArray, tempIndex, tempBufferDataDependence);
		GetCodeSliceControlDependence(tempCodeLineArray, tempIndex, tempBufferControlDependence);
		/*std::cout << "No Code Extract Data Dependenc:\n";
		for (int i = 0; i < tempIndex; i++)
		{
			for (int z = 0; z < tempIndex; z++)
			{
				std::cout << (tempBufferDataDependence[i])[z] << " ";
			}
			std::cout << std::endl;
		}
		std::cout << "No Code Extract Control Dependenc:\n";
		for (int i = 0; i < tempIndex; i++)
		{
			for (int z = 0; z < tempIndex; z++)
			{
				std::cout << (tempBufferControlDependence[i])[z] << " ";
			}
			std::cout << std::endl;
		}*/

		/*
		if (strlen(tempBuffer) != 0)
		{
			TranslateCodeSlice((void**)tempppBuffer, &tempBufferIndex, (void**)tempppBuffer2, &tempBuffer2Index);
		
			TranslateIntermediateToVec((void**)tempppBuffer2, &tempBuffer2Index, (void**)tempppBuffer3, &tempBuffer3Index);
			
			//update previous pic save path
			GetBMP(tempppBuffer3, tempBufferDataDependence, tempBufferControlDependence, bSafe, OutputFilePath18, PicSize, PicSize, 1);
		}
		*/

		//strcat(tempBuffer2, "\r\n");

		/*if (!file::OutPutToFile(OutputFilePath10, tempBuffer2))
			std::cout << "Wirte File Fail" << std::endl;*/

		for (int i = 0; i < 150; i++)
		{
			delete[] tempBufferDataDependence[i];
			delete[] tempBufferControlDependence[i];
		}
		delete tempBufferDataDependence;
		delete tempBufferControlDependence;
		delete tempppBuffer;
		delete tempppBuffer2;
		delete tempppBuffer3;

		return 1;
	}

	int CheckReturnTypeIsPointerType(PVariable pVar)
	{
		if (pVar->returnType == ReturnType::pcharType || pVar->returnType == ReturnType::pdoubleType || pVar->returnType == ReturnType::pfloatType || pVar->returnType == ReturnType::pintType || pVar->returnType == ReturnType::plongType || pVar->returnType == ReturnType::pshortType || pVar->returnType == ReturnType::pvoidType || pVar->returnType == ReturnType::pwchar_tType || pVar->returnType == ReturnType::pint64_tType || pVar->returnType == ReturnType::ptwoIntsStructType || pVar->bArray)
		{
			return 1;
		}
		return 0;
	}

	int CheckLoopBranchHaveArrayAssignment(PStoreSensitiveAPIInfo pStoreSSAPIInfo)
	{
		int tempIndex = 0;
		int tempNameNum = 0;
		char** Name;
		int NameNum = 0;
		char* tempArray[20];
		int tempArrayNum = 0;
		int* tempArrayIndex;
		char tempBuffer[100];
		char** tempppBuffer;
		int tempBufferIndex = 0;
		int tempStartCodeLineNo = 0;
		int tempStopCodeLineNo = 0;
		int tempReturnCodeLineNum = 0;
		int tempCodeLineArray[60];
		int tempCodeLineArrayLength = 0;
		int tempInt = 0;
		int tempReturnMemoryAllocCodeLineNo[5] = {0};
		int tempReturnMemoryAllocCodeLineNoLength = 0;
		PSourceLine temppReturnCodeLine[20];
		PVariable temppVar;
		PSourceLine temppCodeLine;
		PCodeExePathBlock temppCodeBlock;
		PVariable temppVarArray[10];
		PVariable temppValueChangeVar;
		PVariable temppChangeValueVar;
		PVariable temppValueChangeArrayIndexVar;
		PVariable temppChangeValueArrayIndexVar;

		tempppBuffer = new char*;
		*tempppBuffer = (pStoreSSAPIInfo->pSourceLine)->buffer;

		tempArrayIndex = new int[20];
		for (int i = 0; i < 20; i++)
		{
			tempArray[i] = new char[50];
		}

		Name = new char* [10];
		for (int i = 0; i < 10; i++)
		{
			Name[i] = new char[80];
		}

		while (CheckNamableCharacter(&(((pStoreSSAPIInfo->pSourceLine)->buffer)[tempBufferIndex])))
		{
			tempBuffer[tempBufferIndex] = ((pStoreSSAPIInfo->pSourceLine)->buffer)[tempBufferIndex];
			tempBufferIndex++;
		}
		tempBuffer[tempBufferIndex] = 0x0;

		if (strcmp(tempBuffer, "for") == 0 || strcmp(tempBuffer, "while") == 0)
		{
			if (GetLoopBranchStartAndStopCodeLineNoAndIsHaveArrayAssignment(pStoreSSAPIInfo->pSourceLine->CodeLineNo, &tempStartCodeLineNo, &tempStopCodeLineNo, &temppCodeLine))
			{
				//��ѭ����֧���������Ĵ���
				tempNameNum = GetSubCodeName((void**)(tempppBuffer), &tempIndex, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
				for (int i = 0; i < NameNum; i++)
				{
					if (CheckVarExist(Name[i], pStoreSSAPIInfo->pFunc, &temppVar) == 1)
					{
						InitCodeExePathBlock(pStoreSSAPIInfo, pStoreSSAPIInfo->pFunc, &temppCodeBlock, pStoreSSAPIInfo->PathTraceDeepth, pStoreSSAPIInfo->VarDefByOtherVarNum, pStoreSSAPIInfo->VarChangeNum, pStoreSSAPIInfo->FunctionCallNum, pStoreSSAPIInfo->MacroChangeNum, pStoreSSAPIInfo->VarDefByOtherMacroNum, tempInt, true);
						GetVarValueSpreadChainFinalNode(temppVar, pStoreSSAPIInfo->pSourceLine->CodeLineNo, temppReturnCodeLine, &tempReturnCodeLineNum);
						for (int z = 0; z < tempReturnCodeLineNum; z++)
						{
							temppCodeBlock->Path[(temppCodeBlock->PathLength)++] = (temppReturnCodeLine[z])->GlobalLineNo;
						}
						GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(temppVar, temppVarArray, temppCodeBlock);
						tempReturnCodeLineNum = 0;
						GetVarChangeInRangeCodeLineNo(pStoreSSAPIInfo->pFunc, temppVar, temppVarArray, temppCodeBlock, tempStartCodeLineNo, tempStopCodeLineNo);
						tempInt++;
					}

				}

				if(GetArrayAssignmentCodeLineArrayVar(temppCodeLine, pStoreSSAPIInfo->pFunc, &temppValueChangeVar, &temppChangeValueVar, &temppValueChangeArrayIndexVar, &temppChangeValueArrayIndexVar))
				{
					
					InitCodeExePathBlock(pStoreSSAPIInfo, pStoreSSAPIInfo->pFunc, &temppCodeBlock, pStoreSSAPIInfo->PathTraceDeepth, pStoreSSAPIInfo->VarDefByOtherVarNum, pStoreSSAPIInfo->VarChangeNum, pStoreSSAPIInfo->FunctionCallNum, pStoreSSAPIInfo->MacroChangeNum, pStoreSSAPIInfo->VarDefByOtherMacroNum, tempInt, true);
					(temppCodeBlock->Path)[(temppCodeBlock->PathLength)++] = temppCodeLine->CodeLineNo;
					
					//��ѭ����֧������ֵ�ı�����б��ı�ֵ��������д���
					GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(temppValueChangeVar, temppVarArray, temppCodeBlock);
					GetArrayAssignmentValueChangeArrayVarInfo(temppValueChangeVar, temppCodeBlock);
					//update at 23.3.7 �������д���Ϊ����ȡheap_base_buffer_overflow����©����֮ǰstack_base_buffer_overflow����©����û���õ�
					GetVarMemoryAllocInfo(temppValueChangeVar, tempReturnMemoryAllocCodeLineNo, &tempReturnMemoryAllocCodeLineNoLength);
					for (int z = 0; z < tempReturnMemoryAllocCodeLineNoLength; z++)
					{
						(temppCodeBlock->Path)[(temppCodeBlock->PathLength)++] = tempReturnMemoryAllocCodeLineNo[z];
					}
					//update at 23.3.10 �������Ϊ����ȡBuffer_Overread����©���Ĵ���Ƭ�ζ���д��
					ExtractVarAsPrintFuncParInfo(temppValueChangeVar, temppCodeBlock, temppCodeLine->CodeLineNo);

					//��ѭ����֧������ֵ�ı�����б��ı�ֵ�������������д���
					GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(temppValueChangeArrayIndexVar, temppVarArray, temppCodeBlock);
					GetVarValueSpreadChainFinalNode(temppValueChangeArrayIndexVar, pStoreSSAPIInfo->pSourceLine->CodeLineNo, temppReturnCodeLine, &tempReturnCodeLineNum);
					for (int z = 0; z < tempReturnCodeLineNum; z++)
					{
						temppCodeBlock->Path[(temppCodeBlock->PathLength)++] = (temppReturnCodeLine[z])->GlobalLineNo;
					}
					tempReturnCodeLineNum = 0;
					GetVarChangeInRangeCodeLineNo(pStoreSSAPIInfo->pFunc, temppValueChangeArrayIndexVar, temppVarArray, temppCodeBlock, tempStartCodeLineNo, tempStopCodeLineNo);

					//��ѭ����֧������ֵ�ı�����иı�ֵ��������д���
					GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(temppChangeValueVar, temppVarArray, temppCodeBlock);
					GetVarBeforeCodeLineNoChangeValueInfoAndAsFunctionParInfo(temppChangeValueVar, temppCodeLine->CodeLineNo, tempCodeLineArray, &tempCodeLineArrayLength);
					for (int z = 0; z < tempCodeLineArrayLength; z++)
					{
						temppCodeBlock->Path[(temppCodeBlock->PathLength)++] = tempCodeLineArray[z];
					}
					GetVarChangeInRangeCodeLineNo(pStoreSSAPIInfo->pFunc, temppChangeValueVar, temppVarArray, temppCodeBlock, tempStartCodeLineNo, tempStopCodeLineNo);
					GetPVarPointMemoryInfo(temppChangeValueVar, temppCodeBlock);

					//��ѭ����֧������ֵ�ı�����иı�ֵ�������������д���
					GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(temppChangeValueArrayIndexVar, temppVarArray, temppCodeBlock);
					GetVarValueSpreadChainFinalNode(temppChangeValueArrayIndexVar, pStoreSSAPIInfo->pSourceLine->CodeLineNo, temppReturnCodeLine, &tempReturnCodeLineNum);
					for (int z = 0; z < tempReturnCodeLineNum; z++)
					{
						temppCodeBlock->Path[(temppCodeBlock->PathLength)++] = (temppReturnCodeLine[z])->GlobalLineNo;
					}
					tempReturnCodeLineNum = 0;
					GetVarChangeInRangeCodeLineNo(pStoreSSAPIInfo->pFunc, temppChangeValueArrayIndexVar, temppVarArray, temppCodeBlock, tempStartCodeLineNo, tempStopCodeLineNo);
				}
				else
				{
#ifdef _DEBUG
					std::cout << "CheckLoopBranchHaveArrayAssignment Error\n";
#endif
					return 0;
				}

				pStoreSSAPIInfo->ParNum = tempInt;
				BaseCodeExePathGenerateCodeSlice(pStoreSSAPIInfo);
			}
		}

		for (int i = 0; i < 10; i++)
		{
			if (strlen(Name[i]) != 0)
			{
				delete[]Name[i];
			}
		}
		delete[]Name;
		for (int i = 0; i < 20; i++)
		{
			if (strlen(tempArray[i]) != 0)
			{
				delete[]tempArray[i];
			}
		}
		delete[]tempArrayIndex;
		delete tempppBuffer;

		return 1;
	}

	//�򵥵Ķ�ѭ���ṹ��֧�����鸳ֵ�������ж�
	int GetLoopBranchStartAndStopCodeLineNoAndIsHaveArrayAssignment(int LoopBranchCodeLineNo, int* StartCodeLineNo, int* StopCodeLineNo, PSourceLine* AssignmentCodeLine)
	{
		int tempIndex = 1 + LoopBranchCodeLineNo;
		int tempLBraceNum = 0;
		int tempRBraceNum = 0;
		int tempReturn = 0;
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;

		GetCodeLineStruct(tempIndex, &temppCodeLine, &temppFunc);
		if (strcmp(temppCodeLine->buffer, "{") != 0)
		{
#ifdef _DEBUG
			std::cout << "Loop Branch Error\n";
#endif
			return tempReturn;
		}
		else
		{
			*StartCodeLineNo = tempIndex;
			tempLBraceNum++;
			tempIndex++;
			while (tempLBraceNum != tempRBraceNum)
			{
				GetCodeLineStruct(tempIndex, &temppCodeLine, &temppFunc);
				if (strcmp(temppCodeLine->buffer, "{") == 0)
				{
					tempLBraceNum++;
				}
				else if (strcmp(temppCodeLine->buffer, "}") == 0)
				{
					tempRBraceNum++;
				}
				else
				{
					if (CheckCodeLineHaveArrayAssignment(temppCodeLine))
					{
						*AssignmentCodeLine = temppCodeLine;
						tempReturn = 1;
					}
				}
				tempIndex++;
			}
			*StopCodeLineNo = tempIndex - 1;
		}

		return tempReturn;
	}

	//Ŀǰ�������ֻ��ʶ��򵥵����鸳ֵ����
	int CheckCodeLineHaveArrayAssignment(PSourceLine pCodeLine)
	{
		int tempIndex = 0;
		int tempIntArray[5];
		int tempIntReturn = 0;
		char** tempppBuffer;

		tempppBuffer = new char*;
		*tempppBuffer = pCodeLine->buffer;

		tempIntReturn = CheckLincCodeAssigningOperator((void**)tempppBuffer, tempIntArray);
		if (tempIntReturn > 0)
		{
			tempIndex = tempIntArray[0] - 1;
			while (tempIndex > 0)
			{
				if ((pCodeLine->buffer)[tempIndex] == ' ')
				{
					tempIndex--;
				}
				else
				{
					if ((pCodeLine->buffer)[tempIndex] == ']')
					{
						return 1;
					}
					else
					{
						return 0;
					}
				}
			}
		}
		else
		{
			return 0;
		}

		return 0;
	}

	int GetVarChangeInRangeCodeLineNo(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, int StartCodeLineNo, int StopCodeLineNo)
	{
		int tempIndex = 0;
		PStoreVarDefInfo temppStoreVarDefInfo;

		if (pVar->bChangeOtherVar)
		{
			temppStoreVarDefInfo = pVar->pChangeOtherVar;
			if (temppStoreVarDefInfo->ChangGlobalLineNo >= StartCodeLineNo && temppStoreVarDefInfo->ChangGlobalLineNo <= StopCodeLineNo)
			{
				pVarArray[(pCodeBlock->BlockRealVarDefByOtherVarNum)++] = temppStoreVarDefInfo->pVarDef;
				(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
			}
			temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
			for (int i = 1; i < pVar->ChangeOtherVarNum; i++)
			{
				if (temppStoreVarDefInfo->ChangGlobalLineNo >= StartCodeLineNo && temppStoreVarDefInfo->ChangGlobalLineNo <= StopCodeLineNo)
				{
					pVarArray[(pCodeBlock->BlockRealVarDefByOtherVarNum)++] = temppStoreVarDefInfo->pVarDef;
					(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
				}
				temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
			}
		}

		return 1;
	}

	//Ŀǰ�������ֻ��ʶ��򵥵����鸳ֵ����
	int GetArrayAssignmentCodeLineArrayVar(PSourceLine pCodeLine, PSourceFunction pFunc, PVariable* pValueChangeVar, PVariable* pChangeValueVar, PVariable* pValueChangeArrayIndexVar, PVariable* pChangeValueArrayIndexVar)
	{
		int tempIndex = 0;
		char tempBuffer[100];
		int tempBufferIndex = 0;
		int tempVarNo = 0;

		*pValueChangeVar = NULL;
		*pChangeValueVar = NULL;
		*pValueChangeArrayIndexVar = NULL;
		*pChangeValueArrayIndexVar = NULL;

		while ((pCodeLine->buffer)[tempIndex] != 0x0)
		{
			if (CheckNamableCharacter(&((pCodeLine->buffer)[tempIndex])))
			{
				tempBuffer[tempBufferIndex++] = (pCodeLine->buffer)[tempIndex];
			}
			else
			{
				if (tempBufferIndex > 0)
				{
					tempBuffer[tempBufferIndex] = 0x0;
					tempBufferIndex = 0;
					
					switch (tempVarNo)
					{
					case 0:
					{
						CheckVarExist(tempBuffer, pFunc, pValueChangeVar);
						break;
					}
					case 1:
					{
						CheckVarExist(tempBuffer, pFunc, pValueChangeArrayIndexVar);
						break;
					}
					case 2:
					{
						CheckVarExist(tempBuffer, pFunc, pChangeValueVar);
						break;
					}
					case 3:
					{
						CheckVarExist(tempBuffer, pFunc, pChangeValueArrayIndexVar);
						break;
					}
					default:
					{
						std::cout << "GetArrayAssignmentCodeLineArrayVar Error\n";
						return 0;
					}
					}
				}
				if ((pCodeLine->buffer)[tempIndex] == '[' || (pCodeLine->buffer)[tempIndex] == '=')
				{
					tempVarNo++;
				}
			}

			tempIndex++;
		}

		if (*pValueChangeVar && *pChangeValueVar && *pValueChangeArrayIndexVar && *pChangeValueArrayIndexVar)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	int GetVarBeforeCodeLineNoChangeValueInfoAndAsFunctionParInfo(PVariable pVar, int CodeLineNo, int* pCodeLineArray, int* CodeLineArrayLength)
	{
		int tempIndex = 0;
		SyntaxKey SyntaxKeyArray[8] = { SyntaxKey::ifType, SyntaxKey::switchType, SyntaxKey::caseType, SyntaxKey::defaultType, SyntaxKey::forType, SyntaxKey::whileType, SyntaxKey::elseType, SyntaxKey::switchType };
		PStoreVarDefInfo temppStoreVarDefInfo;
		PStoreMacroDefInfo temppStoreMacroDefInfo;
		PStoreFunctionDefInfo temppStoreFunctionDefInfo;
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;
		int tempReturnCodeLineArray[30] = { 0 };
		int tempReturnCodeLineArrayLength = 0;

		if (pVar->bChangVar)
		{
			temppStoreVarDefInfo = pVar->pChangVar;
			if (temppStoreVarDefInfo->ChangGlobalLineNo <= CodeLineNo)
			{
				pCodeLineArray[(*CodeLineArrayLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;

				//update at 23.3.8 ���������ҲӦ��Ϊ����ĺ궨��ı����ֵ�ͺ������øı����ֵ������������
				/*GetCodeLineStruct(temppStoreVarDefInfo->ChangGlobalLineNo, &temppCodeLine, &temppFunc);
				if (CheckCodeLineMasterTypeIsTargetSyntaxType(temppCodeLine->PUnSyntaxCode->MasterLineNo, SyntaxKeyArray, 3))
				{
					pCodeLineArray[(*CodeLineArrayLength)++] = temppCodeLine->PUnSyntaxCode->MasterLineNo;
				}*/
				GetCodeLineCodeBlockInfoIsTargetSyntaxType(temppStoreVarDefInfo->ChangGlobalLineNo, SyntaxKeyArray, 8, tempReturnCodeLineArray, &tempReturnCodeLineArrayLength);
				for (int i = 0; i < tempReturnCodeLineArrayLength; i++)
				{
					pCodeLineArray[(*CodeLineArrayLength)++] = tempReturnCodeLineArray[i];
				}
			}
			temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
			for (int i = 1; i < pVar->ChangeVarNum; i++)
			{
				if (temppStoreVarDefInfo->ChangGlobalLineNo <= CodeLineNo)
				{
					pCodeLineArray[(*CodeLineArrayLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
				
					//update at 23.3.8 ���������ҲӦ��Ϊ����ĺ궨��ı����ֵ�ͺ������øı����ֵ������������
					/*GetCodeLineStruct(temppStoreVarDefInfo->ChangGlobalLineNo, &temppCodeLine, &temppFunc);
					if (CheckCodeLineMasterTypeIsTargetSyntaxType(temppCodeLine->PUnSyntaxCode->MasterLineNo, SyntaxKeyArray, 3))
					{
						pCodeLineArray[(*CodeLineArrayLength)++] = temppCodeLine->PUnSyntaxCode->MasterLineNo;
					}*/
					GetCodeLineCodeBlockInfoIsTargetSyntaxType(temppStoreVarDefInfo->ChangGlobalLineNo, SyntaxKeyArray, 8, tempReturnCodeLineArray, &tempReturnCodeLineArrayLength);
					for (int z = 0; z < tempReturnCodeLineArrayLength; z++)
					{
						pCodeLineArray[(*CodeLineArrayLength)++] = tempReturnCodeLineArray[z];
					}
				}
				temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
			}
		}
		if (pVar->bChangeByOthersMacro)
		{
			temppStoreMacroDefInfo = pVar->pChangeOtherMacro;
			if (temppStoreMacroDefInfo->ChangeGlobalLineNo <= CodeLineNo)
			{
				pCodeLineArray[(*CodeLineArrayLength)++] = temppStoreMacroDefInfo->ChangeGlobalLineNo;
			}
			temppStoreMacroDefInfo = temppStoreMacroDefInfo->pNext;
			for (int i = 1; i < pVar->ChangeByOthersMacroNum; i++)
			{
				if (temppStoreMacroDefInfo->ChangeGlobalLineNo <= CodeLineNo)
				{
					pCodeLineArray[(*CodeLineArrayLength)++] = temppStoreMacroDefInfo->ChangeGlobalLineNo;
				}
				temppStoreMacroDefInfo = temppStoreMacroDefInfo->pNext;
			}
		}
		if (pVar->bIsFunctionCallPar)
		{
			temppStoreFunctionDefInfo = pVar->pFunctionCallPar;
			if (temppStoreFunctionDefInfo->FunctionCallGlobalLineNo <= CodeLineNo)
			{
				pCodeLineArray[(*CodeLineArrayLength)++] = temppStoreFunctionDefInfo->FunctionCallGlobalLineNo;
			}
			temppStoreFunctionDefInfo = temppStoreFunctionDefInfo->pNext;
			for (int i = 1; i < pVar->IsFunctionCallParNum; i++)
			{
				if (temppStoreFunctionDefInfo->FunctionCallGlobalLineNo <= CodeLineNo)
				{
					pCodeLineArray[(*CodeLineArrayLength)++] = temppStoreFunctionDefInfo->FunctionCallGlobalLineNo;
				}
				temppStoreFunctionDefInfo = temppStoreFunctionDefInfo->pNext;
			}
		}

		return 1;
	}

	int DeleteStrArrayRepetStr(char** StrArray, int* StrArrayLength)
	{
		for (int i = 0; i < *StrArrayLength; i++)
		{
			for (int z = i + 1; z < *StrArrayLength; z++)
			{
				if (strcmp(StrArray[i], StrArray[z]) == 0)
				{
					for (int x = z + 1; x < *StrArrayLength; x++)
					{
						strcpy(StrArray[x - 1], StrArray[x]);
					}
					(*StrArrayLength)--;
					z--;
				}
			}
		}

		return 1;
	}

	//ֻ�ܽ��м򵥵ļ�飬���ܽ��и��ӵļ��
	int CheckVarDefCodeLineValueAssignmentVarOrMacroDefInfo(PSourceLine pCodeLine, PSourceFunction pFunc, int* pReturnCodeLineArray, int* ReturnCodeLineArrayLength)
	{
		int tempIndex = 0;
		int tempIntReturn = 0;
		int tempIntReturnIndexArray[5];
		int tempBufferIndex = 0;
		char** tempppBuffer;
		char tempBuffer[100];
		PVariable temppVar;
		PMacro temppMacro;

		tempppBuffer = new char*;
		*tempppBuffer = pCodeLine->buffer;

		tempIntReturn = CheckLincCodeAssigningOperator((void**)tempppBuffer, tempIntReturnIndexArray);
		
		if (tempIntReturn != 0)
		{
			tempIndex = tempIntReturnIndexArray[0] + 1;
			while ((pCodeLine->buffer)[tempIndex] != 0x0)
			{
				if (CheckNamableCharacter(&(pCodeLine->buffer)[tempIndex]))
				{
					tempBuffer[tempBufferIndex++] = (pCodeLine->buffer)[tempIndex];
				}
				else
				{
					if (tempBufferIndex != 0)
					{
						tempBuffer[tempBufferIndex] = 0x0;
						tempBufferIndex = 0;
						if (CheckVarExist(tempBuffer, pFunc, &temppVar))
						{
							pReturnCodeLineArray[(*ReturnCodeLineArrayLength)++] = temppVar->DefCodeLineGlobalNo;
						}
						if (CheckMacroExist(tempBuffer, pFunc, &temppMacro))
						{
							pReturnCodeLineArray[(*ReturnCodeLineArrayLength)++] = temppMacro->DefCodeLineGlobalNo;
						}
					}
				}

				tempIndex++;
			}
		}

		delete tempppBuffer;

		return 1;
	}

	int CheckCodeLineHaveMemoryAlloc(void** Code, PSourceLine pCode, PSourceFunction pFunc)
	{
		int tempIndex = 0;
		char tempMemoryAllocFuncNameArray[2][20] = {"ALLOCA" , "malloc"};
		char tempStr[100];
		char tempStr2[100];
		int tempSubCodeIndex = 0;
		PVariable temppVar;

		while ((*(char**)Code)[tempIndex] != 0x0)
		{
			if (CheckNamableCharacter(&(*(char**)Code)[tempIndex]))
			{
				tempStr[tempSubCodeIndex++] = (*(char**)Code)[tempIndex];
			}
			else
			{
				if (tempSubCodeIndex != 0)
				{
					tempStr[tempSubCodeIndex] = 0x0;
					tempSubCodeIndex = 0;
					MoveCodeIndexUntillNoBlank(Code, &tempIndex);

					if ((*(char**)Code)[tempIndex] == '=' && (*(char**)Code)[tempIndex + 1] != '=')
					{
						strcpy(tempStr2, tempStr);
					}
					else
					{
						for (int i = 0; i < 2; i++)
						{
							if (strcmp(tempStr, tempMemoryAllocFuncNameArray[i]) == 0)
							{
								//����ڱ����������ڴ����н����ڴ����Ͳ������ڴ��������
								if (CheckVarExist(tempStr2, pFunc, &temppVar))
								{
									temppVar->bAllocMemory = true;
									temppVar->AllocMemoryCodeLineNo = AnalysisCodeLineNo;
								}
							}
						}
					}

					continue;
				}
			}

			tempIndex++;
		}

		return 1;
	}

	int GetVarAllocInfo(PVariable pVar, PCodeExePathBlock pCodeBlock)
	{
		int tempIndex = 0;

		if (pVar->bAllocMemory)
		{
			(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = pVar->AllocMemoryCodeLineNo;
			return 1;
		}
		else
		{
			return 0;
		}
	}

	int GetArrayAssignmentValueChangeArrayVarInfo(PVariable pVar, PCodeExePathBlock pCodeBlock)
	{
		int tempIndex = 0;
		PStoreVarDefInfo temppStoreVarDefInfo;
		SyntaxKey SyntaxKeyArray[8] = { SyntaxKey::ifType, SyntaxKey::switchType, SyntaxKey::caseType, SyntaxKey::defaultType, SyntaxKey::forType, SyntaxKey::whileType, SyntaxKey::elseType, SyntaxKey::switchType };
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;
		int tempReturnCodeLineArray[30] = { 0 };
		int tempReturnCodeLineArrayLength = 0;

		if (pVar->bChangVar && pVar->ChangeVarNum)
		{
			temppStoreVarDefInfo = pVar->pChangVar;
			(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
			
			//update at 23.3.8
			/*GetCodeLineStruct(temppStoreVarDefInfo->ChangGlobalLineNo, &temppCodeLine, &temppFunc);
			if (CheckCodeLineMasterTypeIsTargetSyntaxType(temppCodeLine->PUnSyntaxCode->MasterLineNo, SyntaxKeyArray, 8))
			{
				(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppCodeLine->PUnSyntaxCode->MasterLineNo;
			}*/
			GetCodeLineCodeBlockInfoIsTargetSyntaxType(temppStoreVarDefInfo->ChangGlobalLineNo, SyntaxKeyArray, 8, tempReturnCodeLineArray, &tempReturnCodeLineArrayLength);
			for (int i = 0; i < tempReturnCodeLineArrayLength; i++)
			{
				(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = tempReturnCodeLineArray[i];
			}

			if (temppStoreVarDefInfo->pVarDef)
			{
				(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->pVarDef->DefCodeLineGlobalNo;
			}
			for (int i = 1; i < pVar->ChangeVarNum; i++)
			{
				temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
				(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
				
				//update at 23.3.8
				/*GetCodeLineStruct(temppStoreVarDefInfo->ChangGlobalLineNo, &temppCodeLine, &temppFunc);
				if (CheckCodeLineMasterTypeIsTargetSyntaxType(temppCodeLine->PUnSyntaxCode->MasterLineNo, SyntaxKeyArray, 8))
				{
					(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppCodeLine->PUnSyntaxCode->MasterLineNo;
				}*/
				GetCodeLineCodeBlockInfoIsTargetSyntaxType(temppStoreVarDefInfo->ChangGlobalLineNo, SyntaxKeyArray, 8, tempReturnCodeLineArray, &tempReturnCodeLineArrayLength);
				for (int z = 0; z < tempReturnCodeLineArrayLength; z++)
				{
					(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = tempReturnCodeLineArray[z];
				}

				if (temppStoreVarDefInfo->pVarDef)
				{
					(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->pVarDef->DefCodeLineGlobalNo;
				}
			}
		}

		return 1;
	}

	//�򵥽���
	int GetPVarPointMemoryInfo(PVariable pVar, PCodeExePathBlock pCodeBlock)
	{
		int tempIndex = 0;
		PStoreVarDefInfo temppStoreVarDefInfo;
		int tempReturnCodeLineArray[20] = { 0 };
		int tempReturnCodeLineArrayLength = 0;
		SyntaxKey SyntaxKeyArray[8] = { SyntaxKey::ifType, SyntaxKey::switchType, SyntaxKey::caseType, SyntaxKey::defaultType, SyntaxKey::forType, SyntaxKey::whileType, SyntaxKey::elseType, SyntaxKey::switchType };

		if (CheckReturnTypeIsPointerType(pVar))
		{
			if (pVar->bChangVar)
			{
				temppStoreVarDefInfo = pVar->pChangVar;
				if (temppStoreVarDefInfo->pVarDef && CheckReturnTypeIsPointerType(temppStoreVarDefInfo->pVarDef))
				{
					(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;

					//update at 23.3.8
					/*GetCodeLineStruct(temppStoreVarDefInfo->ChangGlobalLineNo, &temppCodeLine, &temppFunc);
					if (CheckCodeLineMasterTypeIsTargetSyntaxType(temppCodeLine->PUnSyntaxCode->MasterLineNo, SyntaxKeyArray, 8))
					{
						(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppCodeLine->PUnSyntaxCode->MasterLineNo;
					}*/
					GetCodeLineCodeBlockInfoIsTargetSyntaxType(temppStoreVarDefInfo->ChangGlobalLineNo, SyntaxKeyArray, 8, tempReturnCodeLineArray, &tempReturnCodeLineArrayLength);
					for (int z = 0; z < tempReturnCodeLineArrayLength; z++)
					{
						(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = tempReturnCodeLineArray[z];
					}

					(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->pVarDef->DefCodeLineGlobalNo;
				}
				for (int i = 1; i < pVar->ChangeVarNum; i++)
				{
					temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
					if (temppStoreVarDefInfo->pVarDef && CheckReturnTypeIsPointerType(temppStoreVarDefInfo->pVarDef))
					{
						(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
						
						//update at 23.3.8
						/*GetCodeLineStruct(temppStoreVarDefInfo->ChangGlobalLineNo, &temppCodeLine, &temppFunc);
						if (CheckCodeLineMasterTypeIsTargetSyntaxType(temppCodeLine->PUnSyntaxCode->MasterLineNo, SyntaxKeyArray, 8))
						{
							(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppCodeLine->PUnSyntaxCode->MasterLineNo;
						}*/
						GetCodeLineCodeBlockInfoIsTargetSyntaxType(temppStoreVarDefInfo->ChangGlobalLineNo, SyntaxKeyArray, 8, tempReturnCodeLineArray, &tempReturnCodeLineArrayLength);
						for (int z = 0; z < tempReturnCodeLineArrayLength; z++)
						{
							(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = tempReturnCodeLineArray[z];
						}

						(pCodeBlock->Path)[(pCodeBlock->PathLength)++] = temppStoreVarDefInfo->pVarDef->DefCodeLineGlobalNo;
					}
				}
			}
		}
		else
		{
			return 0;
		}

		return 1;
	}

	int DisplayInterMediateArray()
	{
		PStoreVecInfo temppStoreVecInfo = pStoreVecTable->VecTableFristNode;

		std::cout << "InterMediate Table:\n";

		for (int i = 0; i < pStoreVecTable->VecNum; i++)
		{
			std::cout << temppStoreVecInfo->String << " : " << temppStoreVecInfo->VecValueStr << std::endl;
			temppStoreVecInfo = temppStoreVecInfo->pNext;
		}

		return 1;
	}

	int OutputFullFunctionIntermediateNew(int* CodeLineArray, int CodeLineArrayLength, bool bSafe)
	{
		int tempIndex = 0;
		int tempCodeLineArray[200];
		char tempBuffer[5000];
		char** tempppBuffer;
		int tempBufferIndex = 0;
		bool bInArray = false;
		PSourceLine temppCodeLine;
		PSourceFunction temppFuncion;

		tempppBuffer = new char*;

		*tempppBuffer = tempBuffer;

		memset(tempBuffer, 0x0, 5000);

		for (int i = 0; i < pSourceCodeFile->SourceCodeLineNum; i++)
		{
			tempCodeLineArray[tempIndex++] = ((pSourceCodeFile->SourceCodeLine)[i])->GlobalLineNo;
		}

		for (int i = 0; i < CodeLineArrayLength; i++)
		{
			bInArray = false;
			for (int z = 0; z < tempIndex; z++)
			{
				if (tempCodeLineArray[z] == CodeLineArray[i])
				{
					bInArray = true;
				}
			}
			if (!bInArray)
			{
				GetCodeLineStruct(CodeLineArray[i], &temppCodeLine, &temppFuncion);
				if (temppFuncion != NULL)
				{
					for (int z = temppFuncion->StartGlobalLineNo + 1; z <= temppFuncion->StopGlobalLineNo; z++)
					{
						tempCodeLineArray[tempIndex++] = z;
					}
				}
				else
				{
					tempCodeLineArray[tempIndex++] = CodeLineArray[i];
				}
			}
		}

		for (int i = 0; i < tempIndex; i++)
		{
			GetCodeLineStruct(tempCodeLineArray[i], &temppCodeLine, &temppFuncion);
			strcat(tempBuffer, temppCodeLine->buffer);
			strcat(tempBuffer, "\r\n");
		}

		strcat(tempBuffer, "\r\n");

		if (!file::OutPutToFile(OutputFilePath12, (char*)"1\r\n"))
			std::cout << "Wirte File Fail" << std::endl;
		if (!file::OutPutToFile(OutputFilePath12, (char*)"--------------------------------------------------------------------\r\n"))
			std::cout << "Wirte File Fail" << std::endl;
		if (!file::OutPutToFile(OutputFilePath12, tempBuffer))
			std::cout << "Wirte File Fail" << std::endl;

		delete tempppBuffer;

		return 1;
	}

	int GetVarMemoryAllocInfo(PVariable pVar, int* pReturn, int* ReturnLength)
	{
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;

		if (pVar->bAllocMemory)
		{
			pReturn[(*ReturnLength)++] = pVar->AllocMemoryCodeLineNo;
			GetCodeLineStruct(pVar->AllocMemoryCodeLineNo, &temppCodeLine, &temppFunc);
			if (temppCodeLine->PUnSyntaxCode->MasterType == 1)
			{
				GetCodeLineStruct(temppCodeLine->PUnSyntaxCode->MasterLineNo, &temppCodeLine, &temppFunc);
				for (int i = 0; i < temppCodeLine->PSyntaxCode->SyntaxChainLength; i++)
				{
					pReturn[(*ReturnLength)++] = (temppCodeLine->PSyntaxCode->SyntaxChainCodeLineArray)[i];
				}
			}
		}
		else
		{
			return 0;
		}

		return 1;
	}

	//���Ŀ��������Ƿ�Ϊtarget����Syntax
	int CheckCodeLineMasterTypeIsTargetSyntaxType(int CodeLineNo, SyntaxKey* target, int SyntaxKeyLength)
	{
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;

		GetCodeLineStruct(CodeLineNo, &temppCodeLine, &temppFunc);
		for (int i = 0; i < SyntaxKeyLength; i++)
		{
			if (temppCodeLine->PSyntaxCode->SyntaxKeyType == target[i])
			{
				return 1;
			}
		}

		return 0;
	}

	int GetCodeLineCodeBlockInfoIsTargetSyntaxType(int CodeLineNo, SyntaxKey* target, int SyntaxKeyLength, int* ReturnCodeLineArray, int* ReturnCodeLineArrayLength)
	{
		int tempCodeLineNo = CodeLineNo;
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;
		bool bFirstCheck = true;

		GetCodeLineStruct(CodeLineNo, &temppCodeLine, &temppFunc);
		GetCodeLineStruct(temppCodeLine->PUnSyntaxCode->MasterLineNo, &temppCodeLine, &temppFunc);
		while (1)
		{
			for (int i = 0; i < SyntaxKeyLength; i++)
			{
				if (bFirstCheck)
				{
					bFirstCheck = false;
					if (temppCodeLine->PSyntaxCode->SyntaxKeyType == SyntaxKey::switchType)
					{
						break;
					}
				}
				if (temppCodeLine->PSyntaxCode->SyntaxKeyType == target[i])
				{
					ReturnCodeLineArray[(*ReturnCodeLineArrayLength)++] = temppCodeLine->GlobalLineNo;
					ReturnCodeLineArray[(*ReturnCodeLineArrayLength)++] = temppCodeLine->PSyntaxCode->FirstContentLineNo;
					ReturnCodeLineArray[(*ReturnCodeLineArrayLength)++] = temppCodeLine->PSyntaxCode->FinalContentLineNo;
					
				}
			}
			if (temppCodeLine->PUnSyntaxCode->MasterType != 1 && temppCodeLine->PUnSyntaxCode->MasterType != 0)
			{
				break;
			}
			else
			{
				GetCodeLineStruct(temppCodeLine->PUnSyntaxCode->MasterLineNo, &temppCodeLine, &temppFunc);
			}
		}

		return 1;
	}

	int AddVarAsArrayIndexInfo(void** Code, int* index, PSourceFunction pFunc)
	{
		int tempIndex = 0;
		int tempSubCodeIndex = 0;
		char tempSubCode[150] = { 0x0 };
		char tempSubCode1[150] = { 0x0 };
		bool bArrayIndex = false;
		PVariable temppVar;
		PVariable temppVar1;
		PStoreAsArrayIndexInfo temppStoreAsArrayIndexInfo;

		while ((*(char**)Code)[*index + tempIndex] != 0x0)
		{
			if (CheckNamableCharacter(&((*(char**)Code)[*index + tempIndex])))
			{
				tempSubCode[tempSubCodeIndex++] = (*(char**)Code)[*index + tempIndex];
			}
			else
			{
				tempSubCode[tempSubCodeIndex] = 0x0;

				if (bArrayIndex && tempSubCodeIndex)
				{
					if (CheckVarExist(tempSubCode, pFunc, &temppVar))
					{
						temppStoreAsArrayIndexInfo = new StoreAsArrayIndexInfo;

						InitStoreAsArrayIndexInfo(temppStoreAsArrayIndexInfo);
						temppStoreAsArrayIndexInfo->AsArrayIndexGlobalCodeLineNo = AnalysisCodeLineNo;
						temppStoreAsArrayIndexInfo->pParent = temppVar;
						CheckVarExist(tempSubCode1, pFunc, &temppVar1);
						temppStoreAsArrayIndexInfo->pVar = temppVar1;

						AddStoreAsArrayIndexInfo(temppVar, temppStoreAsArrayIndexInfo);
					}
				}

				if (tempSubCodeIndex)
				{
					strcpy(tempSubCode1, tempSubCode);
				}
				tempSubCodeIndex = 0;

				if ((*(char**)Code)[*index + tempIndex] == '[')
				{
					bArrayIndex = true;
				}
				if ((*(char**)Code)[*index + tempIndex] == ']')
				{
					bArrayIndex = false;
				}
			}

			tempIndex++;
		}

		return 1;
	}

	int ExtractVarAsPrintFuncParInfo(PVariable pVar, PCodeExePathBlock pBlock, int CodeLineNo)
	{
		PStoreFunctionDefInfo temppStoreFuncDefInfo;
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;
		PStoreVarDefInfo temppStoreVarDefInfo;
		char** tempppCodeLine;
		char tempSubCode[2][15] = { "printLine" , "printWLine"};

		tempppCodeLine = new char*;

		if (pVar->bIsFunctionCallPar)
		{
			temppStoreFuncDefInfo = pVar->pFunctionCallPar;
			if (temppStoreFuncDefInfo->FunctionCallGlobalLineNo > CodeLineNo)
			{
				GetCodeLineStruct(temppStoreFuncDefInfo->FunctionCallGlobalLineNo, &temppCodeLine, &temppFunc);
				*tempppCodeLine = temppCodeLine->buffer;
				for (int z = 0; z < 2; z++)
				{
					if (CheckAscii((void**)tempppCodeLine, strlen(temppCodeLine->buffer), tempSubCode[z]))
					{
						//����һ�δ���Ϊ��buffer_overread����©����д�����25.c֮����ļ�©��������ȡ��д
						if (pVar->bChangVar)
						{
							temppStoreVarDefInfo = pVar->pChangVar;
							if (temppStoreVarDefInfo->ChangGlobalLineNo > CodeLineNo && temppStoreVarDefInfo->ChangGlobalLineNo < temppCodeLine->GlobalLineNo)
							{
								(pBlock->Path)[(pBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
							}
							for (int i = 1; i < pVar->ChangeVarNum; i++)
							{
								temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
								if (temppStoreVarDefInfo->ChangGlobalLineNo > CodeLineNo && temppStoreVarDefInfo->ChangGlobalLineNo < temppCodeLine->GlobalLineNo)
								{
									(pBlock->Path)[(pBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
								}
							}
						}
						////////////////////////////////////////

						(pBlock->Path)[(pBlock->PathLength)++] = temppCodeLine->GlobalLineNo;
					}
				}
			}
			for (int i = 1; i < pVar->IsFunctionCallParNum; i++)
			{
				temppStoreFuncDefInfo = temppStoreFuncDefInfo->pNext;

				if (temppStoreFuncDefInfo->FunctionCallGlobalLineNo > CodeLineNo)
				{
					GetCodeLineStruct(temppStoreFuncDefInfo->FunctionCallGlobalLineNo, &temppCodeLine, &temppFunc);
					*tempppCodeLine = temppCodeLine->buffer;
					for (int x = 0; x < 2; x++)
					{
						if (CheckAscii((void**)tempppCodeLine, strlen(temppCodeLine->buffer), tempSubCode[x]))
						{
							//����һ�δ���Ϊ��buffer_overread����©����д�����25.c֮����ļ�©��������ȡ��д
							if (pVar->bChangVar)
							{
								temppStoreVarDefInfo = pVar->pChangVar;
								if (temppStoreVarDefInfo->ChangGlobalLineNo > CodeLineNo && temppStoreVarDefInfo->ChangGlobalLineNo < temppCodeLine->GlobalLineNo)
								{
									(pBlock->Path)[(pBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
								}
								for (int z = 1; z < pVar->ChangeVarNum; z++)
								{
									temppStoreVarDefInfo = temppStoreVarDefInfo->pNext;
									if (temppStoreVarDefInfo->ChangGlobalLineNo > CodeLineNo && temppStoreVarDefInfo->ChangGlobalLineNo < temppCodeLine->GlobalLineNo)
									{
										(pBlock->Path)[(pBlock->PathLength)++] = temppStoreVarDefInfo->ChangGlobalLineNo;
									}
								}
							}
							////////////////////////////////////////

							(pBlock->Path)[(pBlock->PathLength)++] = temppCodeLine->GlobalLineNo;
						}
					}
				}
			}
		}

		return 1;
	}

	//Ŀǰ�������ֻ�ǽ��м򵥵Ĺ���Strchr�����Ĵ���Ƭ�ε���ȡ
	int ExtractStrchrFuncInfo(PStoreFunctionDefInfo StoreFuncDefInfo, PCodeExePathBlock pBlock)
	{
		if (!strcmp(StoreFuncDefInfo->Name, "strchr"))
		{
			(pBlock->Path)[(pBlock->PathLength)++] = StoreFuncDefInfo->FunctionCallGlobalLineNo;
			(pBlock->Path)[(pBlock->PathLength)++] = StoreFuncDefInfo->FunctionCallGlobalLineNo + 1;
			(pBlock->Path)[(pBlock->PathLength)++] = StoreFuncDefInfo->FunctionCallGlobalLineNo + 2;
			(pBlock->Path)[(pBlock->PathLength)++] = StoreFuncDefInfo->FunctionCallGlobalLineNo + 3;
			(pBlock->Path)[(pBlock->PathLength)++] = StoreFuncDefInfo->FunctionCallGlobalLineNo + 4;
		}

		return 1;
	}

	int ExtractVarAsFprintfFuncParInfo(PVariable pVar, PCodeExePathBlock pBlock, int CodeLineNo)
	{
		PStoreFunctionDefInfo temppStoreFuncDefInfo;
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;
		PStoreVarDefInfo temppStoreVarDefInfo;
		char** tempppCodeLine;
		char tempSubCode[2][15] = { "fprintf", "printf"};

		tempppCodeLine = new char*;

		if (pVar->bIsFunctionCallPar)
		{
			temppStoreFuncDefInfo = pVar->pFunctionCallPar;
			if (temppStoreFuncDefInfo->FunctionCallGlobalLineNo > CodeLineNo)
			{
				GetCodeLineStruct(temppStoreFuncDefInfo->FunctionCallGlobalLineNo, &temppCodeLine, &temppFunc);
				*tempppCodeLine = temppCodeLine->buffer;
				for (int z = 0; z < 2; z++)
				{
					if (CheckAscii((void**)tempppCodeLine, strlen(temppCodeLine->buffer), tempSubCode[z]))
					{
						(pBlock->Path)[(pBlock->PathLength)++] = temppCodeLine->GlobalLineNo;
					}
				}
			}
			for (int i = 1; i < pVar->IsFunctionCallParNum; i++)
			{
				temppStoreFuncDefInfo = temppStoreFuncDefInfo->pNext;

				if (temppStoreFuncDefInfo->FunctionCallGlobalLineNo > CodeLineNo)
				{
					GetCodeLineStruct(temppStoreFuncDefInfo->FunctionCallGlobalLineNo, &temppCodeLine, &temppFunc);
					*tempppCodeLine = temppCodeLine->buffer;
					for (int x = 0; x < 2; x++)
					{
						if (CheckAscii((void**)tempppCodeLine, strlen(temppCodeLine->buffer), tempSubCode[x]))
						{
							(pBlock->Path)[(pBlock->PathLength)++] = temppCodeLine->GlobalLineNo;
						}
					}
				}
			}
		}

		return 1;
	}

	int HandleReturnCodeLineArrayForCWE194(PSourceLine* CodeLineArray, int* CodeLineArrayLength)
	{
		PSourceFunction temppFunc;
		char** tempppSubCode;
		char tempSubCode[10] = "CWE194";

		tempppSubCode = new char*;

		GetFunctionStruct((CodeLineArray[0])->FunctionNo, &temppFunc);
		*tempppSubCode = temppFunc->FunctionName;

		if (CheckAscii((void**)tempppSubCode, strlen(temppFunc->FunctionName), tempSubCode))
		{
			for (int i = 0; i < *CodeLineArrayLength; i++)
			{
				if (!strcmp((CodeLineArray[i])->buffer, "data = 0;"))
				{
					for (int z = i; z < *CodeLineArrayLength - 1; z++)
					{
						CodeLineArray[z] = CodeLineArray[z + 1];
					}
					(*CodeLineArrayLength)--;
					i--;
				}
			}
		}

		return 1;
	}

	int GetFunctionStruct(int FunctionNo, PSourceFunction* pReturn)
	{
		*pReturn = (pSourceCodeFile->Function)[FunctionNo];

		return 1;
	}

	int HandleCodeSliceForCWE134(PVariable pVar, int CodeLineNo, PCodeExePathBlock pBlock)
	{
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;
		PStoreFunctionDefInfo temppStoreFunctionDefInfo;
		char tempSubCode[4][60] = { "strcpy(data, \"fixedstringtest\");" , "strncat(data+dataLen, environment, 100-dataLen-1);" , "wcscpy(data, L\"fixedstringtest\");" , "wcsncat(data+dataLen, environment, 100-dataLen-1);"};
		char tempSubCode1[11][20] = { "SNPRINTF" , "goodG2B1VaSinkB" , "goodG2B2VaSinkB" , "goodG2BVaSink" , "goodB2G1VaSinkG" , "goodB2G2VaSinkG" , "badVaSinkB" , "goodB2GVaSink" , "badVaSink" , "goodB2GVaSinkG" , "goodG2BVaSinkB"};

		GetCodeLineStruct(CodeLineNo, &temppCodeLine, &temppFunc);
		for (int x = 0; x < 4; x++)
		{
			if (!strcmp(temppCodeLine->buffer, tempSubCode[x]))
			{
				if (pVar->bIsFunctionCallPar)
				{
					temppStoreFunctionDefInfo = pVar->pFunctionCallPar;
					for (int z = 0; z < 11; z++)
					{
						if (!strcmp(temppStoreFunctionDefInfo->Name, tempSubCode1[z]))
						{
							(pBlock->Path)[(pBlock->PathLength)++] = temppStoreFunctionDefInfo->FunctionCallGlobalLineNo;
						}
					}
					for (int i = 1; i < pVar->IsFunctionCallParNum; i++)
					{
						temppStoreFunctionDefInfo = temppStoreFunctionDefInfo->pNext;
						for (int z = 0; z < 11; z++)
						{
							if (!strcmp(temppStoreFunctionDefInfo->Name, tempSubCode1[z]))
							{
								(pBlock->Path)[(pBlock->PathLength)++] = temppStoreFunctionDefInfo->FunctionCallGlobalLineNo;
							}
						}
					}
				}
				else
				{
#ifdef _DEBUG
					std::cout << "HandleCodeSliceForCWE134 error\n";
#endif
					return 0;
				}
			}
		}

		return 1;
	}

	int ExtractVfprintfFuncInfo(PStoreFunctionDefInfo StoreFuncDefInfo, PCodeExePathBlock pBlock)
	{
		PSourceLine temppCodeLine;
		PSourceFunction temppFunc;

		if (!strcmp(StoreFuncDefInfo->Name, "va_start"))
		{
			GetCodeLineStruct(StoreFuncDefInfo->FunctionCallGlobalLineNo, &temppCodeLine, &temppFunc);
			if (!strcmp(temppFunc->FunctionName, "goodB2G1VaSinkG") || !strcmp(temppFunc->FunctionName, "goodB2G2VaSinkG") || !strcmp(temppFunc->FunctionName, "goodB2GVaSink") || !strcmp(temppFunc->FunctionName, "goodB2GVaSinkG"))
			{
				(pBlock->Path)[(pBlock->PathLength)++] = StoreFuncDefInfo->FunctionCallGlobalLineNo + 1;
			}
		}

		return 1;
	}

	int CheckCodeBracketIsCompletion(void** Code, int* index, int* end)
	{
		int tempIndex = 0;
		int tempLBracketNum = 0;

		while (*index + tempIndex <= *end)
		{
			if ((*(char**)Code)[*index + tempIndex] == '(')
			{
				tempLBracketNum++;
			}
			if ((*(char**)Code)[*index + tempIndex] == ')')
			{
				if (tempLBracketNum > 0)
				{
					tempLBracketNum--;
				}
				else
				{
					return 0;
				}
			}

			tempIndex++;
		}

		if (tempLBracketNum != 0)
		{
			return 0;
		}

		return 1;
	}

	int CheckCodeBlankNew(void** Code, int* index, char* ReturnSubCode)
	{
		int tempIndex = 0;
		int tempLBracket = 0;

		while ((*(char**)Code)[*index + tempIndex] != 0x0)
		{
			if ((*(char**)Code)[*index + tempIndex] == ' ' && tempLBracket == 0)
			{
				break;
			}
			if ((*(char**)Code)[*index + tempIndex] == '(')
			{
				tempLBracket++;
			}
			if ((*(char**)Code)[*index + tempIndex] == ')')
			{
				if (tempLBracket > 0)
				{
					tempLBracket--;
				}
				else
				{
					return 0;
				}
			}

			ReturnSubCode[tempIndex] = (*(char**)Code)[*index + tempIndex];
			tempIndex++;
		}
		ReturnSubCode[tempIndex] = 0x0;

		return tempIndex;
	}

	int HandleUnprocessableFunc(void** Code, int* index)
	{
		int tempIndex = 0;
		char tempCodeExtractPath[100];
		char tempNoCodeExtractPath[100];

		memset(tempCodeExtractPath, 0x0, 100);
		memset(tempNoCodeExtractPath, 0x0, 100);

		if (strstr(pSourceCodeFile->FilePath, "\\Vulnerable\\"))
		{
			sprintf(tempCodeExtractPath, "%s%d_0.bmp", OutputFilePath9, OutputPicNum);
			sprintf(tempNoCodeExtractPath, "%s%d_0.bmp", OutputFilePath11, OutputPicNum2);
			HandleCodeRxtractFuncVuln(tempCodeExtractPath);
			HandleNoCodeExtractFuncVuln(tempNoCodeExtractPath);
			OutputPicNum++;
			OutputPicNum2++;
		}
		else if (strstr(pSourceCodeFile->FilePath, "\\UnVulnerable\\"))
		{
			sprintf(tempCodeExtractPath, "%s%d_1.bmp", OutputFilePath9, OutputPicNum);
			sprintf(tempNoCodeExtractPath, "%s%d_1.bmp", OutputFilePath11, OutputPicNum2);
			HandleCodeExtractFuncNotVuln(tempCodeExtractPath);
			HandleNoCodeExtractFuncNotVuln(tempNoCodeExtractPath);
			OutputPicNum++;
			OutputPicNum2++;
		}
		else
		{
#ifdef _DEBUG
			std::cout << "Handle Real World Func Error!\n";
#endif
			return 0;
		}

		return 1;
	}

	int HandleNoCodeExtractFuncNotVuln(char* FilePath)
	{
		int** CodeMatrix;
		int** DataDependenceMatrix;
		int** ControlDependenceMatrix;
		int MatrixSize = 150;

		CodeMatrix = new int* [MatrixSize];
		DataDependenceMatrix = new int* [MatrixSize];
		ControlDependenceMatrix = new int* [MatrixSize];

		for (int i = 0; i < MatrixSize; i++)
		{
			CodeMatrix[i] = new int[MatrixSize];
			DataDependenceMatrix[i] = new int[MatrixSize];
			ControlDependenceMatrix[i] = new int[MatrixSize];
		}

		for (int i = 0; i < MatrixSize; i++)
		{
			for (int z = 0; z < MatrixSize; z++)
			{
				CodeMatrix[i][z] = 0;
				DataDependenceMatrix[i][z] = 0;
				ControlDependenceMatrix[i][z] = 0;
			}
		}

		GenerateBMP(FilePath,150,150,CodeMatrix,DataDependenceMatrix,ControlDependenceMatrix);

		for (int i = 0; i < MatrixSize; i++)
		{
			delete[] CodeMatrix[i];
			delete[] DataDependenceMatrix[i];
			delete[] ControlDependenceMatrix[i];
		}

		delete[] CodeMatrix;
		delete[] DataDependenceMatrix;
		delete[] ControlDependenceMatrix;

		return 1;
	}

	int HandleNoCodeExtractFuncVuln(char* FilePath)
	{
		int** CodeMatrix;
		int** DataDependenceMatrix;
		int** ControlDependenceMatrix;
		int MatrixSize = 150;

		CodeMatrix = new int* [MatrixSize];
		DataDependenceMatrix = new int* [MatrixSize];
		ControlDependenceMatrix = new int* [MatrixSize];

		for (int i = 0; i < MatrixSize; i++)
		{
			CodeMatrix[i] = new int[MatrixSize];
			DataDependenceMatrix[i] = new int[MatrixSize];
			ControlDependenceMatrix[i] = new int[MatrixSize];
		}

		for (int i = 0; i < MatrixSize; i++)
		{
			for (int z = 0; z < MatrixSize; z++)
			{
				CodeMatrix[i][z] = 0;
				DataDependenceMatrix[i][z] = 0;
				ControlDependenceMatrix[i][z] = 0;
			}
		}

		GenerateBMP(FilePath, 150, 150, CodeMatrix, DataDependenceMatrix, ControlDependenceMatrix);

		for (int i = 0; i < MatrixSize; i++)
		{
			delete[] CodeMatrix[i];
			delete[] DataDependenceMatrix[i];
			delete[] ControlDependenceMatrix[i];
		}

		delete[] CodeMatrix;
		delete[] DataDependenceMatrix;
		delete[] ControlDependenceMatrix;

		return 1;
	}

	int HandleCodeExtractFuncNotVuln(char* FilePath)
	{
		int** CodeMatrix;
		int** DataDependenceMatrix;
		int** ControlDependenceMatrix;
		int MatrixSize = 50;

		CodeMatrix = new int* [MatrixSize];
		DataDependenceMatrix = new int* [MatrixSize];
		ControlDependenceMatrix = new int* [MatrixSize];

		for (int i = 0; i < MatrixSize; i++)
		{
			CodeMatrix[i] = new int[MatrixSize];
			DataDependenceMatrix[i] = new int[MatrixSize];
			ControlDependenceMatrix[i] = new int[MatrixSize];
		}

		for (int i = 0; i < MatrixSize; i++)
		{
			for (int z = 0; z < MatrixSize; z++)
			{
				CodeMatrix[i][z] = 0;
				DataDependenceMatrix[i][z] = 0;
				ControlDependenceMatrix[i][z] = 0;
			}
		}

		GenerateBMP(FilePath, 50, 50, CodeMatrix, DataDependenceMatrix, ControlDependenceMatrix);

		for (int i = 0; i < MatrixSize; i++)
		{
			delete[] CodeMatrix[i];
			delete[] DataDependenceMatrix[i];
			delete[] ControlDependenceMatrix[i];
		}

		delete[] CodeMatrix;
		delete[] DataDependenceMatrix;
		delete[] ControlDependenceMatrix;

		return 1;
	}

	int HandleCodeRxtractFuncVuln(char* FilePath)
	{

		int** CodeMatrix;
		int** DataDependenceMatrix;
		int** ControlDependenceMatrix;
		int MatrixSize = 50;

		CodeMatrix = new int* [MatrixSize];
		DataDependenceMatrix = new int* [MatrixSize];
		ControlDependenceMatrix = new int* [MatrixSize];

		for (int i = 0; i < MatrixSize; i++)
		{
			CodeMatrix[i] = new int[MatrixSize];
			DataDependenceMatrix[i] = new int[MatrixSize];
			ControlDependenceMatrix[i] = new int[MatrixSize];
		}

		for (int i = 0; i < MatrixSize; i++)
		{
			for (int z = 0; z < MatrixSize; z++)
			{
				CodeMatrix[i][z] = 0;
				DataDependenceMatrix[i][z] = 0;
				ControlDependenceMatrix[i][z] = 0;
			}
		}

		GenerateBMP(FilePath, 50, 50, CodeMatrix, DataDependenceMatrix, ControlDependenceMatrix);

		for (int i = 0; i < MatrixSize; i++)
		{
			delete[] CodeMatrix[i];
			delete[] DataDependenceMatrix[i];
			delete[] ControlDependenceMatrix[i];
		}

		delete[] CodeMatrix;
		delete[] DataDependenceMatrix;
		delete[] ControlDependenceMatrix;

		return 1;
	}

	int HandleFileNumFunc(const char* path, const char* path2)
	{
		char tempBuffer[20];
		char tempBuffer2[8000];
		char** tempppBuffer;
		char** tempppBuffer2;
		int tempInt = 0;
		int tempCurrentFileNo = 0;
		int tempLineFeedNum = 0;
		FILE* fp;

		tempppBuffer = new char*;
		*tempppBuffer = tempBuffer;

		tempppBuffer2 = new char*;
		*tempppBuffer2 = tempBuffer2;

		memset(tempBuffer, 0x0, 20);
		memset(tempBuffer2, 0x0, 8000);

		file::readOneFile(path, (void**)tempppBuffer);

		tempInt = StrToInt(tempBuffer);

		tempCurrentFileNo = GetCurrentFileNo();

		file::readOneFile(path2, (void**)tempppBuffer2);
		tempLineFeedNum = GetFileHaveLineFeedNum(tempppBuffer2);

		if (tempCurrentFileNo != tempInt + tempLineFeedNum)
		{
			memset(tempBuffer2, 0x0, 5000);
			//IntToStr(tempCurrentFileNo - 1, tempBuffer2);
			strcpy(tempBuffer2, pSourceCodeFile->FilePath);
			strcat(tempBuffer2, "\r\n");
			file::OutPutToFile(path2, tempBuffer2);
		}

		tempInt++;

		memset(tempBuffer, 0x0, 20);

		IntToStrNew(tempInt, tempBuffer);

		fp = fopen(path, "wb");
		if (fp == NULL)
		{
			printf("%s: file create failed!\n", path);
			return -1;
		}
		fprintf(fp, "%d", tempInt);
		if (fclose(fp))
		{
			printf("file close failed!\n");
			return -1;
		}
		fp = NULL;

		return 1;
	}

	//Ŀǰ����������ܴ���c�����ļ���Ӳ�����д��
	int GetCurrentFileNo()
	{
		int tempIndex = 0;
		int tempStartIndex = 0;
		int tempStopIndex = 0;
		char* tempPath;
		char tempSubCode[50];
		int tempReturn = 0;

		memset(tempSubCode, 0x0, 20);

		tempPath = pSourceCodeFile->FilePath;

		while (tempPath[tempIndex] != 0x0)
		{
			if (tempPath[tempIndex] == '\\')
			{
				tempStartIndex = tempIndex + 1;
			}
			if (tempPath[tempIndex] == '.' && (tempPath[tempIndex + 1] == 'c' || tempPath[tempIndex] == 'C'))
			{
				tempStopIndex = tempIndex - 1;
			}

			tempIndex++;
		}

		tempIndex = 0;
		for (int i = tempStartIndex; i <= tempStopIndex; i++)
		{
			tempSubCode[tempIndex++] = tempPath[i];
		}

		tempReturn = StrToInt(tempSubCode);

		return tempReturn;
	}

	int GetFileHaveLineFeedNum(char** Code)
	{
		int tempCodeLineNum = 0;
		int tempIndex = 0;
		char tempSubCode[200];
		int tempCodeLength = 0;
		int tempReturnLength = 0;
		tempCodeLength = strlen(*Code);
		while (tempIndex < tempCodeLength)
		{
			tempReturnLength = DivisionCodeByLineFeed((void**)Code, &tempIndex, tempSubCode);
			tempIndex = tempIndex + tempReturnLength + 2;
			tempCodeLineNum++;
		}

		return tempCodeLineNum;
	}

	int OutputFuncToFile(int FuncNo, bool bSafe)
	{
		int tempIndex = 0;
		PSourceFunction temppFunc;
		char tempPath[100];
		char tempBuffer[20];
		char tempBuffer2[10000];

		memset(tempBuffer2, 0x0, 10000);
		memset(tempBuffer, 0x0, 20);
		memset(tempPath, 0x0, 100);

		IntToStrNew(OutputFuncToFileNo, tempBuffer);
		GetFunctionStruct(FuncNo, &temppFunc);

		if (bSafe)
		{
			strcat(tempPath, OutputFilePath14);
			strcat(tempPath, tempBuffer);
			strcat(tempPath, "_1.c");
		}
		else
		{
			strcat(tempPath, OutputFilePath13);
			strcat(tempPath, tempBuffer);
			strcat(tempPath, "_0.c");
		}

		for (int i = 0; i < temppFunc->CodeLineNum; i++)
		{
			strcat(tempBuffer2, ((temppFunc->CodeLine)[i])->buffer);
			strcat(tempBuffer2, "\n");
		}

		file::OutPutToFile((const char*)tempPath, tempBuffer2);

		OutputFuncToFileNo++;

		return 1;
	}

	int WriteOutputFuncNumConfigFile(const char* FilePath)
	{
		char tempBuffer[20];
		FILE* fp;

		memset(tempBuffer, 0x0, 20);

		IntToStrNew(OutputFuncToFileNo, tempBuffer);

		fp = fopen(FilePath, "wb");
		if (fp == NULL)
		{
			printf("%s: file create failed!\n", FilePath);
			return -1;
		}
		fprintf(fp, "%d", OutputFuncToFileNo);
		if (fclose(fp))
		{
			printf("file close failed!\n");
			return -1;
		}
		fp = NULL;

		return 1;
	}

	int ReadOutputFuncNumConfigFile(const char* FilePath)
	{
		char tempBuffer[20];
		char** tempppBuffer;

		tempppBuffer = new char*;
		*tempppBuffer = tempBuffer;

		memset(tempBuffer, 0x0, 20);

		file::readOneFile(FilePath, (void**)tempppBuffer);

		OutputFuncToFileNo = StrToInt(tempBuffer);

		//��ΪǱ��©��Ƭ���ļ��������Ƕ�Ӧ���ɲ�����Ǳ��©������Ƭ����ȡ�ļ�ͬʱ���еģ�������ôд�ˣ�û�ж�Ǳ��©������Ƭ�ε��ļ���Ž��е����Ķ�д
		OutputFuncCodeSliceToFileNo = OutputFuncToFileNo;

		return 1;
	}

	//��������ǽ�Դ�����ļ������еĺ��������ж��Ƿ�Ϊ������Ҫ��ȡ�����浽����Դ�����ļ��ĺ�������Ϊ����֮ǰ��д����ֻ�Ὣ����ȡ��������©���ĺ���������ȡ������ȡ��������������ȡ�����Ĳ����ƣ���������ǽ����ж���ȡ������
	int OutPutFileAllFunction()
	{
		int tempIndex = 0;
		char TargetFuncNameArray[10][30] = { 0 };
		int tempNameArrayReturn = -1;

		for (int i = 0; i < pSourceCodeFile->FunctionNum; i++)
		{
			tempNameArrayReturn = CheckFunctionNameIsTargetNameArray(((pSourceCodeFile->Function)[i])->FunctionName, (char**)TargetFuncNameArray, 10);
			switch (tempNameArrayReturn)
			{
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			{
				OutputFuncToFile(i, false);
				break;
			}
			case 7:
			case 8:
			case 9:
			{
				OutputFuncToFile(i, true);
				break;
			}
			default:
				break;
			}
		}

		return 1;
	}

	int CheckFunctionNameIsTargetNameArray(char* FuncName, char** TargetNameArray, int NameArrayLength)
	{
		int tempIndex = 0;

		for (int i = 0; i < NameArrayLength; i++)
		{
			if (!strcmp(FuncName, TargetNameArray[i]))
			{
				return i;
			}
		}

		return -1;
	}

	int GetTimeOnWindowsPlatform(double* second, double* msecond, double* min)
	{
		SYSTEMTIME currentTime;
		GetSystemTime(&currentTime);
		*second = currentTime.wSecond;
		*msecond = currentTime.wMilliseconds;
		*min = currentTime.wMinute;

		return 1;
	}
	
	int GetTimeOnWindowsPlatformNew(long* pReturn)
	{
		//*pReturn = GetTickCount();
		*pReturn = GetTickCount64();

		return 1;
	}

	int64_t GetSysTimeMicros()
	{
#ifdef _WIN32
		// ��1601��1��1��0:0:0:000��1970��1��1��0:0:0:000��ʱ��(��λ100ns)
#define EPOCHFILETIME   (116444736000000000UL)
		FILETIME ft;
		LARGE_INTEGER li;
		int64_t tt = 0;
		GetSystemTimeAsFileTime(&ft);
		li.LowPart = ft.dwLowDateTime;
		li.HighPart = ft.dwHighDateTime;
		// ��1970��1��1��0:0:0:000�����ڵ�΢����(UTCʱ��)
		tt = (li.QuadPart - EPOCHFILETIME) / 10;
		return tt;
#else
		timeval tv;
		gettimeofday(&tv, 0);
		return (int64_t)tv.tv_sec * 1000000 + (int64_t)tv.tv_usec;
#endif // _WIN32
		return 0;
	}

	int GetFileName(char* FilePath, char* ReturnFileName)
	{
		int tempIndex = 0;
		int tempSignPosition = -1;

		while (FilePath[tempIndex] != 0x0)
		{
			if (FilePath[tempIndex] == '\\')
			{
				tempSignPosition = tempIndex;
			}
			tempIndex++;
		}

		tempIndex = 0;

		if (tempSignPosition == -1)
		{
#ifdef _DEBUG
			std::cout << "Get File Name Error!\n";
#endif
		}
		else
		{
			tempSignPosition++;
			while (FilePath[tempSignPosition] != '.' && FilePath[tempSignPosition] != 0x0)
			{
				ReturnFileName[tempIndex++] = FilePath[tempSignPosition];
				tempSignPosition++;
			}
		}
		ReturnFileName[tempIndex] = 0x0;

		return tempIndex;
	}

	int OutputNotAllIRConvertIntermediate(int* CodeLineArray, int CodeLineArrayLength, bool bSafe, char* FileName, char* FunctionName)
	{
		int tempIndex = 0;
		int tempCodeLineArray[200];
		int tempGlobalCodeLineArray[50] = { -1 };
		int tempGlobalCodeLineArrayLength = 0;
		char tempBuffer[5000];
		char tempBuffer2[5000];
		char tempBuffer3[5000];
		char tempPath[5] = { 0 };
		char** tempppBuffer;
		char** tempppBuffer2;
		char** tempppBuffer3;
		int tempBufferIndex = 0;
		int tempBuffer2Index = 0;
		int tempBuffer3Index = 0;
		int** tempBufferDataDependence;
		int** tempBufferControlDependence;
		int PicSize = 0;
		bool bNotGlobal = false;
		PSourceLine temppCodeLine;
		PSourceFunction temppFuncion;

		PicSize = 50;

		tempppBuffer = new char*;
		tempppBuffer2 = new char*;
		tempppBuffer3 = new char*;

		*tempppBuffer = tempBuffer;
		*tempppBuffer2 = tempBuffer2;
		*tempppBuffer3 = tempBuffer3;

		memset(tempBuffer, 0x0, 5000);
		memset(tempBuffer2, 0x0, 5000);
		memset(tempBuffer3, 0x0, 5000);

		//Ŀǰ������50*50�ľ��󣬺��ڱ�׼�����������ٸ���
		tempBufferDataDependence = new int* [PicSize];
		tempBufferControlDependence = new int* [PicSize];
		for (int i = 0; i < PicSize; i++)
		{
			tempBufferDataDependence[i] = new int[PicSize];
			tempBufferControlDependence[i] = new int[PicSize];
		}

		for (int i = 0; i < PicSize; i++)
		{
			for (int z = 0; z < PicSize; z++)
			{
				(tempBufferDataDependence[i])[z] = 0;
				(tempBufferControlDependence[i])[z] = 0;
			}
		}

		for (int i = 0; i < pSourceCodeFile->SourceCodeLineNum; i++)
		{
			tempGlobalCodeLineArray[tempGlobalCodeLineArrayLength++] = ((pSourceCodeFile->SourceCodeLine)[i])->GlobalLineNo;
		}

		for (int i = 0; i < CodeLineArrayLength; i++)
		{
			bNotGlobal = true;
			for (int z = 0; z < tempGlobalCodeLineArrayLength; z++)
			{
				if (tempGlobalCodeLineArray[z] == CodeLineArray[i])
				{
					bNotGlobal = false;
				}
			}
			if (bNotGlobal)
			{
				tempCodeLineArray[tempIndex++] = CodeLineArray[i];
				GetCodeLineStruct(CodeLineArray[i], &temppCodeLine, &temppFuncion);
				strcat(tempBuffer, temppCodeLine->buffer);
				strcat(tempBuffer, "\r\n");
			}
		}

		GetCodeSliceDataDependence(tempCodeLineArray, tempIndex, tempBufferDataDependence);
		GetCodeSliceControlDependence(tempCodeLineArray, tempIndex, tempBufferControlDependence);
		
		if (strlen(tempBuffer) != 0)
		{
			TranslateCodeSlice((void**)tempppBuffer, &tempBufferIndex, (void**)tempppBuffer2, &tempBuffer2Index);

			TranslateIntermediateToVec((void**)tempppBuffer2, &tempBuffer2Index, (void**)tempppBuffer3, &tempBuffer3Index);

			//update previous pic save path
			GetBMP(tempppBuffer3, tempBufferDataDependence, tempBufferControlDependence, bSafe, OutputFilePath18, tempPath, tempPath, PicSize, PicSize, 0);
		}

		for (int i = 0; i < PicSize; i++)
		{
			delete[] tempBufferDataDependence[i];
			delete[] tempBufferControlDependence[i];
		}
		delete tempBufferDataDependence;
		delete tempBufferControlDependence;
		delete tempppBuffer;
		delete tempppBuffer2;
		delete tempppBuffer3;

		return 1;
	}

	int ReverseIntValue(int** IntMatrix, int MatrixSize)
	{
		int tempIndex = 0;

		for (int i = 0; i < MatrixSize; i++)
		{
			for (int z = 0; z < MatrixSize; z++)
			{
				if (IntMatrix[i][z] == 0)
				{
					IntMatrix[i][z] = 255;
				}
				else if (IntMatrix[i][z] == 255)
				{
					IntMatrix[i][z] = 0;
				}
			}
		}

		return 1;
	}

	//���������Ϊ�����㽫Ǳ��©������Ƭ�����뵽VulCNN�����õģ������ȡ����Ǳ��©������Ƭ��������������ļ���
	int OutputFuncCodeSliceToFile(int* CodeLineArray, int CodeLineArrayLength, bool bSafe)
	{
		int tempIndex = 0;
		PSourceFunction temppFunc;
		PSourceLine temppCodeLine;
		char tempPath[100];
		char tempBuffer[20];
		char tempBuffer2[10000];

		memset(tempBuffer2, 0x0, 10000);
		memset(tempBuffer, 0x0, 20);
		memset(tempPath, 0x0, 100);

		IntToStrNew(OutputFuncCodeSliceToFileNo, tempBuffer);

		if (bSafe)
		{
			strcat(tempPath, ".//No-Vul//");
			strcat(tempPath, tempBuffer);
			strcat(tempPath, "_1.c");
		}
		else
		{
			strcat(tempPath, ".//Vul//");
			strcat(tempPath, tempBuffer);
			strcat(tempPath, "_0.c");
		}

		for (int i = 0; i < CodeLineArrayLength; i++)
		{
			GetCodeLineStruct(CodeLineArray[i], &temppCodeLine, &temppFunc);
			if (temppFunc != NULL)
			{
				strcat(tempBuffer2, temppCodeLine->buffer);
				strcat(tempBuffer2, "\n");
			}
		}

		file::OutPutToFile((const char*)tempPath, tempBuffer2);

		OutputFuncCodeSliceToFileNo++;

		return 1;
	}
}

InterMediateNew::InterMediateNew(void** Input, int* InputIndex, void** Output, int* OutputIndex)
{
	StoreInterMediateUserDefTypeInfoNum = 0;
	StoreInterMediateUserDefFunctionInfoNum = 0;
	StoreInterMediateMacroDefInfoNum = 0;
	StoreInterMediateVarDefInfoNum = 0;
	LBraceNum = 0;
	RBraceNum = 0;
	CodeBlockNum = 0;
	InterMediateCodeLineNum = 0;
	WriteInterMediateCodeLineNo = 0;
	ReadInterMediateCodeLineNo = 0;
	
	/*pStoreUserDefTypeInfo = new StoreInterMediateUserDefTypeInfo;
	pStoreUserDefFunctionInfo = new StoreInterMediateUserDefFunctionInfo;
	pStoreMacroInfo = new StoreInterMediateMacroDefInfo;
	pStoreVarInfo = new StoreInterMediateVarDefInfo;
	func::InitStoreInterMediateUserDefTypeInfo(pStoreUserDefTypeInfo);
	func::InitStoreInterMediateUserDefFunctionInfo(pStoreUserDefFunctionInfo);
	func::InitStoreInterMediateMacroDefInfo(pStoreMacroInfo);
	func::InitStoreInterMediateVarDefInfo(pStoreVarInfo);*/
	InputBuffer = Input;
	InputBufferIndex = InputIndex;
	OutputBuffer = Output;
	OutputBufferIndex = OutputIndex;
}

InterMediateNew::~InterMediateNew()
{
	PStoreInterMediateUserDefTypeInfo temppStoreUserDefTypeInfo;
	PStoreInterMediateUserDefFunctionInfo temppStoreUserDefFunctionInfo;
	PStoreInterMediateMacroDefInfo temppMacroDefInfo;
	PStoreInterMediateVarDefInfo temppVarDefInfo;

	if (StoreInterMediateUserDefTypeInfoNum > 0)
	{
		temppStoreUserDefTypeInfo = pStoreUserDefTypeInfo->pNext;
		for (int i = 0; i < StoreInterMediateUserDefTypeInfoNum; i++)
		{
			delete pStoreUserDefTypeInfo;
			pStoreUserDefTypeInfo = temppStoreUserDefTypeInfo;
			if (temppStoreUserDefTypeInfo != NULL)
			{
				temppStoreUserDefTypeInfo = temppStoreUserDefTypeInfo->pNext;
			}
		}
	}
	if (StoreInterMediateUserDefFunctionInfoNum > 0)
	{
		temppStoreUserDefFunctionInfo = pStoreUserDefFunctionInfo->pNext;
		for (int i = 0; i < StoreInterMediateUserDefFunctionInfoNum; i++)
		{
			delete pStoreUserDefFunctionInfo;
			pStoreUserDefFunctionInfo = temppStoreUserDefFunctionInfo;
			if (temppStoreUserDefFunctionInfo != NULL)
			{
				temppStoreUserDefFunctionInfo = temppStoreUserDefFunctionInfo->pNext;
			}
		}
	}
	if (StoreInterMediateMacroDefInfoNum > 0)
	{
		temppMacroDefInfo = pStoreMacroInfo->pNext;
		for (int i = 0; i < StoreInterMediateMacroDefInfoNum; i++)
		{
			delete pStoreMacroInfo;
			pStoreMacroInfo = temppMacroDefInfo;
			if (temppMacroDefInfo != NULL)
			{
				temppMacroDefInfo = temppMacroDefInfo->pNext;
			}
		}
	}
	if (StoreInterMediateVarDefInfoNum > 0)
	{
		temppVarDefInfo = pStoreVarInfo->pNext;
		for (int i = 0; i < StoreInterMediateVarDefInfoNum; i++)
		{
			delete pStoreVarInfo;
			pStoreVarInfo = temppVarDefInfo;
			if (temppVarDefInfo != NULL)
			{
				temppVarDefInfo = temppVarDefInfo->pNext;
			}
		}
	}
}

int InterMediateNew::AddStoreInterMediateUserDefTypeInfo(PStoreInterMediateUserDefTypeInfo p)
{
	PStoreInterMediateUserDefTypeInfo temppStoreInterMediateUserDefTypeInfo;
	if (StoreInterMediateUserDefTypeInfoNum == 0)
	{
		pStoreUserDefTypeInfo = p;
	}
	else
	{
		temppStoreInterMediateUserDefTypeInfo = pStoreUserDefTypeInfo;
		for (int i = 1; i < StoreInterMediateUserDefTypeInfoNum; i++)
		{
			temppStoreInterMediateUserDefTypeInfo = temppStoreInterMediateUserDefTypeInfo->pNext;
		}
		temppStoreInterMediateUserDefTypeInfo->pNext = p;
	}
	StoreInterMediateUserDefTypeInfoNum++;

	return 1;
}

int InterMediateNew::AddStoreInterMediateUserDefFunctionInfo(PStoreInterMediateUserDefFunctionInfo p)
{
	PStoreInterMediateUserDefFunctionInfo temppStoreInterMediateUserDefFunctionInfo;
	if (StoreInterMediateUserDefFunctionInfoNum == 0)
	{
		pStoreUserDefFunctionInfo = p;
	}
	else
	{
		temppStoreInterMediateUserDefFunctionInfo = pStoreUserDefFunctionInfo;
		for (int i = 1; i < StoreInterMediateUserDefFunctionInfoNum; i++)
		{
			temppStoreInterMediateUserDefFunctionInfo = temppStoreInterMediateUserDefFunctionInfo->pNext;
		}
		temppStoreInterMediateUserDefFunctionInfo->pNext = p;
	}
	StoreInterMediateUserDefFunctionInfoNum++;

	return 1;
}

int InterMediateNew::AddStoreInterMediateMacroDefInfo(PStoreInterMediateMacroDefInfo p)
{
	PStoreInterMediateMacroDefInfo temppStoreInterMediateMacroDefInfo;
	if (StoreInterMediateMacroDefInfoNum == 0)
	{
		pStoreMacroInfo = p;
	}
	else
	{
		temppStoreInterMediateMacroDefInfo = pStoreMacroInfo;
		for (int i = 1; i < StoreInterMediateMacroDefInfoNum; i++)
		{
			temppStoreInterMediateMacroDefInfo = temppStoreInterMediateMacroDefInfo->pNext;
		}
		temppStoreInterMediateMacroDefInfo->pNext = p;
	}
	StoreInterMediateMacroDefInfoNum++;

	return 1;
}

int InterMediateNew::AddStoreInterMediateVarDefInfo(PStoreInterMediateVarDefInfo p)
{
	PStoreInterMediateVarDefInfo temppStoreInterMediateVarDefInfo;
	if (StoreInterMediateVarDefInfoNum == 0)
	{
		pStoreVarInfo = p;
	}
	else
	{
		temppStoreInterMediateVarDefInfo = pStoreVarInfo;
		for (int i = 1; i < StoreInterMediateVarDefInfoNum; i++)
		{
			temppStoreInterMediateVarDefInfo = temppStoreInterMediateVarDefInfo->pNext;
		}
		temppStoreInterMediateVarDefInfo->pNext = p;
	}
	StoreInterMediateVarDefInfoNum++;

	return 1;
}

int InterMediateNew::FindStoreInterMediateUserDefTypeInfo(char* TargetTypeName, PStoreInterMediateUserDefTypeInfo* pReturn)
{
	PStoreInterMediateUserDefTypeInfo temppUserDefTypeInfo;

	*pReturn = NULL;
	temppUserDefTypeInfo = pStoreUserDefTypeInfo;
	for (int i = 0; i < StoreInterMediateUserDefTypeInfoNum; i++)
	{
		if (strcmp(TargetTypeName, temppUserDefTypeInfo->DefTypeMainName) == 0)
		{
			*pReturn = temppUserDefTypeInfo;
			return 1;
		}
		for (int z = 0; z < temppUserDefTypeInfo->AnotherNameNum; z++)
		{
			if (strcmp(TargetTypeName, (temppUserDefTypeInfo->AnotherName)[z]) == 0)
			{
				*pReturn = temppUserDefTypeInfo;
				return 1;
			}
		}
		for (int z = 0; z < temppUserDefTypeInfo->PointerNameNum; z++)
		{
			if (strcmp(TargetTypeName, (temppUserDefTypeInfo->PointerName)[z]) == 0)
			{
				*pReturn = temppUserDefTypeInfo;
				return 1;
			}
		}
		temppUserDefTypeInfo = temppUserDefTypeInfo->pNext;
	}

	return 0;
}

int InterMediateNew::FindStoreInterMediateUserDefFunctionInfo(char* TargetFunctionName, PStoreInterMediateUserDefFunctionInfo* pReturn)
{
	PStoreInterMediateUserDefFunctionInfo temppUserDefFunctionInfo;

	*pReturn = NULL;
	temppUserDefFunctionInfo = pStoreUserDefFunctionInfo;
	for (int i = 0; i < StoreInterMediateUserDefFunctionInfoNum; i++)
	{
		if (strcmp(TargetFunctionName, temppUserDefFunctionInfo->UserDefFunctionName) == 0)
		{
			*pReturn = temppUserDefFunctionInfo;
			return 1;
		}
		temppUserDefFunctionInfo = temppUserDefFunctionInfo->pNext;
	}

	return 0;
}

int InterMediateNew::FindStoreInterMediateMacroDefInfo(char* TargetMacroName, PStoreInterMediateMacroDefInfo* pReturn)
{
	PStoreInterMediateMacroDefInfo temppMacroInfo;

	*pReturn = NULL;
	temppMacroInfo = pStoreMacroInfo;
	for (int i = 0; i < StoreInterMediateMacroDefInfoNum; i++)
	{
		if (strcmp(TargetMacroName, temppMacroInfo->MacroName) == 0)
		{
			*pReturn = temppMacroInfo;
			return 1;
		}
		temppMacroInfo = temppMacroInfo->pNext;
	}

	return 0;
}

//�������û�и��ݵ�ǰ�����Ĵ����н����жϷ����ĸ�ͬ���ı���,��ϸԭ��鿴readme.txt�ĵ���33��
int InterMediateNew::FindStoreInterMediateVarDefInfo(char* TargetVarName, PStoreInterMediateVarDefInfo* pReturn)
{
	PStoreInterMediateVarDefInfo temppVarInfo;
	PStoreInterMediateVarDefInfo temppVarInfoArray[10];
	int temppVarInfoArrayIndex = 0;
	char tempName[100];
	char** Name;
	int NameNum = 0;
	int tempNameNum = 0;
	char** tempArray;
	int tempArrayNum = 0;
	int* tempArrayIndex;
	char** tempppName;
	int tempNameIndex = 0;
	int tempNearlyArrayIndex = -1;
	int tempNearlyInterMediateCodeLineNo = -1;

	tempppName = new char*;
	tempArray = new char* [20];
	tempArrayIndex = new int[20];
	for (int i = 0; i < 20; i++)
	{
		tempArray[i] = new char[80];
	}
	Name = new char* [10];
	for (int i = 0; i < 10; i++)
	{
		Name[i] = new char[100];
	}

	memset(tempName, 0x0, 100);

	*pReturn = NULL;
	temppVarInfo = pStoreVarInfo;
	for (int i = 0; i < StoreInterMediateVarDefInfoNum; i++)
	{
		NameNum = 0;
		tempNameIndex = 0;
		tempArrayNum = 0;
		*tempppName = temppVarInfo->VarName;
		tempNameNum = func::GetSubCodeName((void**)tempppName, &tempNameIndex, Name, &NameNum, tempArray, &tempArrayNum, tempArrayIndex);
		for (int z = 0; z < tempNameNum; z++)
		{
			if (strcmp(TargetVarName, Name[z]) == 0)
			{
				temppVarInfoArray[temppVarInfoArrayIndex++] = temppVarInfo;
				/**pReturn = temppVarInfo;
				return 1;*/
			}
		}
		/*if (strcmp(TargetVarName, temppVarInfo->VarName) == 0)
		{
			*pReturn = temppVarInfo;
			return 1;
		}*/
		temppVarInfo = temppVarInfo->pNext;
	}

	if (temppVarInfoArrayIndex == 0)
	{
		return 0;
	}

	for (int i = 0; i < temppVarInfoArrayIndex; i++)
	{
		if ((temppVarInfoArray[i])->pCodeBlock != NULL)
		{
			if (!((temppVarInfoArray[i])->pCodeBlock)->bMatched)
			{
				if (((temppVarInfoArray[i])->pCodeBlock)->StartInterMediateCodeLineNo >= tempNearlyInterMediateCodeLineNo)
				{
					tempNearlyArrayIndex = i;
					tempNearlyInterMediateCodeLineNo = ((temppVarInfoArray[i])->pCodeBlock)->StartInterMediateCodeLineNo;
				}
			}
		}
	}

	if (tempNearlyArrayIndex >= 0)
	{
		*pReturn = temppVarInfoArray[tempNearlyArrayIndex];
	}
	else
	{
		*pReturn = temppVarInfoArray[0];
	}

	delete tempppName;
	delete [] tempArrayIndex;
	for (int i = 0; i < 20; i++)
	{
		delete [] tempArray[i];
	}
	delete[] tempArray;
	for (int i = 0; i < 10; i++)
	{
		delete [] Name[i];
	}
	delete [] Name;

	return 1;
}

//���� 0 ��ʾʲôҲû�ҵ�; ���� 1 ��ʾ�ҵ�Ϊ�û����������; ���� 2 ��ʾ�ҵ�Ϊ�û�����ĺ���; ���� 3 ��ʾ�ҵ�Ϊ�û�����ĺ궨��; ���� 4 ��ʾ�ҵ�Ϊ�û�����ı���; ���� 5 ��ʾ�ҵ��û�����ı���������; ���� 6 ��ʾ�ҵ��м��ʾ���е�����
int InterMediateNew::FindStoreInterMediateElement(char* TargetName, void** pPointer)
{
	PInterMediateFunctionInfo temppFunctionInfo;

	if (FindStoreInterMediateUserDefTypeInfo(TargetName, (PStoreInterMediateUserDefTypeInfo*)pPointer) == 1)
	{
		return 1;
	}
	if (FindStoreInterMediateUserDefFunctionInfo(TargetName, (PStoreInterMediateUserDefFunctionInfo*)pPointer) == 1)
	{
		return 2;
	}
	if (FindStoreInterMediateMacroDefInfo(TargetName, (PStoreInterMediateMacroDefInfo*)pPointer) == 1)
	{
		return 3;
	}
	if (FindStoreInterMediateVarDefInfo(TargetName, (PStoreInterMediateVarDefInfo*)pPointer) == 1)
	{
		return 4;
	}
	if (FindStoreInterMediateUserDefTypeContenTypeInfo(TargetName, (PStoreInterMediateUserDefTypeContenTypeInfo*)pPointer) == 1)
	{
		return 5;
	}
	if (func::CheckFuntionInInterMediateAndReturnToken(TargetName, &temppFunctionInfo, (char**)pPointer) != -1)
	{
		return 6;
	}

	return 0;
}

int InterMediateNew::AddStoreInterMediateBraceInfo(PStoreInterMediateBraceInfo p, int BraceType)
{
	PStoreInterMediateBraceInfo temppBraceInfo;

	switch (BraceType)
	{
	case -1:
	{
		if (LBraceNum == 0)
		{
			pLBraceChain = p;
			p->pForward = p;
			p->pNext = p;
		}
		else
		{
			temppBraceInfo = pLBraceChain->pForward;
			p->pForward = temppBraceInfo;
			temppBraceInfo->pNext = p;
			p->pNext = pLBraceChain;
			pLBraceChain->pForward = p;
		}
		LBraceNum++;
		break;
	}
	case 1:
	{
		if (RBraceNum == 0)
		{
			pRBraceChain = p;
			p->pForward = p;
			p->pNext = p;
		}
		else
		{
			temppBraceInfo = pRBraceChain->pForward;
			p->pForward = temppBraceInfo;
			temppBraceInfo->pNext = p;
			p->pNext = pRBraceChain;
			pRBraceChain->pForward = p;
		}
		RBraceNum++;
		break;
	}
	default:
	{
		std::cout << "AddStoreInterMediateBraceInfo Fail Brace Type Error\n";
		break;
	}
	}

	return 1;
}

int InterMediateNew::AddStoreInterMediateCodeBlockInfo(PStoreInterMediateCodeBlockInfo p)
{
	PStoreInterMediateCodeBlockInfo temppCodeBlockInfo;

	if (CodeBlockNum == 0)
	{
		pCodeBlock = p;
		p->pForWard = p;
		p->pNext = p;
	}
	else
	{
		temppCodeBlockInfo = pCodeBlock->pForWard;
		p->pForWard = temppCodeBlockInfo;
		temppCodeBlockInfo->pNext = p;
		p->pNext = pCodeBlock;
		pCodeBlock->pForWard = p;
	}
	CodeBlockNum++;

	return 1;
}

int InterMediateNew::GetStoreInterMediateCodeBlockInfoLastUnMatchedElement(PStoreInterMediateCodeBlockInfo* p)
{
	PStoreInterMediateCodeBlockInfo temppCodeBlockInfo;

	*p = NULL;
	if (CodeBlockNum != 0)
	{
		temppCodeBlockInfo = pCodeBlock->pForWard;
		while (temppCodeBlockInfo != pCodeBlock)
		{
			if (temppCodeBlockInfo->bMatched)
			{
				temppCodeBlockInfo = temppCodeBlockInfo->pForWard;
			}
			else
			{
				*p = temppCodeBlockInfo;
				return 1;
			}
		}
		if (pCodeBlock->bMatched)
		{
			//std::cout << "GetStoreInterMediateCodeBlockInfoLastUnMatchedElement Fail\n";
		}
		else
		{
			*p = pCodeBlock;
			return 1;
		}
	}
	else
	{
		//std::cout << "GetStoreInterMediateCodeBlockInfoLastUnMatchedElement Fail\n";
	}

	return 0;
}

//Ŀǰ��������ǶԵ�ǰ�����û���������������е��������ƽ���ƥ��,����ƥ������,����ƥ�䵽���û���������������е�����ָ����з���,��û�����������������͵���������,��Ϊ��ȡ�������ͽ��鷳,����Ŀǰ��Ƭ�в����ڶ���û�������������͵�����������ͬ,���Ծ��Ȳ�����ϸ�µ�ƥ��,����������������������ϵ�ƥ����,�Ǿ�˵���û���������������е���������ͬ���Ƶ�,����Ҫ��һ���Ľ�(�᷵����ʾ��Ϣ)
int InterMediateNew::FindStoreInterMediateUserDefTypeContenTypeInfo(char* Target, PStoreInterMediateUserDefTypeContenTypeInfo* pReturn)
{
	int tempMatchedNum = 0;
	PStoreInterMediateUserDefTypeInfo temppUserDefTypeInfo;
	PStoreInterMediateUserDefTypeContenTypeInfo temppUserDefTypeContentTypeInfo;

	*pReturn = NULL;
	temppUserDefTypeInfo = pStoreUserDefTypeInfo;
	for (int i = 0; i < StoreInterMediateUserDefTypeInfoNum; i++)
	{
		temppUserDefTypeContentTypeInfo = temppUserDefTypeInfo->pContent;
		for (int z = 0; z < temppUserDefTypeInfo->ContentNum; z++)
		{
			if (strcmp(Target, temppUserDefTypeContentTypeInfo->Name) == 0)
			{
				*pReturn = temppUserDefTypeContentTypeInfo;
				tempMatchedNum++;
			}
			temppUserDefTypeContentTypeInfo = temppUserDefTypeContentTypeInfo->pNext;
		}
		temppUserDefTypeInfo = temppUserDefTypeInfo->pNext;
	}

	if (tempMatchedNum > 1)
	{
		std::cout << "FindStoreInterMediateUserDefTypeContenTypeInfo Error: Match Num too More\n";
	}

	return tempMatchedNum;
}