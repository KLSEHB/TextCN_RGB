#include "main.h"

namespace Real
{
	char KeyWordArray[20][50];

	PSourceCodeFile pRealSourceCodeFile = new SourceCodeFile;

	int HandleFileNum;

	int HandleFunctionNum;

	int HandleCodeLineNum;

	int Init()
	{
		InitKeyWordArray();

		return 1;
	}

	int InitKeyWordArray()
	{
		//KeyWordArray = { "struct", "typedef" };

		return 1;
	}

	int HandleReal(void** pCode, int* index)
	{
		InitRealConfig();

		ProcessCodeFunctionDefine(pCode, index);

		HandleFileNum++;

		WriteRealConfig();

		return 1;
	}

	int ProcessCode(void** pCode, int* index)
	{


		return 1;
	}

	int ProcessCodeFunctionDefine(void** pCode, int* index)
	{
		int tempIndex = 0;
		int tempIndex1 = 0;
		int tempIndex2 = 0;
		char tempBuffer[200] = { 0 };
		char tempBuffer1[200] = { 0 };
		void* tempFuncDefCode;
		void** tempppFuncDefCode;
		char** tempppBuffer;
		char** tempppBuffer1;
		int tempReturn = 0;
		int tempReturn1 = 0;
		bool bMatch = false;
		char tempDataTypeKeyWordArray[20][50] = { "int", "void", "bool" ,"short" ,"char", "long", "float", "double", "struct", "union", "enum", "signed", "unsigned" };
		char tempKeyWordArray[20][50] = { "static" };

		tempppBuffer = new char*;
		tempppBuffer1 = new char*;

		*tempppBuffer = tempBuffer;
		*tempppBuffer1 = tempBuffer1;

		tempppFuncDefCode = new void*;
		tempFuncDefCode = malloc(100000);
		*tempppFuncDefCode = tempFuncDefCode;
		memset(tempFuncDefCode, 0x0, 100000);

		tempIndex = *index;
		while ((*(char**)pCode)[tempIndex] != 0x0)
		{
			tempReturn = func::DivisionCodeByLineFeed(pCode, &tempIndex, (void*)tempBuffer);
			tempIndex1 = 0;
			bMatch = false;
			func::MoveCodeIndexUntillNoBlank((void**)tempppBuffer, &tempIndex1);
			func::DivisionCodeByBlank((void**)tempppBuffer, &tempIndex1, (void*)tempBuffer1);
			
			for (int i = 0; i < 20; i++)
			{
				if (!strcmp(tempBuffer1, tempKeyWordArray[i]))
				{
					tempReturn1 = GetFuncDefineCode(pCode, &tempIndex, tempFuncDefCode);
					if (tempReturn1 != 0)
						{
						tempIndex2 = 0;
						HandleFunc(tempppFuncDefCode, &tempIndex2);
						bMatch = true;
						HandleFunctionNum++;
					}
				}
			}
			for (int i = 0; i < 20; i++)
			{
				if (!strcmp(tempBuffer1, tempDataTypeKeyWordArray[i]))
				{
					tempReturn1 = GetFuncDefineCode(pCode, &tempIndex, tempFuncDefCode);
					if (tempReturn1 != 0)
					{
						tempIndex2 = 0;
						HandleFunc(tempppFuncDefCode, &tempIndex2);
						bMatch = true;
						HandleFunctionNum++;
					}
				}
			}

			if (bMatch)
			{
				tempIndex = tempIndex + tempReturn1;
			}
			else
			{
				tempIndex = tempIndex + tempReturn;
			}
			if ((*(char**)pCode)[tempIndex] == '\n')
			{
				tempIndex++;
			}
			if ((*(char**)pCode)[tempIndex] == '\r' && (*(char**)pCode)[tempIndex + 1] == '\n')
			{
				tempIndex += 2;
			}
		}

		free(tempFuncDefCode);

		delete tempppBuffer;
		delete tempppBuffer1;

		return 1;
	}

	int GetFuncDefineCode(void** pCode, int* index, void* pReutnrFuncDefCode)
	{
		int tempIndex = 0;
		int tempIndex1 = 0;
		int tempLBraceNum = 0;
		bool FaceBrace = false;

		tempIndex = *index;
		while (true)
		{
			((char*)pReutnrFuncDefCode)[tempIndex1++] = (*(char**)pCode)[tempIndex];

			if ((*(char**)pCode)[tempIndex] == '{')
			{
				tempLBraceNum++;
				FaceBrace = true;
			}
			if ((*(char**)pCode)[tempIndex] == '}')
			{
				tempLBraceNum--;
			}
			if (FaceBrace && tempLBraceNum == 0)
			{
				break;
			}
			//updata at 23.4.3 for seq_buf.c-seq_buf_putmem_hex
			if ((*(char**)pCode)[tempIndex] == '}' && (*(char**)pCode)[tempIndex - 1] == '\n')
			{
				break;
			}
			if ((*(char**)pCode)[tempIndex] == ';' && !FaceBrace)
			{
				tempIndex1 = 0;
				((char*)pReutnrFuncDefCode)[0] = 0x0;
				break;
			}

			tempIndex++;
		}

		//����Ͱ��հ�������д����ֻ��������Ҫ�����ݸ�ʽ������ȡ�����Ե�һ�ɲ���ȡ
		if ((*(char**)pCode)[tempIndex + 1] == '\n' || ((*(char**)pCode)[tempIndex + 1] == '\r' && (*(char**)pCode)[tempIndex + 2] == '\n') || ((*(char**)pCode)[tempIndex] == '}' && (*(char**)pCode)[tempIndex + 1] == 0x0))
		{
			((char*)pReutnrFuncDefCode)[tempIndex1] = 0x0;
			return tempIndex1;
		}

		((char*)pReutnrFuncDefCode)[0] = 0x0;
			
		return 0;
	}

	int HandleFunc(void** pCode, int* index)
	{
		int tempIndex = 0;

		HandleLineFeed(pCode, &tempIndex);

		func::InitSourceCodeFile(pRealSourceCodeFile);

		func::AnalysisFile(pCode, &tempIndex, pRealSourceCodeFile);

		TranslateCodeFileToPic(pRealSourceCodeFile);

		return 1;
	}

	//Ŀǰ���� {, ;, } ���������ӻ��з��Ŵ��������������������û�����ӻ��з��Ŵ��������磺if() xxx����ʽ ( if�������û�б� { } ������)
	int HandleLineFeed(void** pCode, int* index)
	{
		int tempIndex = 0;

		RemoveAfterLineFeedBlank(pCode, &tempIndex);
		RemoveWindowsLineFeed(pCode, &tempIndex);
		RemoveLinuxLineFeed(pCode, &tempIndex);
		RemoveTabKey(pCode, &tempIndex);
		RemoveKeyWord(pCode, &tempIndex);

		AddLineFeedForThreeSymbol(pCode, &tempIndex);

		return 1;
	}

	int RemoveWindowsLineFeed(void** pCode, int* index)
	{
		int tempIndex = 0;
		int tempIndex1 = 0;
		int tempIndex2 = 0;
		char** tempppBuffer;
		int tempCodeLength = 0;
		char tempBuffer[200] = { 0 };
		int tempBufferIndex = 0;
		ReturnType tempReturnType;
		PUserDefStruct tempppUserDefStruct;

		tempppBuffer = new char*;
		*tempppBuffer = tempBuffer;

		tempIndex = *index;
		tempCodeLength = strlen(*(char**)pCode);
		while(tempIndex < tempCodeLength)
		{
			if ((*(char**)pCode)[tempIndex] == '\r' && (*(char**)pCode)[tempIndex + 1] == '\n')
			{
				//update at 23.4.10
				HandleCodeLineNum++;

				//update at 23.4.4
				tempIndex2 = tempIndex - 1;
				while (true)
				{
					if (tempIndex2 < 0)
					{
						break;
					}
					if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex2])))
					{
						tempBuffer[tempBufferIndex++] = (*(char**)pCode)[tempIndex2];
					}
					else
					{
						break;
					}
					tempIndex2--;
				}
				if (tempBufferIndex > 0)
				{
					tempBuffer[tempBufferIndex] = 0x0;
					tempBufferIndex = 0;
					func::ReverseString(tempBuffer);
					tempIndex2 = 0;
					func::CheckReturnType((void**)tempppBuffer, &tempIndex2, &tempReturnType, &tempppUserDefStruct);
					if (tempReturnType != ReturnType::ReturnType_unknownType)
					{
						tempIndex1 = tempIndex + 2;
						while (tempIndex1 < tempCodeLength)
						{
							(*(char**)pCode)[tempIndex1 - 1] = (*(char**)pCode)[tempIndex1];
							tempIndex1++;
						}
						(*(char**)pCode)[tempIndex] = ' ';
						tempCodeLength -= 1;
					}
					else
					{
						//update at 23.4.5
						if (!strcmp(tempBuffer, "else"))
						{
							tempIndex1 = tempIndex + 2;
							while (tempIndex1 < tempCodeLength)
							{
								(*(char**)pCode)[tempIndex1 - 1] = (*(char**)pCode)[tempIndex1];
								tempIndex1++;
							}
							(*(char**)pCode)[tempIndex] = ' ';
							tempCodeLength -= 1;
						}
						else
						{
							tempIndex1 = tempIndex + 2;
							while (tempIndex1 < tempCodeLength)
							{
								(*(char**)pCode)[tempIndex1 - 2] = (*(char**)pCode)[tempIndex1];
								tempIndex1++;
							}
							tempCodeLength -= 2;
						}
					}
				}
				else
				{
					tempIndex1 = tempIndex + 2;
					while (tempIndex1 < tempCodeLength)
					{
						(*(char**)pCode)[tempIndex1 - 2] = (*(char**)pCode)[tempIndex1];
						tempIndex1++;
					}
					tempCodeLength -= 2;
				}
				tempIndex--;
			}

			tempIndex++;
		}
		(*(char**)pCode)[tempCodeLength] = 0x0;
		
		return 1;
	}

	int RemoveLinuxLineFeed(void** pCode, int* index)
	{
		int tempIndex = 0;
		int tempIndex1 = 0;
		int tempIndex2 = 0;
		char** tempppBuffer;
		int tempCodeLength = 0;
		char tempBuffer[200] = { 0 };
		int tempBufferIndex = 0;
		ReturnType tempReturnType;
		PUserDefStruct tempppUserDefStruct;

		tempppBuffer = new char*;
		*tempppBuffer = tempBuffer;

		tempIndex = *index;
		tempCodeLength = strlen(*(char**)pCode);
		while (tempIndex < tempCodeLength)
		{
			if ((*(char**)pCode)[tempIndex] == '\n')
			{
				//update at 23.4.10
				HandleCodeLineNum++;

				//update at 23.4.4
				tempIndex2 = tempIndex - 1;
				while (true)
				{
					if (tempIndex2 < 0)
					{
						break;
					}
					if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex2])))
					{
						tempBuffer[tempBufferIndex++] = (*(char**)pCode)[tempIndex2];
					}
					else
					{
						break;
					}
					tempIndex2--;
				}
				if (tempBufferIndex > 0)
				{
					tempBuffer[tempBufferIndex] = 0x0;
					tempBufferIndex = 0;
					func::ReverseString(tempBuffer);
					tempIndex2 = 0;
					func::CheckReturnType((void**)tempppBuffer, &tempIndex2, &tempReturnType, &tempppUserDefStruct);
					if (tempReturnType != ReturnType::ReturnType_unknownType)
					{
						(*(char**)pCode)[tempIndex] = ' ';
						/*tempCodeLength -= 1;*/
					}
					else
					{
						//update at 23.4.5
						if (!strcmp(tempBuffer, "else"))
						{
							(*(char**)pCode)[tempIndex] = ' ';
							/*tempCodeLength -= 1;*/
						}
						else
						{
							tempIndex1 = tempIndex + 1;
							while (tempIndex1 < tempCodeLength)
							{
								(*(char**)pCode)[tempIndex1 - 1] = (*(char**)pCode)[tempIndex1];
								tempIndex1++;
							}
							tempCodeLength -= 1;
						}
					}
				}
				else
				{
					tempIndex1 = tempIndex + 1;
					while (tempIndex1 < tempCodeLength)
					{
						(*(char**)pCode)[tempIndex1 - 1] = (*(char**)pCode)[tempIndex1];
						tempIndex1++;
					}
					tempCodeLength -= 1;
				}
				tempIndex--;
				
			}

			tempIndex++;
		}
		(*(char**)pCode)[tempCodeLength] = 0x0;

		return 1;
	}

	int RemoveTabKey(void** pCode, int* index)
	{
		int tempIndex = 0;
		int tempIndex1 = 0;
		int tempCodeLength = 0;

		tempIndex = *index;
		tempCodeLength = strlen(*(char**)pCode);
		while (tempIndex < tempCodeLength)
		{
			if ((*(char**)pCode)[tempIndex] == '\t')
			{
				tempIndex1 = tempIndex + 1;
				while (tempIndex1 < tempCodeLength)
				{
					(*(char**)pCode)[tempIndex1 - 1] = (*(char**)pCode)[tempIndex1];
					tempIndex1++;
				}
				tempCodeLength -= 1;
				tempIndex--;
			}

			tempIndex++;
		}
		(*(char**)pCode)[tempCodeLength] = 0x0;

		return 1;
	}

	int AddLineFeedForThreeSymbol(void** pCode, int* index)
	{
		int tempIndex = 0;
		int tempIndex3 = 0;
		int tempCodeLength = 0;
		int tempIndex1 = 0;
		int LBracketNum = 0;
		int tempIndex2 = 0;
		bool bInSytaxKey = false;
		bool bInStr = false;
		bool bAsAssigmentValue = false;
		int InBlockNum = 0;
		char tempSytaxKeyArray[20][20] = { "if", "for", "while", "else"};
		char tempBuffer[200] = { 0 };
		int tempBufferIndex = 0;

		tempIndex = 0;
		tempCodeLength = strlen(*(char**)pCode);
		while (tempIndex < tempCodeLength)
		{
			if ((*(char**)pCode)[tempIndex] == '{')
			{
				//fix bug at 23.4.9, but alse have bug
				bInSytaxKey = false;
				//////////////////////////////////

				//update at 23.4.4
				tempIndex3 = tempIndex + 1;
				while (true)
				{
					if ((*(char**)pCode)[tempIndex3] == ' ')
					{
						tempIndex3++;
					}
					else
					{
						break;
					}
				}
				while (true)
				{
					if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex3])))
					{
						tempBuffer[tempBufferIndex++] = (*(char**)pCode)[tempIndex3++];
					}
					else
					{
						if (tempBufferIndex > 0)
						{
							tempBuffer[tempBufferIndex] = 0x0;
							tempBufferIndex = 0;
							for (int i = 0; i < 20; i++)
							{
								if (!strcmp(tempBuffer, tempSytaxKeyArray[i]))
								{
									bInSytaxKey = true;
									InBlockNum++;
								}
							}
						}
						break;
					}
				}

				//update at 23.4.8
				tempIndex3 = tempIndex - 1;
				while ((*(char**)pCode)[tempIndex3] == ' ')
				{
					tempIndex3--;
				}
				if ((*(char**)pCode)[tempIndex3] == '=')
				{
					bAsAssigmentValue = true;
				}
				else
				{
					//update at 23.4.5
					if ((*(char**)pCode)[tempIndex3] != '\n')
					{
						tempIndex1 = tempCodeLength;
						while (tempIndex1 > tempIndex)
						{
							(*(char**)pCode)[tempIndex1 + 4] = (*(char**)pCode)[tempIndex1];

							tempIndex1--;
						}
						(*(char**)pCode)[tempIndex + 3] = '\r';
						(*(char**)pCode)[tempIndex + 4] = '\n';
						(*(char**)pCode)[tempIndex + 2] = '{';
						(*(char**)pCode)[tempIndex + 1] = '\n';
						(*(char**)pCode)[tempIndex] = '\r';
						tempIndex += 2;
						tempCodeLength += 4;
					}
					else if ((*(char**)pCode)[tempIndex3] == '\n')
					{
						tempIndex1 = tempCodeLength;
						while (tempIndex1 > tempIndex)
						{
							(*(char**)pCode)[tempIndex1 + 2] = (*(char**)pCode)[tempIndex1];

							tempIndex1--;
						}
						(*(char**)pCode)[tempIndex + 1] = '\r';
						(*(char**)pCode)[tempIndex + 2] = '\n';
						tempCodeLength += 2;
					}
				}
			}
			if ((*(char**)pCode)[tempIndex] == '(')
			{
				LBracketNum++;
			}
			if ((*(char**)pCode)[tempIndex] == ')')
			{
				LBracketNum--;

				//update at 23.4.4
				if (bInSytaxKey && LBracketNum == 0)
				{
					tempIndex2 = tempIndex + 1;
					tempIndex1 = tempCodeLength;
					while ((*(char**)pCode)[tempIndex2] == ' ')
					{
						tempIndex2++;
					}
					while (tempIndex1 >= tempIndex2)
					{
						(*(char**)pCode)[tempIndex1 + 2] = (*(char**)pCode)[tempIndex1];

						tempIndex1--;
					}
					(*(char**)pCode)[tempIndex2] = '\r';
					(*(char**)pCode)[tempIndex2 + 1] = '\n';
					tempCodeLength += 2;
					
					InBlockNum--;
					/*if (InBlockNum == 0)
					{*/
						bInSytaxKey = false;
					/*}*/
				}

				tempIndex3 = tempIndex2 + 1 + 1;
				while (true)
				{
					if ((*(char**)pCode)[tempIndex3] == ' ')
					{
						tempIndex3++;
					}
					else
					{
						break;
					}
				}
				while (true)
				{
					if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex3])))
					{
						tempBuffer[tempBufferIndex++] = (*(char**)pCode)[tempIndex3++];
					}
					else
					{
						if (tempBufferIndex > 0)
						{
							tempBuffer[tempBufferIndex] = 0x0;
							tempBufferIndex = 0;
							for (int i = 0; i < 20; i++)
							{
								if (!strcmp(tempBuffer, tempSytaxKeyArray[i]))
								{
									bInSytaxKey = true;
									InBlockNum++;
								}
							}
						}
						break;
					}
				}
			}
			if ((*(char**)pCode)[tempIndex] == ';' && LBracketNum == 0)
			{
				//update at 23.4.4
				tempIndex3 = tempIndex + 1;
				while (true)
				{
					if ((*(char**)pCode)[tempIndex3] == ' ')
					{
						tempIndex3++;
					}
					else
					{
						break;
					}
				}
				while (true)
				{
					if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex3])))
					{
						tempBuffer[tempBufferIndex++] = (*(char**)pCode)[tempIndex3++];
					}
					else
					{
						if (tempBufferIndex > 0)
						{
							tempBuffer[tempBufferIndex] = 0x0;
							tempBufferIndex = 0;
							for (int i = 0; i < 20; i++)
							{
								if (!strcmp(tempBuffer, tempSytaxKeyArray[i]))
								{
									bInSytaxKey = true;
									InBlockNum++;
								}
							}
						}
						break;
					}
				}

				tempIndex1 = tempCodeLength;
				while (tempIndex1 > tempIndex)
				{
					(*(char**)pCode)[tempIndex1 + 2] = (*(char**)pCode)[tempIndex1];

					tempIndex1--;
				}
				(*(char**)pCode)[tempIndex + 1] = '\r';
				(*(char**)pCode)[tempIndex + 2] = '\n';
				tempCodeLength += 2;
			}
			if ((*(char**)pCode)[tempIndex] == '}' && (*(char**)pCode)[tempIndex + 1] != ';')
			{
				//update at 23.4.4
				tempIndex3 = tempIndex + 1;
				while (true)
				{
					if ((*(char**)pCode)[tempIndex3] == ' ')
					{
						tempIndex3++;
					}
					else
					{
						break;
					}
				}
				while (true)
				{
					if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex3])))
					{
						tempBuffer[tempBufferIndex++] = (*(char**)pCode)[tempIndex3++];
					}
					else
					{
						if (tempBufferIndex > 0)
						{
							tempBuffer[tempBufferIndex] = 0x0;
							tempBufferIndex = 0;
							for (int i = 0; i < 20; i++)
							{
								if (!strcmp(tempBuffer, tempSytaxKeyArray[i]))
								{
									bInSytaxKey = true;
									InBlockNum++;
								}
							}
						}
						break;
					}
				}

				tempIndex2 = tempIndex + 1;
				func::MoveCodeIndexUntillNoBlank(pCode, &tempIndex2);
				if ((*(char**)pCode)[tempIndex2] != ';')
				{
					if ((*(char**)pCode)[tempIndex - 1] != '\n')
					{
						tempIndex1 = tempCodeLength;
						while (tempIndex1 > tempIndex)
						{
							(*(char**)pCode)[tempIndex1 + 4] = (*(char**)pCode)[tempIndex1];

							tempIndex1--;
						}
						(*(char**)pCode)[tempIndex + 3] = '\r';
						(*(char**)pCode)[tempIndex + 4] = '\n';
						(*(char**)pCode)[tempIndex + 2] = '}';
						(*(char**)pCode)[tempIndex + 1] = '\n';
						(*(char**)pCode)[tempIndex] = '\r';
						tempIndex += 2;
						tempCodeLength += 4;
					}
					else if ((*(char**)pCode)[tempIndex - 1] == '\n')
					{
						tempIndex1 = tempCodeLength;
						while (tempIndex1 > tempIndex)
						{
							(*(char**)pCode)[tempIndex1 + 2] = (*(char**)pCode)[tempIndex1];

							tempIndex1--;
						}
						(*(char**)pCode)[tempIndex + 1] = '\r';
						(*(char**)pCode)[tempIndex + 2] = '\n';
						tempCodeLength += 2;
					}
				}
			}

			//update at 23.4.4
			//����д�Ĳ�������bug,Ŀǰ����������,����������Ҫ�ٽ�������
			if ((*(char**)pCode)[tempIndex] == '\'' || (*(char**)pCode)[tempIndex] == '\"')
			{
				bInStr = !bInStr;
			}
			if (!bInStr && (*(char**)pCode)[tempIndex] == ':')
			{
				//update at 23.4.4
				tempIndex3 = tempIndex + 1;
				while (true)
				{
					if ((*(char**)pCode)[tempIndex3] == ' ')
					{
						tempIndex3++;
					}
					else
					{
						break;
					}
				}
				while (true)
				{
					if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex3])))
					{
						tempBuffer[tempBufferIndex++] = (*(char**)pCode)[tempIndex3++];
					}
					else
					{
						if (tempBufferIndex > 0)
						{
							tempBuffer[tempBufferIndex] = 0x0;
							tempBufferIndex = 0;
							for (int i = 0; i < 20; i++)
							{
								if (!strcmp(tempBuffer, tempSytaxKeyArray[i]))
								{
									bInSytaxKey = true;
									InBlockNum++;
								}
							}
						}
						break;
					}
				}

				//update at 23.4.7
				//������򵥵��޸���һ��bug,���Ǵ�������,����Ϊ�˼����������ôд��
				if ((*(char**)pCode)[tempIndex - 1] != ' ')
				{
					tempIndex1 = tempCodeLength;
					while (tempIndex1 > tempIndex)
					{
						(*(char**)pCode)[tempIndex1 + 2] = (*(char**)pCode)[tempIndex1];

						tempIndex1--;
					}
					(*(char**)pCode)[tempIndex + 1] = '\r';
					(*(char**)pCode)[tempIndex + 2] = '\n';
					tempCodeLength += 2;
				}
			}

			//update at 23.4.5
			if ((*(char**)pCode)[tempIndex] == '\r' && (*(char**)pCode)[tempIndex + 1] == '\n')
			{
				tempIndex3 = tempIndex + 2;
				while ((*(char**)pCode)[tempIndex3] == ' ')
				{
					tempIndex3++;
				}
				while (true)
				{
					if (tempIndex3 >= tempCodeLength)
					{
						break;
					}
					if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex3])))
					{
						tempBuffer[tempBufferIndex++] = (*(char**)pCode)[tempIndex3++];
					}
					else
					{
						if (tempBufferIndex > 0)
						{
							tempBuffer[tempBufferIndex] = 0x0;
							tempBufferIndex = 0;
							if (!strcmp(tempBuffer, "else"))
							{
								//����Ŀǰû��ʵ�ֶ�else if�Ĵ���,��ʵ���˶�else�Ĵ���
								while (true)
								{
									if ((*(char**)pCode)[tempIndex3] != ' ')
									{
										break;
									}
									else
									{
										tempIndex3++;
									}
								}
								if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex3])))
								{
									tempIndex1 = tempCodeLength;
									while (tempIndex1 >= tempIndex3)
									{
										(*(char**)pCode)[tempIndex1 + 2] = (*(char**)pCode)[tempIndex1];

										tempIndex1--;
									}
									(*(char**)pCode)[tempIndex3] = '\r';
									(*(char**)pCode)[tempIndex3 + 1] = '\n';
									tempCodeLength += 2;
								}
							}
						}
						break;
					}
				}
			}

			//update at 23.4.7
			if ((*(char**)pCode)[tempIndex] == '=' && (*(char**)pCode)[tempIndex + 1] != '=' && (*(char**)pCode)[tempIndex + 1] != ' ')
			{
				tempIndex1 = tempCodeLength;
				while (tempIndex1 > tempIndex)
				{
					(*(char**)pCode)[tempIndex1 + 1] = (*(char**)pCode)[tempIndex1];

					tempIndex1--;
				}
				(*(char**)pCode)[tempIndex + 1] = ' ';
				tempCodeLength += 1;
			}

			tempIndex++;
		}

		return 1;
	}

	//Ŀǰ��������в��ٱ������õĶ�Ϊ�̶�ֵ
	int TranslateCodeFileToPic(PSourceCodeFile pCodeFile)
	{
		int tempCodeLineArray[500] = { 0 };
		int tempCodeLineArrayLength = 0;
		char* tempBuffer;
		char* tempBuffer2;
		char* tempBuffer3;
		char** tempppBuffer;
		char** tempppBuffer2;
		char** tempppBuffer3;
		char FileName[150] = "";
		char FunctionName[200] = "";
		int tempBufferIndex = 0;
		int tempBuffer2Index = 0;
		int tempBuffer3Index = 0;
		int** tempBufferDataDependence;
		int** tempBufferControlDependence;
		int PicSize = 0;
		bool bSafe = true;
		PSourceLine temppCodeLine;
		PSourceFunction temppFuncion;

		PicSize = 150;
		
		tempBuffer = (char*)(malloc(50000));
		tempBuffer2 = (char*)(malloc(50000));
		tempBuffer3 = (char*)(malloc(50000));

		tempppBuffer = new char*;
		tempppBuffer2 = new char*;
		tempppBuffer3 = new char*;

		*tempppBuffer = tempBuffer;
		*tempppBuffer2 = tempBuffer2;
		*tempppBuffer3 = tempBuffer3;

		memset(tempBuffer, 0x0, 50000);
		memset(tempBuffer2, 0x0, 50000);
		memset(tempBuffer3, 0x0, 50000);
		memset(FileName, 0x0, 100);

		strcpy(FunctionName, ((pCodeFile->Function)[0])->FunctionName);
		switch (func::CheckStrHaveGoodOrBad(((pCodeFile->Function)[0])->FunctionName))
		{
		case 1:
		{
			bSafe = true;
			break;
		}
		case -1:
		{
			bSafe = false;
			break;
		}
		default:
		{
#ifdef _DEBUG
			std::cout << "Translate Code File To Pic Fail\n";
#endif
			break;
		}
		}

		for (int i = 0; i < ((pCodeFile->Function)[0])->CodeLineNum; i++)
		{
			tempCodeLineArray[tempCodeLineArrayLength++] = ((((pCodeFile->Function)[0])->CodeLine)[i])->GlobalLineNo;
		}

		if (tempCodeLineArrayLength > 150)
		{
			tempCodeLineArrayLength = 150;
			std::cout << "Out 150 range\n";
		}

		for (int i = 0; i < tempCodeLineArrayLength; i++)
		{
			GetCodeLineStruct(pCodeFile, tempCodeLineArray[i], &temppCodeLine, &temppFuncion);
			strcat(tempBuffer, temppCodeLine->buffer);
			strcat(tempBuffer, "\r\n");
		}

		//Ŀǰ������150*150�ľ��󣬺��ڱ�׼�����������ٸ���
		tempBufferDataDependence = new int* [PicSize];
		tempBufferControlDependence = new int* [PicSize];
		for (int i = 0; i < PicSize; i++)
		{
			tempBufferDataDependence[i] = new int[PicSize];
			tempBufferControlDependence[i] = new int[PicSize];
		}

		for (int i = 0; i < PicSize; i++)
		{
			for (int z = 0; z < PicSize; z++)
			{
				(tempBufferDataDependence[i])[z] = 0;
				(tempBufferControlDependence[i])[z] = 0;
			}
		}

		//update at 23.3.25 �������д�����Ϊ�˽�������ȡ��������һ���������ļ����б�������ƥ��VulCNN�����ݼ�Ҫ��
		//OutputFuncToFile(temppFuncion->FunctionNo, bSafe);

		func::GetCodeSliceDataDependence(tempCodeLineArray, tempCodeLineArrayLength, tempBufferDataDependence);
		func::GetCodeSliceControlDependence(tempCodeLineArray, tempCodeLineArrayLength, tempBufferControlDependence);
		/*std::cout << "No Code Extract Data Dependenc:\n";
		for (int i = 0; i < tempIndex; i++)
		{
			for (int z = 0; z < tempIndex; z++)
			{
				std::cout << (tempBufferDataDependence[i])[z] << " ";
			}
			std::cout << std::endl;
		}
		std::cout << "No Code Extract Control Dependenc:\n";
		for (int i = 0; i < tempIndex; i++)
		{
			for (int z = 0; z < tempIndex; z++)
			{
				std::cout << (tempBufferControlDependence[i])[z] << " ";
			}
			std::cout << std::endl;
		}*/
		
		if (strlen(tempBuffer) != 0)
		{
			func::TranslateCodeSlice((void**)tempppBuffer, &tempBufferIndex, (void**)tempppBuffer2, &tempBuffer2Index);

			func::TranslateIntermediateToVec((void**)tempppBuffer2, &tempBuffer2Index, (void**)tempppBuffer3, &tempBuffer3Index);

			GetFileName(func::pSourceCodeFile, FileName);

			func::GetBMP(tempppBuffer3, tempBufferDataDependence, tempBufferControlDependence, bSafe, func::OutputFilePath18, FileName, FunctionName, PicSize, PicSize, 1);
		}

		//strcat(tempBuffer2, "\r\n");

		/*if (!file::OutPutToFile(OutputFilePath10, tempBuffer2))
			std::cout << "Wirte File Fail" << std::endl;*/

		free(tempBuffer);
		free(tempBuffer2);
		free(tempBuffer3);

		return 1;
	}

	//���������д�����ܱȽϷ�ʱ�䣬��Ҫ�����ٶȵĻ����Խ��������Ĵ����нṹ��ȡ
	int GetCodeLineStruct(PSourceCodeFile pSourceCodeFile, int GlobalCodeLineNo, PSourceLine* pSourceLineReturn, PSourceFunction* pFunctionReturn)
	{
		int tempIndex;
		PSourceFunction temppFunc;

		for (int i = 0; i < pSourceCodeFile->FunctionNum; i++)
		{
			temppFunc = pSourceCodeFile->Function[i];
			if (GlobalCodeLineNo >= temppFunc->StartGlobalLineNo && GlobalCodeLineNo <= temppFunc->StopGlobalLineNo)
			{
				*pSourceLineReturn = temppFunc->CodeLine[GlobalCodeLineNo - temppFunc->StartGlobalLineNo];
				*pFunctionReturn = temppFunc;
				return 1;
			}
		}
		for (int i = 0; i < pSourceCodeFile->SourceCodeLineNum; i++)
		{
			if (GlobalCodeLineNo == ((pSourceCodeFile->SourceCodeLine)[i])->GlobalLineNo)
			{
				*pSourceLineReturn = (pSourceCodeFile->SourceCodeLine)[i];
				*pFunctionReturn = NULL;
				return 1;
			}
		}

		return 0;
	}

	int RemoveKeyWord(void** pCode, int* index)
	{
		int tempIndex = 0;
		int tempIndex1 = 0;
		int tempIndex2 = 0;
		int tempCodeLength = 0;
		int tempSubCodeLength = 0;
		char tempBuffer[200];
		int tempBufferIndex = 0;
		char tempKeyWordArray[20][20] = { "unsigned", "signed", "const", "struct", "__init", "inline"};

		tempIndex = *index;
		tempCodeLength = strlen(*(char**)pCode);
		while (tempIndex < tempCodeLength)
		{
			if (func::CheckNamableCharacter(&((*(char**)pCode)[tempIndex])))
			{
				tempBuffer[tempBufferIndex++] = (*(char**)pCode)[tempIndex];
			}
			else
			{
				if (tempBufferIndex > 0)
				{
					tempBuffer[tempBufferIndex] = 0x0;
					tempBufferIndex = 0;
					for (int i = 0; i < 20; i++)
					{
						if (!strcmp(tempBuffer, tempKeyWordArray[i]))
						{
							tempSubCodeLength = strlen(tempBuffer);
							tempIndex1 = tempIndex - tempSubCodeLength;

							if ((*(char**)pCode)[tempIndex] == ' ')
							{
								tempIndex++;
								tempSubCodeLength++;
							}

							tempIndex2 = tempIndex;
							while (tempIndex2 < tempCodeLength)
							{
								(*(char**)pCode)[tempIndex2 - tempSubCodeLength] = (*(char**)pCode)[tempIndex2];
								tempIndex2++;
							}

							tempIndex = tempIndex1 - 1;
							tempCodeLength -= tempSubCodeLength;
						}
					}
				}
			}
			
			tempIndex++;
		}
		(*(char**)pCode)[tempCodeLength] = 0x0;

	}

	int RemoveAfterLineFeedBlank(void** pCode, int* index)
	{
		int tempIndex = 0;
		int tempIndex2 = 0;
		int tempCodeLength = 0;
		int tempBlankLength = 0;

		tempIndex = *index;
		tempCodeLength = strlen(*(char**)pCode);
		while (tempIndex < tempCodeLength)
		{
			if ((*(char**)pCode)[tempIndex] == '\n')
			{
				tempIndex2 = tempIndex + 1;
				while ((*(char**)pCode)[tempIndex2] == ' ' || (*(char**)pCode)[tempIndex2] == '\t')
				{
					tempIndex2++;
					tempBlankLength++;
				}
				if (tempBlankLength > 0)
				{
					while (tempIndex2 < tempCodeLength)
					{
						(*(char**)pCode)[tempIndex2 - tempBlankLength] = (*(char**)pCode)[tempIndex2];
						tempIndex2++;
					}
					tempCodeLength -= tempBlankLength;
					tempBlankLength = 0;
				}
			}

			tempIndex++;
		}
		(*(char**)pCode)[tempCodeLength] = 0x0;

		return 1;
	}

	int InitRealConfig()
	{
		char tempBuffer[20];
		char** tempppBuffer;

		tempppBuffer = new char*;
		*tempppBuffer = tempBuffer;

		memset(tempBuffer, 0x0, 20);

		file::readOneFile("./RealFileNum.txt", (void**)tempppBuffer);

		HandleFileNum = func::StrToInt(tempBuffer);

		memset(tempBuffer, 0x0, 20);

		file::readOneFile("./RealFunctionNum.txt", (void**)tempppBuffer);

		HandleFunctionNum = func::StrToInt(tempBuffer);

		memset(tempBuffer, 0x0, 20);

		file::readOneFile("./RealCodeLineNum.txt", (void**)tempppBuffer);

		HandleCodeLineNum = func::StrToInt(tempBuffer);

		return 1;
	}

	int WriteRealConfig()
	{
		char tempBuffer[20];
		FILE* fp;

		memset(tempBuffer, 0x0, 20);

		func::IntToStrNew(HandleFileNum, tempBuffer);

		fp = fopen("./RealFileNum.txt", "wb");
		if (fp == NULL)
		{
			printf("%s: file create failed!\n", "./RealFileNum.txt");
			return -1;
		}
		fprintf(fp, "%d", HandleFileNum);
		if (fclose(fp))
		{
			printf("file close failed!\n");
			return -1;
		}
		fp = NULL;

		memset(tempBuffer, 0x0, 20);

		func::IntToStrNew(HandleFunctionNum, tempBuffer);

		fp = fopen("./RealFunctionNum.txt", "wb");
		if (fp == NULL)
		{
			printf("%s: file create failed!\n", "./RealFunctionNum.txt");
			return -1;
		}
		fprintf(fp, "%d", HandleFunctionNum);
		if (fclose(fp))
		{
			printf("file close failed!\n");
			return -1;
		}
		fp = NULL;

		memset(tempBuffer, 0x0, 20);

		func::IntToStrNew(HandleCodeLineNum, tempBuffer);

		fp = fopen("./RealCodeLineNum.txt", "wb");
		if (fp == NULL)
		{
			printf("%s: file create failed!\n", "./RealCodeLineNum.txt");
			return -1;
		}
		fprintf(fp, "%d", HandleCodeLineNum);
		if (fclose(fp))
		{
			printf("file close failed!\n");
			return -1;
		}
		fp = NULL;

		return 1;
	}

	int GetFileName(PSourceCodeFile pCodeFile, char* ReturnFileName)
	{
		int tempIndex = 0;
		int tempSignPosition = -1;

		while ((pCodeFile->FilePath)[tempIndex] != 0x0)
		{
			if ((pCodeFile->FilePath)[tempIndex] == '\\')
			{
				tempSignPosition = tempIndex;
			}
			tempIndex++;
		}
		
		tempIndex = 0;

		if (tempSignPosition == -1)
		{
#ifdef _DEBUG
			std::cout << "Get File Name Error!\n";
#endif
		}
		else
		{
			tempSignPosition++;
			while ((pCodeFile->FilePath)[tempSignPosition] != '.' && (pCodeFile->FilePath)[tempSignPosition] != 0x0)
			{
				ReturnFileName[tempIndex++] = (pCodeFile->FilePath)[tempSignPosition];
				tempSignPosition++;
			}
		}
		ReturnFileName[tempIndex] = 0x0;

		return tempIndex;
	}
}