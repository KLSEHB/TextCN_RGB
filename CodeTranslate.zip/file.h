#pragma once

namespace file
{
	int readOneFile(const char* filePath, void** readBuffe);

	int readDirAllFile(const char* dirPath);

	int OutPutToFile(const char* FilePath, char* writebuffer);
}