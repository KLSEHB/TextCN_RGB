#pragma once

namespace Real
{
	extern char KeyWordArray[20][50];

	extern PSourceCodeFile pRealSourceCodeFile;

	extern int HandleFileNum;

	extern int HandleFunctionNum;

	extern int HandleCodeLineNum;

	int Init();

	int InitKeyWordArray();

	int HandleReal(void** pCode, int* index);

	int ProcessCode(void** pCode, int* index);

	int ProcessCodeFunctionDefine(void** pCode, int* index);

	int GetFuncDefineCode(void** pCode, int* index, void* pReutnrFuncDefCode);

	int HandleFunc(void** pCode, int* index);

	int HandleLineFeed(void** pCode, int* index);

	int RemoveWindowsLineFeed(void** pCode, int* index);

	int RemoveLinuxLineFeed(void** pCode, int* index);

	int RemoveTabKey(void** pCode, int* index);

	int AddLineFeedForThreeSymbol(void** pCode, int* index);

	int TranslateCodeFileToPic(PSourceCodeFile pCodeFile);

	int GetCodeLineStruct(PSourceCodeFile pSourceCodeFile, int GlobalCodeLineNo, PSourceLine* pSourceLineReturn, PSourceFunction* pFunctionReturn);

	int RemoveKeyWord(void** pCode, int* index);

	int RemoveAfterLineFeedBlank(void** pCode, int* index);

	int InitRealConfig();

	int WriteRealConfig();

	int GetFileName(PSourceCodeFile pCodeFile, char* ReturnFileName);
}