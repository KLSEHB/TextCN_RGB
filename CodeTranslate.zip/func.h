﻿#pragma once

enum ReturnType : int
{
	ReturnType_unknownType = 0,
	charType = 1,
	pcharType = 2,
	intType = 3,
	pintType = 4,
	floatType = 5,
	pfloatType = 6,
	doubleType = 7,
	pdoubleType = 8,
	voidType = 9,
	pvoidType = 10,
	shortType = 11,
	pshortType = 12,
	longType = 13,
	plongType = 14,
	size_tType = 15,
	wchar_tType = 16,
	FILEType = 17,
	HCRYPTPROVType = 18,
	HCRYPTKEYType = 19,
	HCRYPTHASHType = 20,
	DWORDType = 21,
	UserDefStructType = 22,
	UserDefStructAnotherNameType = 23,
	UserDefStructPointerType = 24,
	UserDefStructContentType = 25,
	pwchar_tType = 26,
	WSADATAType = 27,
	sockaddr_inType = 28,
	SOCKETType = 29,
	sockaddrType = 30,
	int64_tType = 31,
	pint64_tType = 32,
	twoIntsStructType = 33,
	ptwoIntsStructType = 34,
	va_listType = 35,
	boolType = 36,
	pboolType = 37,
	u8Type = 38,
	u16Type = 39,
	u32Type = 40,
	tipc_mon_domainType = 41,
	ptipc_mon_domainType = 42,
	tipc_peerType = 43,
	ptipc_peerType = 44,
	tipc_monitorType = 45,
	ptipc_monitorType = 46,
	oz_usb_hdrType = 47,
	poz_usb_hdrType = 48,
	oz_usb_ctxType = 49,
	poz_usb_ctxType = 50,
	oz_get_desc_rspType = 51,
	poz_get_desc_rspType = 52,
	oz_portType = 53,
	poz_portType = 54,
	urbType = 55,
	purbType = 56,
	usb_ctrlrequestType = 57,
	pusb_ctrlrequestType = 58,
	pu8Type = 59,
	pu16Type = 60,
	pu32Type = 61,
	oz_dataType = 62,
	poz_dataType = 63,
	oz_multiple_fixedType = 64,
	poz_multiple_fixedType = 65,
	oz_isoc_fixedType = 66,
	poz_isoc_fixedType = 67,
	nft_set_extType = 68,
	pnft_set_extType = 69,
	int32_tType = 70,
	pint32_tType = 71,
	uint8_tType = 72,
	puint8_tType = 73,
	uint64_tType = 74,
	puint64_tType = 75,
	uint16_tType = 76,
	puint16_tType = 77,
	uint32_tType = 78,
	puint32_tType = 79,
	pFILEType = 80,
	Int32Type = 81,
	pInt32Type = 82,
	UInt32Type = 83,
	pUInt32Type = 84,
	UInt64Type = 85,
	pUInt64Type = 86,
	dfl_afu_mmio_regionType = 87,
	pdfl_afu_mmio_regionType = 88,
	dfl_afuType = 89,
	pdfl_afuType = 90,
	vlan_ethhdrType = 91,
	pvlan_ethhdrType = 92,
	wilc_attr_entryType = 93,
	pwilc_attr_entryType = 94,
	wilc_attr_ch_listType = 95,
	pwilc_attr_ch_listType = 96,
	wilc_attr_oper_chType = 97,
	pwilc_attr_oper_chType = 98,
	wilc_ch_list_elemType = 99,
	pwilc_ch_list_elemType = 100
};

enum ProfixType : int
{
	ProfixType_unknownType = 0,
	staticType = 1,
	typedefType = 2,
	staticconstType = 3,
	namespaceType = 4,
	usingType = 5,
	usingnamespaceType = 6,
	structType = 7,
	externType = 8,
	unionType = 9
};

enum SyntaxKey : int
{
	SyntaxKey_unknownType = 0,
	ifType = 1,
	elseType = 2,
	elseifType = 3,
	forType = 4,
	whileType = 5,
	switchType = 6,
	breakType = 7,
	continueType = 8,
	returnType = 9,
	caseType = 10,
	defaultType = 11,
	doType = 12
};

enum Sign : int
{
	Sign_unknownType = 0,
	semicolon = 1,
	Rbracket = 2
};

enum SubCodeLineType :int
{
	SubCodeLineType_unknownType = 0,
	FunctionDeclareOrFunctionCall = 1,
};

//enum CodeLineType :int
//{
//	VariableDeclare = 1,
//	VariableDefine = 2,
//	VariableDeclareAndDefinedByVariable = 3,
//	VariableDeclareAndDefinedByFunctionCall = 4,
//	VariableAssignmentByVaribale = 5,
//	FunctionCall = 6,
//	VariableAssignmentByFunctionCall = 7,
//	ConditionStatement = 8,
//	Bracket = 9,
//	Default = 0,
//	FunctionDeclare = 10,
//	FunctionDefine = 11,
//	Preprocessing = 12,
//	Syntax = 13,
//	CodeLineType_unknownType = 0
//};

enum CodeLineType : int
{
	CodeLineType_unknownType = 0,
	MacroType = 1,
	VariableDeclare = 2,
	VariableDefine = 3,
	FunctionDeclare = 4,
	FunctionDefine = 5,
	OnlyFunctionCall = 6,
	FunctionCall = 7,
	Syntax = 8,
	LBraceType = 9,
	RBraceType = 10,
	StructDefType = 11,
	UnionDefType = 12,
	namespaceDefType = 13,
	usingKeywordType = 14,
	usingnamespaceKeywordType = 15,
	externKeywordType = 16
};

enum CodeFileType : int
{
	OnlyOne = 1,
	LinkWithLibrary = 2,
	LinkWithOtherFile = 3,
	LinkWithOtherFileAndLibrary = 4,
	CodeFileType_unknownType = 0
};

enum IntermediateTokenType : int
{
	IntermediateTokenType_unknownType = 0,
	Input = 1,
	Sanit_f = 2,
	ss = 3,
	cond = 4,
	var = 5,
	Var_vv = 6
};

enum TypedefType : int
{
	TypedefType_unknownType = 0,
	StructType = 1,
	UnionType = 2
};

enum OperatorType :int
{
	OperatorType_UnknownType = 0,
	EqualOperator = 1,
	GreaterOperator = 2,
	GreaterAndEqualOperator = 3,
	LessOperator = 4,
	LessAndEqualOperator = 5,
	SubOperator = 6,
	AddOperator = 7,
	MulOperator = 8,
	DivOperator = 9,
	ComplementationOperator = 10,
	DoubleAddOperator = 11,
	DoubleSubOperator = 12,
	AssignmentOperator = 13,
	OrOperator = 14,
	AndOperator = 15,
	DoubleOrOperator = 16,
	DoubleAndOperator = 17
};

enum LanguageType : int
{
	LanguageType_UnknownType = 0,
	CLanguageType = 1,
	CPlusPlusLanguageType = 2
};

enum CodeBlockType : int
{
	CodeBlockType_unknown = 0,
	MacroDefType = 1,
	StructDef = 2,
	TypedefStructDef = 3,
	UnionDef = 4,
	TypedefUnionDef = 5,
	VarDefType = 6,
	VarDeclareType = 7,
	VarAssignmentType = 8,
	CodeBlockTypeOnlyFunctionCall = 9,
	SyntaxKeyCodeLine = 10,
	CodeBlockTypeLBraceType = 11,
	CodeBlockTypeRBraceType = 12,
	CodeBlockTypeFunctionDeclare = 13
};

typedef union {
	uint8_t bytes[4];
	uint32_t value;
}LITTLE;

typedef struct _InterMediateParInfo
{
	int ParType;                     // ==-1 [IN]; == 0 [OUT,IN];  ==1 [OUT]
	int ParSens;                     // == 1 Sensitive; == -1 UnSensitive
}InterMediateParInfo, * PInterMediateParInfo;

typedef struct _InterMediateFunctionInfo
{
	char Name[50];
	int FunctionType;                 //== -1 No Par, Just Return Value; == 0 Have Par And Return Value; == 1 Have Par, No Return Value;
	int FunctionParNum;
	int FunctionDirect;               //== -1 Forward;  ==1 Back
	InterMediateParInfo pPar[5];
}InterMediateFunctionInfo, * PInterMediateFunctionInfo;

typedef struct _InterMediate
{
	char Token[50];
	char Descripte[50];
	InterMediateFunctionInfo CodeElements[100];
	int CodeElementsNum;
}InterMediate, * PInterMediate;

typedef struct _InterMediateArray
{
	PInterMediate Array[20];
	int ArrayNum;
}InterMediateArray, * PInterMediateArray;

typedef struct _SubCode SubCode, * PSubCode;
struct _SubCode
{
	char buff[200];
	PSubCode subCode;
	int subCodeNum;
	bool bSubCode;
	int Bracket = -2;            //Bracket == 0 ��ʾ�ڣ����ڣ� == -1 ��ʾ�ڣ�����ߣ� == 1 ��ʾ�ڣ����ұ�, == 2 ��ʾ���߶��� ������ == - 2 ��ʾ���루������
};

typedef struct _Variable Variable, * PVariable;
typedef struct _Macro Macro, * PMacro;
typedef struct _SourceFunction SourceFunction, * PSourceFunction;

typedef struct _StoreMacroDefInfo StoreMacroDefInfo, * PStoreMacroDefInfo;
struct _StoreMacroDefInfo
{
	char Name[50];
	int DefGlobalLineNo;
	bool bChangeOtherVar;
	int ChangeGlobalLineNo;
	int InFunctionNo;
	PVariable pParent;
	PMacro pMacroDef;
	PStoreMacroDefInfo pNext;
};

typedef struct _StoreVarDefInfo StoreVarDefInfo, * PStoreVarDefInfo;
struct _StoreVarDefInfo
{
	char Name[50];
	int DefGlobalLineNo;
	bool bChangVar;
	bool bChangeOtherVar;
	int ChangGlobalLineNo;
	int InFunctionNo;
	//PVariable pChangVar;
	PVariable pParent;
	PVariable pVarDef;
	PStoreVarDefInfo pNext;
};

typedef struct _StoreFunctionDefInfo StoreFunctionDefInfo, * PStoreFunctionDefInfo;
struct _StoreFunctionDefInfo
{
	char Name[100];
	int FunctionCallGlobalLineNo;
	bool bUserDefFunction;
	int ParNo;                         // == -1 : �ñ������������÷���ֵ�޸�
	PVariable pParent;
	PSourceFunction pFuncDef;
	PStoreFunctionDefInfo pNext;
};

struct _Macro
{
	char Name[50];
	char Value[50];
	int DefCodeLineGlobalNo;
};

typedef struct _SourceLine SourceLine, * PSourceLine;

typedef struct _UserDefStruct UserDefStruct, * PUserDefStruct;

typedef struct _StoreSyntaxKeyInfo StoreSyntaxKeyInfo, * PStoreSyntaxKeyInfo;
struct _StoreSyntaxKeyInfo
{
	int GlobalCodeLineNo;
	SyntaxKey SyntaxKeyType;
	PVariable pParent;
	PSourceLine pSourceLine;
	PStoreSyntaxKeyInfo pNext;
};

typedef struct _StoreVarNameInfo StoreVarNameInfo, * PStoreVarNameInfo;
struct _StoreVarNameInfo
{
	char buffer[50];
	int VarType;                              //== 0 ���û������������; == 1 �û����� Struct ����; == 2 �û����� PStruct ����;
	char VarMainName[30];                     //��¼������������
	char VarMinorName[10][30];                //��¼�����Ĵ�Ҫ����
	int MinorNameNum;                         //��Ҫ��������
	bool bHaveSubName;                        //��ʾ�Ƿ��������ƣ����磺�༶ָ��
	PStoreVarNameInfo pSubCode;               //ָ��������
};

typedef struct _StoreArrayIndexInfo StoreArrayIndexInfo, * PStoreArrayIndexInfo;
struct _StoreArrayIndexInfo
{
	int GlobalCodeLineNo;
	PVariable pParent;
	PVariable pArray;
	PSourceLine pSourceLine;
	PStoreArrayIndexInfo pNext;
};

typedef struct _StoreAsArrayIndexInfo StoreAsArrayIndexInfo, * PStoreAsArrayIndexInfo;
struct _StoreAsArrayIndexInfo
{
	int AsArrayIndexGlobalCodeLineNo;
	PVariable pVar;
	PVariable pParent;
	PStoreAsArrayIndexInfo pNext;
};

struct _Variable
{
	ReturnType returnType;
	ProfixType profixType;
	bool bGlobal;
	bool bDefByOthersMacro;                   //��ʾ�ñ����Ķ����Ƿ����õ������궨��
	bool bChangeByOthersMacro;                //��ʾ�ñ�����ֵ�Ƿ������궨��ı��
	bool bDefByOthersVar;
	bool bChangVar;
	bool bChangeOtherVar;
	bool bIsFunctionCallPar;                   //��ʾ�ñ����Ƿ��������������õĲ���
	bool bFunctionCallReturn;                  //��ʾ�ñ�����ֵ�Ƿ񱻺������õķ���ֵ�ı��
	bool bUserDefStruct;                       //�Ƿ����û��������������
	bool bUserDefStructContent;                //�Ƿ����û���������������е����� 
	bool bInSyntaxBlock;                       //��ʾ�ñ����Ƿ�����ָ���֧�й�
	bool bPointerType;                         //��ʾ�����Ƿ���ָ�����ͱ������������ͱ���������Ҳ������ָ�����ͱ�����
	bool bArrayIndex;                          //��ʾ�����Ƿ�������������
	bool bAllocMemory;                         //是否存在内存分配
	int AllocMemoryCodeLineNo;                 //内存分配代码行号
	int PointerPointMemSize;                   //��ʾ��ָ�����ָ��Ŀռ�Ĵ�С��BYTE��
	int DefCodeLineGlobalNo;
	int DefByOthersVarNum;
	int ChangeNewGlobalCodeLineNo;
	int ChangeVarNum;                          //����ı����ı�ֵ�Ĵ���
	int ChangeOtherVarNum;					   //�ı��ı���ֵ�Ĵ���
	int IsFunctionCallParNum;                  //��ʾ�ñ�������Ϊ�������ò����Ĵ���
	int FunctionCallReturnNum;                 //��¼�ñ�����������������ֵ�ı��
	int ContentNum;                            //�����������
	int DefByOthersMacroNum;                   //��ʾ�붨��ñ����йصĺ궨����
	int ChangeByOthersMacroNum;                //��ʾ�ı�ñ���ֵ�ĺ궨����Ŀ
	PStoreVarDefInfo pChangeOtherVar;          //ָ����������ı�ֵ�����������Ĵ洢�ṹ
	PStoreVarDefInfo pDefOthersVar;
	PStoreVarDefInfo pChangVar;                //ָ��ı��������ֵ�����������Ĵ洢�ṹ
	PStoreFunctionDefInfo pFunctionCallPar;    //ָ���ں������������������Ϊ�����ĺ������õĴ洢�ṹ
	PStoreFunctionDefInfo pFunctionCallReturn; //ָ�������÷���ֵ�ı������������ֵ�ĺ������õĴ洢�ṹ
	PStoreMacroDefInfo pDefOthersMacro;        //ָ����ñ��������йصĺ궨������
	PStoreMacroDefInfo pChangeOtherMacro;      //ָ��ı�ñ���ֵ�ĺ궨������  

	//��Ϊ�������������ͱ�ò��ð��ˣ������������ֶ�����ʱ����
	PVariable pParent;                         //������û���������������е�������ô����ָ��������
	PVariable pContent[10];

	PUserDefStruct pUserDefStruct;             //ָ���û���������͵Ķ���
	int CodeLineNum;                           //���������еĴ����д���
	int CodeLineNoArray[100];                  //���������еĴ����к�����
	int SyntaxCodeLineNum;                     //��������Syntax�Ĵ�������Ŀ
	PStoreSyntaxKeyInfo SyntaxCodeLineNoArray;                 //��������Syntax�Ĵ����к�����
	int StoreArrayIndexInfoNum;                //����Ϊ���������Ĵ����д���
	PStoreArrayIndexInfo pStoreArrayIndexInfo;  //ָ��洢Ϊ���������Ĵ�������Ϣ��
	int AsArrayIndexNum;                       //��ʾ��Ϊ���������Ĵ���
	PStoreAsArrayIndexInfo pStoreAsArrayIndexInfo;    //ָ��洢������Ϊ���������Ĵ�������Ϣ��
	bool bArray;
	char* Array;
	bool bParameter;
	int ParNo;                                  //�������Ϊ�����Ĳ����Ļ�����ֵ��ʾΪ�����ĵڼ�������
	bool bFunctionCall;
	char Name[100];
	char Value[100];
	int FunctionNo;
	int CodeLineNo;                               //�������ڵĴ����к�
	int VariableNo;
};

typedef struct _DataDependence DataDependence, * PDataDependence;
struct _DataDependence
{
	int GlobalCodeLineNo;
	PSourceLine pCodeLine;
	bool bDependenceFunctionCallCodeLine;
	PDataDependence pNext;
};

typedef struct _ControlDependence ControlDependence, * PControlDependence;
struct _ControlDependence
{
	int GlobalCodeLineNo;
	PSourceLine pCodeLine;
	bool bDependenceFunctionCallCodeLine;
	PControlDependence pNext;
};

typedef struct _UnSyntaxSourceLine
{
	int MasterType; ///== 0:表示所属用{}括出来的代码块，== 1 ：表示属于语法结构If\for; == 2 表示属于定义函数 == -1 unknown
	int MasterLineNo;
}UnSyntaxSourceLine, * PUnSyntaxSourceLine;

typedef struct _SyntaxCodeLine
{
	SyntaxKey SyntaxKeyType;
	bool bbrace;
	int FirstContentLineNo;
	int FinalContentLineNo;
	int SyntaxChainCodeLineArray[20];
	int SyntaxChainLength;
	bool bCondition;
	char Condition[200];
	int BraceContentFeedLineNum;
}SyntaxCodeLine, * PSyntaxCodeLine;

typedef struct _MiddleSourcceLine
{
	char buffer[200];
}MiddleSourcceLine, * PMiddleSourcceLine;

struct _SourceLine
{
	CodeLineType CodeType;
	PSyntaxCodeLine PSyntaxCode;
	PUnSyntaxSourceLine PUnSyntaxCode;
	PMiddleSourcceLine PMiddleCode;
	SubCode pSubCode[10];
	PVariable  Variable[20];
	char buffer[400];
	bool bDataDependence;
	int DataDependenceNum;
	PDataDependence pDataDependence;
	bool bControlDependence;
	int ControlDependenceNum;
	PControlDependence pControlDependence;
	bool bHaveUserDefFunctionCall;
	int HaveUserDefFunctionCallNum;
	int HaveUserDefFunctionCallCodeLineNoArray[5];
	int WriteBufferNo;
	int ReadBufferNo;
	int VariableNum;
	int WriteVariableNo;
	int ReadVariableNo;
	int SubCodeNum;
	int Syntax;                          //Syntax == 1 : Syntax Code ; Syntax == 0 : UnSyntax Code ; Syntax == -1 : init
	int FunctionNo;
	int CodeLineNo;
	int GlobalLineNo;
	int LocalLineNo;
};

typedef struct _FunctionInfo FunctionInfo, * PFunctionInfo;

typedef struct _ParInfo ParInfo, * PParInfo;
struct _ParInfo
{
	char Name[100];
	bool bDefPar;
	bool bDefMacro;                        //�����˹��ں����Ĳ����Ǻ궨��ļ�¼
	PVariable pVar;
	PMacro pMacro;                         //�����˹��ں����Ĳ����Ǻ궨��ļ�¼
	PFunctionInfo pParent;
	PParInfo pNext;
};

typedef struct _CodeBlock CodeBlock, * PCodeBlock;
struct _CodeBlock
{
	bool bChildBlock;
	bool bFunctionCall;
	bool bParent;
	bool bReturn;
	int ReturnGlobalLineNo[5];
	int ReturnNum;
	PFunctionInfo pFunctionInfo;
	PCodeBlock pNext;
	PCodeBlock pChildBlock;
	PCodeBlock pParent;
	int ChildBlockNum;
	int StartGlobalLineNo;
	int StopGlobalLineNo;
	int CodeBlockType;
};

struct _SourceFunction
{
	char FunctionName[200];
	ReturnType returnType;
	int CodeLineNum;
	PSourceLine CodeLine[200];
	PUserDefStruct pReturnUserDefStruct;
	int VariableNum;
	PVariable  Variable[30];
	bool bDeclare;
	bool bDefinition;
	bool bHavePar;
	bool bReturnUserDefStruct;
	int ParNum;
	char Value[300];
	int FunctionNo;
	int DeclareGlobalLineNo;
	int WriteCodeLineNo;
	int ReadCodeLineNo;
	int WriteVariableNo;
	int ReadVariableNo;
	int StartGlobalLineNo;
	int StopGlobalLineNo;
	int StartIndex;
	int StopIndex;
	PFunctionInfo CallFunction;                //������øú����ĺ�����Ϣ�ṹ
	PFunctionInfo CalledFunction;              //����ú����е��õ�������������Ϣ�ṹ
	int CallFunctionNum;
	int CalledFunctionNum;
	PCodeBlock pCodeBlock;
};

struct _FunctionInfo
{
	int FunctionNo;
	int GlobalLineNo;
	int LocalLineNo;
	char Name[100];
	bool bIsUserDefFunc;
	int ParNum;
	PParInfo pPar;
	PSourceFunction pFunc;
	PFunctionInfo pNext;
};

typedef struct _CodeExePathBlock CodeExePathBlock, * PCodeExePathBlock;

typedef struct _StoreSensitiveAPIInfo
{
	char APIName[100];
	int ParNum;
	int ReturnVarNum;
	int CodePathBlockNum[5];
	int ReturnVarCodePathBlockNum[5];
	int PathTraceDeepth;
	int VarChangeNum;
	int FunctionCallNum;
	int VarDefByOtherVarNum;
	int MacroChangeNum;
	int VarDefByOtherMacroNum;
	int FunctionCallGlobalLineNo;
	int RealVarChangeNum;
	int RealFunctionCallNum;
	int RealVarDefByOtherVarNum;
	int RealMacroChangeNum;
	int RealVarDefByOtherMacroNum;
	PSourceFunction pFunc;
	PSourceLine pSourceLine;
	PCodeExePathBlock pCodePathBlock[5];
	PCodeExePathBlock pReturnVarCodePathBlock[5];
}StoreSensitiveAPIInfo, * PStoreSensitiveAPIInfo;

typedef struct _StoreArrayUseInfo
{
	int ArrayIndexVarNum;
	int CodePathBlockNum[5];
	PVariable pArrayVar;
	PVariable pArrayIndexVar;
	PSourceFunction pFunc;
	PSourceLine pSourceLine;
	PCodeExePathBlock pCodePathBlock[5];
}StoreArrayUseInfo, * PStoreArrayUseInfo;

//typedef struct _StoreArrayUseInfo
//{
//	int ArrayIndexVarNum;
//	int CodePathBlockNum[5];
//	PVariable pArrayVar;
//	PVariable pArrayIndexVar;
//	PSourceFunction pFunc;
//	PSourceLine pSourceLine;
//	PCodeExePathBlock pCodePathBlock[5];
//}StoreArrayUseInfo, *PStoreArrayUseInfo;

struct _CodeExePathBlock
{
	int Path[300];
	int PathLength;
	int BlockRealFunctionCallNum;
	int BlockRealVarChangeNum;
	int BlockRealVarDefByOtherVarNum;
	int BlockRealMacroChangeNum;
	int BlockRealVarDefByOtherMacroNum;
	int PathTraceDeepth;
	int FunctionCallNum;
	int VarChangeNum;
	int VarDefByOtherVarNum;
	int MacroChangeNum;
	int VarDefByOtherMacroNum;
	int ParNo;
	int ReturnVarNo;
	bool bIsPar;
	PSourceFunction pFunc;
	PStoreSensitiveAPIInfo pParent;
	PCodeExePathBlock pNext;
	PCodeExePathBlock pForward;
};

typedef struct _UserDefStructContent
{
	char Name[50];
	bool bArray;
	bool bPointerType;                         //��ʾ�����Ƿ���ָ�����ͱ������������ͱ���������Ҳ������ָ�����ͱ�����
	int PointerPointMemSize;                   //��ʾ��ָ�����ָ��Ŀռ�Ĵ�С��BYTE��
	bool bUserDefStruct;
	/*bool bUserDefStructContent;*/
	PUserDefStruct pUserDefStruct;                     //Ŀǰû�ж�������Խ�һ���Ĵ�������Ϊû�д��봦���û�����Ľṹ�е��ֶ�
	char Array[50];
	int DefCodeLineGlobalNo;
	int UserDefStructNo;
	ReturnType ReturnType;
	ProfixType ProfixType;
}UserDefStructContant, * PUserDefStructContant;

//����ṹ�������û�����Ľṹ�壬��ʵ��ʼ��ʱ������������ṹ�����û������Struct���͵ģ�
//���Ǻ����������û������Union���ͣ��о�Union���ͺ�Struct���������Ǵ���������ﲢ�������ֿ���
//���Ծͽ��û������Union����Ҳ����������ṹ���ˣ���ʵ��Ҫ��ԭ������Ϊ������дһ���µĽṹ������
//Union�����ˣ���ΪҪ�Ķ��ܶ���룬���Ҹо�Union���ͺ�Struct�������𲻴�Ͳ��ö��ˣ�����ΪUnion����
//��ʵ��Struct���͸о�����ͬ�ģ�֮���������Ҫ��˵�ɣ����ھ���������ṹ�����������ֶ�����ʾ�䵽����ʲô���͵�
struct _UserDefStruct
{
	char Name[100];
	char AnotherName[2][100];               //����ͼ���������������
	char PointerName[2][100];               //ͨ��
	bool bUserDefStruct;                   //��ʾ�Ƿ�Ϊ�û������Struct����
	bool bUserDefUnion;                    //��ʾ�Ƿ�Ϊ�û������Union����
	int ContentNum;
	int DefStartGlobalLineNo;
	int DefStopGlobalLineNo;
	int AnotherNameNum;
	int PointerNameNum;
	int WriteContantNo;
	int ReadContantNo;
	UserDefStructContant Content[10];
};

//����ṹ��ʱ�Ȳ������ˣ��Ⱥ��濴���ѣ����������
typedef struct _UserDefStructAnotherName
{
	char Name[50];
	int AnotherNameType;                  // == -1 Pointer ; == 1 AnoterName
	PUserDefStruct pParent;
}UserDefStructAnotherName, * PUserDefStructAnotherName;

typedef struct _StoreNameSpaceInfo
{
	char Name[100];
	int NameSpaceNo;
	int StartGlobalLineNo;
	int StopGlobalLineNo;
	PVariable Variable[20];
	PSourceLine SourceCodeLine[20];
	PSourceFunction SourceFunction[10];
	int VariableNum;
	int WriteVariableNo;
	int ReadVariableNo;
	int SourceCodeLineNum;
	int WriteSourceCodeLineNo;
	int ReadSourceCodeLineNo;
	int SourceFunctionNum;
	int WriteSourceFunctionNo;
	int ReadSourceFunctionNo;
}StoreNameSpaceInfo, * PStoreNameSpaceInfo;

typedef struct _StoreUseNameSpaceInfo StoreUseNameSpaceInfo, * PStoreUseNameSpaceInfo;
struct _StoreUseNameSpaceInfo
{
	int UseNameSpaceCodeLineNo;                         //��¼using namespace �Ĵ����к�
	char NameSpaceName[100];
	bool bUserDefNameSpace;
	PStoreNameSpaceInfo pNameSpaceDefInfo;
	PStoreUseNameSpaceInfo pNext;
};

typedef struct _StoreInterMediateCodeBlockInfo StoreInterMediateCodeBlockInfo, * PStoreInterMediateCodeBlockInfo;

typedef struct _StoreInterMediateVarDefInfo StoreInterMediateVarDefInfo, * PStoreInterMediateVarDefInfo;
struct _StoreInterMediateVarDefInfo
{
	char VarName[100];
	char InterMediateName[80];
	int InterMediateCodeLineNo;
	bool bArray;
	char Array[100];
	PStoreInterMediateCodeBlockInfo pCodeBlock;
	PStoreInterMediateVarDefInfo pNext;
};

typedef struct _StoreInterMediateMacroDefInfo StoreInterMediateMacroDefInfo, * PStoreInterMediateMacroDefInfo;
struct _StoreInterMediateMacroDefInfo
{
	char MacroName[100];
	char InterMediateName[80];
	int InterMediateCodeLineNo;
	PStoreInterMediateCodeBlockInfo pCodeBlock;
	PStoreInterMediateMacroDefInfo pNext;
};

typedef struct _StoreInterMediateUserDefFunctionInfo StoreInterMediateUserDefFunctionInfo, * PStoreInterMediateUserDefFunctionInfo;
struct _StoreInterMediateUserDefFunctionInfo
{
	char UserDefFunctionName[100];
	char InterMediateName[80];
	PStoreInterMediateUserDefFunctionInfo pNext;
};

typedef struct _StoreInterMediateUserDefTypeContenTypeInfo StoreInterMediateUserDefTypeContenTypeInfo, * PStoreInterMediateUserDefTypeContenTypeInfo;
struct _StoreInterMediateUserDefTypeContenTypeInfo
{
	char Name[100];
	char InterMediateName[80];
	bool bArray;
	char Array[100];
	PStoreInterMediateUserDefTypeContenTypeInfo pNext;
};

typedef struct _StoreInterMediateUserDefTypeInfo StoreInterMediateUserDefTypeInfo, * PStoreInterMediateUserDefTypeInfo;
struct _StoreInterMediateUserDefTypeInfo
{
	int UserDefTypeType;                                 //��ʾ�����û�����ĺ������͵ı�������: == 0:Ϊ��֪������; == 1 ΪStruct����; == 2 ΪUnion����; == 3 Ϊ�û������typedef struct ����; == 4:Ϊ�û������ typedef union ����
	char DefTypeMainName[100];
	char InterMediateName[80];
	char AnotherName[2][100];
	int AnotherNameNum;
	char PointerName[2][100];
	int PointerNameNum;
	PStoreInterMediateUserDefTypeContenTypeInfo pContent;
	int ContentNum;
	PStoreInterMediateUserDefTypeInfo pNext;
};

typedef struct _StoreInterMediateBraceInfo StoreInterMediateBraceInfo, * PStoreInterMediateBraceInfo;
struct _StoreInterMediateBraceInfo
{
	int BraceType;                       // == 0 Ϊ��֪������: == -1 Ϊ'{'; == 2 Ϊ '}'
	bool bMatched;
	int InterMediateCodeLineNo;
	PStoreInterMediateBraceInfo pMatched;
	PStoreInterMediateCodeBlockInfo pParent;
	PStoreInterMediateBraceInfo pForward;
	PStoreInterMediateBraceInfo pNext;
};

struct _StoreInterMediateCodeBlockInfo
{
	bool bMatched;
	int StartInterMediateCodeLineNo;
	int StopInterMediateCodeLineNo;
	int InterMediateCodeLineNum;
	PStoreInterMediateBraceInfo pLBrace;
	PStoreInterMediateBraceInfo pRBrace;
	PStoreInterMediateCodeBlockInfo pForWard;
	PStoreInterMediateCodeBlockInfo pNext;
};

class InterMediateNew
{
public:
	int StoreInterMediateUserDefTypeInfoNum;
	PStoreInterMediateUserDefTypeInfo pStoreUserDefTypeInfo;
	int StoreInterMediateUserDefFunctionInfoNum;
	PStoreInterMediateUserDefFunctionInfo pStoreUserDefFunctionInfo;
	int StoreInterMediateMacroDefInfoNum;
	PStoreInterMediateMacroDefInfo pStoreMacroInfo;
	int StoreInterMediateVarDefInfoNum;
	PStoreInterMediateVarDefInfo pStoreVarInfo;
	int LBraceNum;
	PStoreInterMediateBraceInfo pLBraceChain;
	int RBraceNum;
	PStoreInterMediateBraceInfo pRBraceChain;
	int CodeBlockNum;
	PStoreInterMediateCodeBlockInfo pCodeBlock;
	void** InputBuffer;
	int* InputBufferIndex;
	void** OutputBuffer;
	int* OutputBufferIndex;
	int InterMediateCodeLineNum;
	int WriteInterMediateCodeLineNo;
	int ReadInterMediateCodeLineNo;

public:
	InterMediateNew(void** Input, int* InputIndex, void** Output, int* OutputIndex);
	~InterMediateNew();
	int AddStoreInterMediateUserDefTypeInfo(PStoreInterMediateUserDefTypeInfo p);
	int AddStoreInterMediateUserDefFunctionInfo(PStoreInterMediateUserDefFunctionInfo p);
	int AddStoreInterMediateMacroDefInfo(PStoreInterMediateMacroDefInfo p);
	int AddStoreInterMediateVarDefInfo(PStoreInterMediateVarDefInfo p);
	int AddStoreInterMediateBraceInfo(PStoreInterMediateBraceInfo p, int BraceType);
	int AddStoreInterMediateCodeBlockInfo(PStoreInterMediateCodeBlockInfo p);
	int FindStoreInterMediateUserDefTypeInfo(char* TargetTypeName, PStoreInterMediateUserDefTypeInfo* pReturn);
	int FindStoreInterMediateUserDefFunctionInfo(char* TargetFunctionName, PStoreInterMediateUserDefFunctionInfo* pReturn);
	int FindStoreInterMediateMacroDefInfo(char* TargetMacroName, PStoreInterMediateMacroDefInfo* pReturn);
	int FindStoreInterMediateVarDefInfo(char* TargetVarName, PStoreInterMediateVarDefInfo* pReturn);
	int FindStoreInterMediateElement(char* TargetName, void** pPointer);
	int FindStoreInterMediateUserDefTypeContenTypeInfo(char* Target, PStoreInterMediateUserDefTypeContenTypeInfo* pReturn);
	int GetStoreInterMediateCodeBlockInfoLastUnMatchedElement(PStoreInterMediateCodeBlockInfo* p);
};

typedef struct _StoreCPlusPlusLanguageCharacter
{
	bool bHaveNameSpace;
	bool bUseNameSpace;
	PStoreNameSpaceInfo pStoreNameSpaceInfo[5];
	PStoreUseNameSpaceInfo pStoreUseNameSpaceInfo;
	int UseNameSpaceInfoNum;
	int NameSpaceNum;
	int WriteNameSpaceNo;
	int ReadNameSpaceNo;
}StoreCPlusPlusLanguageCharacter, * PStoreCPlusPlusLanguageCharacter;

typedef struct _StoreLanguageCharacterInfo
{
	LanguageType FileLanguageType;
	PStoreCPlusPlusLanguageCharacter pStoreCPlusPlusLanguageCharater;
}StoreLanguageCharacterInfo, * PStoreLanguageCharacterInfo;

typedef struct _SourceCodeFile
{
	char FilePath[200];
	char buff[1024 * 50];
	LanguageType FileLanguageType;
	CodeFileType FileType;
	PStoreLanguageCharacterInfo pStoreLanguageCharacterInfo;
	int MacroNum;
	//char* Macro[20];
	PMacro Macro[20];
	int UnknownNum;
	char* Unknown[20];
	int VariableNum;
	PVariable Variable[50];
	int FunctionNum;
	PSourceFunction Function[15];
	int SourceCodeLineNum;
	PSourceLine SourceCodeLine[20];
	int UserDefStructNum;
	PUserDefStruct UserDefStruct[10];
	int WriteUserDefStructNo;
	int ReadUserDefStructNo;
	int WriteFunctionNo;
	int ReadFunctionNo;
	int WriteVariableNo;
	int ReadVariableNo;
	int WriteMacroNo;
	int ReadMacroNo;
	int WriteSourceCodeLineNo;
	int ReadSourceCodeLineNo;
	int WriteUnknownNo;
	int ReadUnknownNo;
}SourceCodeFile, * PSourceCodeFile;

typedef struct _StoreVecInfo StoreVecInfo, * PStoreVecInfo;
struct _StoreVecInfo
{
	char String[100];                  //向量对应的字符串
	double VecValue;                   //Vec向量值
	int VecIntValue;
	int VecNo;                         //Vec编号
	char VecValueStr[20];              //向量值的字符串形式
	PStoreVecInfo pNext;
	PStoreVecInfo pForward;
};

typedef struct _StoreVecTableInfo
{
	int VecNum;
	PStoreVecInfo VecTableFristNode;
}StoreVecTableInfo, * PStoreVecTableInfo;

namespace func
{
	extern PInterMediateArray pInterMediateArray;

	extern PSourceCodeFile pSourceCodeFile;

	extern PStoreVecTableInfo pStoreVecTable;

	extern void** pSourceCode;

	extern int AnalysisCodeLineNo;

	extern char OutputFilePath[100];

	extern char OutputFilePath2[100];

	extern char OutputFilePath3[100];

	extern char OutputFilePath4[100];

	extern char OutputFilePath5[100];

	extern char OutputFilePath6[100];

	extern char OutputFilePath7[100];

	extern char OutputFilePath8[100];

	extern char OutputFilePath9[100];

	extern char OutputFilePath10[100];

	extern char OutputFilePath11[100];

	extern char OutputFilePath12[100];

	extern char OutputFilePath13[100];

	extern char OutputFilePath14[100];

	extern char OutputFilePath15[100];

	extern char OutputFilePath16[100];

	extern char OutputFilePath17[100];

	extern int OutputPicNum;

	extern int OutputPicNum2;

	extern char OutputPicNumConfigFilePath[100];

	extern char OutputPicNumConfigFilePath2[100];

	extern int OutputFuncToFileNo;

	extern int OutputFuncCodeSliceToFileNo;

	extern int Mod;

	extern char OutputFilePath18[100];

	int Init(int InterMediateNum);

	int InitSourceCodeFile(PSourceCodeFile);

	int collectCode(void* fileBytes, void* collectResultBytes);

	int TranslatCode();

	int ReadIntermediate(const char* FilePath);

	template <typename type>
	void display(type Bytes, int BytesLength, int mod);

	void InitInterMediate(PInterMediateArray, int);

	int ReadOneSourceFile(const char* FilePath);

	int PatternMatch(int mode, char* MatchChar);

	CodeLineType GetCodeLineType(char* CodeLine);

	int CodeProprecess(void** Code);

	int Translate(void** Code, int* index);

	int IntToStr(int n, char* str);

	int TranslateSubCode(void** Code, int* index, char* SubCode, char*** pPar, int ParNum);

	int VariableProcess();

	int FunctionProcess();

	int CheckFunctionOrVariable(void** Code, int* index, bool bBrace, int* LBraceNum, int* RBraceNum);

	int CheckReturnType(void** Code, int* index, ReturnType* returnType, PUserDefStruct* returnUserDefStructType);

	int CheckProfixType(void** Code, int* index, ProfixType* profixType);

	int DivisionCodeByBlank(void** Code, int* index, void* SubCode);

	int DivisionCodeByBlankF(void** Code, int* index, void* SubCode);

	int CheckCodeBlank(void** Code, int* index);

	int MoveCodeIndexUntillNoBlank(void** Code, int* index);

	int CodeTransposition(void** Code, int num);

	int CkeckNameF(void** Code, int* index, int* indexNum, void** Name, int* NameNum);

	int CkeckNameB(void** Code, int* index, int* indexNum, void** Name, int* NameNum);

	int DivisionCodeByLineFeed(void** Code, int* index, void* SubCode);

	int CheckVariableOrFunctionAndDeclareOrDefOrCall(void** Code, int* index, bool bSyntax, void* SubCode, ProfixType* profixType, ReturnType* returnType, int* indexArray, void** Name, int* NameNum, int* FunctionCallIndex, int* FunctionCallNum, int* NameIndex, int* NameNumFull);

	Sign CheckCodeSign(void** Code, int index);

	int CheckSyntaxKey(void** Code, int* index, SyntaxKey* syntaxKey1, SyntaxKey* syntaxKey2);

	int CheckAssigningOperator(void** Code, int start, int end, int* index);

	int CheckLincCodeAssigningOperator(void** Code, int* index);

	int GetCodeLength(void** Code);

	int CheckByte(void** Code, int* index, int CodeLen, BYTE target);

	int CheckAscii(void** Code, int CodeLen, char* target);

	int CheckFunctionCall(void** Code, int start, int end, int* index);

	int CheckName(void** Code, int start, int end, int* index);

	int CheckLineFunctionCall(void** Code, int* index);

	int CheckLineName(void** Code, int* index);

	int CodeAnalyzeDebugPrint(void** Code, int* index);

	int CheckNamableCharacter(char* target);

	int CheckNameble(char** Name, int* NameNum, int start, int end, int* ErrorIndex);

	int AdjustName(char** Name, int* NameNum, int start, int end);

	int CheckBlank(char* target);

	int FindCodeElementsNo(char* target, char* token, char*** pPar, int ParNum);

	int GetBrace(void** Code, int* index, int** RNO, int** LNO, int* RBraceNum, int* LBraceNum);

	int GetBracketContent(void** Code, int* index, int* start, int* end);

	int GetSubCode(void** Code, int start, int end, void** SubCode);

	int CheckBrace(void** Code, int* index);

	int GetLineFeedNum(void** Code, int start, int end);

	int CheckElement(void** Code, int* index, char* Name, bool* bPar, char* pPar, bool* bPro, char* pPro, char* token, char*** pParArray, int ParNum);

	int AnalysisFile(void** Code, int* index, PSourceCodeFile pFile);

	int AnalysisFunction(void** Code, int* index, PSourceFunction pFunction);

	int AnalysisCodeLine(void** Code, int* index, PSourceLine pCodeLine, bool bFunction, PSourceFunction pFunction, int MasterType, int MasterLineNo, int** ControlDependenceArray, int* ControlDependenceNum, int* ControlDependenceArrayLBraceArray, int** ControlDependenceType);

	int AnalysisSyntaxCodeLine(void** Code, int* index, PSyntaxCodeLine pSyntaxCodeLine);

	int AnalysisUnSyntaxSourceLine(void** Code, int* index, PUnSyntaxSourceLine pUnSyntaxSourceLine);

	int CheckCodeLineType(void** Code, bool bSyntax, int CodeLength);

	int GetName(void** Code, int* index, int start, int end, char** Name, int* NameNum, char** Array, int* ArrayNum, int* ArrayIndex);

	int GetSubCodeName(void** Code, int* index, char** Name, int* NameNum, char** Array, int* ArrayNum, int* ArrayIndex);

	bool CheckVarDefen(void** Code, int CodeLength);

	int DivisionCode(void** Code, int* index, PSubCode pSubCode, int* SubCodeNum);

	int InitSubCodeArray(PSubCode subCode);

	int AnalysisCode(void** Code, int* index, PSubCode pSubCode);

	int ProcessSubCodeBrackets(PSubCode pSubCode);

	int GetBracketIndex(void** Code, int* index, int** BracketIndex, int* BracketNum);

	int GetVariableName(void** Code, int* index, char* Name, char* type, char* Array);

	int FindDefindedValue(char* Name, PVariable* pVar, bool bInFunc, PSourceFunction pFunc, bool bInCodeLine, PSourceLine pSourceLine);

	int GetFunctionNameAndPara(void** Code, int* index, bool bFuncCall, char* Name, PVariable* pVar, int* VarNum, char* Profix);

	int MoveBeforeUntilNoBlank(void** Code);

	int GetCFG(PSourceFunction pFunction, void** Code);

	int InitCodeBlock(PCodeBlock* pCodeBlock);

	int DivisionCodeBlock(void** Code, int* index, int* endindex, int CodeBlockType, PCodeBlock pCodeBlock);

	int ProcessIfBranch(void** Code, int* index, int* endindex, int CodeBockType, PCodeBlock pCodeBlock);

	int ProcessSwitchBrach(void** Code, int* index, int* endindex, int CodeBockType, PCodeBlock pCodeBlock);

	bool CheckReturnCodeLine(char** Code);

	int CheckVarDefByOtherVarStatus(char** Code, PVariable pVar, PSourceFunction pFunc);

	int CheckVarExist(char* pVar, PSourceFunction pFunc, PVariable* pReturn);

	int CheckMacroExist(char* pMacro, PSourceFunction pFunc, PMacro* pReturn);

	int CheckFuncExist(char* pFunc, PSourceFunction* pReturn);

	int CheckVarValueChange(char* Code, PVariable pVar, PSourceFunction pFunc);

	int CheckVarValueChangeByFunctionCallReturn(char* Code, PVariable pVar, PSourceFunction pFunc);

	int CheckVarValueChangeByOtherVar(char* Code, PVariable pVar, PSourceFunction pFunc);

	int GetVarDefByOtherVarAndOtherMacroAndItsDefInfo(PVariable target, PVariable* pVarArray, PCodeExePathBlock pCodeBlock);

	int GetVarChangeByOtherVar(PVariable target, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeBlock);

	int GetVarChangeOtherVar(PVariable target, PSourceFunction pFunc, int* ArrayLenth, PVariable* pVarArray, int* CodeLineNoArray, int CodeLineNoStart, int CodeLineNoStop);

	int GetForwardOrBackAPI(char* target, int* ParNum, char** pPar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PStoreSensitiveAPIInfo pSSAPIInfo, int AlgorithmType);

	int GetForwardAPI(char* target, int* ParNum, char** pPar, PInterMediateFunctionInfo pFuncInfo, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PStoreSensitiveAPIInfo pSSAPIInfo);

	int GetBackAPI(char* target, int* ParNum, char** pPar, PInterMediateFunctionInfo pFuncInfo, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreSensitiveAPIInfo pSSAPIInfo);

	int GetVarChangeVarAndFunctionCallPathDefInfo(PVariable pVar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PCodeExePathBlock pCodeBlock, bool bIsPar);

	int GetForwardAPIOnePar(char* target, PInterMediateParInfo pPar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PCodeExePathBlock pCodeExeBlock, bool bIsPar);

	int GetBackAPIOnePar(char* target, PInterMediateParInfo pPar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeExeBlock, bool bIsPar);

	int CheckFunctionInOneTypeInterMediate(char* target, int Type, PInterMediateFunctionInfo* pReturn);

	int CheckCodeLineHaveFunctionCallAndMarkInParAndMarkInFunctionInfo(void** Code, PSourceFunction pFunc);

	int GetFunctionCallParName(void** Code, int* indexStart, int* indexStop, char** ParName, int* ParNum);

	int CheckParNameIsDefParAndAddInfo(PSourceFunction pFunc, char** ParName, int* ParNum, char* FunctionName);

	int GetNameFromLastNamePos(void** Code, int index, char* pReturn);

	int ReverseString(char* pStr);

	int GetFunctionStructAndParStruct(char* pFunctionName, int* ParNum, int* ParNo, PSourceFunction pFuncReturn, PVariable* pParReturn);

	int GetFunctionParStruct(PSourceFunction pFunc, int ParNo, PVariable pVarReturn);

	int GetVarSpreadPath(PVariable pVar, int indexStart, int indexStop, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PCodeExePathBlock pCodeBlock);

	int GetFunctionCallParSpreadPath(char* pFunctionName, int* ParNum, int* ParNo, int FunctionCallNum, int VarChangeNum, int* RealFunctionCallNum, int* RealVarChangeNum, int* CodeLineNo, PStoreVarDefInfo* pReturnVar, PStoreFunctionDefInfo* pReturnFunc, PCodeExePathBlock pCodeBlock);

	int GetVarChangeOtherVarPath();

	int GetVarAsFunctionCallPath();

	//int CheckCodeLineHaveImportAPI(PSourceLine pSourceLine, PSourceFunction pFunc, int PathTraceDeepth, int FunctionCallNum, int VarChangeNum);
	int CheckCodeLineHaveImportAPI(PStoreSensitiveAPIInfo pStoreSSAPIInfo, int AlgorithmType);

	int ProcessPath(PCodeExePathBlock pCodePath);

	int ProcessOneFuncPath(PCodeExePathBlock pCodePath);

	int InitCodeExePathBlock(PStoreSensitiveAPIInfo pSSAPIInfo, PSourceFunction pFunc, PCodeExePathBlock* pReturnCodeBlock, int PathTraceDeepth, int VarDefByOtherVarNum, int VarChangeNum, int FunctionCallNum, int MacroChangeNum, int VarDefByOtherMacroNum, int ParNo, bool IsPar);

	int AddFunctionInfoAtLastFuntionInfoChain(PSourceFunction pFunc, PFunctionInfo pFuncInfo, int ChainType);

	int CheckFuncNameIsDefFuncAndAddInfo(PSourceFunction pFunc, char* FunctionName, char** ParName, int* ParNum);

	int FuntionInfoAddCalledFunc(PSourceFunction pFunc, PSourceFunction pCallFunc, PParInfo pPar, int ParNum);

	int CheckVarIsFunctionPar(PSourceFunction pFunc, PVariable pTargetVar);

	int CheckVarAndDefVarOtherVarIsFunctionPar(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, bool bIsPar);

	int GetOneVarChangePathInFunc(PParInfo pPar, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeBlock, bool bIsPar);

	//����������������������еĺ����������ϵݹ��ȡ������������·��
	int GetFunctionCallForwardParPath(PSourceFunction pFunc, PVariable* pVarArray, int* ParNo, int ParNum, PCodeExePathBlock pCodeBlock, bool bIsPar);

	int CheckAllCodeLineToGenerateCodeSlice(int PathTraceDeepth, int VarChangeNum, int FunctionCallNum, int VarDefByOtherVarNum, int MacroChangeNum, int VarDefByOtherMacroNum, int AlgorithmType);

	int BaseCodeExePathGenerateCodeSlice(PStoreSensitiveAPIInfo pStoreSSAPIInfo);

	int RemoveStringFrontBlank(char* target);

	int StrToInt(char* target);

	int GetFunctionCallReturnVarInOneCodeLine(void** Code, PSourceFunction pFunc, int* ReturnVarNum, PVariable* pReturnVar);

	int GetStrFirstCharIndex(char* str, char* target);

	int GetCodeLineStruct(int GlobalCodeLineNo, PSourceLine* pSourceLineReturn, PSourceFunction* pFunctionReturn);

	int GetForwardAPICodeSlice(int* CodeLineNoArray, int* ArrayLength);

	int GetBackAPICodeSlice(int* CodeLineNoArray, int* ArrayLength);

	int AdjustCodeLineNoOrder(int* CodeLineNoArray, int* ArrayLength);

	int AdjustIntOrderSTL(int* IntArray, int* ArrayLength);

	int RemoveRepeateIntInIntArray(int* IntArray, int* ArrayLength);

	int RemoveIntArrayMemberFromStartToStop(int* IntArray, int* ArrayLength, int StartIndex, int StopIndex);

	int CheckTypedefType(void** Code, int* index, TypedefType* pReturn);

	int AddTypeDefStruct(void** Code, int* index);

	int GetUserDefStructAnotherName(void** Code, int* index, PUserDefStruct pUserDefStruct);

	int CheckCodeLineHaveBrace(void** Code, int* index, int* LBraceNum, int* RBraceNum);

	int AddPointerTypeVarInfo(void** Code, int* index, PVariable pVar, PSourceFunction pFunc);

	OperatorType CheckOperatorType(char* target);

	int GetReturnTypeSize(ReturnType target);

	int CalculateIntExpression(void** Code, int* index, PSourceFunction pFunc);

	int AddVarStructSyntaxKeyInfo(PVariable pVar, PSourceLine pSourceLine);

	int GetBackAPIInTypeOnePar(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, bool bIsPar, int CodeLineNo);

	int GetBackAPIOUTTypeOnePar(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, bool bIsPar, int CodeLineNo);

	int GetBackAPIINAndOUTTypeOnePar(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, bool bIsPar, int CodeLineNo);

	int GetVarChangeByOtherVarOrFunctionCallNew(PVariable pTargetVar, int* ReturnVarNum, PStoreVarDefInfo* pReturnVar, int* ReturnFunctionNum, PStoreFunctionDefInfo* pReturnFuncion, PStoreFunctionDefInfo* pReturnFunctionArray, int* ReturnFunctionArrayLength, int* ReturnMacroNum, PStoreMacroDefInfo* pReturnMacro, int CodeLineNo);

	int GetStoreFunctionDefInfoChainFrontNode(PStoreFunctionDefInfo Target, PStoreFunctionDefInfo Start, PStoreFunctionDefInfo* Return);

	int GetStoreVarDefInfoChainFrontNode(PStoreVarDefInfo Target, PStoreVarDefInfo Start, PStoreVarDefInfo* Return);

	int GetVarInSyntaxBlockInfo(PVariable pTarget, int CodeLineNo, PStoreSyntaxKeyInfo* pReturn, int* ReturnCodeLineNum);

	int GetStoreSyntaxKeyInfoChainFrontNode(PStoreSyntaxKeyInfo Target, PStoreSyntaxKeyInfo Start, PStoreSyntaxKeyInfo* pReturn);

	int GetCodeLineInSyntaxBlockInfo(PSourceLine pTarget, PSourceLine* pReturn, int* ReturnCodeLineNum);

	int GetVarValueSpreadChainFinalNode(PVariable pTarget, int CodeLineNo, PSourceLine* pReturn, int* ReturnCodeLineNum);

	int GetBackAPIOneParNew(char* target, PInterMediateParInfo pPar, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeExeBlock, bool bIsPar);

	int GetBackAPINew(char* target, int* ParNum, char** pPar, PInterMediateFunctionInfo pFuncInfo, int* ArrayLenth, PVariable* pVarArray, int CodeLineNo, PStoreSensitiveAPIInfo pSSAPIInfo);

	int RemoveStringEndBlank(char* target);

	int ProcessExpression(char* target);

	int GetStoreMacroDefInfoChainFrontNode(PStoreMacroDefInfo Target, PStoreMacroDefInfo Start, PStoreMacroDefInfo* Return);

	int GetVarChangeByOtherMacro(PVariable target, PMacro* pMacroArray, PVariable* pVarArray, int CodeLineNo, PCodeExePathBlock pCodeBlock);

	int ProcessVar(void** Code, int* index, PStoreVarNameInfo* ReturnNameArray, int* ReturnNameArrayLength);

	int ProcessCodeLineInSyntaxBlockInfo(PSourceLine* TargetSourceLineArray, int* SourceLineArrayLength);

	int EncounterSyntaxKsyAddSyntaxChainInfo(PSourceLine TargetCodeLine, PSourceFunction pFunc);

	int AddNewSyntaxKeyCodeLineInSyntaxKeyChainEveryNode(int* SyntaxKeyChainArray, int SyntaxKeyChainArrayLength, int AddCodeLineNo, PSourceFunction pFunc);

	int RemoveUnSyntaxKeyCodeLineInSyntaxBlockInfo(PSourceLine* TargetSourceLineArray, int* SourceLineArrayLength);

	int GetWholeSyntaxChain(PSourceLine* TargetSourceLineArray, int* SourceLineArrayLength);

	int AddUserDefVarTypeInfoInCodeExePathBlock(PVariable pVar, PCodeExePathBlock pCodeExeBlock);

	int GetInCodeVarOrMacroDefCodeLineStruct(void** Code, int* index, PSourceFunction pFunc, PSourceLine* pReturnSourceLineArray, int* ReturnSourceLineArrayLength);

	int GetSyntaxKeyConditionContentVarOrMacroDefInfo(PSourceLine* pSourceLineArray, int* SourceLineArrayLength);

	int IntToStrNew(long target, char* StrReturn);

	int AddTypedefUnion(void** Code, int* index);

	int GetUserDefUnionName(void** Code, int* index, PUserDefStruct pUserDefStruct);

	int CheckSourceFileType(const char* FilePath, LanguageType* pReturnLanguageType);

	int InitSourceFileLanguageCharacterInfo(PSourceCodeFile pSourceCodeFile, LanguageType SourceFileLanguageType);

	int InitVariable(PVariable pVar);

	int InitSourceCodeLine(PSourceLine pSourceLine);

	int InitSourceFunction(PSourceFunction pSourceFunction);

	int InitStoreNameSpaceInfo(PStoreNameSpaceInfo pStoreNameSpaceInfo);

	int InitStoreCPlusPlusLanguageCharacter(PStoreCPlusPlusLanguageCharacter pStoreCPlusPlusLanguageCharacter);

	int InitUnSyntaxSourceLine(PUnSyntaxSourceLine pUnSyntaxSourceLine);

	int InitSyntaxCodeLine(PSyntaxCodeLine pSyntaxCodeLine);

	int InitStoreUseNameSpaceInfo(PStoreUseNameSpaceInfo pStoreUseNameSpaceInfo);

	int AddNodeInStoreUseNameSpaceInfoChain(PStoreCPlusPlusLanguageCharacter pStoreCPlusPlusLanguageCharacter, PStoreUseNameSpaceInfo target);

	int AddNameSpaceDefInfo(void** Code, int* index);

	int AddUseNameSpaceInfo(void** Code, int* index);

	int CheckNameSpaceExist(char* target, PStoreNameSpaceInfo* pReturnStoreNameSpaceInfo);

	int GetOneCodeLineInCodeBlockInfo(int TargetCodeLineNo, int* ReturnCodeLineNoArray, int* ReturnCodeLineNoArrayLength);

	int GetCodeLineArrayInCodeBlockInfo(int* TargetCodeLineNoArray, int* TargetCodeLineNoArrayLength);

	int CheckStrHaveGoodOrBad(char* Target);

	int TranslateCodeSlice(void** Code, int* index, void** OutPut, int* OutPutindex);

	int CheckCodeBlockType(void** Code, int* index, CodeBlockType* pReturn);

	int InitStoreArrayIndexInfo(PStoreArrayIndexInfo pStoreArrayIndexInfo);

	int ProcessCodeSliceMacroDef(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceStructDef(InterMediateNew* pInterMediateNew);

	int LIKED();

	int InitStoreInterMediateVarDefInfo(PStoreInterMediateVarDefInfo p);

	int InitStoreInterMediateMacroDefInfo(PStoreInterMediateMacroDefInfo p);

	int InitStoreInterMediateUserDefFunctionInfo(PStoreInterMediateUserDefFunctionInfo);

	int InitStoreInterMediateUserDefTypeContenTypeInfo(PStoreInterMediateUserDefTypeContenTypeInfo);

	int InitStoreInterMediateUserDefTypeInfo(PStoreInterMediateUserDefTypeInfo);

	int InitStoreInterMediateBraceInfo(PStoreInterMediateBraceInfo);

	int InitStoreInterMediateCodeBlockInfo(PStoreInterMediateCodeBlockInfo);

	int AddStoreInterMediateUserDefTypeContentInfo(PStoreInterMediateUserDefTypeInfo pParent, PStoreInterMediateUserDefTypeContenTypeInfo p);

	int ProcessCodeSliceUnionDef(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceTypedefStructDef(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceTypedefUnionDef(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceCodeBlockTypeLBraceType(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceCodeBlockTypeRBraceType(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceVarDeclareType(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceVarAssignmentType(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceVarDefType(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceCodeBlockTypeOnlyFunctionCallType(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceSyntaxKeyCodeLineType(InterMediateNew* pInterMediateNew);

	int ProcessCodeSliceCodeBlockTypeFunctionDeclare(InterMediateNew* pInterMediateNew);

	int CheckFuntionInInterMediateAndReturnToken(char* target, PInterMediateFunctionInfo* pReturn, char** pReturnToken);

	int LOVE();

	int InitStoreAsArrayIndexInfo(PStoreAsArrayIndexInfo p);

	int AddStoreAsArrayIndexInfo(PVariable pVar, PStoreAsArrayIndexInfo p);

	int CheckArrayIndexIsVarAndAddInfo(char* Code, int* index, PVariable pVar, PSourceFunction pFunc);

	int GetNameableSubCodeInCode(char* TargetCode, int* index, char* NameableSubCode, char* UnNameableChar);

	int ArrayVulnerabilityModule(void** Code, int* index);

	int CheckCodeLineHaveArrayUse(PStoreSensitiveAPIInfo pStoreSSAPIInfo, int AlgorithmType);

	int CheckCodeLineArrayUse(char* Code, int* ArrayNameIndex, int* ArrayIndexNameIndex);

	int GetVarAsArrayIndexUseInfo(PVariable pVar, PCodeExePathBlock pCodeExePathBlock, int CodeLineNo);

	int InitStoreVecTableInfo(PStoreVecTableInfo pStoreVecTable);

	int InitStoreVecInfo(PStoreVecInfo pStoreVec);

	int AddStoreVecInfoToChain(PStoreVecTableInfo pVecTable, PStoreVecInfo pVec);

	int ReadVecTable(const char* VecTableFilePath, const char* VecValueTableFilePath);

	int StrToDouble(const char* Str, double* pReturn);

	int DoubleToStr(double target, char* pReturn);

	int TranslateIntermediateToVec(void** Code, int* index, void** OutPut, int* OutPutindex);

	int FindVecTableElement(const char* pInputStr, char* pOutputStr, double* pOutputValue, int* pOutputIntValue);

	int InitDataDependenceStruct(PDataDependence p);

	int InitControlDependenceStruct(PControlDependence p);

	int AddDataDependenceStruct(PSourceLine pCodeLine, PDataDependence pData);

	int AddControlDependenceStruct(PSourceLine pCodeLine, PControlDependence pControl);

	int CheckDataDependence(void** Code, PSourceLine pCodeLine, PSourceFunction pFunc);

	int CheckCodeLineExist(int CodeLineGlobalLineNo, PSourceFunction pFunc, PSourceLine* pCodeLine);

	int CheckControlDependence(void** Code, PSourceLine pCodeLine, PSourceFunction pFunc, int** ControlDependenceArray, int* ControlDependenceNum, int* ControlDependenceArrayLBraceArray, int** ControlDependenceType);

	int GetCodeSliceDataDependence(int* CodeSliceArray, int CodeSliceArrayLength, int** ReturnDataDependence);

	int GetCodeSliceControlDependence(int* CodeSliceArray, int CodeSliceArrayLength, int** ReturnControlDependence);

	int CheckCodeLineHaveUserDefFunctionCall(void** Code, PSourceLine pCodeLine, PSourceFunction pFunc);

	int TransformIntMatrix2Str(int** Matrix, int RealWidth, int RealHeight, int Width, int Height, char* Pad, char** ReturnBuffer);

	int GenerateBMP(char* FileName, uint32_t Width, uint32_t Height, int** CodeMatrix, int** DataDependenceMatrix, int** ControlDependenceMatrix);

	int MatrixStr2Int(char** Matrix, int** ReturnMatrix, int Width, int Height);

	int GetBMP(char** CodeMatrix, int** DataDependenceMatrix, int** ControlDependenceMatrix, bool bSafe, const char* StroeFilePath, char* FileName, char* FunctionName, int width, int height, int mod);

	int ReadOutputPicNumConfigFile(const char* FilePath, const char* FilePath2);

	int WriteOutputPicNumConfigFile(const char* FilePath, const char* FilePath2);

	int OutputAllSourceFileIntermediate();

	int OutputFullFunctionIntermediate(int* CodeLineArray, int CodeLineArrayLength, bool bSafe);

	int CheckReturnTypeIsPointerType(PVariable pVar);

	int CheckLoopBranchHaveArrayAssignment(PStoreSensitiveAPIInfo pStoreSSAPIInfo);

	int GetLoopBranchStartAndStopCodeLineNoAndIsHaveArrayAssignment(int LoopBranchCodeLineNo, int* StartCodeLineNo, int* StopCodeLineNo, PSourceLine* AssignmentCodeLine);

	int CheckCodeLineHaveArrayAssignment(PSourceLine pCodeLine);

	int GetVarChangeInRangeCodeLineNo(PSourceFunction pFunc, PVariable pVar, PVariable* pVarArray, PCodeExePathBlock pCodeBlock, int StartCodeLineNo, int StopCodeLineNo);

	int GetArrayAssignmentCodeLineArrayVar(PSourceLine pCodeLine, PSourceFunction pFunc, PVariable* pValueChangeVar, PVariable* pChangeValueVar, PVariable* pValueChangeArrayIndexVar, PVariable* pChangeValueArrayIndexVar);

	int GetVarBeforeCodeLineNoChangeValueInfoAndAsFunctionParInfo(PVariable pVar, int CodeLineNo, int* pCodeLineArray, int* CodeLineArrayLength);

	int DeleteStrArrayRepetStr(char** StrArray, int* StrArrayLength);

	int CheckVarDefCodeLineValueAssignmentVarOrMacroDefInfo(PSourceLine pCodeLine, PSourceFunction pFunc, int* pReturnCodeLineArray, int* ReturnCodeLineArrayLength);

	int CheckCodeLineHaveMemoryAlloc(void** Code, PSourceLine pCode, PSourceFunction pFunc);

	int GetVarAllocInfo(PVariable pVar, PCodeExePathBlock pCodeBlock);

	int GetArrayAssignmentValueChangeArrayVarInfo(PVariable pVar, PCodeExePathBlock pCodeBlock);

	int GetPVarPointMemoryInfo(PVariable pVar, PCodeExePathBlock pCodeBlock);

	int DisplayInterMediateArray();

	int OutputFullFunctionIntermediateNew(int* CodeLineArray, int CodeLineArrayLength, bool bSafe);

	int GetVarMemoryAllocInfo(PVariable pVar, int* pReturn, int* ReturnLength);

	int CheckCodeLineMasterTypeIsTargetSyntaxType(int CodeLineNo, SyntaxKey* target, int SyntaxKeyLength);

	int GetCodeLineCodeBlockInfoIsTargetSyntaxType(int CodeLineNo, SyntaxKey* target, int SyntaxKeyLength, int* ReturnCodeLineArray, int* ReturnCodeLineArrayLength);

	int AddVarAsArrayIndexInfo(void** Code, int* index, PSourceFunction pFunc);

	int ExtractVarAsPrintFuncParInfo(PVariable pVar, PCodeExePathBlock pBlock, int CodeLineNo);

	int ExtractStrchrFuncInfo(PStoreFunctionDefInfo StoreFuncDefInfo, PCodeExePathBlock pBlock);

	int ExtractVarAsFprintfFuncParInfo(PVariable pVar, PCodeExePathBlock pBlock, int CodeLineNo);

	int HandleReturnCodeLineArrayForCWE194(PSourceLine* CodeLineArray, int* CodeLineArrayLength);

	int GetFunctionStruct(int FunctionNo, PSourceFunction* pReturn);

	int HandleCodeSliceForCWE134(PVariable pVar, int CodeLineNo, PCodeExePathBlock pBlock);

	int ExtractVfprintfFuncInfo(PStoreFunctionDefInfo StoreFuncDefInfo, PCodeExePathBlock pBlock);

	int CheckCodeBracketIsCompletion(void** Code, int* index, int* end);

	int CheckCodeBlankNew(void** Code, int* index, char* ReturnSubCode);

	int HandleUnprocessableFunc(void** Code, int* index);

	int HandleNoCodeExtractFuncNotVuln(char* FilePath);

	int HandleNoCodeExtractFuncVuln(char* FilePath);

	int HandleCodeExtractFuncNotVuln(char* FilePath);

	int HandleCodeRxtractFuncVuln(char* FilePath);

	int HandleFileNumFunc(const char* path, const char* path2);

	int GetCurrentFileNo();

	int GetFileHaveLineFeedNum(char** Code);

	int OutputFuncToFile(int FuncNo, bool bSafe);

	int WriteOutputFuncNumConfigFile(const char* FilePath);

	int ReadOutputFuncNumConfigFile(const char* FilePath);

	int OutPutFileAllFunction();

	int CheckFunctionNameIsTargetNameArray(char* FuncName, char** TargetNameArray, int NameArrayLength);

	int GetTimeOnWindowsPlatform(double* second, double* msecond, double* min);

	int GetTimeOnWindowsPlatformNew(long* pReturn);

	int GetNSecondTime(int* pReturn);

	int64_t GetSysTimeMicros();

	int GetFileName(char* FilePath, char* ReturnFileName);

	int OutputNotAllIRConvertIntermediate(int* CodeLineArray, int CodeLineArrayLength, bool bSafe, char* FileName, char* FunctionName);

	int ReverseIntValue(int** IntMatrix, int MatrixSize);

	int OutputFuncCodeSliceToFile(int* CodeLineArray, int CodeLineArrayLength, bool bSafe);
}