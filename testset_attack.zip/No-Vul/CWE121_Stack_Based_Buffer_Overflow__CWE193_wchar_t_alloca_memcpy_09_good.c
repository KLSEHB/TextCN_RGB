void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_memcpy_09_good ( ) {    var_xxamsm = 0;
 goodG2B1 ( ) ; var_amauzr ( ) ; }