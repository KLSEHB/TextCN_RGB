void CWE114_Process_Control__w32_char_console_54b_goodG2B_sink ( char * data ) {    ;
 CWE114_Process_Control__w32_char_console_54c_goodG2B_sink ( data ) ; }