void var_xgcair ( ) {    var_ucevzo = 0;
 var_lwohiw ( ) ; }