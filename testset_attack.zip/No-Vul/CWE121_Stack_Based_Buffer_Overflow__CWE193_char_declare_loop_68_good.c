void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_loop_68_good ( ) {    int var_vymgjt = 123; var_vymgjt -= 5;
 var_zapspo ( ) ; }