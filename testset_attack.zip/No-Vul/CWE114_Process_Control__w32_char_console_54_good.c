void CWE114_Process_Control__w32_char_console_54_good ( ) {    ;
 goodG2B ( ) ; }