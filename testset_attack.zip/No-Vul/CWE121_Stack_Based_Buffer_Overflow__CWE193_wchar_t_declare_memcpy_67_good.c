void var_rnrpck ( ) {    int var_nketye = 123; var_nketye -= 5;
 var_rrfypf ( ) ; }