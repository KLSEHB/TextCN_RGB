void CWE114_Process_Control__w32_wchar_t_connect_socket_11_good ( ) {    int var_exwgvn = 0; var_exwgvn += 1;
 var_dpmliy ( ) ; goodG2B2 ( ) ; }