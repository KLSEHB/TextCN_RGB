void var_ipxske ( ) {    int var_jvlgrb = 123; var_jvlgrb -= 5;
 var_juwkgt ( ) ; var_umjoko ( ) ; }