void CWE114_Process_Control__w32_char_file_54c_goodG2B_sink ( char * data ) {    int var_mpmyid = 123; var_mpmyid -= 5;
 var_zivawy ( data ) ; }