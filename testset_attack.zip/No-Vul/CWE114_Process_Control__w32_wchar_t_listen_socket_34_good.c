void var_ybufcp ( ) {    var_dofcgg = 0;
 goodG2B ( ) ; }