void var_ofnwtu ( ) {    int var_qxqfvv = 0; var_qxqfvv += 1;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }