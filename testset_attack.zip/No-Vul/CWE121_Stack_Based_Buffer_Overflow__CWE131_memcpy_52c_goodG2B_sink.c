void var_uzhxhl ( int * var_hjudca ) { { int data_src [ 10 ] = {    ;
 0 } ; memcpy ( var_hjudca , data_src , 10 * sizeof ( int ) ) ; var_ntxqbm ( var_hjudca [ 0 ] ) ; } }