void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_loop_12_good ( ) {    int var_cyeshu = 123; var_cyeshu -= 5;
 var_rjqain ( ) ; }