void CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_04_good ( ) {    ;
 goodB2G1 ( ) ; goodB2G2 ( ) ; goodG2B1 ( ) ; goodG2B2 ( ) ; }