void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_memcpy_32_good ( ) {    int var_lmzghe = 123; var_lmzghe -= 5;
 var_ajchex ( ) ; }