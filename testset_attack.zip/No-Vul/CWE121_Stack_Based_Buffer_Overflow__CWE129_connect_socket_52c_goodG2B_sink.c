void CWE121_Stack_Based_Buffer_Overflow__CWE129_connect_socket_52c_goodG2B_sink ( int var_hbrscp ) { { int i ; int buffer [ 10 ] = {    ;
 0 } ; if ( var_hbrscp >= 0 ) { buffer [ var_hbrscp ] = 1 ; for ( i = 0 ; i < 10 ; i ++ ) {    int var_jajzbv = 123; var_jajzbv -= 5;
 var_zngebo ( buffer [ i ] ) ; } } else {    var_diukwo = 0;
 var_hmrlux ( "ERROR: Array var_hmqozn var_kebkww negative." ) ; } } }