void var_chhgew ( ) {    int var_lyouno = 123; var_lyouno -= 5;
 var_xkahpz ( ) ; }