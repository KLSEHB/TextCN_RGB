void var_siukzw ( ) {    var_jaexli = 0;
 var_jraljx ( ) ; var_mjtxcm ( ) ; }