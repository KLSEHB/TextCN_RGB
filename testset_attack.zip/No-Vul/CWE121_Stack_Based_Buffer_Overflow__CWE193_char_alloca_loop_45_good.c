void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_45_good ( ) {    int var_nmhcjj = 123; var_nmhcjj -= 5;
 var_ovnfhg ( ) ; }