void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_cat_41_good ( ) {    int var_fczkis = 123; var_fczkis -= 5;
 goodG2B ( ) ; }