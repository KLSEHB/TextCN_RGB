void var_tnitan ( ) {    ;
 goodG2B1 ( ) ; var_nejocw ( ) ; }