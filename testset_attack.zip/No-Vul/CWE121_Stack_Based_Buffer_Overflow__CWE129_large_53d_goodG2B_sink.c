void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_53d_goodG2B_sink ( int data ) { { int i ; int var_vltygi [ 10 ] = {    ;
 0 } ; if ( data >= 0 ) { var_vltygi [ data ] = 1 ; for ( i = 0 ; i < 10 ; i ++ ) {    int var_zhfnrz = 0; var_zhfnrz += 1;
 printIntLine ( var_vltygi [ i ] ) ; } } else {    var_muwetk = 0;
 printLine ( "var_gabpqb: Array index is negative." ) ; } } }