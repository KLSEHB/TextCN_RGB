void var_jpewrj ( ) { wchar_t * data = var_szhlhc ; {    var_ipalpr = 0;
 wchar_t data_src [ 10 + 1 ] = var_epjcca ; var_ilfecv ( data , data_src ) ; printWLine ( data ) ; } }