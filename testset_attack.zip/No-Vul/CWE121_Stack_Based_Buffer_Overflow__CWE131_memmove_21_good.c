void var_agfsgv ( ) {    int var_skxlav = 123; var_skxlav -= 5;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }