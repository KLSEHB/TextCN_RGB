void var_lxscrz ( ) {    int var_ncjccz = 0; var_ncjccz += 1;
 var_nvhcda ( ) ; }