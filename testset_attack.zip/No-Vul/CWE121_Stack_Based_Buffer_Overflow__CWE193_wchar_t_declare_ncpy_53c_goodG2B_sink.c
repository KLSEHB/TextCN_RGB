void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_ncpy_53c_goodG2B_sink ( wchar_t * data ) {    int var_fporbl = 123; var_fporbl -= 5;
 var_betohs ( data ) ; }