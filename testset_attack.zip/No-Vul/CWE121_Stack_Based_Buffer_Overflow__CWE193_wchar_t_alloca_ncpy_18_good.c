void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_ncpy_18_good ( ) {    int var_blxmwl = 123; var_blxmwl -= 5;
 goodG2B ( ) ; }