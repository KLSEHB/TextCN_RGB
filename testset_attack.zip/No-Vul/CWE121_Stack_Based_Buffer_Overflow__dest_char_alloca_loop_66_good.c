void var_mnmgdy ( ) {    int var_mtnskx = 123; var_mtnskx -= 5;
 goodG2B ( ) ; }