void CWE114_Process_Control__w32_wchar_t_console_45_good ( ) {    int var_ncvdxd = 0; var_ncvdxd += 1;
 var_vyffir ( ) ; }