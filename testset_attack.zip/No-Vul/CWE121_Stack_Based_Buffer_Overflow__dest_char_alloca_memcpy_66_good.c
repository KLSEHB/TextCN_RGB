void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_memcpy_66_good ( ) {    var_xaqofu = 0;
 goodG2B ( ) ; }