void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_ncpy_09_good ( ) {    int var_etybie = 0; var_etybie += 1;
 goodG2B1 ( ) ; var_pfdqsb ( ) ; }