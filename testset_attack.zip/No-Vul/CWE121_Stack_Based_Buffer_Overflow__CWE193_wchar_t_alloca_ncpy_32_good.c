void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_ncpy_32_good ( ) {    int var_zvrmrd = 0; var_zvrmrd += 1;
 goodG2B ( ) ; }