char * CWE114_Process_Control__w32_char_relativePath_22_goodG2B1_source ( char * var_gmbsyz ) { if ( CWE114_Process_Control__w32_char_relativePath_22_goodG2B1_global ) {    var_pfrbhq = 0;
 var_cdnnxw ( var_gmbsyz , "var_vggfso.dll" ) ; } else {    int var_gpjnpr = 0; var_gpjnpr += 1;
 var_cdnnxw ( var_gmbsyz , "var_hucgfl:\\var_zlgxwd\\var_exgufa\\var_vggfso.dll" ) ; } return var_gmbsyz ; }