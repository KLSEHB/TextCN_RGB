void CWE114_Process_Control__w32_wchar_t_relativePath_31_good ( ) {    ;
 goodG2B ( ) ; }