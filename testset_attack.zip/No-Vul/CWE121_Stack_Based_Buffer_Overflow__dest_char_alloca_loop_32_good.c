void var_yzcntk ( ) {    var_wbxnoj = 0;
 var_mbpons ( ) ; }