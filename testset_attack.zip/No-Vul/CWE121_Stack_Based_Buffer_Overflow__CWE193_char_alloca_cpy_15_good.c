void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_cpy_15_good ( ) {    var_vrqlll = 0;
 goodG2B1 ( ) ; var_zijorm ( ) ; }