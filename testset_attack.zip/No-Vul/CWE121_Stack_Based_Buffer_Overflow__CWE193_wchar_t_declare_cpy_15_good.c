void var_rdfdwr ( ) {    int var_wefzmc = 123; var_wefzmc -= 5;
 var_xawtpl ( ) ; goodG2B2 ( ) ; }