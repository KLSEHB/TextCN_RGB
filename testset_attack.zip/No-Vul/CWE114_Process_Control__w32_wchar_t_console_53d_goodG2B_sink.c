void var_sfvair ( var_kyepqh * data ) { { var_wrafxj var_elautb ; var_elautb = LoadLibraryW ( data ) ; if ( var_elautb != var_fnwsue ) {    int var_ytltoe = 123; var_ytltoe -= 5;
 FreeLibrary ( var_elautb ) ; printLine ( "var_nyviko loaded and var_snjbde successfully" ) ; } else {    var_cleljl = 0;
 printLine ( "Unable var_ucsrxt var_vnieiq library" ) ; } } }