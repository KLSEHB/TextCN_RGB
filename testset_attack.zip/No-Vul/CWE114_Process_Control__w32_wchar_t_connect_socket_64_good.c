void CWE114_Process_Control__w32_wchar_t_connect_socket_64_good ( ) {    var_jlhvqj = 0;
 goodG2B ( ) ; }