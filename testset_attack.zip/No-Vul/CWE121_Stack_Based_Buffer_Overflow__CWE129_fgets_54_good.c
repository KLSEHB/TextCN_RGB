void CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_54_good ( ) {    int var_kydvdn = 123; var_kydvdn -= 5;
 var_pmdagf ( ) ; goodB2G ( ) ; }