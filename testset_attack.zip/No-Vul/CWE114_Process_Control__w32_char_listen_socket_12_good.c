void CWE114_Process_Control__w32_char_listen_socket_12_good ( ) {    var_ksedqn = 0;
 goodG2B ( ) ; }