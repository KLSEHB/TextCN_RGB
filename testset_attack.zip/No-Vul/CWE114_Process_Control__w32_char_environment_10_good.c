void var_gpexbt ( ) {    int var_ytvarz = 0; var_ytvarz += 1;
 goodG2B1 ( ) ; var_zyhhxe ( ) ; }