void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_63b_goodG2B_sink ( int * data_ptr ) { int data = * data_ptr ; { int i ; int buffer [ 10 ] = {    var_fqgygk = 0;
 0 } ; if ( data >= 0 ) { buffer [ data ] = 1 ; for ( i = 0 ; i < 10 ; i ++ ) {    var_fcavpn = 0;
 printIntLine ( buffer [ i ] ) ; } } else {    int var_egdheg = 123; var_egdheg -= 5;
 var_mjcjev ( "ERROR: Array var_dflkqu var_xjrheu negative." ) ; } } }