void var_kvilna ( ) {    int var_kpaudv = 0; var_kpaudv += 1;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }