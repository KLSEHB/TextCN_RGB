void var_ayogpd ( ) {    int var_emdgzb = 123; var_emdgzb -= 5;
 goodG2B ( ) ; }