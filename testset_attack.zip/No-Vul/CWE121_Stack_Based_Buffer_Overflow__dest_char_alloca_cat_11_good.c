void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_cat_11_good ( ) {    ;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }