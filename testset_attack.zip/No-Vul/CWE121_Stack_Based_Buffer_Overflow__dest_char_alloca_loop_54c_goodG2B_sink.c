void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_loop_54c_goodG2B_sink ( char * data ) {    int var_eqtkzt = 0; var_eqtkzt += 1;
 var_jghcxj ( data ) ; }