void CWE114_Process_Control__w32_char_relativePath_21_good ( ) {    int var_ylqmsf = 0; var_ylqmsf += 1;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }