void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_loop_63_good ( ) {    ;
 goodG2B ( ) ; }