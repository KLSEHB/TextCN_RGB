void var_motkjo ( ) {    ;
 var_xvlcdr ( ) ; }