void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_cpy_51_good ( ) {    var_oibeym = 0;
 var_uzhgan ( ) ; }