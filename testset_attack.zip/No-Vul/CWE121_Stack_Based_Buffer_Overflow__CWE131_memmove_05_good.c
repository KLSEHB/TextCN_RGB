void var_nadckh ( ) {    int var_yywypc = 123; var_yywypc -= 5;
 goodG2B1 ( ) ; var_kbmjbd ( ) ; }