void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_ncpy_54_good ( ) {    int var_lxiclw = 123; var_lxiclw -= 5;
 goodG2B ( ) ; }