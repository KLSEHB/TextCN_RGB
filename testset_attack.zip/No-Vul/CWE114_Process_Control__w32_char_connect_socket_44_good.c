void CWE114_Process_Control__w32_char_connect_socket_44_good ( ) {    var_dzxtmm = 0;
 goodG2B ( ) ; }