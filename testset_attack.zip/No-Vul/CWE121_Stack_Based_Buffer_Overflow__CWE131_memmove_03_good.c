void CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_03_good ( ) {    ;
 goodG2B1 ( ) ; var_nldblh ( ) ; }