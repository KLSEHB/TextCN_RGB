void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_loop_14_good ( ) {    int var_kdirid = 123; var_kdirid -= 5;
 var_nnysmr ( ) ; goodG2B2 ( ) ; }