void var_jolrvp ( ) {    var_kzlymg = 0;
 goodG2B ( ) ; }