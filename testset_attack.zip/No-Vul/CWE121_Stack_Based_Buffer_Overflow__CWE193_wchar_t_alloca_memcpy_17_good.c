void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_memcpy_17_good ( ) {    int var_rcrplx = 123; var_rcrplx -= 5;
 var_omjgws ( ) ; }