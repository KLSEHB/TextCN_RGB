void CWE114_Process_Control__w32_char_file_54_good ( ) {    int var_slarfn = 123; var_slarfn -= 5;
 goodG2B ( ) ; }