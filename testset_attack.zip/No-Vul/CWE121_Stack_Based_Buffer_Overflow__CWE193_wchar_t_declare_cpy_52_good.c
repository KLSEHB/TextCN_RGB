void var_cfsajj ( ) {    ;
 var_tqgsyb ( ) ; }