void var_xiisrr ( ) {    int var_fhtnsv = 123; var_fhtnsv -= 5;
 goodG2B ( ) ; }