void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_31_good ( ) {    int var_iigcoc = 123; var_iigcoc -= 5;
 goodG2B ( ) ; }