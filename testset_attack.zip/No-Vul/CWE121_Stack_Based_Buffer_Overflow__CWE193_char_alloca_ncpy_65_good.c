void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_ncpy_65_good ( ) {    var_poronp = 0;
 goodG2B ( ) ; }