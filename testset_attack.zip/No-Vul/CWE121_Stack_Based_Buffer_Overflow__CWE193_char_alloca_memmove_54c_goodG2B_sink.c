void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memmove_54c_goodG2B_sink ( char * data ) {    int var_xiyenc = 123; var_xiyenc -= 5;
 var_fozbnz ( data ) ; }