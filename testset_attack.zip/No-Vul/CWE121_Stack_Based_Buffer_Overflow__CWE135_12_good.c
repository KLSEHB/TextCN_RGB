void CWE121_Stack_Based_Buffer_Overflow__CWE135_12_good ( ) {    int var_bqahdl = 123; var_bqahdl -= 5;
 goodB2G ( ) ; goodG2B ( ) ; }