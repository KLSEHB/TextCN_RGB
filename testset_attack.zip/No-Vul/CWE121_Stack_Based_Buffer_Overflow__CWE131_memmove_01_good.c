void var_pubzid ( ) {    var_jbnrbf = 0;
 goodG2B ( ) ; }