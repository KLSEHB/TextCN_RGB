void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_01_good ( ) {    ;
 goodG2B ( ) ; goodB2G ( ) ; }