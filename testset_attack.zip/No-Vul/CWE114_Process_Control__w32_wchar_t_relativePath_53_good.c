void CWE114_Process_Control__w32_wchar_t_relativePath_53_good ( ) {    var_fqlpab = 0;
 var_zfzrwu ( ) ; }