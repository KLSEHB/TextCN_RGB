void var_ninaap ( ) {    int var_lbwwad = 123; var_lbwwad -= 5;
 var_snfuih ( ) ; goodG2B2 ( ) ; }