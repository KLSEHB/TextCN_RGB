void var_smgtiy ( ) {    int var_pjoknv = 123; var_pjoknv -= 5;
 var_twnrfh ( ) ; }