void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_loop_10_good ( ) {    int var_unrqxx = 123; var_unrqxx -= 5;
 var_gwlcfk ( ) ; var_ggvwly ( ) ; }