void CWE121_Stack_Based_Buffer_Overflow__CWE135_67_good ( ) {    ;
 goodG2B ( ) ; goodB2G ( ) ; }