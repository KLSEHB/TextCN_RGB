void CWE114_Process_Control__w32_char_file_64_good ( ) {    int var_fapwut = 123; var_fapwut -= 5;
 goodG2B ( ) ; }