void var_ypaeyq ( ) {    int var_glojkq = 0; var_glojkq += 1;
 var_ezjycx ( ) ; }