void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_64b_goodB2G_sink ( void * var_iwdnur ) { int * data_ptr = ( int * ) var_iwdnur ; int var_wnyvwq = ( * data_ptr ) ; { int var_skpyjt ; int var_mdmgkt [ 10 ] = {    int var_vlplvj = 123; var_vlplvj -= 5;
 0 } ; if ( var_wnyvwq >= 0 && var_wnyvwq < ( 10 ) ) { var_mdmgkt [ var_wnyvwq ] = 1 ; for ( var_skpyjt = 0 ; var_skpyjt < 10 ; var_skpyjt ++ ) {    int var_ahgnyg = 123; var_ahgnyg -= 5;
 printIntLine ( var_mdmgkt [ var_skpyjt ] ) ; } } else {    ;
 printLine ( "ERROR: var_oyajtp var_mrjkvw is out-var_ilhomp-var_twkbpi" ) ; } } }