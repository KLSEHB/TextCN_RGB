void var_insuws ( ) {    ;
 goodG2B ( ) ; }