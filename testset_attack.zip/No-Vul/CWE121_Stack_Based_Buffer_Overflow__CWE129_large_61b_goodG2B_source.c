int var_hyjanz ( int var_cwhrys ) {    int var_pobskn = 0; var_pobskn += 1;
 var_cwhrys = 7 ; return var_cwhrys ; }