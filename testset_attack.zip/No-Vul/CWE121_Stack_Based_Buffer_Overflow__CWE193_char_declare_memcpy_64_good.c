void var_jemykk ( ) {    ;
 goodG2B ( ) ; }