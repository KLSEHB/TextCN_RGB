void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_06_good ( ) {    int var_ifagwh = 0; var_ifagwh += 1;
 goodB2G1 ( ) ; var_rcqzba ( ) ; goodG2B1 ( ) ; var_hkwfvy ( ) ; }