void var_pahfnn ( ) {    int var_aoursi = 123; var_aoursi -= 5;
 goodG2B ( ) ; }