void CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_15_good ( ) {    var_zgsnbg = 0;
 goodB2G1 ( ) ; var_dhqdsx ( ) ; goodG2B1 ( ) ; goodG2B2 ( ) ; }