void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_18_good ( ) {    var_hddamu = 0;
 goodB2G ( ) ; var_yufhnl ( ) ; }