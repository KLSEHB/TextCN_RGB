void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_ncpy_67_good ( ) {    ;
 goodG2B ( ) ; }