void CWE114_Process_Control__w32_char_environment_12_good ( ) {    int var_zuhaon = 0; var_zuhaon += 1;
 goodG2B ( ) ; }