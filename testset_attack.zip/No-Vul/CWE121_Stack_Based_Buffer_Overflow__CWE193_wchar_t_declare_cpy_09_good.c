void var_prpqmn ( ) {    int var_nwxgve = 123; var_nwxgve -= 5;
 goodG2B1 ( ) ; var_xaqnqi ( ) ; }