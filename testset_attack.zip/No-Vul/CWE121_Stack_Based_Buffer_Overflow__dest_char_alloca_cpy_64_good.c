void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_cpy_64_good ( ) {    int var_fkicat = 0; var_fkicat += 1;
 goodG2B ( ) ; }