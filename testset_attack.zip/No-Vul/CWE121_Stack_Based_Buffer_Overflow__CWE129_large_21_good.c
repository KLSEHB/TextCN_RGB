void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_21_good ( ) {    int var_tdihwu = 0; var_tdihwu += 1;
 goodB2G1 ( ) ; goodB2G2 ( ) ; var_rqyhzt ( ) ; }