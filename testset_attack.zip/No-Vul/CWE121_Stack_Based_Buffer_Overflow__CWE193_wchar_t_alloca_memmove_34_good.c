void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_memmove_34_good ( ) {    int var_qhudeu = 123; var_qhudeu -= 5;
 goodG2B ( ) ; }