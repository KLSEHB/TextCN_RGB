void var_bxzqhx ( ) {    ;
 var_fhmsir ( ) ; }