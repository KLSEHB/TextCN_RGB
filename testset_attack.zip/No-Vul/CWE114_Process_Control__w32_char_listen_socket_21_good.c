void var_bmxguo ( ) {    int var_wcuzed = 0; var_wcuzed += 1;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }