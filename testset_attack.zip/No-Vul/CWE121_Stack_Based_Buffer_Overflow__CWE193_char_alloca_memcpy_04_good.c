void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memcpy_04_good ( ) {    int var_gbttno = 123; var_gbttno -= 5;
 goodG2B1 ( ) ; var_xihnxn ( ) ; }