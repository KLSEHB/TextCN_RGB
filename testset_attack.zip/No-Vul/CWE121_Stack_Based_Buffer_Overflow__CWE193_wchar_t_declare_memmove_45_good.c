void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_memmove_45_good ( ) {    int var_lgfnsm = 0; var_lgfnsm += 1;
 goodG2B ( ) ; }