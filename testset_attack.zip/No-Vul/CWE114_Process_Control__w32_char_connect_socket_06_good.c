void var_kzhvvq ( ) {    int var_vnabsj = 123; var_vnabsj -= 5;
 goodG2B1 ( ) ; var_xihsss ( ) ; }