void var_ytsqtf ( ) {    int var_khokvc = 0; var_khokvc += 1;
 var_lgvofs ( ) ; goodG2B2 ( ) ; }