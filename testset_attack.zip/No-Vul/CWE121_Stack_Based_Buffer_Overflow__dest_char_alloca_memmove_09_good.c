void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_memmove_09_good ( ) {    int var_hlcbdp = 123; var_hlcbdp -= 5;
 var_pskiod ( ) ; goodG2B2 ( ) ; }