void CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_17_good ( ) {    int var_crdgmd = 0; var_crdgmd += 1;
 goodG2B ( ) ; }