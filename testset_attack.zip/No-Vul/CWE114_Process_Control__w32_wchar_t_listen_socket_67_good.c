void CWE114_Process_Control__w32_wchar_t_listen_socket_67_good ( ) {    ;
 goodG2B ( ) ; }