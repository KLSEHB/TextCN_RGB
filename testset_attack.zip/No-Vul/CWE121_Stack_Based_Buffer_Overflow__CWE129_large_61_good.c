void var_ojcnud ( ) {    var_uwjban = 0;
 var_mxiuax ( ) ; var_ipfnlk ( ) ; }