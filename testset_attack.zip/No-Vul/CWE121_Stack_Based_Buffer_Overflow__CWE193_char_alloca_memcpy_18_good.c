void var_upvlfa ( ) {    int var_vosusx = 123; var_vosusx -= 5;
 goodG2B ( ) ; }