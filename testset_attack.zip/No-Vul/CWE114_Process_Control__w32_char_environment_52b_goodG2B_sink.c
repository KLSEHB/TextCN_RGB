void var_uigqbf ( char * data ) {    var_yxbqci = 0;
 CWE114_Process_Control__w32_char_environment_52c_goodG2B_sink ( data ) ; }