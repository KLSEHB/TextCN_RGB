void var_kwtrhq ( ) {    ;
 var_uxzndz ( ) ; }