void CWE114_Process_Control__w32_char_file_54b_goodG2B_sink ( char * data ) {    var_eopiik = 0;
 CWE114_Process_Control__w32_char_file_54c_goodG2B_sink ( data ) ; }