void var_txqfyh ( ) {    ;
 goodG2B ( ) ; }