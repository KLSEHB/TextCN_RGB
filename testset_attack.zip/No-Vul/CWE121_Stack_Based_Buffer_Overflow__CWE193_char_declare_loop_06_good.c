void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_loop_06_good ( ) {    int var_ctynnh = 123; var_ctynnh -= 5;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }