char * CWE114_Process_Control__w32_char_console_61b_goodG2B_source ( char * data ) {    var_ytvnan = 0;
 strcpy ( data , "var_mfcuou:\\var_rdlqbv\\System32\\winsrv.var_hrzrpp" ) ; return data ; }