void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_memcpy_07_good ( ) {    var_rkmtct = 0;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }