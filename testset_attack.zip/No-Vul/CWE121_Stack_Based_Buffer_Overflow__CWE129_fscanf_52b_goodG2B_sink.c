void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_52b_goodG2B_sink ( int data ) {    var_zbbbia = 0;
 var_rvwijs ( data ) ; }