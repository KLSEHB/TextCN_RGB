void var_dzruvd ( ) {    int var_tmbvyp = 123; var_tmbvyp -= 5;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }