void CWE114_Process_Control__w32_char_console_53b_goodG2B_sink ( char * data ) {    var_ndxedh = 0;
 var_teumjs ( data ) ; }