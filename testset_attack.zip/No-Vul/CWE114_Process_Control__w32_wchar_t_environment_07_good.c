void var_hqdwpo ( ) {    ;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }