void var_gyxqxk ( ) {    ;
 var_avhiqx ( ) ; var_cyvfjt ( ) ; }