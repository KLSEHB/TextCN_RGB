void var_errsnl ( ) {    var_mpsswv = 0;
 goodG2B ( ) ; }