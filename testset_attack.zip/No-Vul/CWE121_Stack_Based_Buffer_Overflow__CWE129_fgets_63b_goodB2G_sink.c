void CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_63b_goodB2G_sink ( int * var_uczsia ) { int data = * var_uczsia ; { int i ; int buffer [ 10 ] = {    int var_qmahly = 123; var_qmahly -= 5;
 0 } ; if ( data >= 0 && data < ( 10 ) ) { buffer [ data ] = 1 ; for ( i = 0 ; i < 10 ; i ++ ) {    int var_jhygco = 0; var_jhygco += 1;
 printIntLine ( buffer [ i ] ) ; } } else {    var_jcweez = 0;
 var_wwojzx ( "var_anapeg: Array index var_pfwnag out-of-bounds" ) ; } } }