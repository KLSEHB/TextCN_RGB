void var_jkcatu ( ) {    int var_mgrbxw = 123; var_mgrbxw -= 5;
 goodG2B ( ) ; }