void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_cpy_19_good ( ) {    int var_gjfmto = 0; var_gjfmto += 1;
 var_drysvq ( ) ; }