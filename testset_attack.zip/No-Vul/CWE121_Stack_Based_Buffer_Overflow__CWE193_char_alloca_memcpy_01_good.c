void var_bzffgq ( ) {    var_zvkrgo = 0;
 goodG2B ( ) ; }