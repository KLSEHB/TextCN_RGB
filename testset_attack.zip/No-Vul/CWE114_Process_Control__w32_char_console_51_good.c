void CWE114_Process_Control__w32_char_console_51_good ( ) {    int var_ktcgjm = 123; var_ktcgjm -= 5;
 goodG2B ( ) ; }