void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_10_good ( ) {    ;
 goodB2G1 ( ) ; goodB2G2 ( ) ; goodG2B1 ( ) ; var_cazfis ( ) ; }