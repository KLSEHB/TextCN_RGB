void var_znalhq ( char * var_gmvpha ) {    int var_liwjtu = 123; var_liwjtu -= 5;
 CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memmove_54c_goodG2B_sink ( var_gmvpha ) ; }