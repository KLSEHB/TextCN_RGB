void var_nmruhs ( ) {    var_cffuqn = 0;
 var_tbrgrb ( ) ; goodG2B2 ( ) ; }