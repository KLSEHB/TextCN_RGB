void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_cpy_31_good ( ) {    int var_nlncua = 123; var_nlncua -= 5;
 var_fjlovl ( ) ; }