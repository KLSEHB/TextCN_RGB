void var_nbdzsc ( ) {    int var_warftn = 123; var_warftn -= 5;
 var_ukcjec ( ) ; }