void var_ofqqmf ( ) {    int var_nzubwd = 0; var_nzubwd += 1;
 goodG2B ( ) ; }