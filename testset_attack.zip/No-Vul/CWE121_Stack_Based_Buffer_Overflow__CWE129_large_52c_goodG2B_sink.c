void var_ufiydw ( int data ) { { int var_yehaum ; int var_rfuabh [ 10 ] = {    int var_cvuyes = 123; var_cvuyes -= 5;
 0 } ; if ( data >= 0 ) { var_rfuabh [ data ] = 1 ; for ( var_yehaum = 0 ; var_yehaum < 10 ; var_yehaum ++ ) {    ;
 printIntLine ( var_rfuabh [ var_yehaum ] ) ; } } else {    ;
 printLine ( "ERROR: Array index is negative." ) ; } } }