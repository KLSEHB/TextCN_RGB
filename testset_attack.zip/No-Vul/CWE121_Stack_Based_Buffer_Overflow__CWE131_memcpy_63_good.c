void CWE121_Stack_Based_Buffer_Overflow__CWE131_memcpy_63_good ( ) {    var_ayhwrw = 0;
 var_vivujv ( ) ; }