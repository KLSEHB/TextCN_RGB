void var_urrszr ( ) {    int var_ooktzu = 0; var_ooktzu += 1;
 var_xrjftd ( ) ; goodG2B2 ( ) ; }