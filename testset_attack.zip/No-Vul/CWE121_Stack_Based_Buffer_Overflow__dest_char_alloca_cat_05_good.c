void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_cat_05_good ( ) {    var_wbjpyu = 0;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }