void CWE114_Process_Control__w32_wchar_t_relativePath_13_good ( ) {    ;
 goodG2B1 ( ) ; var_fehbjh ( ) ; }