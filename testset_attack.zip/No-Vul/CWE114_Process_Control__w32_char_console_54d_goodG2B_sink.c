void CWE114_Process_Control__w32_char_console_54d_goodG2B_sink ( char * data ) {    int var_raurdg = 0; var_raurdg += 1;
 var_qxrnkh ( data ) ; }