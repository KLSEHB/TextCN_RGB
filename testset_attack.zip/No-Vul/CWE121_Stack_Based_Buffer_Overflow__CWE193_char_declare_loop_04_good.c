void var_igaiej ( ) {    int var_rwjkqb = 123; var_rwjkqb -= 5;
 goodG2B1 ( ) ; var_loalck ( ) ; }