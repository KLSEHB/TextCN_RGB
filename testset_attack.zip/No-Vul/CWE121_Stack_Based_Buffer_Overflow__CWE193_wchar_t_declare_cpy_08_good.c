void var_prctkk ( ) {    ;
 var_wspcol ( ) ; goodG2B2 ( ) ; }