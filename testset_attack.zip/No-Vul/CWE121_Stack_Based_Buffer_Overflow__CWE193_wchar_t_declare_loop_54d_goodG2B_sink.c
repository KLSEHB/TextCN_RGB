void var_qqsfpl ( wchar_t * var_qomksl ) {    int var_waqoxs = 0; var_waqoxs += 1;
 var_owvujs ( var_qomksl ) ; }