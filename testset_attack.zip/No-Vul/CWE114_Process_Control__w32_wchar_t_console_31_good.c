void var_quhdsf ( ) {    int var_sjunrg = 0; var_sjunrg += 1;
 var_vdhtlu ( ) ; }