void CWE121_Stack_Based_Buffer_Overflow__CWE135_19_good ( ) {    int var_vvtdee = 0; var_vvtdee += 1;
 var_pzpqbv ( ) ; goodG2B ( ) ; }