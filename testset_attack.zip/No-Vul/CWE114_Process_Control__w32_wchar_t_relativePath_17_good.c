void CWE114_Process_Control__w32_wchar_t_relativePath_17_good ( ) {    ;
 goodG2B ( ) ; }