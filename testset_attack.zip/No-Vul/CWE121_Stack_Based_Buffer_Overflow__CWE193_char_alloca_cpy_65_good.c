void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_cpy_65_good ( ) {    int var_gklptl = 123; var_gklptl -= 5;
 goodG2B ( ) ; }