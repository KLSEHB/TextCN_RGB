void var_yquhpk ( ) {    var_eqzbtj = 0;
 goodG2B ( ) ; }