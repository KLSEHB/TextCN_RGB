void var_bzolon ( ) {    var_dckyti = 0;
 var_kmgofg ( ) ; }