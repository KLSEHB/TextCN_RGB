void var_nagiio ( ) {    ;
 goodG2B ( ) ; }