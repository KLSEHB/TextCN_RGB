void CWE114_Process_Control__w32_wchar_t_listen_socket_21_good ( ) {    var_joqvfw = 0;
 goodG2B1 ( ) ; var_kflidr ( ) ; }