void var_sbosmm ( int data ) {    int var_kbkzao = 123; var_kbkzao -= 5;
 var_gdjdhm ( data ) ; }