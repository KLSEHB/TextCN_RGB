void var_hyvrpj ( wchar_t * data ) {    ;
 var_rdjloe ( data ) ; }