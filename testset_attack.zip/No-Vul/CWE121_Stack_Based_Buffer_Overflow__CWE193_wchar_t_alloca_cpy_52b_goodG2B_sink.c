void var_pyklwl ( wchar_t * data ) {    int var_bazpcs = 123; var_bazpcs -= 5;
 var_bveplb ( data ) ; }