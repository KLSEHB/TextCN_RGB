void var_yyrsmq ( ) {    var_ndbase = 0;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }