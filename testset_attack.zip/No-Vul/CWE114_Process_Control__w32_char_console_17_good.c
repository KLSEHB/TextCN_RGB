void CWE114_Process_Control__w32_char_console_17_good ( ) {    var_apqbzz = 0;
 var_dhxqwt ( ) ; }