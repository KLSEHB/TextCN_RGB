void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_ncpy_03_good ( ) {    int var_homwek = 0; var_homwek += 1;
 var_fmuehn ( ) ; var_oefudu ( ) ; }