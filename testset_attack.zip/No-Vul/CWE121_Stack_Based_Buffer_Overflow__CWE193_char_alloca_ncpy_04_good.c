void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_ncpy_04_good ( ) {    int var_aonynh = 123; var_aonynh -= 5;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }