void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memmove_04_good ( ) {    int var_lbhfaq = 0; var_lbhfaq += 1;
 goodG2B1 ( ) ; var_pfwgkj ( ) ; }