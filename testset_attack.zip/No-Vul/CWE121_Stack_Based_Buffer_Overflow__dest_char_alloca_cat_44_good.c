void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_cat_44_good ( ) {    int var_pahqkx = 0; var_pahqkx += 1;
 goodG2B ( ) ; }