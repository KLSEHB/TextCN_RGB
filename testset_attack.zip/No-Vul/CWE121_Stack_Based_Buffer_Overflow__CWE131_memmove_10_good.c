void CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_10_good ( ) {    var_mrvwqr = 0;
 var_abmhri ( ) ; goodG2B2 ( ) ; }