void CWE121_Stack_Based_Buffer_Overflow__CWE131_memcpy_67_good ( ) {    ;
 var_mimyxv ( ) ; }