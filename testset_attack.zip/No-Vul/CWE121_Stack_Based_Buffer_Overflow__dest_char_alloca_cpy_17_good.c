void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_cpy_17_good ( ) {    int var_azprgk = 0; var_azprgk += 1;
 goodG2B ( ) ; }