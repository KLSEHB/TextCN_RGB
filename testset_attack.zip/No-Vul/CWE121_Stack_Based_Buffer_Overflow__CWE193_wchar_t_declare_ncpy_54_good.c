void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_ncpy_54_good ( ) {    int var_htziks = 0; var_htziks += 1;
 goodG2B ( ) ; }