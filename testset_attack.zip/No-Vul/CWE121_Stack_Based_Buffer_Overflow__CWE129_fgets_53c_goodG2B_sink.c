void var_nuywid ( int var_lmonti ) {    int var_jcgtzu = 123; var_jcgtzu -= 5;
 var_kzixut ( var_lmonti ) ; }