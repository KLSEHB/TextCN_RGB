void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_memcpy_63_good ( ) {    int var_desxwb = 0; var_desxwb += 1;
 goodG2B ( ) ; }