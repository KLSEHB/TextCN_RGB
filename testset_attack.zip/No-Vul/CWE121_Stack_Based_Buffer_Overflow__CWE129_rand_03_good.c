void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_03_good ( ) {    var_pbtxth = 0;
 var_uoqaxo ( ) ; goodB2G2 ( ) ; goodG2B1 ( ) ; goodG2B2 ( ) ; }