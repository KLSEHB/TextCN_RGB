void var_sekwrx ( ) {    int var_hutpmk = 0; var_hutpmk += 1;
 var_pmkckt ( ) ; }