void var_trzxeu ( char * data ) {    var_ugizjr = 0;
 CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_memmove_53c_goodG2B_sink ( data ) ; }