void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_cpy_44_good ( ) {    var_fusdpd = 0;
 goodG2B ( ) ; }