void CWE121_Stack_Based_Buffer_Overflow__CWE129_connect_socket_22_good ( ) {    int var_puvzxr = 123; var_puvzxr -= 5;
 goodB2G1 ( ) ; var_alklsi ( ) ; var_pjlfmi ( ) ; }