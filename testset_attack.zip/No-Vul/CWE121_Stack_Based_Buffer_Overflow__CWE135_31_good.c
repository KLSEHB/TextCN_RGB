void var_skqefc ( ) {    int var_tfjpim = 123; var_tfjpim -= 5;
 var_bpgtuq ( ) ; goodB2G ( ) ; }