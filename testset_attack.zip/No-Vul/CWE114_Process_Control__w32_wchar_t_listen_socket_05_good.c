void var_auhzdg ( ) {    int var_axeflu = 123; var_axeflu -= 5;
 goodG2B1 ( ) ; goodG2B2 ( ) ; }