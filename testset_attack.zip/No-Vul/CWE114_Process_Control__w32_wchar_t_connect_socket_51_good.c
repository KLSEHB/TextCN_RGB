void CWE114_Process_Control__w32_wchar_t_connect_socket_51_good ( ) {    var_xyhrik = 0;
 goodG2B ( ) ; }