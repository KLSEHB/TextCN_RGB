void var_ctshty ( ) {    var_oiofnu = 0;
 goodB2G1 ( ) ; goodB2G2 ( ) ; var_qlapci ( ) ; var_myuzms ( ) ; }