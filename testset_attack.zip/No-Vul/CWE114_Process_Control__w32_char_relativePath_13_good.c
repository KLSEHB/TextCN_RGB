void CWE114_Process_Control__w32_char_relativePath_13_good ( ) {    int var_ijnilt = 0; var_ijnilt += 1;
 var_kgopez ( ) ; var_tgbxje ( ) ; }