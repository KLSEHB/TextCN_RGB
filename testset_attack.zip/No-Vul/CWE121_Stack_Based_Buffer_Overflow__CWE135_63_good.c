void CWE121_Stack_Based_Buffer_Overflow__CWE135_63_good ( ) {    int var_hyqgxy = 123; var_hyqgxy -= 5;
 var_vrpqof ( ) ; var_qokglg ( ) ; }