void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_16_good ( ) {    ;
 goodB2G ( ) ; goodG2B ( ) ; }