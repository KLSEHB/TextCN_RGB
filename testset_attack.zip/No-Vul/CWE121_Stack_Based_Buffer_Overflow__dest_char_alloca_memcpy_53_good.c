void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_memcpy_53_good ( ) {    int var_jpxyeg = 0; var_jpxyeg += 1;
 var_iaxspk ( ) ; }