void CWE114_Process_Control__w32_wchar_t_console_53c_goodG2B_sink ( var_edqdsz * data ) {    ;
 CWE114_Process_Control__w32_wchar_t_console_53d_goodG2B_sink ( data ) ; }