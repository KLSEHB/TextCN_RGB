#pragma once
#include <Windows.h>
#include <iostream>

#include "func.h"