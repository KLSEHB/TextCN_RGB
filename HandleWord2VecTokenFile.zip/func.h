#pragma once

int DivisionCodeByLineFeed(void** Code, int* index, void* SubCode);

int readOneFile(const char* filePath, void** readBuffer);

int OutPutToFile(const char* FilePath, char* writebuffer);

int CheckCharIsValueChar(char target);

int StrToInt(char* target);

int TransformStrArrayToIntArray(char** StrArray, int StrArrayLength, int* IntArray);

int AdjustIntOrderSTL(int* IntArray, int* ArrayLength, int* IndexArray);

int AdjustStrArray(char** SourceStrArray, char** TargetStrArray, int* ArrayIndex, int ArrayIndexLength);

int display(char** TokenArray, int TokenArrayLength, double* TokenValueArray, int TokenValueArrayLength, int* TokenIntValueArray, int TokenIntValueArrayLength, char* filePath1, char* filePath2);

int StrToDouble(const char* Str, double* pReturn);

int TransformStrArrayToDoubleArray(char** StrArray, int StrArrayLength, double* DoubleArray);

int AdjustDoubleOrderSTL(double* DoubleArray, int* ArrayLength, int* IndexArray);

int FindValueInDoubleArrayIndex(double* DoubleArray, int DoubleArrayLength, double target);

int MapDoubleToInt(double* DoubleArray, int DoubleArrayLength, int* ReturnIntArray, int startIntValue, int StopIntValue, int mod);

int ReverseIntArray(int* IntArray, int IntArrayLength);

int HandleBeyondRangeIntArray(int* IntArray, int IntArrayLength, int RangeTop);

int IntToStrNew(int target, char* StrReturn);