#include "main.h"

int DivisionCodeByLineFeed(void** Code, int* index, void* SubCode)
{
	int tempIndex = 0;
	while ((*((char**)Code))[*index + tempIndex] != '\n')
	{
		((char*)SubCode)[tempIndex] = (*((char**)Code))[*index + tempIndex];
		tempIndex++;
	}
	((char*)SubCode)[tempIndex] = 0x0;

	return tempIndex;
}

int readOneFile(const char* filePath, void** readBuffer)
{
	HANDLE f;
	DWORD realReadBytesNum;
	int readBytesNum;

	f = CreateFileA(filePath, GENERIC_READ, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if (f == INVALID_HANDLE_VALUE)
		return 0;

	readBytesNum = GetFileSize(f, NULL);

	if (!ReadFile(f, *readBuffer, readBytesNum, &realReadBytesNum, NULL))
		return 0;

	CloseHandle(f);

	return readBytesNum;
}

int OutPutToFile(const char* FilePath, char* writebuffer)
{
	HANDLE f;
	DWORD RealWriteBytesNum = 0;
	int WriteBytesNum;

	f = CreateFileA(FilePath, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if (f == INVALID_HANDLE_VALUE)
		return 0;

	SetFilePointer(f, NULL, NULL, FILE_END);

	if (!WriteFile(f, writebuffer, strlen(writebuffer), &RealWriteBytesNum, NULL))
		return 0;

	FlushFileBuffers(f);

	CloseHandle(f);

	return RealWriteBytesNum;
}

int CheckCharIsValueChar(char target)
{
	if ((target >= '0' && target <= '9') || target == '-' || target == '.')
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int StrToInt(char* target)
{
	int tempStrLength = 0;
	int tempResult = 0;
	int tempInt = 0;
	int tempInt1 = 10;

	tempStrLength = strlen(target);
	if (target[0] == '-')
	{
		for (int i = 1; i < tempStrLength; i++)
		{
			tempInt = target[i] - 48;
			tempInt1 = 10;
			for (int z = 2; z < tempStrLength - i; z++)
			{
				tempInt1 *= 10;
			}
			if (i != tempStrLength - 1)
			{
				tempResult = tempResult + tempInt * tempInt1;
			}
			else
			{
				tempResult += tempInt;
			}
		}
		tempResult = 0 - tempResult;
	}
	else
	{
		for (int i = 0; i < tempStrLength; i++)
		{
			tempInt = target[i] - 48;
			tempInt1 = 10;
			for (int z = 2; z < tempStrLength - i; z++)
			{
				tempInt1 *= 10;
			}
			if (i != tempStrLength - 1)
			{
				tempResult = tempResult + tempInt * tempInt1;
			}
			else
			{
				tempResult += tempInt;
			}
		}
	}

	return tempResult;
}

int TransformStrArrayToIntArray(char** StrArray, int StrArrayLength, int* IntArray)
{
	for (int i = 0; i < StrArrayLength; i++)
	{
		IntArray[i] = StrToInt(StrArray[i]);
	}

	return 1;
}

int TransformStrArrayToDoubleArray(char** StrArray, int StrArrayLength, double* DoubleArray)
{
	for (int i = 0; i < StrArrayLength; i++)
	{
		StrToDouble(StrArray[i], &(DoubleArray[i]));
	}

	return 1;
}

//��Ϊ����һ������������С���������ԾͲ�ʹ�ÿ��ŵ�ʱ�临�Ӷȵ͵��㷨�ˣ������������ԸĽ�
int AdjustIntOrderSTL(int* IntArray, int* ArrayLength, int* IndexArray)
{
	int tempIndex = -1;
	int tempIndex1 = -1;

	for (int i = 0; i < *ArrayLength; i++)
	{
		tempIndex = i;
		for (int z = i + 1; z < *ArrayLength; z++)
		{
			if (IntArray[tempIndex] > IntArray[z])
			{
				tempIndex = z;
			}
		}
		tempIndex1 = IntArray[tempIndex];
		IntArray[tempIndex] = IntArray[i];
		IntArray[i] = tempIndex1;
		IndexArray[i] = tempIndex;
	}

	return 1;
}

//��Ϊ����һ������������С���������ԾͲ�ʹ�ÿ��ŵ�ʱ�临�Ӷȵ͵��㷨�ˣ������������ԸĽ�
int AdjustDoubleOrderSTL(double* DoubleArray, int* ArrayLength, int* IndexArray)
{
	int tempIndex = -1;
	double tempIndex1 = -1;
	double tempDoubleArray[250];

	for (int i = 0; i < *ArrayLength; i++)
	{
		tempDoubleArray[i] = DoubleArray[i];
	}

	for (int i = 0; i < *ArrayLength; i++)
	{
		tempIndex = i;
		for (int z = i + 1; z < *ArrayLength; z++)
		{
			if (DoubleArray[tempIndex] > DoubleArray[z])
			{
				tempIndex = z;
			}
		}
		tempIndex1 = DoubleArray[tempIndex];
		DoubleArray[tempIndex] = DoubleArray[i];
		DoubleArray[i] = tempIndex1;
		IndexArray[i] = FindValueInDoubleArrayIndex(tempDoubleArray, *ArrayLength, tempIndex1);
	}

	return 1;
}

int AdjustStrArray(char** SourceStrArray, char** TargetStrArray, int* ArrayIndex, int ArrayIndexLength)
{
	for (int i = 0; i < ArrayIndexLength; i++)
	{
		strcpy(TargetStrArray[i], SourceStrArray[(ArrayIndex[i])]);
	}

	return 1;
}

int display(char** TokenArray, int TokenArrayLength, double* TokenValueArray, int TokenValueArrayLength, int* TokenIntValueArray, int TokenIntValueArrayLength, char* filePath1, char* filePath2)
{
	char tempBuffer[5000];
	char tempBuffer1[10];

	memset(tempBuffer, 0x0, 5000);

	std::cout << "Token Array:\n";
	for (int i = 0; i < TokenArrayLength; i++)
	{
		std::cout << TokenArray[i] << std::endl;
		strcat(tempBuffer, TokenArray[i]);
		strcat(tempBuffer, "\r\n");
	}
	OutPutToFile((const char*)filePath1, tempBuffer);
	std::cout << "\nToken Value Array:\n";
	for (int i = 0; i < TokenValueArrayLength; i++)
	{
		std::cout << TokenValueArray[i] << std::endl;
	}
	std::cout << "\nToken Int Value Array:\n";
	memset(tempBuffer, 0x0, 5000);
	for (int i = 0; i < TokenIntValueArrayLength; i++)
	{
		std::cout << TokenIntValueArray[i] << " ";
		IntToStrNew(TokenIntValueArray[i], tempBuffer1);
		strcat(tempBuffer, tempBuffer1);
		if (i != TokenIntValueArrayLength - 1)
		{
			strcat(tempBuffer, " ");
		}
	}
	OutPutToFile((const char*)filePath2, tempBuffer);

	return 1;
}

int StrToDouble(const char* Str, double* pReturn)
{
	int tempIndex = 0;
	int tempIndex2 = 0;
	int tempInt = 0;
	char tempStr[100];
	double tempDouble = 0.10;
	double tempDouble2 = 0.0;

	while (Str[tempIndex] != '.')
	{
		tempStr[tempIndex2++] = Str[tempIndex];
		tempIndex++;
	}
	tempIndex++;
	tempStr[tempIndex2] = 0x0;
	tempIndex2 = 0;
	tempInt = StrToInt(tempStr);
	(*pReturn) += tempInt;

	while (Str[tempIndex] != 0x0)
	{
		tempStr[tempIndex2++] = Str[tempIndex];
		tempIndex++;
	}
	tempStr[tempIndex2] = 0x0;
	for (int i = 0; i < tempIndex2; i++)
	{
		tempDouble2 = tempDouble2 + tempDouble * (tempStr[i] - 48);
		tempDouble *= 0.1;
	}
	if (Str[0] == '-')
	{
		tempDouble2 = 0 - tempDouble2;
	}
	*pReturn += tempDouble2;

	return 1;
}

int FindValueInDoubleArrayIndex(double* DoubleArray, int DoubleArrayLength, double target)
{
	for (int i = 0; i < DoubleArrayLength; i++)
	{
		if (DoubleArray[i] == target)
		{
			return i;
		}
	}

	return -1;
}

int MapDoubleToInt(double* DoubleArray, int DoubleArrayLength, int* ReturnIntArray, int startIntValue, int StopIntValue, int mod)
{
	int tempIntRange = StopIntValue - startIntValue + 1;
	double tempDoubleRange = DoubleArray[DoubleArrayLength - 1] - DoubleArray[0];
	double tempRatio = tempIntRange / tempDoubleRange;
	int tempInt = 0;

	for (int i = 0; i < DoubleArrayLength; i++)
	{
		tempInt = (int)((DoubleArray[i] - DoubleArray[0]) * tempRatio);
		if (tempInt == 0)
		{
			tempInt++;
		}

		for (int z = 0; z < i; z++)
		{
			if (tempInt <= ReturnIntArray[z])
			{
				tempInt++;
				z--;
			}
		}
		ReturnIntArray[i] = tempInt;
	}

	HandleBeyondRangeIntArray(ReturnIntArray, DoubleArrayLength, StopIntValue);

	if (mod == 1)
	{
		ReverseIntArray(ReturnIntArray, DoubleArrayLength);
	}

	return 0;
}

int ReverseIntArray(int* IntArray, int IntArrayLength)
{
	int tempInt = 0;
	int temp = IntArrayLength / 2;

	for (int i = 0; i < temp; i++)
	{
		tempInt = IntArray[i];
		IntArray[i] = IntArray[IntArrayLength - 1 - i];
		IntArray[IntArrayLength - 1 - i] = tempInt;
	}

	return 0;
}

int HandleBeyondRangeIntArray(int* IntArray, int IntArrayLength, int RangeTop)
{
	int tempInt = 0;
	int tempIndex = 0;
	int tempInt2;

	if (IntArray[IntArrayLength - 1] > RangeTop)
	{
		tempInt = IntArray[IntArrayLength - 1] - RangeTop;

		while (tempInt > 0)
		{
			tempInt2 = IntArray[IntArrayLength - 1];
			for (int i = IntArrayLength - 1; i >= 0; i--)
			{
				if (tempInt2 != IntArray[i])
				{
					tempIndex = i + 1;
					tempInt2 -= IntArray[i];

					for (int z = tempIndex; z < IntArrayLength; z++)
					{
						IntArray[z] -= tempInt2;
					}
					tempInt -= tempInt2;
					break;
				}
				else
				{
					tempInt2--;
				}
			}
		}
	}

	return 0;
}

//����������֧���򼶱��ת��
int IntToStrNew(int target, char* StrReturn)
{
	int tempInt;
	int tempInt1 = target;
	int Multiple = 10000;
	int tempIndex = 0;

	if (target >= 100000)
	{
		StrReturn[0] = 0x0;
		return 0;
	}
	for (int i = 0; i < 4; i++)
	{
		tempInt = tempInt1 / Multiple;
		tempInt1 = tempInt1 % Multiple;
		Multiple /= 10;
		if (tempInt == 0)
		{
			if (tempIndex != 0)
			{
				StrReturn[tempIndex++] = tempInt + 48;
			}
		}
		else
		{
			StrReturn[tempIndex++] = tempInt + 48;
		}
	}
	StrReturn[tempIndex++] = tempInt1 + 48;
	StrReturn[tempIndex] = 0x0;

	return 1;
}