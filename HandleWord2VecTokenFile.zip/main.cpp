#include "main.h"

void** pCode = new void*;

int main(int argc,char* argv[])
{
	char filePath[100];
	char filePath1[100];
	char filePath2[100];
	int tempIndex = 0;
	char tempSubCode[200];
	char** tempppSubCode;
	int tempReturnLength = 0;
	char** tempTokenArray;
	char** tempTokenArray1;
	char** tempTokenValueArray;
	int tempTokenArrayIndex = 0;
	int tempTokenValueArrayIndex = 0;
	bool bFirstValue = false;
	int tempIndex1 = 0;
	int tempIndex2 = 0;
	int tempTokenValueArrayInt[250] = { 0 };
	int tempTokenValueArrayIntIndex = 0;
	int tempTokenValueTransformIndex[250] = {-1};
	double tempTokenValueArrayDouble[250] = { 0.0 };
	int tempTokenValueArrayDoubleIndex = 0;

	memset(filePath, 0x0, 100);
	memset(filePath1, 0x0, 100);
	memset(filePath2, 0x0, 100);

	tempppSubCode = new char*;
	*tempppSubCode = tempSubCode;

	tempTokenArray = new char* [250];
	tempTokenValueArray = new char* [250];
	tempTokenArray1 = new char* [250];

	for (int i = 0; i < 250; i++)
	{
		tempTokenArray[i] = new char[50];
		tempTokenArray1[i] = new char[50];
		tempTokenValueArray[i] = new char[20];

		memset(tempTokenArray[i], 0x0, 50);
		memset(tempTokenArray1[i], 0x0, 50);
		memset(tempTokenValueArray[i], 0x0, 20);
	}

#ifdef _DEBUG
	strcpy(filePath, "G:\\c\\yan\\CodeTranslate\\x64\\Debug\\14.txt");
	strcpy(filePath1, "G:\\temp\\11.txt");
	strcpy(filePath2, "G:\\temp\\18.txt");
#else
	if (argc != 4)
	{
		std::cout << "Usage: xxx.exe FilePath OutputFilePath OutputFilePath2\n";
		return 0;
	}
	strcpy(filePath, argv[1]);
	strcpy(filePath1, argv[2]);
	strcpy(filePath2, argv[3]);
#endif

	* pCode = malloc(sizeof(char) * 10000);
	memset(*pCode, 0x0, 10000);

	if (!readOneFile(filePath, pCode))
	{
		std::cout << "Read File Fail!" << std::endl;
		return 0;
	}

	while ((*(char**)pCode)[tempIndex] != 0x0)
	{
		tempReturnLength = DivisionCodeByLineFeed(pCode, &tempIndex, tempSubCode);
		tempIndex1 = 0;
		tempIndex2 = 0;
		bFirstValue = true;

		while (tempSubCode[tempIndex1] != ' ' || bFirstValue)
		{
			tempTokenArray[tempTokenArrayIndex][tempIndex2++] = tempSubCode[tempIndex1];
			tempIndex1++;
			bFirstValue = false;
		}
		
		tempTokenArray[tempTokenArrayIndex][tempIndex2] = 0x0;
		tempIndex2 = 0;
		tempTokenArrayIndex++;
		tempIndex1++;

		while (CheckCharIsValueChar(tempSubCode[tempIndex1]))
		{
			tempTokenValueArray[tempTokenValueArrayIndex][tempIndex2++] = tempSubCode[tempIndex1];
			tempIndex1++;
		}
		tempTokenValueArray[tempTokenValueArrayIndex][tempIndex2++] = 0x0;
		tempIndex2 = 0;
		tempTokenValueArrayIndex++;

		tempIndex = tempIndex + tempReturnLength + 1;
	}

	//TransformStrArrayToIntArray(tempTokenValueArray, tempTokenValueArrayIndex, tempTokenValueArrayInt);

	TransformStrArrayToDoubleArray(tempTokenValueArray, tempTokenValueArrayIndex, tempTokenValueArrayDouble);

	//tempTokenValueArrayIntIndex = tempTokenValueArrayIndex;
	tempTokenValueArrayDoubleIndex = tempTokenValueArrayIndex;
	//AdjustIntOrderSTL(tempTokenValueArrayInt, &tempTokenValueArrayIntIndex, tempTokenValueTransformIndex);
	AdjustDoubleOrderSTL(tempTokenValueArrayDouble, &tempTokenValueArrayDoubleIndex, tempTokenValueTransformIndex);

	AdjustStrArray(tempTokenArray, tempTokenArray1, tempTokenValueTransformIndex, tempTokenArrayIndex);

	MapDoubleToInt(tempTokenValueArrayDouble, tempTokenValueArrayDoubleIndex, tempTokenValueArrayInt, 1, 255, 1);
	tempTokenValueArrayIntIndex = tempTokenValueArrayDoubleIndex;

	display(tempTokenArray1, tempTokenArrayIndex, tempTokenValueArrayDouble, tempTokenValueArrayIndex, tempTokenValueArrayInt, tempTokenValueArrayIntIndex, filePath1, filePath2);

	for (int i = 0; i < 250; i++)
	{
		delete[] tempTokenArray[i];
		delete[] tempTokenValueArray[i];
	}

	delete[] tempTokenArray;
	delete[] tempTokenValueArray;

	delete tempppSubCode;
	free(*pCode);
	*pCode = NULL;
	delete pCode;

	return 0;
}