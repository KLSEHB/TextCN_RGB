static int end_superexec ( i_ctx_t * i_ctx_p ) {
 i_ctx_p -> in_superexec -- ;
 return 0 ;
 }