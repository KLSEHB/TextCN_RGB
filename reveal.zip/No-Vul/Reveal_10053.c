static void stroke_reread ( private_stroke_socket_t * this , stroke_msg_t * msg , FILE * out ) {
 this -> cred -> reread ( this -> cred , msg , out ) ;
 }