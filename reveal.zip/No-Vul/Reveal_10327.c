static void ohci_set_hub_status ( OHCIState * ohci , uint32_t val ) {
 uint32_t old_state ;
 old_state = ohci -> rhstatus ;
 if ( val & OHCI_RHS_OCIC ) ohci -> rhstatus &= ~ OHCI_RHS_OCIC ;
 if ( val & OHCI_RHS_LPS ) {
 int i ;
 for ( i = 0 ;
 i < ohci -> num_ports ;
 i ++ ) ohci_port_power ( ohci , i , 0 ) ;
 trace_usb_ohci_hub_power_down ( ) ;
 }
 if ( val & OHCI_RHS_LPSC ) {
 int i ;
 for ( i = 0 ;
 i < ohci -> num_ports ;
 i ++ ) ohci_port_power ( ohci , i , 1 ) ;
 trace_usb_ohci_hub_power_up ( ) ;
 }
 if ( val & OHCI_RHS_DRWE ) ohci -> rhstatus |= OHCI_RHS_DRWE ;
 if ( val & OHCI_RHS_CRWE ) ohci -> rhstatus &= ~ OHCI_RHS_DRWE ;
 if ( old_state != ohci -> rhstatus ) ohci_set_interrupt ( ohci , OHCI_INTR_RHSC ) ;
 }