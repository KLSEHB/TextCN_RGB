void config_filter_add_all ( struct config_filter_context * ctx , struct config_filter_parser * const * parsers ) {
 ctx -> parsers = parsers ;
 }