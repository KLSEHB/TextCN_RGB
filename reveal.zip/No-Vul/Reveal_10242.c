static void i_defer_frees ( gs_memory_t * mem , int defer ) {
 }