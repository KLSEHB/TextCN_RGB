static int no_cleanup ( i_ctx_t * i_ctx_p ) {
 return 0 ;
 }