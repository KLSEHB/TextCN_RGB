static void sum_usage ( FILE * out , int count , size_t bytes , int whitelisted ) {
 fprintf ( out , "Total memory usage: %zu\n" , bytes ) ;
 }