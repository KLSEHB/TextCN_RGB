static void print_version ( void ) {
 printf ( "%s Ver %s Distrib %s, for %s (%s)\n" , my_progname_short , DUMP_VERSION , MYSQL_SERVER_VERSION , SYSTEM_TYPE , MACHINE_TYPE ) ;
 }