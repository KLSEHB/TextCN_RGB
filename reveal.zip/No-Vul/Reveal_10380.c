static int zneedinput ( i_ctx_t * i_ctx_p ) {
 return gs_error_NeedInput ;
 }