void gs_memory_gc_status ( const gs_ref_memory_t * mem , gs_memory_gc_status_t * pstat ) {
 * pstat = mem -> gc_status ;
 }