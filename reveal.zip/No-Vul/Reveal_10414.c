static inline int8_t isAnonAuth ( relpTcp_t * pThis ) {
 return pThis -> ownCertFile == NULL ;
 }