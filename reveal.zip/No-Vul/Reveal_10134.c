int init_dumping_views ( char * qdatabase __attribute__ ( ( unused ) ) ) {
 return 0 ;
 }