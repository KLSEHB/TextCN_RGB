static void init_dir_data ( iax_call_dirdata * dirdata ) {
 dirdata -> current_frag_bytes = 0 ;
 dirdata -> current_frag_minlen = 0 ;
 }