static void short_usage ( FILE * f ) {
 short_usage_sub ( f ) ;
 fprintf ( f , "For more options, use %s --help\n" , my_progname_short ) ;
 }