static int dump_all_tablespaces ( ) {
 return dump_tablespaces ( NULL ) ;
 }