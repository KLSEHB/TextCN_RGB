static gs_memory_t * i_stable ( gs_memory_t * mem ) {
 return mem -> stable_memory ;
 }