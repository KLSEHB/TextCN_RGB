void gs_memory_set_gc_status ( gs_ref_memory_t * mem , const gs_memory_gc_status_t * pstat ) {
 mem -> gc_status = * pstat ;
 ialloc_set_limit ( mem ) ;
 }