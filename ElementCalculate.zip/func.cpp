#include "func.h"

int DivisionCodeByLineFeed(void** Code, int* index, void* SubCode)
{
	int tempIndex = 0;
	while ((*((char**)Code))[*index + tempIndex] != '\r' || (*((char**)Code))[*index + tempIndex + 1] != '\n')
	{
		((char*)SubCode)[tempIndex] = (*((char**)Code))[*index + tempIndex++];
	}
	((char*)SubCode)[tempIndex] = 0x0;

	return tempIndex;
}

int CheckNamableCharacter(char* target)
{
	if (*target == '_' || (*target >= '0' && *target <= '9') || (*target >= 'a' && *target <= 'z') || (*target >= 'A' && *target <= 'Z'))
	{
		return 1;
	}

	return 0;
}

int CalculateElementAndCodeLineNum(void** Code, int* index, int* CodeLineElementArray, int* CodeLineElementMax, int* FunctionCodeLineNumArray, int* FunctionCodeLineMax)
{
	int tempIndex = 0;
	int tempInt = 0;
	int tempIndex1 = 0;
	int tempReturn = 0;
	char tempSubCode[200];
	int tempFunctionCodeLineNum = 0;
	int tempCodeLineElementMax = 0;
	int tempCodeLineElement = 0;

	while (1)
	{
		tempInt = *index + tempIndex;
		tempReturn = DivisionCodeByLineFeed(Code, &tempInt, tempSubCode);

		if (tempReturn == 0)
		{
			tempIndex = tempIndex + tempReturn + 2;

			tempInt = *index + tempIndex;

			if ((*(char**)Code)[tempInt] == 0x0)
			{
				break;
			}

			tempReturn = DivisionCodeByLineFeed(Code, &tempInt, tempSubCode);

			if (!strcmp(tempSubCode, "1") || !strcmp(tempSubCode, "0"))
			{
				break;
			}
			else
			{
				tempFunctionCodeLineNum++;

				(CodeLineElementArray[tempCodeLineElement])++;

				tempCodeLineElement = 0;
				tempIndex = tempIndex + tempReturn + 2;

				continue;
			}
		}

		for (int i = 0; i < tempReturn; i++)
		{
			if (CheckNamableCharacter(&(tempSubCode[i])))
			{
				tempIndex1++;
			}
			else
			{
				tempCodeLineElement++;

				if (tempIndex1 != 0)
				{
					tempIndex1 = 0;
					tempCodeLineElement++;
				}
			}
		}

		if (tempIndex1 != 0)
		{
			tempIndex1 = 0;
			tempCodeLineElement++;
		}

		if (tempCodeLineElement > tempCodeLineElementMax)
		{
			tempCodeLineElementMax = tempCodeLineElement;
		}

		tempFunctionCodeLineNum++;

		(CodeLineElementArray[tempCodeLineElement])++;

		tempCodeLineElement = 0;
		tempIndex = tempIndex + tempReturn + 2;
	}

	if (tempCodeLineElementMax > *CodeLineElementMax)
	{
		*CodeLineElementMax = tempCodeLineElementMax;
	}

	if (tempFunctionCodeLineNum > *FunctionCodeLineMax)
	{
		*FunctionCodeLineMax = tempFunctionCodeLineNum;
	}

	(FunctionCodeLineNumArray[tempFunctionCodeLineNum])++;

	return tempIndex;
}

int ExtractCodeFragmentAndCalculate(void** Code, int* index, int* CodeLineElementArray, int* CodeLineElementMax, int* FunctionCodeLineNumArray, int* FunctionCodeLineMax)
{
	int tempReturn = 0;
	int tempInt = 0;
	int tempIndex = 0;
	char tempSubCode[200];

	while ((*(char**)Code)[*index + tempIndex] != 0x0)
	{
		tempInt = *index + tempIndex;
		tempReturn = DivisionCodeByLineFeed(Code, &tempInt, tempSubCode);
		if (!strcmp(tempSubCode, "1") || !strcmp(tempSubCode, "0"))
		{
			tempIndex = tempIndex + tempReturn + 2;
			tempInt = *index + tempIndex;
			tempReturn = DivisionCodeByLineFeed(Code, &tempInt, tempSubCode);
		}
		else
		{
			std::cout << "Extract Code Fragment Fail!\n";
			return 0;
		}

		if (!strcmp(tempSubCode, "--------------------------------------------------------------------"))
		{
			tempIndex = tempIndex + tempReturn + 2;
			tempInt = *index + tempIndex;
		}
		else
		{
			std::cout << "Extract Code Fragment Fail!\n";
			return 0;
		}

		tempReturn = CalculateElementAndCodeLineNum(Code, &tempInt, CodeLineElementArray, CodeLineElementMax, FunctionCodeLineNumArray, FunctionCodeLineMax);
		if (tempReturn == 0)
		{
			std::cout << "Extract Code Fragment Fail!\n";
			return 0;
		}
		tempIndex = tempIndex + tempReturn;
	}

	return 1;
}

int readOneFile(const char* filePath, void** readBuffer)
{
	HANDLE f;
	DWORD realReadBytesNum;
	int readBytesNum;

	f = CreateFileA(filePath, GENERIC_READ, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if (f == INVALID_HANDLE_VALUE)
		return 0;

	readBytesNum = GetFileSize(f, NULL);

	if (!ReadFile(f, *readBuffer, readBytesNum, &realReadBytesNum, NULL))
		return 0;

	CloseHandle(f);

	return readBytesNum;
}