#include "main.h"

void** pCode = new void*;

int main(int argc, char* argv[])
{
	char filePath[100];
	int tempIndex = 0;
	int* CodeLineElementArray;
	int* FunctionCodeLineNumArray;
	int CodeLineElementMax = 0;
	int FunctionCodeLineMax = 0;
	int FunctionNum = 0;
	int CodeLineNum = 0;

	memset(filePath, 0x0, 100);

#ifdef _DEBUG
	strcpy(filePath, "G:\\c\\yan\\CodeTranslate\\x64\\Debug\\data\\9\\2.txt");
#else
	if (argc != 2)
	{
		std::cout << "Usage: xxx.exe FilePath\n";
		return 0;
	}
	strcpy(filePath, argv[1]);
#endif

	CodeLineElementArray = new int[150];
	FunctionCodeLineNumArray = new int[150];
	*pCode = malloc(sizeof(char) * 20000000);
	memset(*pCode, 0x0, 20000000);

	for (int i = 0; i < 150; i++)
	{
		CodeLineElementArray[i] = 0;
		FunctionCodeLineNumArray[i] = 0;
	}

	if (!readOneFile(filePath, pCode))
	{
		std::cout << "Read File Fail!" << std::endl;
		return 0;
	}

	if (ExtractCodeFragmentAndCalculate(pCode, &tempIndex, CodeLineElementArray, &CodeLineElementMax, FunctionCodeLineNumArray, &FunctionCodeLineMax))
	{
		std::cout << "Code Line Have Elements Num Max: " << CodeLineElementMax << std::endl;
		for (int i = 0; i <= CodeLineElementMax; i++)
		{
			std::cout << "Code Line Have " << i << " Elements Num : " << CodeLineElementArray[i] << std::endl;
			CodeLineNum += CodeLineElementArray[i];
		}

		std::cout << "Code Line Num :" << CodeLineNum << std::endl;
		std::cout << "\n";
		std::cout << "Function Have Code Line Num Max: " << FunctionCodeLineMax << std::endl;
		for (int i = 0; i <= FunctionCodeLineMax; i++)
		{
			std::cout << "Function Have " << i << " Code Line Num: " << FunctionCodeLineNumArray[i] << std::endl;
			FunctionNum += FunctionCodeLineNumArray[i];
		}

		std::cout << "Function Num :" << FunctionNum << std::endl;
	}
	else
	{
		std::cout << "Extract Code Fragment And Calculate Fail!\n";
	}

	delete[] CodeLineElementArray;
	delete[] FunctionCodeLineNumArray;
	free(*pCode);
	*pCode = NULL;
	delete pCode;

	return 0;
}