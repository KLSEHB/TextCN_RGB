#pragma once
#include <iostream>
#include <Windows.h>

extern void** pCode;

int DivisionCodeByLineFeed(void** Code, int* index, void* SubCode);

int CheckNamableCharacter(char* target);

int CalculateElementAndCodeLineNum(void** Code, int* index, int* CodeLineElementArray, int* CodeLineElementMax, int* FunctionCodeLineNumArray, int* FunctionCodeLineMax);

int ExtractCodeFragmentAndCalculate(void** Code, int* index, int* CodeLineElementArray, int* CodeLineElementMax, int* FunctionCodeLineNumArray, int* FunctionCodeLineMax);

int readOneFile(const char* filePath, void** readBuffer);