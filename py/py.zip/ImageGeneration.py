# -*- coding: utf-8 -*-
import networkx as nx
import numpy as np
import argparse
import os
import sent2vec
import pickle
import glob
import matplotlib.pyplot as plt
from multiprocessing import Pool
from functools import partial
import pydot
import cv2
import math
from PIL import Image
import numpy as np
import os
import shutil
from PIL import Image



def parse_options():
    parser = argparse.ArgumentParser(description='Image-based Vulnerability Detection.')
    parser.add_argument('-i', '--input', help='The path of a dir which consists of some dot_files')
    parser.add_argument('-o', '--out', help='The path of output.', required=True)
    parser.add_argument('-m', '--model', help='The path of model.', required=True)
    args = parser.parse_args()
    return args


def graph_extraction(dot):
    graph = nx.drawing.nx_pydot.read_dot(dot)
    return graph


def kshell(G):
    graph = G.copy()
    importance_dict = {}
    level = 1
    while len(graph.degree):
        importance_dict[level] = []
        while True:
            level_node_list = []
            for item in graph.degree:
                if item[1] <= level:
                    level_node_list.append(item[0])
            graph.remove_nodes_from(level_node_list)
            importance_dict[level].extend(level_node_list)
            if not len(graph.degree):
                return importance_dict
            if min(graph.degree, key=lambda x: x[1])[1] > level:
                break
        level = min(graph.degree, key=lambda x: x[1])[1]
    return importance_dict

def gDegree(G):
    """
    将G.degree()的返回值变为字典
    """
    node_degrees_dict = {}
    for i in G.degree():
        node_degrees_dict[i[0]] = i[1]
    return node_degrees_dict.copy()


def get_neighbors(g,node,depth=1):
    output = {}
    layers = dict(nx.bfs_successors(g, source=node, depth_limit=depth))
    nodes = [node]
    for i in range(1, depth + 1):
        output[i] = []
        for x in nodes:
            output[i].extend(layers.get(x, []))
        nodes = output[i]
    return output


def get_ksnode(ks):
    ks_node = {}
    for k,v in ks.items():
        for i in v:
            ks_node[i] = k
    return ks_node

def sentence_embedding(sentence):
    emb = sent2vec_model.embed_sentence(sentence)
    return emb[0]

def hits_algorithm(G, max_iter=100, tol=1e-6):

    hub = {node: 1 for node in G.nodes()}
    authority = {node: 1 for node in G.nodes()}

    for _ in range(max_iter):
        new_authority = {}
        for node in G.nodes():
            new_authority[node] = sum(hub[neighbor] for neighbor in G.predecessors(node))
        norm = sum(value ** 2 for value in new_authority.values()) ** 0.5
        new_authority = {node: value / norm for node, value in new_authority.items()}

        new_hub = {}
        for node in G.nodes():
            new_hub[node] = sum(authority[neighbor] for neighbor in G.successors(node))

        norm = sum(value ** 2 for value in new_hub.values()) ** 0.5
        new_hub = {node: value / norm for node, value in new_hub.items()}

        hub_residual = sum(abs(new_hub[node] - hub[node]) for node in G.nodes())
        authority_residual = sum(abs(new_authority[node] - authority[node]) for node in G.nodes())
        if hub_residual < tol and authority_residual < tol:
            break

        hub = new_hub
        authority = new_authority
    combined_importance = {node: hub[node] + authority[node] for node in G.nodes()}
    return combined_importance

def map_to_uint8(values):
    
    valid_values = values[~np.isnan(values)]  
    if len(valid_values) == 0:
        return np.zeros_like(values, dtype=np.uint8)  
    min_value = np.min(valid_values)
    max_value = np.max(valid_values)
    if min_value == max_value:
        return np.zeros_like(values, dtype=np.uint8) 
    mapped_values = ((values - min_value) / (max_value - min_value) * 255).astype(np.uint8)
    return mapped_values


def image_generation(dot):
    try:
        No_Vul = "/home/liushuai/Key-notes/images_for_compare/No-Vul"
        Vul = "/home/liushuai/Key-notes/images_for_compare/Vul" 
        dot_name = dot.split('/')[-1].split('.dot')[0]
        pdg = graph_extraction(dot)
        G = nx.DiGraph()
        G.add_nodes_from(pdg.nodes())
        G.add_edges_from(pdg.edges())
        ks = kshell(G.copy())
        ks_min = min(ks)
        ks_max = max(ks)
        k = gDegree(G)
        ks_node = get_ksnode(ks)
        m_d = 2.235
        k_shell_cen_dict = {}
        for i in G.nodes():
            s = 0
            neighbor = get_neighbors(G, i, int(0.5 * m_d))
            for d, nodes in neighbor.items():
                for j in nodes:
                    cij = (ks_node[i] - ks_node[j]) / math.exp(ks_max - ks_min)
                    s += cij * ((k[i] * k[j]) / d ** 2)
            k_shell_cen_dict[i] = s
        hits_cen_dict = hits_algorithm(G)
        labels_dict = nx.get_node_attributes(pdg, 'label')
        labels_code = dict()
        for label, all_code in labels_dict.items():
            code = all_code[all_code.index(",") + 1:-2].split('\\n')[0]
            code = code.replace("static void", "void")
            labels_code[label] = code
        degree_cen_dict = nx.degree_centrality(pdg)
        degree_channel = []
        k_shell_channel = []
        hits_channel = []
        for label, code in labels_code.items():
            line_vec = sentence_embedding(code)
            line_vec = np.array(line_vec)

            degree_cen = degree_cen_dict[label]
            degree_channel.append(degree_cen * line_vec)

            k_shell_cen = k_shell_cen_dict[label]
            k_shell_channel.append(k_shell_cen * line_vec)
            hits_cen = hits_cen_dict[label]
            hits_channel.append(hits_cen * line_vec)

        degree_channel = np.stack(degree_channel, axis=0)
        hits_channel = np.stack(hits_channel, axis=0)
        k_shell_channel = np.stack(k_shell_channel, axis=0)


        degree_channel_resized = cv2.resize(degree_channel, (80, 80), interpolation=cv2.INTER_AREA)
        hits_channel_resized = cv2.resize(hits_channel, (80, 80), interpolation=cv2.INTER_AREA)
        k_shell_channel_resized = cv2.resize(k_shell_channel, (80, 80), interpolation=cv2.INTER_AREA)

        degree_channel_resized = (degree_channel_resized - np.min(degree_channel_resized)) / (np.max(degree_channel_resized) - np.min(degree_channel_resized))
        hits_channel_resized = (hits_channel_resized - np.min(hits_channel_resized)) / (np.max(hits_channel_resized) - np.min(hits_channel_resized))
        k_shell_channel_resized = (k_shell_channel_resized - np.min(k_shell_channel_resized)) / (np.max(k_shell_channel_resized) - np.min(k_shell_channel_resized))

        image = np.stack([degree_channel_resized, hits_channel_resized, k_shell_channel_resized], axis=-1)

        print("Image Shape after resizing:", image.shape)
        
        save_dir = "l"
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        plt.imsave(os.path.join(save_dir, dot_name + ".jpg"), image)
        for filename in os.listdir(save_dir):
            file_path = os.path.join(save_dir, filename)
            if filename.endswith('.jpg') or filename.endswith('.jpg'):
                if category == 'No-Vul':
                    shutil.copy(file_path, os.path.join(No_Vul, filename))
                elif category == 'Vul':
                    shutil.copy(file_path, os.path.join(Vul, filename))
                else:
                    pass
        return (degree_channel_resized, hits_channel_resized, k_shell_channel_resized)
    except Exception as e:
        # print(f"Error generating image for {dot}: {e}")
        print("Error generating image for {}: {}".format(dot, e))

        return None



def write_to_pkl(dot,out,existing_files):
    dot_name = dot.split('/')[-1].split('.dot')[0]
    if dot_name in existing_files:
        return None
    else:
        channels = image_generation(dot)
        if channels == None:
            return None
        else:
            (degree_channel, closeness_channel, katz_channel) = channels
            out_pkl = out + dot_name + '.pkl'
            data = [degree_channel, closeness_channel, katz_channel]
            with open(out_pkl, 'wb') as f:
                pickle.dump(data, f)


def main():
    args = parse_options()
    dir_name = args.input
    out_path = args.out
    trained_model_path = args.model
    global sent2vec_model
    sent2vec_model = sent2vec.Sent2vecModel()
    sent2vec_model.load_model(trained_model_path)
    if dir_name[-1] == '/':
        dir_name = dir_name
    else:
        dir_name += "/"
    dotfiles = glob.glob(dir_name + '*.dot')
    if out_path[-1] == '/':
        out_path = out_path
    else:
        out_path += '/'
    existing_files = glob.glob(out_path + "/*.pkl")
    existing_files = [f.split('.pkl')[0] for f in existing_files]
    pool = Pool(10)
    if not os.path.exists(out_path):
        os.makedirs(out_path)
    pool.map(partial(write_to_pkl,out=out_path,existing_files=existing_files), dotfiles)
    sent2vec_model.release_shared_mem(trained_model_path)

if __name__ == '__main__':
    main()
