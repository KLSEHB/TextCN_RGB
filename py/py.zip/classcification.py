import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from CNN_model import train_and_evaluate_model
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger()

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] = 'true'
os.environ['TF_CUDNN_USE_AUTOTUNE'] = '0'
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

train_dir = ''
test_dir = ‘'
img_height, img_width = 80, 80
batch_size = 16
epochs = 10000

train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest'
)

test_datagen = ImageDataGenerator(rescale=1./255)

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='binary'
)

test_generator = test_datagen.flow_from_directory(
    test_dir,
    target_size=(img_height, img_width),
    batch_size=batch_size,
    class_mode='binary'
)

accuracy, TPR, FNR, precision, recall, F1 = train_and_evaluate_model(
    train_generator, test_generator, img_height, img_width, batch_size, epochs
)

logger.info(f"Test Accuracy: {accuracy * 100:.2f}%")
logger.info(f"TPR: {TPR * 100:.2f}%")
logger.info(f"FNR: {FNR * 100:.2f}%")
logger.info(f"Precision: {precision * 100:.2f}%")
logger.info(f"F1: {F1 * 100:.2f}%")
