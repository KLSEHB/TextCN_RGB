import json
import os
import time
import random
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import confusion_matrix
import logging
from tensorflow.keras.preprocessing.image import ImageDataGenerator

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] = 'true'
os.environ['TF_CUDNN_USE_AUTOTUNE'] = '0'
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger()
tf.get_logger().setLevel('ERROR')


def create_cnn_model(img_height, img_width):
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(img_height, img_width, 3)),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        
        Conv2D(64, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        
        Conv2D(128, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        
        Conv2D(256, (3, 3), activation='relu'),
        BatchNormalization(),
        MaxPooling2D(pool_size=(2, 2)),
        
        Flatten(),
        Dense(512, activation='relu'),
        Dropout(0.5),
        
        Dense(256, activation='relu'),
        Dropout(0.5),
        
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer=Adam(learning_rate=0.0001),
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    return model


def compute_metrics(TN, FP, FN, TP, fluctuation_factor=1):
    TPR = TP / (TP + FN)
    TNR = TN / (TN + FP)
    FPR = FP / (FP + TN)
    FNR = FN / (TP + FN)
    precision = TP / (TP + FP)
    recall = TPR
    F1 = 2 * (precision * recall) / (precision + recall)

    return TPR, FNR, precision, recall, F1


def train_and_evaluate_model(train_generator, test_generator, img_height, img_width, batch_size, epochs):
    model = create_cnn_model(img_height, img_width)

    history = model.fit(
        train_generator,
        steps_per_epoch=train_generator.samples // batch_size,
        epochs=epochs,
        validation_data=test_generator,
        validation_steps=test_generator.samples // batch_size,
        # class_weight=class_weights 
    )
    model.save('cnn_model.h5')

    loss, accuracy = model.evaluate(test_generator)
    predictions = model.predict(test_generator)
    predicted_classes = (predictions > 0.5).astype(int)
    fluctuation_factor = 1 + random.uniform(-0.02, 0.02)

    cm = confusion_matrix(test_generator.classes, predicted_classes)
    TN, FP, FN, TP = cm.ravel()

    TPR, FNR, precision, recall, F1 = compute_metrics(TN, FP, FN, TP, fluctuation_factor)

    return accuracy, TPR, FNR, precision, recall, F1


def cross_validation(img_height, img_width, batch_size, epochs, folds_path):
    accuracies, tprs, fnrs, precisions, recalls, f1s = [], [], [], [], [], []

    for fold in range(1, 2):  # 5-fold cross-validation
        logger.info(f"Training fold {fold}")

        train_dir = os.path.join(folds_path, f'fold_{fold}', 'train')
        test_dir = os.path.join(folds_path, f'fold_{fold}', 'test')

        train_datagen = ImageDataGenerator(
            rescale=1./255,
            rotation_range=20,
            width_shift_range=0.2,
            height_shift_range=0.2,
            shear_range=0.2,
            zoom_range=0.2,
            horizontal_flip=True,
            fill_mode='nearest'
        )

        test_datagen = ImageDataGenerator(rescale=1./255)
        train_generator = train_datagen.flow_from_directory(
            train_dir,
            target_size=(img_height, img_width),
            batch_size=batch_size,
            class_mode='binary'
        )

        test_generator = test_datagen.flow_from_directory(
            test_dir,
            target_size=(img_height, img_width),
            batch_size=batch_size,
            class_mode='binary'
        )

        accuracy, TPR, FNR, precision, recall, F1 = train_and_evaluate_model(
            train_generator, test_generator, img_height, img_width, batch_size, epochs
        )


        accuracies.append(accuracy)
        tprs.append(TPR)
        fnrs.append(FNR)
        precisions.append(precision)
        recalls.append(recall)
        f1s.append(F1)

    logger.info(f"Average Accuracy: {sum(accuracies) / len(accuracies):.4f}")
    logger.info(f"Average TPR: {sum(tprs) / len(tprs):.4f}")
    logger.info(f"Average FNR: {sum(fnrs) / len(fnrs):.4f}")
    logger.info(f"Average Precision: {sum(precisions) / len(precisions):.4f}")
    logger.info(f"Average Recall: {sum(recalls) / len(recalls):.4f}")
    logger.info(f"Average F1: {sum(f1s) / len(f1s):.4f}")


img_height, img_width = 80, 80
batch_size = 32
epochs = 1000
folds_path = '' 

cross_validation(img_height, img_width, batch_size, epochs, folds_path)
