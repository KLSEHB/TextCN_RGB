import os
import shutil
from sklearn.model_selection import KFold
import numpy as np


vul_folder = "" 
no_vul_folder = "" 
output_folder = "" 

os.makedirs(output_folder, exist_ok=True)
vul_images = [os.path.join(vul_folder, img) for img in os.listdir(vul_folder) if img.endswith('.jpg')]
no_vul_images = [os.path.join(no_vul_folder, img) for img in os.listdir(no_vul_folder) if img.endswith('.jpg')]


kf_vul = KFold(n_splits=5, shuffle=True, random_state=42)
kf_no_vul = KFold(n_splits=5, shuffle=True, random_state=42)


for fold, ((vul_train_index, vul_test_index), (no_vul_train_index, no_vul_test_index)) in enumerate(zip(kf_vul.split(vul_images), kf_no_vul.split(no_vul_images))):
    fold_folder = os.path.join(output_folder, f'fold_{fold + 1}')
    train_folder = os.path.join(fold_folder, 'train')
    test_folder = os.path.join(fold_folder, 'test')
    

    os.makedirs(os.path.join(train_folder, 'Vul'), exist_ok=True)
    os.makedirs(os.path.join(test_folder, 'Vul'), exist_ok=True)
    os.makedirs(os.path.join(train_folder, 'No-Vul'), exist_ok=True)
    os.makedirs(os.path.join(test_folder, 'No-Vul'), exist_ok=True)
    

    vul_train, vul_test = np.array(vul_images)[vul_train_index], np.array(vul_images)[vul_test_index]
    no_vul_train, no_vul_test = np.array(no_vul_images)[no_vul_train_index], np.array(no_vul_images)[no_vul_test_index]
    

    for img in vul_train:
        shutil.copyfile(img, os.path.join(train_folder, 'Vul', os.path.basename(img)))
    for img in vul_test:
        shutil.copyfile(img, os.path.join(test_folder, 'Vul', os.path.basename(img)))
    

    for img in no_vul_train:
        shutil.copyfile(img, os.path.join(train_folder, 'No-Vul', os.path.basename(img)))
    for img in no_vul_test:
        shutil.copyfile(img, os.path.join(test_folder, 'No-Vul', os.path.basename(img)))

    print(f"Fold {fold + 1} completed.")
