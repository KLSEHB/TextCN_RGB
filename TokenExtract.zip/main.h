#pragma once

#include <iostream>
#include <string.h>
#include <Windows.h>

#include "file.h"
#include "func.h"