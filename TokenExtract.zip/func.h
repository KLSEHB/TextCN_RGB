#pragma once

namespace func
{
	extern void** pCode;

	extern void** pOutputBuffer;

	extern int OutputBufferNum;

	int ReadIntermediateFile(const char* FilePath);

	int WriteTokenFile(const char* FilePath, char* Code);

	int ProcessIntermediateFile(const char* InputFilePath, const char* OutputFilePath);

	int ProcessIntermediateFileNew(const char* InputFilePath, const char* OutputFilePath);

	int CheckNamableCharacter(char* target);

	int DivisionCodeByLineFeed(char* Code, int* index, char* SubCode);

	int InsertElement(char* Code);
}