#include "main.h"

void** func::pCode;
void** func::pOutputBuffer;
int func::OutputBufferNum = 0;

int main(int argc, char* argv[])
{
	char InputFilePath[100];
	char TokenFilePath[100];
	char 

	func::pCode = new void*;
	func::pOutputBuffer = new void* [1000];
	for (int i = 0; i < 1000; i++)
	{
		(func::pOutputBuffer)[i] = malloc(150);
		memset((func::pOutputBuffer)[i], 0x0, 150);
	}
	*(func::pCode) = (char*)malloc(50000000);
	memset(*func::pCode, 0x0, 50000000);
	memset(InputFilePath, 0x0, 100);
	memset(TokenFilePath, 0x0, 100);

#ifdef _DEBUG
	strcpy(InputFilePath, "G:\\c\\yan\\CodeTranslate\\x64\\Debug\\9.txt");
	strcpy(TokenFilePath, "G:\\c\\yan\\CodeTranslate\\x64\\Debug\\11.txt");
#else
	if (argc != 3)
	{
		std::cout << argc << std::endl;
		std::cout << "xxx.exe InputFilePath TokenFilePath\n";
		return 0;
	}
	strcpy(InputFilePath, argv[1]);
	strcpy(TokenFilePath, argv[2]);
#endif //DEBUG

	//func::ProcessIntermediateFile(InputFilePath, TokenFilePath);
	func::ProcessIntermediateFileNew(InputFilePath, TokenFilePath);

	for (int i = 0; i < 1000; i++)
	{
		free((func::pOutputBuffer)[i]);
	}
	delete[] func::pOutputBuffer;
	free(*func::pCode);
	delete func::pCode;

	getchar();

	return 0;
}