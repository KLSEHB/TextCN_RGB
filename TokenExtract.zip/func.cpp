#include "main.h"

namespace func
{
	int ReadIntermediateFile(const char* FilePath)
	{
		file::readOneFile(FilePath, pCode);

		return 1;
	}

	int WriteTokenFile(const char* FilePath, char* Code)
	{
		file::OutPutToFile(FilePath, Code);

		return 1;
	}

	int ProcessIntermediateFile(const char* InputFilePath, const char* OutputFilePath)
	{
		int tempIndex = 0;
		int tempIndex1 = 0;
		int tempReturn = 0;
		char** tempOutputBuffer;
		bool bBlock = false;
		char tempSubCode[200];
		char tempSubCode1[100];
		char tempSubCode2[200];
	
		tempOutputBuffer = new char*;
		*tempOutputBuffer = new char[10000];

		ReadIntermediateFile(InputFilePath);

		while ((*(char**)pCode)[tempIndex] != 0x0)
		{
			tempReturn = DivisionCodeByLineFeed(*(char**)pCode, &tempIndex, tempSubCode);

			///////////////////�ⲿ���ǹ̶���ʽ����
			if (tempSubCode[0] == '-')
			{
				bBlock = true;
				tempIndex = tempIndex + tempReturn + 2;
				continue;
			}
			if (tempReturn == 0)
			{
				bBlock = false;
			}
			/////////////////////////////
			
			if (bBlock)
			{
				for (int i = 0; i < tempReturn; i++)
				{
					if (CheckNamableCharacter(&(tempSubCode[i])))
					{
						tempSubCode1[tempIndex1++] = tempSubCode[i];
					}
					else
					{
						tempSubCode1[tempIndex1] = 0x0;
						
						if (tempIndex1 != 0)
						{
							InsertElement(tempSubCode1);
							tempIndex1 = 0;
						}
						
						tempSubCode1[0] = tempSubCode[i];
						tempSubCode1[1] = 0x0;
						InsertElement(tempSubCode1);
					}
				}
			}

			tempIndex = tempIndex + tempReturn + 2;
		}

		for (int i = 0; i < OutputBufferNum; i++)
		{
			strcpy(tempSubCode2, ((char**)pOutputBuffer)[i]);
			strcat(tempSubCode2, "\r\n");
			WriteTokenFile(OutputFilePath, tempSubCode2);
		}

		//WriteTokenFile(OutputFilePath, (void**)tempOutputBuffer);

		delete[] * tempOutputBuffer;
		delete tempOutputBuffer;

		return 1;
	}

	int ProcessIntermediateFileNew(const char* InputFilePath, const char* OutputFilePath)
	{
		int tempIndex = 0;
		int tempIndex1 = 0;
		int tempReturn = 0;
		char** tempOutputBuffer;
		bool bBlock = false;
		char tempSubCode[200];
		char tempSubCode1[100];
		char tempSubCode2[200];

		tempOutputBuffer = new char*;
		*tempOutputBuffer = new char[10000];

		ReadIntermediateFile(InputFilePath);

		while ((*(char**)pCode)[tempIndex] != 0x0)
		{
			tempReturn = DivisionCodeByLineFeed(*(char**)pCode, &tempIndex, tempSubCode);

			for (int i = 0; i < tempReturn; i++)
			{
				if (CheckNamableCharacter(&(tempSubCode[i])))
				{
					tempSubCode1[tempIndex1++] = tempSubCode[i];
				}
				else
				{
					tempSubCode1[tempIndex1] = 0x0;

					if (tempIndex1 != 0)
					{
						InsertElement(tempSubCode1);
						tempIndex1 = 0;
					}

					tempSubCode1[0] = tempSubCode[i];
					tempSubCode1[1] = 0x0;
					InsertElement(tempSubCode1);
				}
			}

			tempIndex = tempIndex + tempReturn + 2;
		}

		for (int i = 0; i < OutputBufferNum; i++)
		{
			strcpy(tempSubCode2, ((char**)pOutputBuffer)[i]);
			strcat(tempSubCode2, "\r\n");
			WriteTokenFile(OutputFilePath, tempSubCode2);
		}

		//WriteTokenFile(OutputFilePath, (void**)tempOutputBuffer);

		delete[] * tempOutputBuffer;
		delete tempOutputBuffer;

		return 1;
	}

	//����Ƿ�Ϊ��Ϊ�������ֵ��ַ�
	int CheckNamableCharacter(char* target)
	{
		if (*target == '_' || (*target >= '0' && *target <= '9') || (*target >= 'a' && *target <= 'z') || (*target >= 'A' && *target <= 'Z'))
		{
			return 1;
		}

		return 0;
	}

	int DivisionCodeByLineFeed(char* Code, int* index, char* SubCode)
	{
		int tempIndex = 0;
		while (Code[*index + tempIndex] != '\r' || Code[*index + tempIndex + 1] != '\n')
		{
			SubCode[tempIndex] = Code[*index + tempIndex++];
		}
		SubCode[tempIndex] = 0x0;

		return tempIndex;
	}

	int InsertElement(char* Code)
	{
		int tempIndex = 0;

		for (int i = 0; i < OutputBufferNum; i++)
		{
			if (strcmp(((char**)pOutputBuffer)[i], Code) == 0)
			{
				return 0;
			}
		}
		strcpy(((char**)pOutputBuffer)[OutputBufferNum++], Code);

		return 1;
	}
}